--
-- PostgreSQL database dump
--

\restrict NoIaK7aG6wvXLmpraKndapXIiNl29tN5yTfmrVtDDERn77denbZPp79v7tjU13H

-- Dumped from database version 16.14 (b253d90)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    action character varying(50) NOT NULL,
    entity_type character varying(50),
    entity_id character varying(36),
    description text,
    performed_by character varying(100),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    document character varying(18),
    phone character varying(20) NOT NULL,
    email character varying(200),
    address_street character varying(200),
    address_number character varying(20),
    address_complement character varying(100),
    address_neighborhood character varying(100),
    address_city character varying(100),
    address_state character varying(2),
    address_zip character varying(8),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: company_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    document character varying(18),
    phone character varying(20),
    phone2 character varying(20),
    email character varying(200),
    address_street character varying(200),
    address_number character varying(20),
    address_complement character varying(100),
    address_neighborhood character varying(100),
    address_city character varying(100),
    address_state character varying(2),
    address_zip character varying(8),
    logo_url text,
    header_text text,
    footer_text text,
    default_warranty_days integer DEFAULT 90,
    admin_pin character varying(10),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: equipment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    type character varying(100) NOT NULL,
    brand character varying(100) NOT NULL,
    model character varying(100) NOT NULL,
    serial_number character varying(100),
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: financial_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    type character varying(20) NOT NULL,
    description text NOT NULL,
    amount numeric(10,2) NOT NULL,
    due_date date,
    paid_date date,
    status character varying(20) DEFAULT 'pendente'::character varying NOT NULL,
    service_order_id uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: knex_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


--
-- Name: knex_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: knex_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_id_seq OWNED BY public.knex_migrations.id;


--
-- Name: knex_migrations_lock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_lock_index_seq OWNED BY public.knex_migrations_lock.index;


--
-- Name: service_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_order_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_order_id uuid NOT NULL,
    quantity numeric(10,2) DEFAULT '1'::numeric NOT NULL,
    description text NOT NULL,
    unit_price numeric(10,2) DEFAULT '0'::numeric NOT NULL
);


--
-- Name: service_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    order_number integer NOT NULL,
    client_id uuid NOT NULL,
    equipment_id uuid NOT NULL,
    technician_id uuid NOT NULL,
    status character varying(30) DEFAULT 'aberta'::character varying NOT NULL,
    reported_defect text,
    diagnosis text,
    notes text,
    payment_method character varying(50),
    warranty_days integer DEFAULT 90,
    entry_date date,
    completion_date date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: technicians; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.technicians (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    phone character varying(20) NOT NULL,
    specialty character varying(200),
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(50) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    modules jsonb DEFAULT '["os"]'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    name character varying(200) NOT NULL,
    email character varying(200) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) DEFAULT 'tenant_user'::character varying NOT NULL,
    active boolean DEFAULT true NOT NULL,
    last_login timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: knex_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations ALTER COLUMN id SET DEFAULT nextval('public.knex_migrations_id_seq'::regclass);


--
-- Name: knex_migrations_lock index; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.knex_migrations_lock_index_seq'::regclass);


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, tenant_id, action, entity_type, entity_id, description, performed_by, created_at) FROM stdin;
ed1865f7-8331-4583-8e4b-98222cf62b1e	\N	delete_os	service_order	6b655868-07db-4bda-8325-3c84d2c7b9f7	OS #0003 - Cliente: Sandra Costa	admin	2026-07-24 00:24:15.856+00
3d79b209-9b8e-4020-8c72-83c8d825b812	\N	delete_client	client	e348105d-1a6c-4b34-911c-ef8b74baf29a	Cliente: José Oliveira	admin	2026-07-24 00:24:25.688+00
582e5c95-8262-4cba-84e4-07322316a7eb	\N	delete_technician	technician	a4661e6f-1a20-4f0a-89af-78101f967f15	Técnico: Felipe	admin	2026-07-24 00:27:09.551+00
6e15171d-4c71-4c46-a482-fe57ce332c76	\N	delete_client	client	7fafefb7-0a24-40a2-b82b-75cc9679e71f	Cliente: Carlos Mendes	admin	2026-07-24 00:27:26.467+00
d1344eab-3711-4cf5-bd60-9643966b61c9	\N	delete_technician	technician	0a2b60f8-f270-4752-a8ca-9faffd6448fb	Técnico: Junior	admin	2026-07-24 16:08:24.902+00
074b1915-1e37-4e36-bf8e-2274104649a8	\N	delete_technician	technician	2257be26-1899-4625-aa5b-9ef0bfad2821	Técnico: Marcos	admin	2026-07-24 16:08:29.347+00
277d4f17-f4e5-4bd9-8d9b-2851a6e33c55	\N	delete_os	service_order	c7186ef6-34d8-499b-add3-b305f498eac6	OS #0002 - Cliente: José Oliveira	admin	2026-07-24 16:08:46.109+00
278f9600-3181-4399-a948-70ae40e2bf07	\N	delete_os	service_order	8371ae12-4971-4b81-9129-6943cec3572a	OS #0001 - Cliente: José Oliveira	admin	2026-07-24 16:08:49.671+00
6d5446f5-fd69-4dd6-8bfb-0cd44fbb3515	\N	delete_client	client	491590c4-3257-4ba1-8d68-52b2f139542f	Cliente: Sandra Costa	admin	2026-07-24 16:08:55.652+00
1aff2e18-4289-42d6-b5da-eb5b623ada20	\N	delete_equipment	equipment	2c76dcad-dfaa-4f7b-8c8e-0d0043c23700	Equipamento: Parafusadeira DeWalt DCD777 - Cliente: Sandra Costa	admin	2026-07-24 16:09:04.534+00
8d112bfa-cb68-4de0-8b98-b142cf7d067a	\N	delete_equipment	equipment	1c66cf0e-24c6-4b42-8558-d192aa718d2e	Equipamento: Furadeira Bosch GSB 550 RE - Cliente: José Oliveira	admin	2026-07-24 16:09:08.141+00
e32ecad1-70b8-477d-b1bd-a1f9b9e8c0db	\N	delete_equipment	equipment	b1c97b68-5084-4aec-9a40-ff5d19b168ac	Equipamento: Serra Mármore Makita 4100NH3 - Cliente: José Oliveira	admin	2026-07-24 16:09:11.548+00
193b405b-184e-44d5-9450-06c9a5d36ee9	\N	delete_os	service_order	04f3b564-f2f3-42ea-9073-73cc8c828b74	OS #0000 - Cliente: N/A	admin	2026-07-24 18:56:37.999+00
6bf85a9c-49ea-407e-8dc2-9fc15c92a02e	\N	delete_os	service_order	4285f73a-4ec2-4144-97d7-0067c4e773b7	OS #0000 - Cliente: N/A	admin	2026-07-27 14:51:43.05+00
cf8765df-5fc4-4fac-967e-9727ffbdcf8c	\N	delete_os	service_order	babe140f-a4f8-45e1-a9e6-50d8fe94624c	OS #0013 - Cliente: Jurandi da Silva	admin	2026-07-27 15:49:14.031+00
954fcf58-8283-48f4-8fbd-a83d57567c8f	\N	delete_client	client	7ccccbf4-cd13-420c-8cea-f3d18a2bb956	Cliente: Jurandi da Silva	admin	2026-07-27 15:50:18.121+00
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clients (id, tenant_id, name, document, phone, email, address_street, address_number, address_complement, address_neighborhood, address_city, address_state, address_zip, created_at, updated_at, deleted_at) FROM stdin;
4503d407-55f8-471f-a9f9-52b2e04cf7d6	c8659485-b234-4723-9681-1e71ee94ac3b	Carlos Mendes	52998224725	21991001001	\N	\N	\N	\N	\N	Rio de Janeiro	RJ	\N	2026-07-23 23:40:47.693623+00	2026-07-23 23:40:47.693623+00	\N
22dda795-7f60-44b8-b405-c0f9565d4eef	c8659485-b234-4723-9681-1e71ee94ac3b	Luciana Ferreira	83456789012	21992002002	\N	\N	\N	\N	\N	Rio de Janeiro	RJ	\N	2026-07-23 23:40:47.857645+00	2026-07-23 23:40:47.857645+00	\N
e2b48e4a-89dc-4336-af04-a6344e15a3ba	c8659485-b234-4723-9681-1e71ee94ac3b	Rafael Souza	71234567890	21993003003	\N	\N	\N	\N	\N	Rio de Janeiro	RJ	\N	2026-07-23 23:40:48.017508+00	2026-07-23 23:40:48.017508+00	\N
a8cbd12f-36a7-45fd-b948-238e5f175c4c	c8659485-b234-4723-9681-1e71ee94ac3b	Luciana Ferreira	55566677788	21992002002	\N	\N	\N	\N	\N	Rio de Janeiro	RJ	\N	2026-07-23 23:41:41.96689+00	2026-07-23 23:41:41.96689+00	\N
28bd5954-4c39-41fc-89d1-5b3443c3a030	c8659485-b234-4723-9681-1e71ee94ac3b	Rafael Souza	99988877700	21993003003	\N	\N	\N	\N	\N	Rio de Janeiro	RJ	\N	2026-07-23 23:41:42.122589+00	2026-07-23 23:41:42.122589+00	\N
e348105d-1a6c-4b34-911c-ef8b74baf29a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	José Oliveira	12312312300	21991110001	\N	\N	\N	\N	\N	Teresópolis	RJ	\N	2026-07-23 23:59:29.91214+00	2026-07-23 23:59:29.91214+00	2026-07-24 00:24:26.029+00
7fafefb7-0a24-40a2-b82b-75cc9679e71f	c8659485-b234-4723-9681-1e71ee94ac3b	Carlos Mendes	11122233344	21991001001	\N	\N	\N	\N	\N	Rio de Janeiro	RJ	\N	2026-07-23 23:41:41.808983+00	2026-07-23 23:41:41.808983+00	2026-07-24 00:27:26.821+00
491590c4-3257-4ba1-8d68-52b2f139542f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Sandra Costa	45645645600	21992220002	\N	\N	\N	\N	\N	Teresópolis	RJ	\N	2026-07-23 23:59:30.231719+00	2026-07-23 23:59:30.231719+00	2026-07-24 16:08:55.971+00
5b1cc305-7edb-4b0c-b608-0d64b765e849	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Ronaldo Nascimento 	00000000000	21976132251									2026-07-24 17:45:45.199093+00	2026-07-24 17:45:45.199093+00	\N
eb0c392b-6a24-4ec4-84a0-d0729c7e719b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Ricardo Vieira 		21997077868		\N	\N	\N	\N	\N	\N	\N	2026-07-24 17:51:05.081969+00	2026-07-24 17:51:05.081969+00	\N
656caf20-8394-4d02-9da4-ae91a25072d2	c8659485-b234-4723-9681-1e71ee94ac3b	Charles Daflon		21974303932									2026-07-27 14:06:52.618245+00	2026-07-27 14:06:52.618245+00	\N
856ef1e0-8011-445f-b6a3-97ce79ff088d	c8659485-b234-4723-9681-1e71ee94ac3b	charles		21974303932									2026-07-27 14:07:11.327521+00	2026-07-27 14:07:11.327521+00	\N
02c08106-b823-413c-99dc-3018afd8c70c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Celmo Santos 		21973473671									2026-07-27 14:44:24.173503+00	2026-07-27 14:44:24.173503+00	\N
43cb493c-25ec-4657-8393-f937e6576890	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Bruno Garagem 21		21979603725		\N	\N	\N	\N	\N	\N	\N	2026-07-27 14:54:03.93193+00	2026-07-27 14:54:03.93193+00	\N
72833910-7f5b-4141-8133-dda7e8ff9e12	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Luiz Carlos 		21992816115		\N	\N	\N	\N	\N	\N	\N	2026-07-27 15:31:19.107207+00	2026-07-27 15:31:19.107207+00	\N
4235c814-b03a-42d7-b57d-4589f01f8c1d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	welington charles		21974232600		\N	\N	\N	\N	\N	\N	\N	2026-07-27 15:39:17.11714+00	2026-07-27 15:39:17.11714+00	\N
7ccccbf4-cd13-420c-8cea-f3d18a2bb956	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Jurandi da Silva		21969211701		\N	\N	\N	\N	\N	\N	\N	2026-07-27 15:46:34.059901+00	2026-07-27 15:46:34.059901+00	2026-07-27 15:50:18.469+00
f342957a-54f7-4d46-9409-6f3e1d503b4c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Pilar Seis (Paulo Ricardo)	06940763000107	21987214190		\N	\N	\N	\N	\N	\N	\N	2026-07-27 15:56:35.368902+00	2026-07-27 15:56:35.368902+00	\N
ac66c053-d055-497a-8dbd-28d290142c0d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Visoma (Darci)		21994934718		\N	\N	\N	\N	\N	\N	\N	2026-07-27 17:26:35.387329+00	2026-07-27 17:26:35.387329+00	\N
\.


--
-- Data for Name: company_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_settings (id, tenant_id, name, document, phone, phone2, email, address_street, address_number, address_complement, address_neighborhood, address_city, address_state, address_zip, logo_url, header_text, footer_text, default_warranty_days, admin_pin, created_at, updated_at) FROM stdin;
b41f075a-4fd1-42b8-8dc1-3d457f825972	c8659485-b234-4723-9681-1e71ee94ac3b	Empresa Master				\N	\N	\N	\N	\N	\N	\N		\N	\N	\N	90	\N	2026-07-23 18:01:31.526+00	2026-07-23 23:23:00.081+00
b5a64b2c-2008-47f9-92b9-5edd45b2125d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Eletrotécnica São Miguel	50115416000123	21975473524	21968161250	feliperebello6@gmail.com	São Francisco 	Lote 02		Nossa Senhora de Fátima	TERESÓPOLIS	RJ	25957152	blob:https://web.whatsapp.com/53a332ad-9739-4f81-83f1-0a94c6422922	Conserto de ferramentas elétricas em geral 	Mediante a Realização ou não do serviço, a máquina deverá ser retirada no prazo de 180 dias conforme a PL 2545/22. Contados a partir da realização ou não do serviço.	90	0000	2026-07-23 23:32:28.948+00	2026-07-27 17:55:13.173+00
\.


--
-- Data for Name: equipment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.equipment (id, tenant_id, client_id, type, brand, model, serial_number, notes, created_at, updated_at, deleted_at) FROM stdin;
980fc8e7-a3ba-455e-bfd9-669d5e0b097a	c8659485-b234-4723-9681-1e71ee94ac3b	4503d407-55f8-471f-a9f9-52b2e04cf7d6	Serra Mármore	Makita	4100NH	SN-17018	\N	2026-07-23 23:40:48.176011+00	2026-07-23 23:40:48.176011+00	\N
aea36194-c9cc-4e4d-ac28-141549d1849b	c8659485-b234-4723-9681-1e71ee94ac3b	4503d407-55f8-471f-a9f9-52b2e04cf7d6	Furadeira	Bosch	GSB 13 RE	SN-23969	\N	2026-07-23 23:40:48.343753+00	2026-07-23 23:40:48.343753+00	\N
65dd1106-3ddd-4882-aab4-f2ca485c21da	c8659485-b234-4723-9681-1e71ee94ac3b	22dda795-7f60-44b8-b405-c0f9565d4eef	Parafusadeira	DeWalt	DCD796	SN-32532	\N	2026-07-23 23:40:48.503433+00	2026-07-23 23:40:48.503433+00	\N
f1329c35-d35e-4bd5-85e0-cd20d687a563	c8659485-b234-4723-9681-1e71ee94ac3b	22dda795-7f60-44b8-b405-c0f9565d4eef	Esmerilhadeira	Makita	GA4530	SN-48294	\N	2026-07-23 23:40:48.661712+00	2026-07-23 23:40:48.661712+00	\N
1dbd502c-6aa8-4715-9a89-8ce4e83eb5be	c8659485-b234-4723-9681-1e71ee94ac3b	e2b48e4a-89dc-4336-af04-a6344e15a3ba	Serra Tico-Tico	Bosch	GST 650	SN-59253	\N	2026-07-23 23:40:48.819363+00	2026-07-23 23:40:48.819363+00	\N
7a636607-6d19-4110-aa9c-7fa4bb521924	c8659485-b234-4723-9681-1e71ee94ac3b	e2b48e4a-89dc-4336-af04-a6344e15a3ba	Lixadeira	Black+Decker	QS800	SN-63844	\N	2026-07-23 23:40:48.977591+00	2026-07-23 23:40:48.977591+00	\N
3571f89b-39ed-4e4f-bd86-6922492707f6	c8659485-b234-4723-9681-1e71ee94ac3b	7fafefb7-0a24-40a2-b82b-75cc9679e71f	Serra Mármore	Makita	4100NH	SN-18203	\N	2026-07-23 23:41:42.282939+00	2026-07-23 23:41:42.282939+00	\N
cbf10a4f-b031-49e5-9fd4-1b793cf3b05d	c8659485-b234-4723-9681-1e71ee94ac3b	7fafefb7-0a24-40a2-b82b-75cc9679e71f	Furadeira	Bosch	GSB 13 RE	SN-25278	\N	2026-07-23 23:41:42.442849+00	2026-07-23 23:41:42.442849+00	\N
b3ea49d3-208a-4a27-ba1e-d64b866c468a	c8659485-b234-4723-9681-1e71ee94ac3b	a8cbd12f-36a7-45fd-b948-238e5f175c4c	Parafusadeira	DeWalt	DCD796	SN-31446	\N	2026-07-23 23:41:42.605068+00	2026-07-23 23:41:42.605068+00	\N
16379a78-19e1-491f-8f0b-591cfad270aa	c8659485-b234-4723-9681-1e71ee94ac3b	a8cbd12f-36a7-45fd-b948-238e5f175c4c	Esmerilhadeira	Makita	GA4530	SN-46502	\N	2026-07-23 23:41:42.765056+00	2026-07-23 23:41:42.765056+00	\N
0d6203d3-49ee-440e-b0ab-90a6de66ca6e	c8659485-b234-4723-9681-1e71ee94ac3b	28bd5954-4c39-41fc-89d1-5b3443c3a030	Serra Tico-Tico	Bosch	GST 650	SN-53635	\N	2026-07-23 23:41:42.924976+00	2026-07-23 23:41:42.924976+00	\N
f1539efb-cb2a-4462-9018-d331a2a464c9	c8659485-b234-4723-9681-1e71ee94ac3b	28bd5954-4c39-41fc-89d1-5b3443c3a030	Lixadeira	Black+Decker	QS800	SN-69735	\N	2026-07-23 23:41:43.079804+00	2026-07-23 23:41:43.079804+00	\N
b71fa710-bb85-4439-976f-2f4bef2bea1d	c8659485-b234-4723-9681-1e71ee94ac3b	7fafefb7-0a24-40a2-b82b-75cc9679e71f	Serra Mármore	Makita	4100NH	SN-16551	\N	2026-07-23 23:48:08.784659+00	2026-07-23 23:48:08.784659+00	\N
7bc893f7-9ca6-47c9-bd43-644165d7bc44	c8659485-b234-4723-9681-1e71ee94ac3b	7fafefb7-0a24-40a2-b82b-75cc9679e71f	Furadeira	Bosch	GSB 13 RE	SN-23869	\N	2026-07-23 23:48:08.948546+00	2026-07-23 23:48:08.948546+00	\N
cf0b791a-f141-4395-8563-ccf2c7aad200	c8659485-b234-4723-9681-1e71ee94ac3b	a8cbd12f-36a7-45fd-b948-238e5f175c4c	Parafusadeira	DeWalt	DCD796	SN-33456	\N	2026-07-23 23:48:09.108581+00	2026-07-23 23:48:09.108581+00	\N
87b8fce7-ae7f-4c3c-a0b9-85d7c094402e	c8659485-b234-4723-9681-1e71ee94ac3b	a8cbd12f-36a7-45fd-b948-238e5f175c4c	Esmerilhadeira	Makita	GA4530	SN-43603	\N	2026-07-23 23:48:09.270752+00	2026-07-23 23:48:09.270752+00	\N
373cee8c-1dc2-4010-bdf4-133f29c28953	c8659485-b234-4723-9681-1e71ee94ac3b	28bd5954-4c39-41fc-89d1-5b3443c3a030	Serra Tico-Tico	Bosch	GST 650	SN-57399	\N	2026-07-23 23:48:09.430942+00	2026-07-23 23:48:09.430942+00	\N
06dd2dc3-04f2-471c-bf0c-cad9ca81a7a4	c8659485-b234-4723-9681-1e71ee94ac3b	28bd5954-4c39-41fc-89d1-5b3443c3a030	Lixadeira	Black+Decker	QS800	SN-61141	\N	2026-07-23 23:48:09.590543+00	2026-07-23 23:48:09.590543+00	\N
2c76dcad-dfaa-4f7b-8c8e-0d0043c23700	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	491590c4-3257-4ba1-8d68-52b2f139542f	Parafusadeira	DeWalt	DCD777	ESM-3	\N	2026-07-23 23:59:30.706769+00	2026-07-23 23:59:30.706769+00	2026-07-24 16:09:04.857+00
1c66cf0e-24c6-4b42-8558-d192aa718d2e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	e348105d-1a6c-4b34-911c-ef8b74baf29a	Furadeira	Bosch	GSB 550 RE	ESM-2	\N	2026-07-23 23:59:30.552322+00	2026-07-23 23:59:30.552322+00	2026-07-24 16:09:08.51+00
b1c97b68-5084-4aec-9a40-ff5d19b168ac	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	e348105d-1a6c-4b34-911c-ef8b74baf29a	Serra Mármore	Makita	4100NH3	ESM-1	\N	2026-07-23 23:59:30.387113+00	2026-07-23 23:59:30.387113+00	2026-07-24 16:09:11.885+00
f90c8596-5b63-405f-9d59-951ebd4af451	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	5b1cc305-7edb-4b0c-b608-0d64b765e849	Serra Mármore 	Makita	4100NH3			2026-07-24 17:46:30.088097+00	2026-07-24 17:46:30.088097+00	\N
bf88898b-f512-4d48-a1e9-78daa7fde64f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	eb0c392b-6a24-4ec4-84a0-d0729c7e719b	Motocompressor	Schulz	Air Plus 8,5		Versão 1	2026-07-24 17:52:13.02503+00	2026-07-24 17:52:13.02503+00	\N
daebcb85-c3d9-4462-a966-1a47aa20e3f3	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	02c08106-b823-413c-99dc-3018afd8c70c	Serra circular 	Bosch 	GKS130			2026-07-27 14:45:28.388696+00	2026-07-27 14:45:28.388696+00	\N
0a4066df-c59e-4783-8e9d-9fd085f7b72f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	02c08106-b823-413c-99dc-3018afd8c70c	Serra Mármore 	Makita	4100NH3			2026-07-27 14:50:54.094231+00	2026-07-27 14:50:54.094231+00	\N
e582d93f-39e8-477e-9e7a-43817b7804cf	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	02c08106-b823-413c-99dc-3018afd8c70c	Serra Mármore 	Makita	4100NH3			2026-07-27 14:51:16.439502+00	2026-07-27 14:51:16.439502+00	\N
030da74c-3830-4b7f-9fc8-5676785dd808	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	43cb493c-25ec-4657-8393-f937e6576890	Lava-Jato	Karcher 	HD585		Com mangueira 	2026-07-27 14:54:32.858703+00	2026-07-27 14:54:32.858703+00	\N
c29a10bf-79e7-47a0-a10f-8487d7635985	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	72833910-7f5b-4141-8133-dda7e8ff9e12	Lixadeira 	Makita 	SA7000C			2026-07-27 15:31:41.660881+00	2026-07-27 15:31:41.660881+00	\N
7fe8cb25-6427-4201-af7f-4e1666731a47	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	72833910-7f5b-4141-8133-dda7e8ff9e12	Lixadeira 	THAF	000			2026-07-27 15:34:15.76973+00	2026-07-27 15:34:15.76973+00	\N
a54b2776-1afa-4a22-95b4-bc083be6a90b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	4235c814-b03a-42d7-b57d-4589f01f8c1d	Soprador	NSFG	41CC			2026-07-27 15:41:16.796321+00	2026-07-27 15:41:16.796321+00	\N
c62687ec-7631-4c88-b037-beb12f95a4ef	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	7ccccbf4-cd13-420c-8cea-f3d18a2bb956	roçadeira 	Toyama	TBC43X			2026-07-27 15:47:09.519894+00	2026-07-27 15:47:09.519894+00	\N
8bb9f9a7-2b38-4c6d-8dd3-7fcfdc0d9a93	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	f342957a-54f7-4d46-9409-6f3e1d503b4c	Betoneira 	Menegotti	400L			2026-07-27 15:57:15.480322+00	2026-07-27 15:57:15.480322+00	\N
989f6383-78c6-4dac-86c6-f737c0885e4a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	ac66c053-d055-497a-8dbd-28d290142c0d	Lixadeira	Rammer	RTS1			2026-07-27 17:28:28.430806+00	2026-07-27 17:28:28.430806+00	\N
\.


--
-- Data for Name: financial_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_entries (id, tenant_id, type, description, amount, due_date, paid_date, status, service_order_id, created_at, updated_at) FROM stdin;
177b20d1-c572-4c09-a760-c344d954fe51	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0002 - José Oliveira	148.00	2026-07-24	\N	pendente	c7186ef6-34d8-499b-add3-b305f498eac6	2026-07-24 13:43:02.171238+00	2026-07-24 13:43:02.171238+00
3b6390ab-a4a5-4f31-8cbb-eee2997c2cd8	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0001 - José Oliveira	162.00	2026-07-24	\N	pendente	8371ae12-4971-4b81-9129-6943cec3572a	2026-07-24 13:43:07.602097+00	2026-07-24 13:43:07.602097+00
10a4b7e3-aa4d-418f-8074-ac95a3ea7e3f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0007 - Celmo Santos 	100.00	2026-07-27	\N	pendente	d67bada3-0998-4f0c-a0c7-39a97bb4d8c9	2026-07-27 14:49:31.32429+00	2026-07-27 14:49:31.32429+00
e593fa76-b2fe-482e-8e70-82b3dd9787c7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0009 - Bruno Garagem 21	239.99	2026-07-27	\N	pendente	c6f2c468-9920-4840-9879-f4537c438cf4	2026-07-27 14:56:17.344799+00	2026-07-27 14:56:17.344799+00
06df6517-e535-4ce4-bfae-b7c5d6903338	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0012 - welington charles	290.00	2026-07-27	\N	pendente	9f9aeb41-0fbf-47aa-988b-e5f0b09d6a49	2026-07-27 15:45:09.996625+00	2026-07-27 15:45:09.996625+00
\.


--
-- Data for Name: knex_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations (id, name, batch, migration_time) FROM stdin;
1	20260722_001_initial_saas_schema.js	1	2026-07-23 16:31:44.354+00
2	20260727_001_make_document_optional.js	2	2026-07-27 13:52:27.397+00
\.


--
-- Data for Name: knex_migrations_lock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- Data for Name: service_order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_order_items (id, service_order_id, quantity, description, unit_price) FROM stdin;
b83bfbe7-e16b-4c56-9d3e-7a12bbc759c9	3b0675d2-4894-46d3-ab98-f312937fa556	1.00	Mão de obra	80.00
c8458527-b907-4e13-91f4-dc09ea8d6fa0	3b0675d2-4894-46d3-ab98-f312937fa556	1.00	Peça de reposição	107.00
8e5807fb-c875-4743-967b-d0eee0122486	64717cae-fce7-492e-b675-f30205202ef1	1.00	Mão de obra	80.00
94346824-f36a-4387-806a-cf15fd83d3dd	64717cae-fce7-492e-b675-f30205202ef1	1.00	Peça de reposição	74.00
eb10d488-299c-4897-a874-2918b7ae1b35	ba6865d7-ec54-4bed-9239-d7ed8b06880b	1.00	Mão de obra	80.00
a79adb04-c8b1-4fdd-b463-ccbe8cd92f4a	ba6865d7-ec54-4bed-9239-d7ed8b06880b	1.00	Peça de reposição	101.00
4370b639-3085-4224-8913-cde8e6c07317	7bb62260-5f7c-4dff-98f2-363c0564caf9	1.00	Mão de obra	80.00
0d2d094d-7747-470b-b5a8-780cc2765bfe	7bb62260-5f7c-4dff-98f2-363c0564caf9	1.00	Peça de reposição	74.00
0d82c72d-8b8b-427e-8789-c2d3986560c1	9b481aa8-0ccf-437f-8968-fcdeb6aab3dc	1.00	Mão de obra	80.00
f579c1a1-414e-4095-ba09-5a015cd040ca	9b481aa8-0ccf-437f-8968-fcdeb6aab3dc	1.00	Peça de reposição	83.00
a054b6c8-715e-485f-815d-9871d5e75a12	5d0cab4a-d9db-489c-bdfc-d6f2d8f1f2e6	1.00	Mão de obra	80.00
427f64b0-a0ad-4911-940a-550283a0f852	5d0cab4a-d9db-489c-bdfc-d6f2d8f1f2e6	1.00	Peça de reposição	149.00
cb7a195d-0333-42e1-a65b-7514093a98d5	2f763d83-95c3-492a-993e-b43bce8b69aa	1.00	Mão de obra	80.00
9d4aae73-68e0-459f-905f-e0a6bd111fbd	2f763d83-95c3-492a-993e-b43bce8b69aa	1.00	Peça de reposição	82.00
a4717358-3c2e-40c3-b9e9-d19411cedf54	6c1ad83f-b31f-4ac3-bec9-fa3f4a719610	1.00	Mão de obra	80.00
d6523445-2773-4863-8016-22751cbfd998	6c1ad83f-b31f-4ac3-bec9-fa3f4a719610	1.00	Peça de reposição	103.00
594fc633-5658-4ee6-a384-930b2ccdf0db	91874eda-692b-4eaa-a111-cc0e3ea5b1b5	1.00	Mão de obra	80.00
d898a6bc-89b5-493c-969a-41ed1878fa56	91874eda-692b-4eaa-a111-cc0e3ea5b1b5	1.00	Peça de reposição	102.00
f027e5bc-8b44-4257-829c-7393eac1a18b	6238c6ad-c5d7-4448-8b68-38e8120fb10c	1.00	Mão de obra	80.00
51a8af52-a5c6-486b-939c-0474d3502da0	6238c6ad-c5d7-4448-8b68-38e8120fb10c	1.00	Peça de reposição	118.00
d2516149-2d2b-4f48-9071-bb653bb5cdea	60c0f67e-dd23-4289-af2e-58d6140c6d59	1.00	Mão de obra	80.00
2f09c7d9-90d5-404f-8d6c-c9f6cefc1adf	60c0f67e-dd23-4289-af2e-58d6140c6d59	1.00	Peça de reposição	105.00
ced9b703-49bb-40c4-92d7-8ff02474cd9c	3a054487-f443-4413-9903-2b826fd1b02d	1.00	Mão de obra	80.00
e7afc20d-3803-4214-a624-11bafb025826	3a054487-f443-4413-9903-2b826fd1b02d	1.00	Peça de reposição	123.00
52c38967-9ba4-4113-a8fe-23cff74e82e2	8371ae12-4971-4b81-9129-6943cec3572a	1.00	Mão de obra	70.00
1fb3d52c-7fe9-4938-8f45-9cac6fe0bce4	8371ae12-4971-4b81-9129-6943cec3572a	1.00	Peça	92.00
f4e66f97-49b3-4464-a351-d86da057fd49	c7186ef6-34d8-499b-add3-b305f498eac6	1.00	Mão de obra	70.00
970c0ed2-9e60-4de4-b0d8-fbf3a6ffe53c	c7186ef6-34d8-499b-add3-b305f498eac6	1.00	Peça	78.00
ed3f61a4-555e-4fa9-9a94-753212a04ef4	6b655868-07db-4bda-8325-3c84d2c7b9f7	1.00	Mão de obra	70.00
83d80820-5a53-4946-ac20-0b3362dc5ef2	6b655868-07db-4bda-8325-3c84d2c7b9f7	1.00	Peça	63.00
8f3a8228-761f-48f4-9ab3-62bb458fcddb	04f3b564-f2f3-42ea-9073-73cc8c828b74	1.00	Jogo de anéis 	50.00
4a8fb2e4-b957-472c-b086-ef863eba6510	04f3b564-f2f3-42ea-9073-73cc8c828b74	1.00	Jogo de Juntas 	30.00
c6720eba-7c08-4d96-bc64-a22ef385f15b	04f3b564-f2f3-42ea-9073-73cc8c828b74	1.00	Limpeza no prato de válvulas	0.00
7e3c6daa-6046-4c3c-bb2d-9e650e2d0d17	04f3b564-f2f3-42ea-9073-73cc8c828b74	1.00	Elemento filtrante 	30.00
fb57ceeb-7975-4187-bbfe-11b9231c952a	04f3b564-f2f3-42ea-9073-73cc8c828b74	1.00	Óleo 	20.00
66e16fa1-c7a9-4cc8-b55e-73f7420b1ead	04f3b564-f2f3-42ea-9073-73cc8c828b74	1.00	M.O	60.00
d30de170-ef62-45b7-884f-261c067f01e7	c2f35eef-18b4-482b-9260-352dc134f6d4	1.00	M.O 	30.00
78eefb11-2242-47ed-9081-6014f554dc85	b8c8ea7d-ca4e-4f71-8fc5-67bbe8f30602	1.00	Jogo de anéis 	50.00
863a874d-8f7b-44d7-be41-e95ecaa996f3	b8c8ea7d-ca4e-4f71-8fc5-67bbe8f30602	1.00	Jogo de Juntas 	30.00
04a33887-8c42-4350-b797-678d7405c571	b8c8ea7d-ca4e-4f71-8fc5-67bbe8f30602	1.00	Limpeza no prato de válvulas	0.00
2670777f-9b25-45f7-9177-60796a536003	b8c8ea7d-ca4e-4f71-8fc5-67bbe8f30602	1.00	Elemento filtrante 	30.00
7f64e767-41b9-4081-88d2-87e4da2b0ff3	b8c8ea7d-ca4e-4f71-8fc5-67bbe8f30602	1.00	Óleo 	20.00
8ec161c6-a856-4db0-a1d7-8d328f7be9b4	b8c8ea7d-ca4e-4f71-8fc5-67bbe8f30602	1.00	M.O	60.00
0e65ff81-d684-4de1-a824-333693c2314f	d67bada3-0998-4f0c-a0c7-39a97bb4d8c9	1.00	Rolamento 608	20.00
f4d4f966-f0ff-4e30-bb2e-904e2971ceed	d67bada3-0998-4f0c-a0c7-39a97bb4d8c9	1.00	Rolamento 6001	30.00
1e7f68aa-8226-467b-af9b-ed9de7ac1349	d67bada3-0998-4f0c-a0c7-39a97bb4d8c9	1.00	M.O 	50.00
b384f381-29b8-4bd8-851d-04baee3de4c5	4285f73a-4ec2-4144-97d7-0067c4e773b7	1.00	Rolamento 608	20.00
61ce93b1-0bf7-4d2a-b5c8-e1472a034168	4285f73a-4ec2-4144-97d7-0067c4e773b7	1.00	Rolamento 6001	30.00
b652c33b-507c-4ffb-a1da-2cfe785e9d7a	4285f73a-4ec2-4144-97d7-0067c4e773b7	1.00	M.O 	50.00
4607352d-1780-4a38-8ad8-a5de0a649db6	c6f2c468-9920-4840-9879-f4537c438cf4	1.00	Válvula By Pass	160.00
68e7ae6b-fcec-4a38-a5d0-5d4c805bcb00	c6f2c468-9920-4840-9879-f4537c438cf4	1.00	M.O 	79.99
146acec4-b038-4a8a-bab2-1f5883da5f96	6dc86da8-1a64-40e9-94a8-9c60d63d8bdf	1.00	Rolamento 6201	30.00
3bfff1ab-b7f9-438a-a87d-2352a62f6f80	6dc86da8-1a64-40e9-94a8-9c60d63d8bdf	1.00	M.O 	40.00
1177609a-357b-4049-a7e0-909587e8ce07	56e73ee6-79ee-41af-9827-66a21ad7159e	1.00	Controlador de Velocidade 	450.00
800fab3a-cdbc-47b6-a570-e70140f1d947	56e73ee6-79ee-41af-9827-66a21ad7159e	1.00	Gatilho 	170.00
40988540-af7f-4d73-9e34-830f98b3c1b0	56e73ee6-79ee-41af-9827-66a21ad7159e	1.00	M.O 	50.00
689e4786-51ec-41fc-aa57-08aaed732ef9	9f9aeb41-0fbf-47aa-988b-e5f0b09d6a49	1.00	Cilindro e Pistão	190.00
8a95c8bb-7084-4c9e-9824-ae6610d38bc2	9f9aeb41-0fbf-47aa-988b-e5f0b09d6a49	1.00	Junta do Cilindro	20.00
966636c6-f175-4217-94b5-963417799532	9f9aeb41-0fbf-47aa-988b-e5f0b09d6a49	1.00	Mão de obra	80.00
038d4d50-fd3d-4a15-8bfa-94cf4100e039	c0f24c43-eaaa-4dfe-89ca-9e6342cbca2a	1.00	Chave de comando	600.00
7e9aafdf-3892-43b6-a159-a0815c8b54d7	c0f24c43-eaaa-4dfe-89ca-9e6342cbca2a	1.00	Mão de obra	100.00
\.


--
-- Data for Name: service_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_orders (id, tenant_id, order_number, client_id, equipment_id, technician_id, status, reported_defect, diagnosis, notes, payment_method, warranty_days, entry_date, completion_date, created_at, updated_at, deleted_at) FROM stdin;
c6f2c468-9920-4840-9879-f4537c438cf4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	9	43cb493c-25ec-4657-8393-f937e6576890	030da74c-3830-4b7f-9fc8-5676785dd808	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	concluida	Sem pressão 	\N	\N	PIX	90	2026-07-20	2026-07-27	2026-07-27 14:56:09.783945+00	2026-07-27 14:56:17.083+00	\N
6dc86da8-1a64-40e9-94a8-9c60d63d8bdf	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	11	72833910-7f5b-4141-8133-dda7e8ff9e12	7fe8cb25-6427-4201-af7f-4e1666731a47	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	concluida	Fazendo Barulho 	\N	Duplicada da OS #0010	A combinar	90	2026-07-21	\N	2026-07-27 15:33:47.670245+00	2026-07-27 15:35:32.523+00	\N
56e73ee6-79ee-41af-9827-66a21ad7159e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	10	72833910-7f5b-4141-8133-dda7e8ff9e12	c29a10bf-79e7-47a0-a10f-8487d7635985	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aguardando_peca	Não liga 	\N	\N	PIX	90	2026-07-21	\N	2026-07-27 15:33:29.907458+00	2026-07-27 15:36:41.988+00	\N
9f9aeb41-0fbf-47aa-988b-e5f0b09d6a49	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	12	4235c814-b03a-42d7-b57d-4589f01f8c1d	a54b2776-1afa-4a22-95b4-bc083be6a90b	6da88878-0303-4aac-941c-24b9622d20b8	concluida	Não Liga/Parou trabalhando	\N	Foi avisado ao cliente que o carburador está em OBS!, o mesmo falou que tem outro carburador de reserva!	PIX	90	2026-07-21	2026-07-27	2026-07-27 15:44:48.077978+00	2026-07-27 15:45:09.726+00	\N
babe140f-a4f8-45e1-a9e6-50d8fe94624c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	13	7ccccbf4-cd13-420c-8cea-f3d18a2bb956	c62687ec-7631-4c88-b037-beb12f95a4ef	6da88878-0303-4aac-941c-24b9622d20b8	aberta	\N	\N	\N	\N	90	2026-07-27	\N	2026-07-27 15:47:54.339275+00	2026-07-27 15:47:54.339275+00	2026-07-27 15:49:14.502+00
c0f24c43-eaaa-4dfe-89ca-9e6342cbca2a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	14	f342957a-54f7-4d46-9409-6f3e1d503b4c	8bb9f9a7-2b38-4c6d-8dd3-7fcfdc0d9a93	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aguardando_peca	Não liga	\N	\N	\N	90	2026-07-23	\N	2026-07-27 15:58:42.501911+00	2026-07-27 15:58:42.501911+00	\N
34c06735-d64a-44f4-98d6-0cea04823b96	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	15	ac66c053-d055-497a-8dbd-28d290142c0d	989f6383-78c6-4dac-86c6-f737c0885e4a	6da88878-0303-4aac-941c-24b9622d20b8	aberta	Está com cheiro de queimado, colocar parafuso original.	\N	\N	\N	90	2026-07-27	\N	2026-07-27 17:31:41.313351+00	2026-07-27 17:31:41.313351+00	\N
3b0675d2-4894-46d3-ab98-f312937fa556	c8659485-b234-4723-9681-1e71ee94ac3b	1	4503d407-55f8-471f-a9f9-52b2e04cf7d6	980fc8e7-a3ba-455e-bfd9-669d5e0b097a	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	aberta	Não liga	\N	\N	PIX	90	2026-07-03	\N	2026-07-23 23:40:49.143693+00	2026-07-23 23:40:49.143693+00	\N
64717cae-fce7-492e-b675-f30205202ef1	c8659485-b234-4723-9681-1e71ee94ac3b	2	4503d407-55f8-471f-a9f9-52b2e04cf7d6	aea36194-c9cc-4e4d-ac28-141549d1849b	e5012518-7b2d-4424-b07c-227c8116915f	aprovada	Barulho no motor	\N	\N	PIX	90	2026-07-01	\N	2026-07-23 23:40:49.47964+00	2026-07-23 23:40:49.47964+00	\N
ba6865d7-ec54-4bed-9239-d7ed8b06880b	c8659485-b234-4723-9681-1e71ee94ac3b	3	22dda795-7f60-44b8-b405-c0f9565d4eef	65dd1106-3ddd-4882-aab4-f2ca485c21da	50f51495-7dac-4549-8cc7-e7283714054e	aguardando_peca	Disco travando	\N	\N	PIX	90	2026-07-14	\N	2026-07-23 23:40:49.797702+00	2026-07-23 23:40:49.797702+00	\N
7bb62260-5f7c-4dff-98f2-363c0564caf9	c8659485-b234-4723-9681-1e71ee94ac3b	4	22dda795-7f60-44b8-b405-c0f9565d4eef	f1329c35-d35e-4bd5-85e0-cd20d687a563	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	concluida	Esquentando muito	\N	\N	PIX	90	2026-07-02	2026-07-02	2026-07-23 23:40:50.115685+00	2026-07-23 23:40:50.115685+00	\N
9b481aa8-0ccf-437f-8968-fcdeb6aab3dc	c8659485-b234-4723-9681-1e71ee94ac3b	5	e2b48e4a-89dc-4336-af04-a6344e15a3ba	1dbd502c-6aa8-4715-9a89-8ce4e83eb5be	e5012518-7b2d-4424-b07c-227c8116915f	entregue	Faísca nas escovas	\N	\N	PIX	90	2026-07-14	2026-07-14	2026-07-23 23:40:50.427454+00	2026-07-23 23:40:50.427454+00	\N
5d0cab4a-d9db-489c-bdfc-d6f2d8f1f2e6	c8659485-b234-4723-9681-1e71ee94ac3b	6	e2b48e4a-89dc-4336-af04-a6344e15a3ba	7a636607-6d19-4110-aa9c-7fa4bb521924	50f51495-7dac-4549-8cc7-e7283714054e	aberta	Vibração anormal	\N	\N	PIX	90	2026-07-03	\N	2026-07-23 23:40:50.743688+00	2026-07-23 23:40:50.743688+00	\N
2f763d83-95c3-492a-993e-b43bce8b69aa	c8659485-b234-4723-9681-1e71ee94ac3b	7	7fafefb7-0a24-40a2-b82b-75cc9679e71f	b71fa710-bb85-4439-976f-2f4bef2bea1d	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	aberta	Não liga	\N	\N	PIX	90	2026-07-01	\N	2026-07-23 23:48:09.926327+00	2026-07-23 23:48:09.926327+00	\N
6c1ad83f-b31f-4ac3-bec9-fa3f4a719610	c8659485-b234-4723-9681-1e71ee94ac3b	8	7fafefb7-0a24-40a2-b82b-75cc9679e71f	7bc893f7-9ca6-47c9-bd43-644165d7bc44	e5012518-7b2d-4424-b07c-227c8116915f	aprovada	Barulho no motor	\N	\N	PIX	90	2026-07-06	\N	2026-07-23 23:48:10.246632+00	2026-07-23 23:48:10.246632+00	\N
91874eda-692b-4eaa-a111-cc0e3ea5b1b5	c8659485-b234-4723-9681-1e71ee94ac3b	9	a8cbd12f-36a7-45fd-b948-238e5f175c4c	cf0b791a-f141-4395-8563-ccf2c7aad200	50f51495-7dac-4549-8cc7-e7283714054e	aguardando_peca	Disco travando	\N	\N	PIX	90	2026-07-08	\N	2026-07-23 23:48:10.566682+00	2026-07-23 23:48:10.566682+00	\N
6238c6ad-c5d7-4448-8b68-38e8120fb10c	c8659485-b234-4723-9681-1e71ee94ac3b	10	a8cbd12f-36a7-45fd-b948-238e5f175c4c	87b8fce7-ae7f-4c3c-a0b9-85d7c094402e	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	concluida	Esquentando muito	\N	\N	PIX	90	2026-07-13	2026-07-13	2026-07-23 23:48:10.879678+00	2026-07-23 23:48:10.879678+00	\N
60c0f67e-dd23-4289-af2e-58d6140c6d59	c8659485-b234-4723-9681-1e71ee94ac3b	11	28bd5954-4c39-41fc-89d1-5b3443c3a030	373cee8c-1dc2-4010-bdf4-133f29c28953	e5012518-7b2d-4424-b07c-227c8116915f	entregue	Faísca nas escovas	\N	\N	PIX	90	2026-07-18	2026-07-18	2026-07-23 23:48:11.194788+00	2026-07-23 23:48:11.194788+00	\N
3a054487-f443-4413-9903-2b826fd1b02d	c8659485-b234-4723-9681-1e71ee94ac3b	12	28bd5954-4c39-41fc-89d1-5b3443c3a030	06dd2dc3-04f2-471c-bf0c-cad9ca81a7a4	50f51495-7dac-4549-8cc7-e7283714054e	aberta	Vibração anormal	\N	\N	PIX	90	2026-07-04	\N	2026-07-23 23:48:11.519477+00	2026-07-23 23:48:11.519477+00	\N
6b655868-07db-4bda-8325-3c84d2c7b9f7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	3	491590c4-3257-4ba1-8d68-52b2f139542f	2c76dcad-dfaa-4f7b-8c8e-0d0043c23700	2257be26-1899-4625-aa5b-9ef0bfad2821	concluida	Faísca excessiva	\N	\N	PIX	90	2026-07-17	2026-07-17	2026-07-23 23:59:31.688002+00	2026-07-23 23:59:31.688002+00	2026-07-24 00:24:16.631+00
c7186ef6-34d8-499b-add3-b305f498eac6	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2	e348105d-1a6c-4b34-911c-ef8b74baf29a	1c66cf0e-24c6-4b42-8558-d192aa718d2e	0a2b60f8-f270-4752-a8ca-9faffd6448fb	entregue	Motor fraco	\N	\N	PIX	90	2026-07-13	\N	2026-07-23 23:59:31.372297+00	2026-07-24 13:43:01.943+00	2026-07-24 16:08:46.497+00
8371ae12-4971-4b81-9129-6943cec3572a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	1	e348105d-1a6c-4b34-911c-ef8b74baf29a	b1c97b68-5084-4aec-9a40-ff5d19b168ac	2257be26-1899-4625-aa5b-9ef0bfad2821	entregue	Não liga	\N	\N	PIX	90	2026-07-20	\N	2026-07-23 23:59:31.044315+00	2026-07-24 13:43:07.381+00	2026-07-24 16:08:50.046+00
c2f35eef-18b4-482b-9260-352dc134f6d4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	4	5b1cc305-7edb-4b0c-b608-0d64b765e849	f90c8596-5b63-405f-9d59-951ebd4af451	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Não liga 	Fio partido	OS interna 2303	A combinar	90	2026-07-23	\N	2026-07-24 17:47:18.993044+00	2026-07-24 18:45:37.38+00	\N
04f3b564-f2f3-42ea-9073-73cc8c828b74	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	5	eb0c392b-6a24-4ec4-84a0-d0729c7e719b	bf88898b-f512-4d48-a1e9-78daa7fde64f	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aberta	Vazando óleo/Não enche 	\N	Sinal para realização do serviço: 100,00	A combinar	90	2026-07-23	\N	2026-07-24 18:07:55.467562+00	2026-07-24 18:07:55.467562+00	2026-07-24 18:56:38.529+00
b8c8ea7d-ca4e-4f71-8fc5-67bbe8f30602	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	6	eb0c392b-6a24-4ec4-84a0-d0729c7e719b	bf88898b-f512-4d48-a1e9-78daa7fde64f	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aguardando_peca	Vazando óleo/Não enche 	Sinal para o serviço: 100,00\nOK 24/07	Os interna 2299	A combinar	90	2026-07-24	\N	2026-07-24 18:24:31.028489+00	2026-07-24 19:00:51.277+00	\N
d67bada3-0998-4f0c-a0c7-39a97bb4d8c9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	7	02c08106-b823-413c-99dc-3018afd8c70c	daebcb85-c3d9-4462-a966-1a47aa20e3f3	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Máquina travada	\N	\N	\N	90	2026-07-27	\N	2026-07-27 14:48:03.539466+00	2026-07-27 14:49:31.06+00	\N
4285f73a-4ec2-4144-97d7-0067c4e773b7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	8	02c08106-b823-413c-99dc-3018afd8c70c	e582d93f-39e8-477e-9e7a-43817b7804cf	db2355b2-9927-449b-97fb-7b95ccb5edb2	aberta	Máquina travada	\N	Duplicada da OS #0007	\N	90	2026-07-27	\N	2026-07-27 14:50:09.942496+00	2026-07-27 14:51:21.892+00	2026-07-27 14:51:43.477+00
\.


--
-- Data for Name: technicians; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.technicians (id, tenant_id, name, phone, specialty, active, created_at, updated_at, deleted_at) FROM stdin;
a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	c8659485-b234-4723-9681-1e71ee94ac3b	Fernando	21999996666	Ferramentas elétricas em geral	t	2026-07-23 23:40:47.205615+00	2026-07-23 23:40:47.205615+00	\N
e5012518-7b2d-4424-b07c-227c8116915f	c8659485-b234-4723-9681-1e71ee94ac3b	Igor	21988885555	Serra mármore e furadeiras	t	2026-07-23 23:40:47.375491+00	2026-07-23 23:40:47.375491+00	\N
50f51495-7dac-4549-8cc7-e7283714054e	c8659485-b234-4723-9681-1e71ee94ac3b	Felipe	21977774444	Parafusadeiras e esmerilhadeiras	t	2026-07-23 23:40:47.5353+00	2026-07-23 23:40:47.5353+00	\N
5ad58663-8f31-416e-8e57-1a970952c6aa	c8659485-b234-4723-9681-1e71ee94ac3b	Fernando	21999996666	Ferramentas elétricas em geral	t	2026-07-23 23:40:57.798528+00	2026-07-23 23:40:57.798528+00	\N
f5f297ac-326b-4a6a-9043-5438eebb3d0c	c8659485-b234-4723-9681-1e71ee94ac3b	Igor	21988885555	Serra mármore e furadeiras	t	2026-07-23 23:40:57.96053+00	2026-07-23 23:40:57.96053+00	\N
7245eed4-f1f1-4471-adb1-57bb5cd20903	c8659485-b234-4723-9681-1e71ee94ac3b	Felipe	21977774444	Parafusadeiras e esmerilhadeiras	t	2026-07-23 23:40:58.122455+00	2026-07-23 23:40:58.122455+00	\N
b02de207-7771-40bd-99b5-b951ff5126d5	c8659485-b234-4723-9681-1e71ee94ac3b	Fernando	21999996666	Ferramentas elétricas em geral	t	2026-07-23 23:41:41.329343+00	2026-07-23 23:41:41.329343+00	\N
22362f19-ce6d-458b-8db1-3a027b911533	c8659485-b234-4723-9681-1e71ee94ac3b	Igor	21988885555	Serra mármore e furadeiras	t	2026-07-23 23:41:41.488164+00	2026-07-23 23:41:41.488164+00	\N
1543382d-df2c-48cc-9354-5a1eb36f43dc	c8659485-b234-4723-9681-1e71ee94ac3b	Fernando	21999996666	Ferramentas elétricas em geral	t	2026-07-23 23:43:38.950836+00	2026-07-23 23:43:38.950836+00	\N
92acc99e-a09b-41ab-ada2-eaaba7110e04	c8659485-b234-4723-9681-1e71ee94ac3b	Igor	21988885555	Serra mármore e furadeiras	t	2026-07-23 23:43:39.114875+00	2026-07-23 23:43:39.114875+00	\N
732a158a-1474-4300-b6ff-679d19073fb4	c8659485-b234-4723-9681-1e71ee94ac3b	Felipe	21977774444	Parafusadeiras e esmerilhadeiras	t	2026-07-23 23:43:39.326834+00	2026-07-23 23:43:39.326834+00	\N
a4661e6f-1a20-4f0a-89af-78101f967f15	c8659485-b234-4723-9681-1e71ee94ac3b	Felipe	21977774444	Parafusadeiras e esmerilhadeiras	t	2026-07-23 23:41:41.649069+00	2026-07-23 23:41:41.649069+00	2026-07-24 00:27:09.997+00
db2355b2-9927-449b-97fb-7b95ccb5edb2	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Felipe Queiroz Rebello	21968161250		t	2026-07-24 13:40:55.229999+00	2026-07-24 13:40:55.229999+00	\N
6da88878-0303-4aac-941c-24b9622d20b8	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Igor Queiroz Rebello	21975473524		t	2026-07-24 13:41:21.212651+00	2026-07-24 13:41:21.212651+00	\N
ba921ec9-0acf-40f2-8917-c1dd88d46c5c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Luiz Fernando da Silva Rebello	21968198904		t	2026-07-24 13:42:30.561141+00	2026-07-24 13:42:30.561141+00	\N
0a2b60f8-f270-4752-a8ca-9faffd6448fb	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Junior	21988001122	Furadeiras e parafusadeiras	t	2026-07-23 23:59:29.588099+00	2026-07-23 23:59:29.588099+00	2026-07-24 16:08:25.235+00
2257be26-1899-4625-aa5b-9ef0bfad2821	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Marcos	21975473524	Serra mármore	t	2026-07-23 23:59:29.264777+00	2026-07-23 23:59:29.264777+00	2026-07-24 16:08:29.678+00
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenants (id, name, slug, active, modules, created_at, updated_at) FROM stdin;
cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Eletrotécnica São Miguel	esm	t	["os"]	2026-07-23 23:28:16.863334+00	2026-07-23 23:28:16.863334+00
c8659485-b234-4723-9681-1e71ee94ac3b	Empresa Master	master	t	["os"]	2026-07-23 18:01:31.047369+00	2026-07-23 18:45:26.324+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, tenant_id, name, email, password_hash, role, active, last_login, created_at, updated_at) FROM stdin;
1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	\N	Super Admin	admin@oslaboris.com	$2b$10$ClpFbXKfh5rrKbg4dqE9pur4POtPtlpnHg4nYCwXNzp3xTnbPhKHq	super_admin	t	2026-07-24 00:06:58.36+00	2026-07-23 16:46:53.668218+00	2026-07-23 16:46:53.668218+00
b1874604-7b06-4507-aa91-636baad193d6	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Admin Eletrotécnica São Miguel	esm@oslaboris.com	$2b$10$CNe4qdtqk8jh3AVP9uI4r.W0MVPc2uqqthXcYjV9Wuo3Gp1tBAX/W	tenant_user	t	2026-07-27 15:01:59.328+00	2026-07-23 18:01:31.364096+00	2026-07-24 00:13:32.158+00
\.


--
-- Name: knex_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_id_seq', 2, true);


--
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_lock_index_seq', 1, true);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: company_settings company_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_settings
    ADD CONSTRAINT company_settings_pkey PRIMARY KEY (id);


--
-- Name: company_settings company_settings_tenant_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_settings
    ADD CONSTRAINT company_settings_tenant_id_unique UNIQUE (tenant_id);


--
-- Name: equipment equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_pkey PRIMARY KEY (id);


--
-- Name: financial_entries financial_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_entries
    ADD CONSTRAINT financial_entries_pkey PRIMARY KEY (id);


--
-- Name: knex_migrations_lock knex_migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock
    ADD CONSTRAINT knex_migrations_lock_pkey PRIMARY KEY (index);


--
-- Name: knex_migrations knex_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations
    ADD CONSTRAINT knex_migrations_pkey PRIMARY KEY (id);


--
-- Name: service_order_items service_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_order_items
    ADD CONSTRAINT service_order_items_pkey PRIMARY KEY (id);


--
-- Name: service_orders service_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_pkey PRIMARY KEY (id);


--
-- Name: service_orders service_orders_tenant_id_order_number_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_tenant_id_order_number_unique UNIQUE (tenant_id, order_number);


--
-- Name: technicians technicians_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technicians
    ADD CONSTRAINT technicians_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_unique UNIQUE (slug);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: clients_tenant_document_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX clients_tenant_document_unique ON public.clients USING btree (tenant_id, document) WHERE ((document IS NOT NULL) AND ((document)::text <> ''::text));


--
-- Name: equipment_client_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX equipment_client_id_index ON public.equipment USING btree (client_id);


--
-- Name: equipment_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX equipment_tenant_id_index ON public.equipment USING btree (tenant_id);


--
-- Name: financial_entries_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX financial_entries_tenant_id_index ON public.financial_entries USING btree (tenant_id);


--
-- Name: service_orders_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_orders_tenant_id_index ON public.service_orders USING btree (tenant_id);


--
-- Name: audit_logs audit_logs_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: clients clients_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: company_settings company_settings_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_settings
    ADD CONSTRAINT company_settings_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: equipment equipment_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: equipment equipment_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: financial_entries financial_entries_service_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_entries
    ADD CONSTRAINT financial_entries_service_order_id_foreign FOREIGN KEY (service_order_id) REFERENCES public.service_orders(id);


--
-- Name: financial_entries financial_entries_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_entries
    ADD CONSTRAINT financial_entries_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: service_order_items service_order_items_service_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_order_items
    ADD CONSTRAINT service_order_items_service_order_id_foreign FOREIGN KEY (service_order_id) REFERENCES public.service_orders(id) ON DELETE CASCADE;


--
-- Name: service_orders service_orders_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- Name: service_orders service_orders_equipment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_equipment_id_foreign FOREIGN KEY (equipment_id) REFERENCES public.equipment(id);


--
-- Name: service_orders service_orders_technician_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_technician_id_foreign FOREIGN KEY (technician_id) REFERENCES public.technicians(id);


--
-- Name: service_orders service_orders_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: technicians technicians_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technicians
    ADD CONSTRAINT technicians_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: users users_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict NoIaK7aG6wvXLmpraKndapXIiNl29tN5yTfmrVtDDERn77denbZPp79v7tjU13H

