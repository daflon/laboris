pg_dump: last built-in OID is 16383
pg_dump: reading extensions
pg_dump: identifying extension members
pg_dump: reading schemas
pg_dump: reading user-defined tables
pg_dump: reading user-defined functions
pg_dump: reading user-defined types
pg_dump: reading procedural languages
pg_dump: reading user-defined aggregate functions
pg_dump: reading user-defined operators
pg_dump: reading user-defined access methods
pg_dump: reading user-defined operator classes
pg_dump: reading user-defined operator families
pg_dump: reading user-defined text search parsers
pg_dump: reading user-defined text search templates
pg_dump: reading user-defined text search dictionaries
pg_dump: reading user-defined text search configurations
pg_dump: reading user-defined foreign-data wrappers
pg_dump: reading user-defined foreign servers
pg_dump: reading default privileges
pg_dump: reading user-defined collations
pg_dump: reading user-defined conversions
pg_dump: reading type casts
pg_dump: reading transforms
pg_dump: reading table inheritance information
pg_dump: reading event triggers
pg_dump: finding extension tables
pg_dump: finding inheritance relationships
pg_dump: reading column info for interesting tables
pg_dump: finding table default expressions
pg_dump: flagging inherited columns in subtables
pg_dump: reading partitioning data
pg_dump: reading indexes
pg_dump: flagging indexes in partitioned tables
pg_dump: reading extended statistics
pg_dump: reading constraints
pg_dump: reading triggers
pg_dump: reading rewrite rules
pg_dump: reading policies
pg_dump: reading row-level security policies
pg_dump: reading publications
pg_dump: reading publication membership of tables
pg_dump: reading publication membership of schemas
pg_dump: reading subscriptions
pg_dump: reading large objects
pg_dump: reading dependency data
pg_dump: saving encoding = UTF8
pg_dump: saving standard_conforming_strings = on
pg_dump: saving search_path = 
pg_dump: creating EXTENSION "pgcrypto"
pg_dump: creating COMMENT "EXTENSION pgcrypto"
pg_dump: creating TABLE "public.audit_logs"
pg_dump: creating TABLE "public.clients"
pg_dump: creating TABLE "public.company_settings"
pg_dump: creating TABLE "public.equipment"
pg_dump: creating TABLE "public.financial_entries"
--
-- PostgreSQL database dump
--

\restrict BfSs5Vgeo884ac1WBarO7vdYPtsVNK1cSBDap0NdMEodCFZzabwn9nQpG8KQMob

-- Dumped from database version 16.14 (422d414)
-- Dumped by pg_dump version 16.14 (Ubuntu 16.14-1.pgdg24.04+1)

-- Started on 2026-08-19 06:56:35 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 2 (class 3079 OID 24590)
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- TOC entry 3541 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 228 (class 1259 OID 24781)
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    action character varying(50) NOT NULL,
    entity_type character varying(50),
    entity_id character varying(36),
    description text,
    performed_by character varying(100),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 222 (class 1259 OID 24660)
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    document character varying(18),
    phone character varying(20) NOT NULL,
    email character varying(200),
    address_street character varying(200),
    address_number character varying(20),
    address_complement character varying(100),
    address_neighborhood character varying(100),
    address_city character varying(100),
    address_state character varying(2),
    address_zip character varying(8),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- TOC entry 227 (class 1259 OID 24763)
-- Name: company_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.company_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    document character varying(18),
    phone character varying(20),
    phone2 character varying(20),
    email character varying(200),
    address_street character varying(200),
    address_number character varying(20),
    address_complement character varying(100),
    address_neighborhood character varying(100),
    address_city character varying(100),
    address_state character varying(2),
    address_zip character varying(8),
    logo_url text,
    header_text text,
    footer_text text,
    default_warranty_days integer DEFAULT 90,
    admin_pin character varying(10),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 224 (class 1259 OID 24691)
-- Name: equipment; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.equipment (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    client_id uuid NOT NULL,
    type character varying(100) NOT NULL,
    brand character varying(100) NOT NULL,
    model character varying(100) NOT NULL,
    serial_number character varying(100),
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- TOC entry 229 (class 1259 OID 24795)
-- Name: financial_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE pg_dump: creating TABLE "public.impersonate_logs"
pg_dump: creating TABLE "public.knex_migrations"
pg_dump: creating SEQUENCE "public.knex_migrations_id_seq"
pg_dump: creating SEQUENCE OWNED BY "public.knex_migrations_id_seq"
pg_dump: creating TABLE "public.knex_migrations_lock"
pg_dump: creating SEQUENCE "public.knex_migrations_lock_index_seq"
pg_dump: creating SEQUENCE OWNED BY "public.knex_migrations_lock_index_seq"
pg_dump: creating TABLE "public.pin_attempts"
pg_dump: creating TABLE "public.service_order_items"
pg_dump: creating TABLE "public.service_orders"
pg_dump: creating TABLE "public.technicians"
TABLE public.financial_entries (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    type character varying(20) NOT NULL,
    description text NOT NULL,
    amount numeric(10,2) NOT NULL,
    due_date date,
    paid_date date,
    status character varying(20) DEFAULT 'pendente'::character varying NOT NULL,
    service_order_id uuid,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 231 (class 1259 OID 57358)
-- Name: impersonate_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.impersonate_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    admin_id uuid,
    tenant_id uuid,
    started_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    ended_at timestamp with time zone,
    ip_address character varying(45),
    actions_summary text
);


--
-- TOC entry 217 (class 1259 OID 24577)
-- Name: knex_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations (
    id integer NOT NULL,
    name character varying(255),
    batch integer,
    migration_time timestamp with time zone
);


--
-- TOC entry 216 (class 1259 OID 24576)
-- Name: knex_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3542 (class 0 OID 0)
-- Dependencies: 216
-- Name: knex_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_id_seq OWNED BY public.knex_migrations.id;


--
-- TOC entry 219 (class 1259 OID 24584)
-- Name: knex_migrations_lock; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.knex_migrations_lock (
    index integer NOT NULL,
    is_locked integer
);


--
-- TOC entry 218 (class 1259 OID 24583)
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.knex_migrations_lock_index_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3543 (class 0 OID 0)
-- Dependencies: 218
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.knex_migrations_lock_index_seq OWNED BY public.knex_migrations_lock.index;


--
-- TOC entry 230 (class 1259 OID 57344)
-- Name: pin_attempts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.pin_attempts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    ip_address character varying(45) NOT NULL,
    attempted_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    success boolean DEFAULT false
);


--
-- TOC entry 226 (class 1259 OID 24748)
-- Name: service_order_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_order_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_order_id uuid NOT NULL,
    quantity numeric(10,2) DEFAULT '1'::numeric NOT NULL,
    description text NOT NULL,
    unit_price numeric(10,2) DEFAULT '0'::numeric NOT NULL
);


--
-- TOC entry 225 (class 1259 OID 24713)
-- Name: service_orders; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.service_orders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    order_number integer NOT NULL,
    client_id uuid NOT NULL,
    equipment_id uuid NOT NULL,
    technician_id uuid NOT NULL,
    status character varying(30) DEFAULT 'aberta'::character varying NOT NULL,
    reported_defect text,
    diagnosis text,
    notes text,
    payment_method character varying(50),
    warranty_days integer DEFAULT 90,
    entry_date date,
    completion_date date,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone,
    lote_numero integer,
    lote_sufixo character varying(1)
);


--
-- TOpg_dump: creating TABLE "public.tenants"
pg_dump: creating TABLE "public.users"
pg_dump: creating DEFAULT "public.knex_migrations id"
pg_dump: creating DEFAULT "public.knex_migrations_lock index"
pg_dump: processing data for table "public.audit_logs"
pg_dump: dumping contents of table "public.audit_logs"
C entry 223 (class 1259 OID 24677)
-- Name: technicians; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.technicians (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    name character varying(200) NOT NULL,
    phone character varying(20) NOT NULL,
    specialty character varying(200),
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    deleted_at timestamp with time zone
);


--
-- TOC entry 220 (class 1259 OID 24627)
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(50) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    modules jsonb DEFAULT '["os"]'::jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 221 (class 1259 OID 24641)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid,
    name character varying(200) NOT NULL,
    email character varying(200) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) DEFAULT 'tenant_user'::character varying NOT NULL,
    active boolean DEFAULT true NOT NULL,
    last_login timestamp with time zone,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- TOC entry 3270 (class 2604 OID 24580)
-- Name: knex_migrations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations ALTER COLUMN id SET DEFAULT nextval('public.knex_migrations_id_seq'::regclass);


--
-- TOC entry 3271 (class 2604 OID 24587)
-- Name: knex_migrations_lock index; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock ALTER COLUMN index SET DEFAULT nextval('public.knex_migrations_lock_index_seq'::regclass);


--
-- TOC entry 3532 (class 0 OID 24781)
-- Dependencies: 228
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, tenant_id, action, entity_type, entity_id, description, performed_by, created_at) FROM stdin;
ed1865f7-8331-4583-8e4b-98222cf62b1e	\N	delete_os	service_order	6b655868-07db-4bda-8325-3c84d2c7b9f7	OS #0003 - Cliente: Sandra Costa	admin	2026-07-24 00:24:15.856+00
3d79b209-9b8e-4020-8c72-83c8d825b812	\N	delete_client	client	e348105d-1a6c-4b34-911c-ef8b74baf29a	Cliente: José Oliveira	admin	2026-07-24 00:24:25.688+00
582e5c95-8262-4cba-84e4-07322316a7eb	\N	delete_technician	technician	a4661e6f-1a20-4f0a-89af-78101f967f15	Técnico: Felipe	admin	2026-07-24 00:27:09.551+00
6e15171d-4c71-4c46-a482-fe57ce332c76	\N	delete_client	client	7fafefb7-0a24-40a2-b82b-75cc9679e71f	Cliente: Carlos Mendes	admin	2026-07-24 00:27:26.467+00
d1344eab-3711-4cf5-bd60-9643966b61c9	\N	delete_technician	technician	0a2b60f8-f270-4752-a8ca-9faffd6448fb	Técnico: Junior	admin	2026-07-24 16:08:24.902+00
074b1915-1e37-4e36-bf8e-2274104649a8	\N	delete_technician	technician	2257be26-1899-4625-aa5b-9ef0bfad2821	Técnico: Marcos	admin	2026-07-24 16:08:29.347+00
277d4f17-f4e5-4bd9-8d9b-2851a6e33c55	\N	delete_os	service_order	c7186ef6-34d8-499b-add3-b305f498eac6	OS #0002 - Cliente: José Oliveira	admin	2026-07-24 16:08:46.109+00
278f9600-3181-4399-a948-70ae40e2bf07	\N	delete_os	service_order	8371ae12-4971-4b81-9129-6943cec3572a	OS #0001 - Cliente: José Oliveira	admin	2026-07-24 16:08:49.671+00
6d5446f5-fd69-4dd6-8bfb-0cd44fbb3515	\N	delete_client	client	491590c4-3257-4ba1-8d68-52b2f139542f	Cliente: Sandra Costa	admin	2026-07-24 16:08:55.652+00
1aff2e18-4289-42d6-b5da-eb5b623ada20	\N	delete_equipment	equipment	2c76dcad-dfaa-4f7b-8c8e-0d0043c23700	Equipamento: Parafusadeira DeWalt DCD777 - Cliente: Sandra Costapg_dump: processing data for table "public.clients"
pg_dump: dumping contents of table "public.clients"
	admin	2026-07-24 16:09:04.534+00
8d112bfa-cb68-4de0-8b98-b142cf7d067a	\N	delete_equipment	equipment	1c66cf0e-24c6-4b42-8558-d192aa718d2e	Equipamento: Furadeira Bosch GSB 550 RE - Cliente: José Oliveira	admin	2026-07-24 16:09:08.141+00
e32ecad1-70b8-477d-b1bd-a1f9b9e8c0db	\N	delete_equipment	equipment	b1c97b68-5084-4aec-9a40-ff5d19b168ac	Equipamento: Serra Mármore Makita 4100NH3 - Cliente: José Oliveira	admin	2026-07-24 16:09:11.548+00
193b405b-184e-44d5-9450-06c9a5d36ee9	\N	delete_os	service_order	04f3b564-f2f3-42ea-9073-73cc8c828b74	OS #0000 - Cliente: N/A	admin	2026-07-24 18:56:37.999+00
6bf85a9c-49ea-407e-8dc2-9fc15c92a02e	\N	delete_os	service_order	4285f73a-4ec2-4144-97d7-0067c4e773b7	OS #0000 - Cliente: N/A	admin	2026-07-27 14:51:43.05+00
cf8765df-5fc4-4fac-967e-9727ffbdcf8c	\N	delete_os	service_order	babe140f-a4f8-45e1-a9e6-50d8fe94624c	OS #0013 - Cliente: Jurandi da Silva	admin	2026-07-27 15:49:14.031+00
954fcf58-8283-48f4-8fbd-a83d57567c8f	\N	delete_client	client	7ccccbf4-cd13-420c-8cea-f3d18a2bb956	Cliente: Jurandi da Silva	admin	2026-07-27 15:50:18.121+00
04129fe0-0d1a-4e8b-a1a5-59863c5f61c9	\N	delete_os	service_order	f44de641-582e-4180-8676-1aa37dad3e56	OS #0000 - Cliente: N/A	admin	2026-07-28 14:19:25.201+00
11421436-80ac-41c1-aa32-b1eed64ae415	\N	delete_os	service_order	694a7ac3-297f-4e7d-8ac7-1a1283a55529	OS #0000 - Cliente: N/A	admin	2026-07-28 14:24:45.262+00
447ea422-88c0-4319-b425-20980e3f5135	\N	delete_client	client	6314dfad-9a56-4185-b353-f10769b0c2de	Cliente: luciano da costa	admin	2026-07-28 14:26:18.019+00
3c5a562d-8533-46ca-9c87-573222141307	\N	delete_client	client	9c5e19ac-6e8f-49b0-ab49-ba71a0eca09e	Cliente: Felipe Queiroz Rebello	admin	2026-07-28 14:26:24.553+00
fbe960c5-3614-42f7-ba06-c725c877ead9	\N	delete_equipment	equipment	66c8a777-ae14-4106-b746-16c66341c2ae	Equipamento:    - Cliente: N/A	admin	2026-07-28 14:51:24.849+00
4e7e5706-1ef1-4f26-9867-3656cbc03c34	\N	delete_os	service_order	0baf5e3f-f39b-4ec7-9d05-7b1b73e22180	OS #0000 - Cliente: N/A	admin	2026-07-28 17:45:30.579+00
591ad5c8-7f83-4198-91fd-7550bd70cf37	\N	delete_client	client	e40eb094-6f78-428a-8d4a-a376dbf222e7	Cliente: Luiz Carlos 	admin	2026-07-28 19:13:47.37+00
94c34df6-6fa6-42a8-8f7e-db0c37672f94	\N	delete_os	service_order	648644fe-8b54-4fd6-a1ba-e3b727bf862e	OS #0000 - Cliente: N/A	admin	2026-07-28 19:14:37.606+00
58fffd0c-5859-4f98-b564-d1e08392a079	\N	delete_equipment	equipment	d4b83c29-e64b-496b-92e2-fd1d2370897d	Equipamento: politriz  makita  sd - Cliente: Luiz Carlos 	admin	2026-07-31 14:19:54.451+00
0e412133-a1b4-44c1-b52a-893e5fbc4f88	\N	delete_equipment	equipment	a28a4794-bff0-428a-9fc0-b02792b99e4b	Equipamento: Politriz  Makita  SA7021 - Cliente: Luiz Carlos 	admin	2026-07-31 14:20:01.918+00
119cea92-855f-49e1-81e9-ef314c844935	\N	delete_os	service_order	fae91efb-ea64-47fe-88cb-5f7424751d78	OS #0000 - Cliente: N/A	admin	2026-08-03 16:07:10.075+00
bc4d0a43-2093-4e3a-805c-600bc7172803	\N	delete_equipment	equipment	d912ebe8-fb46-4fc2-a965-65a97247211b	Equipamento:    - Cliente: N/A	admin	2026-08-03 17:30:41.345+00
af29332d-320c-4d99-99ac-ab902e4951b3	\N	delete_equipment	equipment	ff4f72f0-1674-4680-8386-83f13ad499d2	Equipamento:    - Cliente: N/A	admin	2026-08-03 17:33:02.362+00
9aa4839d-7505-425e-a0af-0d167e02171d	\N	delete_os	service_order	4e24e848-369c-47eb-b6da-4f27c4fdf90b	OS #0081 - Cliente: Marcos Felc Pint 	admin	2026-08-11 13:50:28.208+00
\.


--
-- TOC entry 3526 (class 0 OID 24660)
-- Dependencies: 222
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clients (id, tenant_id, name, document, phone, email, address_street, address_number, address_complement, address_neighborhood, address_city, address_state, address_zip, created_at, updated_at, deleted_at) FROM stdin;
4503d407-55f8-471f-a9f9-52b2e04cf7d6	c8659485-b234-4723-9681-1e71ee94ac3b	Carlos Mendes	52998224725	21991001001	\N	\N	\N	\N	\N	Rio de Janeiro	RJ	\N	2026-07-23 23:40:47.693623+00	2026-07-23 23:40:47.693623+00	\N
22dda795-7f60-44b8-b405-c0f9565d4eef	c8659485-b234-4723-9681-1e71ee94ac3b	Luciana Ferreira	83456789012	21992002002	\N	\N	\N	\N	\N	Rio de Janeiro	RJ	\N	2026-07-23 23:40:47.857645+00	2026-07-23 23:40:47.857645+00	\N
e2b48e4a-89dc-4336-af04-a6344e15a3ba	c8659485-b234-4723-9681-1e71ee94ac3b	Rafael Souza	71234567890	21993003003	\N	\N	\N	\N	\N	Rio de Janeiro	RJ	\N	2026-07-23 23:40:48.017508+00	2026-07-23 23:40:48.017508+00	\N
a8cbd12f-36a7-45fd-b948-238e5f175c4c	c8659485-b234-4723-9681-1e71ee94ac3b	Luciana Ferreira	55566677788	21992002002	\N	\N	\N	\N	\N	Rio de Janeiro	RJ	\N	2026-07-23 23:41:41.96689+00	2026-07-23 23:41:41.96689+00	\N
28bd5954-4c39-41fc-89d1-5b3443c3a030	c8659485-b234-4723-9681-1e71ee94ac3b	Rafael Souza	99988877700	21993003003	\N	\N	\N	\N	\N	Rio de Janeiro	RJ	\N	2026-07-23 23:41:42.122589+00	2026-07-23 23:41:42.122589+00	\N
e348105d-1a6c-4b34-911c-ef8b74baf29a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	José Oliveira	12312312300	21991110001	\N	\N	\N	\N	\N	Teresópolis	RJ	\N	2026-07-23 23:59:29.91214+00	2026-07-23 23:59:29.91214+00	2026-07-24 00:24:26.029+00
7fafefb7-0a24-40a2-b82b-75cc9679e71f	c8659485-b234-4723-9681-1e71ee94ac3b	Carlos Mendes	11122233344	21991001001	\N	\N	\N	\N	\N	Rio de Janeiro	RJ	\N	2026-07-23 23:41:41.808983+00	2026-07-23 23:41:41.808983+00	2026-07-24 00:27:26.821+00
491590c4-3257-4ba1-8d68-52b2f139542f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Sandra Costa	45645645600	21992220002	\N	\N	\N	\N	\N	Teresópolis	RJ	\N	2026-07-23 23:59:30.231719+00	2026-07-23 23:59:30.231719+00	2026-07-24 16:08:55.971+00
5b1cc305-7edb-4b0c-b608-0d64b765e849	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Ronaldo Nascimento 	00000000000	21976132251									2026-07-24 17:45:45.199093+00	2026-07-24 17:45:45.199093+00	\N
eb0c392b-6a24-4ec4-84a0-d0729c7e719b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Ricardo Vieira 		21997077868		\N	\N	\N	\N	\N	\N	\N	2026-07-24 17:51:05.081969+00	2026-07-24 17:51:05.081969+00	\N
656caf20-8394-4d02-9da4-ae91a25072d2	c8659485-b234-4723-9681-1e71ee94ac3b	Charles Daflon		21974303932									2026-07-27 14:06:52.618245+00	2026-07-27 14:06:52.618245+00	\N
856ef1e0-8011-445f-b6a3-97ce79ff088d	c8659485-b234-4723-9681-1e71ee94ac3b	charles		21974303932									2026-07-27 14:07:11.327521+00	2026-07-27 14:07:11.327521+00	\N
02c08106-b823-413c-99dc-3018afd8c70c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Celmo Santos 		21973473671									2026-07-27 14:44:24.173503+00	2026-07-27 14:44:24.173503+00	\N
43cb493c-25ec-4657-8393-f937e6576890	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Bruno Garagem 21		21979603725		\N	\N	\N	\N	\N	\N	\N	2026-07-27 14:54:03.93193+00	2026-07-27 14:54:03.93193+00	\N
72833910-7f5b-4141-8133-dda7e8ff9e12	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Luiz Carlos 		21992816115		\N	\N	\N	\N	\N	\N	\N	2026-07-27 15:31:19.107207+00	2026-07-27 15:31:19.107207+00	\N
4235c814-b03a-42d7-b57d-4589f01f8c1d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	welington charles		21974232600		\N	\N	\N	\N	\N	\N	\N	2026-07-27 15:39:17.11714+00	2026-07-27 15:39:17.11714+00	\N
7ccccbf4-cd13-420c-8cea-f3d18a2bb956	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Jurandi da Silva		21969211701		\N	\N	\N	\N	\N	\N	\N	2026-07-27 15:46:34.059901+00	2026-07-27 15:46:34.059901+00	2026-07-27 15:50:18.469+00
f342957a-54f7-4d46-9409-6f3e1d503b4c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Pilar Seis (Paulo Ricardo)	06940763000107	21987214190		\N	\N	\N	\N	\N	\N	\N	2026-07-27 15:56:35.368902+00	2026-07-27 15:56:35.368902+00	\N
ac66c053-d055-497a-8dbd-28d290142c0d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Visoma (Darci)		21994934718		\N	\N	\N	\N	\N	\N	\N	2026-07-27 17:26:35.387329+00	2026-07-27 17:26:35.387329+00	\N
6314dfad-9a56-4185-b353-f10769b0c2de	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	luciano da costa		21978352495		\N	\N	\N	\N	\N	\N	\N	2026-07-28 14:21:21.777539+00	2026-07-28 14:21:21.777539+00	2026-07-28 14:26:18.415+00
00e91576-5a07-4227-91da-36560b39b2a7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Tiago Boerher Sales 		21981772235									2026-07-27 21:11:07.769688+00	2026-07-27 21:17:52.846+00	\N
5ad6797d-488f-4e61-aaa0-ea9667f0aafd	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Betinho Castelo Branco		21976900984		\N	\N	\N	\N	\N	\N	\N	2026-07-28 12:06:07.023803+00	2026-07-28 12:06:07.023803+00	\N
7384934f-2bcf-4f85-83b0-dcf623c6ed22	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Manoel José 		21971609690		\N	\N	\N	\N	\N	\N	\N	2026-07-28 12:22:23.347354+00	2026-07-28 12:22:23.347354+00	\N
ced6073a-0a5d-47a8-8e32-50a3eee914b4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Marcos Felc Pint 		21994955842		\N	\N	\N	\N	\N	\N	\N	2026-07-28 12:31:47.183419+00	2026-07-28 12:31:47.183419+00	\N
de143cae-013d-467e-910a-3d5d564cbd25	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Marcos de Paula		21976392024		\N	\N	\N	\N	\N	\N	\N	2026-07-28 13:58:36.344695+00	2026-07-28 13:58:36.344695+00	\N
9c5e19ac-6e8f-49b0-ab49-ba71a0eca09e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Felipe Queiroz Rebello		21968161250	feliperebello6@gmail.com	\N	\N	\N	\N	\N	\N	\N	2026-07-28 14:16:21.579071+00	2026-07-28 14:16:21.579071+00	2026-07-28 14:26:24.901+00
0d66cd3e-0f02-4c63-bd34-1973ca26c673	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Luiz de Melo / Cristina		21976497061									2026-07-28 14:43:41.455464+00	2026-07-28 14:50:37.607+00	\N
6d750b5a-f4e2-43d6-94cf-3d2af5c748da	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Celso Nunes		21966917114		\N	\N	\N	\N	\N	\N	\N	2026-07-28 15:04:41.082525+00	2026-07-28 15:04:41.082525+00	\N
716204a4-7981-48e9-9126-2a9b0239bd9a	c8659485-b234-4723-9681-1e71ee94ac3b	Construtora Lote & CIA	12345678000199	11999887766	lote@construtora.com	\N	\N	\N	\N	São Paulo	SP	\N	2026-07-28 15:20:30.372131+00	2026-07-28 15:20:30.372131+00	\N
8c00fca4-6130-4fa6-99f6-835d89aad8c3	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Ricardo Augusto 		21996958146		\N	\N	\N	\N	\N	\N	\N	2026-07-28 15:48:52.49933+00	2026-07-28 15:48:52.49933+00	\N
ba75cd9b-9850-45a5-9432-af409ee947f4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Ricardo Augusto		21996958146		\N	\N	\N	\N	\N	\N	\N	2026-07-28 15:53:52.455643+00	2026-07-28 15:53:52.455643+00	\N
f3e9be14-3b81-430d-be5f-2ad8c119921a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Rodrigo Reis 		21973818236		\N	\N	\N	\N	\N	\N	\N	2026-07-28 17:33:22.886913+00	2026-07-28 17:33:22.886913+00	\N
3cf92c8a-0fe5-40a8-80dc-5b8a8860d9c5	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Zé Luiz		21990963798		\N	\N	\N	\N	\N	\N	\N	2026-07-28 18:56:36.494649+00	2026-07-28 18:56:36.494649+00	\N
e40eb094-6f78-428a-8d4a-a376dbf222e7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Luiz Carlos 		21992816115		\N	\N	\N	\N	\N	\N	\N	2026-07-28 19:04:36.381494+00	2026-07-28 19:04:36.381494+00	2026-07-28 19:13:47.712+00
cbe54fe3-9203-4718-beb7-766185ffa927	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Devalcir De Jesus		21999446549		\N	\N	\N	\N	\N	\N	\N	2026-07-28 19:21:52.105833+00	2026-07-28 19:21:52.105833+00	\N
5ce60189-4263-423d-a1e4-d166baf66a8b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Paulo Cesar Fortunado 		21992965729		\N	\N	\N	\N	\N	\N	\N	2026-07-28 19:29:43.650235+00	2026-07-28 19:29:43.650235+00	\N
005f0c88-f77f-4e8e-b079-06881fa72685	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Alan Soares 		21993406443		\N	\N	\N	\N	\N	\N	\N	2026-07-28 19:52:44.318348+00	2026-07-28 19:52:44.318348+00	\N
2460faab-37f1-414b-b8e9-dd8988814f41	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Nelcy		21976041551		\N	\N	\N	\N	\N	\N	\N	2026-07-28 21:26:45.97044+00	2026-07-28 21:26:45.97044+00	\N
33cbc579-810b-4435-9288-40fbd66a12ca	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Marco Borcaro 		21980492743		\N	\N	\N	\N	\N	\N	\N	2026-07-29 12:28:12.811968+00	2026-07-29 12:28:12.811968+00	\N
8b2a2b71-c47b-45ba-a8ce-1cbbc2b633f7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Odair José 		21973810742		\N	\N	\N	\N	\N	\N	\N	2026-07-29 14:15:40.287941+00	2026-07-29 14:15:40.287941+00	\N
3b58b228-0e27-4954-9d00-27e58035562f	c8659485-b234-4723-9681-1e71ee94ac3b	Cliente Teste Alertas	99999999999	21999999999	\N	\N	\N	\N	\N	Rio de Janeiro	RJ	\N	2026-07-29 16:15:52.973692+00	2026-07-29 16:15:52.973692+00	\N
32c9c508-f81d-46d5-b96a-b9d4e7143728	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Moises Pires Marcenaria Moshe		21968650093		\N	\N	\N	\N	\N	\N	\N	2026-07-29 17:50:26.880789+00	2026-07-29 17:50:26.880789+00	\N
c0984895-5dfa-4663-9816-469fabb70000	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Reginaldo Freire		21994894918		\N	\N	\N	\N	\N	\N	\N	2026-07-29 20:11:14.535027+00	2026-07-29 20:11:14.535027+00	\N
daea5356-7032-4c55-88ae-1a6e55a8609c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Jair brigido		21976566793		\N	\N	\N	\N	\N	\N	\N	2026-07-29 20:21:41.739933+00	2026-07-29 20:21:41.739933+00	\N
c7ae6402-2cb9-4a7e-baa5-4f8efb54262f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Alex Araujo 		21997707771		\N	\N	\N	\N	\N	\N	\N	2026-07-29 20:26:52.837935+00	2026-07-29 20:26:52.837935+00	\N
2d019df4-3df6-4ef8-86ba-891dcb5e9ce2	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Atila 		21974097641		\N	\N	\N	\N	\N	\N	\N	2026-07-29 20:37:02.170275+00	2026-07-29 20:37:02.170275+00	\N
fa625623-4d8e-4401-866a-2d2050a7765c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Lucas Turino damazio		21975356047		\N	\N	\N	\N	\N	\N	\N	2026-07-30 12:07:36.836311+00	2026-07-30 12:07:36.836311+00	\N
8c12838f-9ad9-4c47-9e04-0fd8f5076994	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Lucas Turino Damazio		21975356047		\N	\N	\N	\N	\N	\N	\N	2026-07-30 12:12:17.741094+00	2026-07-30 12:12:17.741094+00	\N
d1d9d7c0-a55a-4474-b829-8e37461d9fe5	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Pilar Seis (Paulo Ricardo)		21987214190		\N	\N	\N	\N	\N	\N	\N	2026-07-30 12:45:28.402922+00	2026-07-30 12:45:28.402922+00	\N
fcbcb142-6e9f-4961-9350-b121fb78738b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Adir Martins Ramos 	77949439734	21991829436		\N	\N	\N	\N	\N	\N	\N	2026-07-30 14:52:42.853054+00	2026-07-30 14:52:42.853054+00	\N
5a6976ee-6988-4a2d-9783-abef84c22375	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Vanusa Limeira Rezende		21997430527		\N	\N	\N	\N	\N	\N	\N	2026-07-30 15:18:51.057509+00	2026-07-30 15:18:51.057509+00	\N
ad48afdb-0fbd-419d-94dd-50efadb169d4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Davi Lopes Ferreira / Thais 		21992497288		\N	\N	\N	\N	\N	\N	\N	2026-07-30 15:34:48.686119+00	2026-07-30 15:34:48.686119+00	\N
bbb53896-df27-4535-9a0f-6c6abf577352	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Danilo Pinto Silva 	37677846882	21995033500									2026-07-28 18:03:47.799339+00	2026-07-30 15:47:17.138+00	\N
0fb9604a-9ed4-456a-b014-745c0f0e34d5	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Marcos Evangelista Rocha	15544836701	21966999750		\N	\N	\N	\N	\N	\N	\N	2026-07-30 15:52:52.731646+00	2026-07-30 15:52:52.731646+00	\N
a41d03ee-47e6-482a-a4cb-dde0a146a80f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	MJJ Serralheria 		21999072573		\N	\N	\N	\N	\N	\N	\N	2026-07-30 19:49:08.114197+00	2026-07-30 19:49:08.114197+00	\N
bdcafd51-6adb-4361-a45c-9e76f63f947c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	José Carlos Fernandes  		21981457368		\N	\N	\N	\N	\N	\N	\N	2026-07-30 20:28:48.521686+00	2026-07-30 20:28:48.521686+00	\N
de252bde-1b36-4120-9ec6-79f0fc854287	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Felippe Rebello		21967368031		\N	\N	\N	\N	\N	\N	\N	2026-07-31 11:40:40.517689+00	2026-07-31 11:40:40.517689+00	\N
4c5c36c6-0594-445c-af0d-83e45bad0fa3	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Rone Clementino 		21966648747		\N	\N	\N	\N	\N	\N	\N	2026-07-31 15:48:27.972799+00	2026-07-31 15:48:27.972799+00	\N
1028f9ae-f12a-41b1-b28d-29322a1beb76	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Nelson José de Barros 		21999380810		\N	\N	\N	\N	\N	\N	\N	2026-07-31 18:03:01.043997+00	2026-07-31 18:03:01.043997+00	\N
51f35478-f3c3-412c-ad60-de472ab1484b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Paulo Cesar Braga	24826421753	21975025882		\N	\N	\N	\N	\N	\N	\N	2026-08-01 13:24:46.538108+00	2026-08-01 13:24:46.538108+00	\N
61eb8a2d-5ea5-468d-a2e8-e99284504c62	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Valdnei Silva 		21975571092		\N	\N	\N	\N	\N	\N	\N	2026-08-03 11:47:08.985493+00	2026-08-03 11:47:08.985493+00	\N
a1c5f1de-64d6-48c2-af16-f800465124b9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	João Pedro Gonçalves Sampaio	48603678715	21997275797		\N	\N	\N	\N	\N	\N	\N	2026-08-03 12:19:18.653152+00	2026-08-03 12:19:18.653152+00	\N
a6510644-5be1-40ef-adc6-e5e99891c0dd	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Roberto Castelo Branco		21976900984		\N	\N	\N	\N	\N	\N	\N	2026-08-03 12:40:08.356031+00	2026-08-03 12:40:08.356031+00	\N
b8b5da0e-05d5-4e8e-8c08-c0f265d3f42c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Pricila Essencial 		21993845698		\N	\N	\N	\N	\N	\N	\N	2026-08-03 14:35:34.979219+00	2026-08-03 14:35:34.979219+00	\N
ee6e8dd3-896a-413b-9b0d-20e6bd9dcd79	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Luis Carlos Evangelista 	98097580730	21975886526		\N	\N	\N	\N	\N	\N	\N	2026-08-03 14:39:59.646915+00	2026-08-03 14:39:59.646915+00	\N
54c9ba13-d8e9-4151-9b3c-bae9c598cdee	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Luiz Souza Alvez	10111693713	21992824150		\N	\N	\N	\N	\N	\N	\N	2026-08-03 15:24:59.808738+00	2026-08-03 15:24:59.808738+00	\N
08f5f4f7-b334-42a8-88f4-7379b267d01c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Marquinho MM Instalações 		21993003589		\N	\N	\N	\N	\N	\N	\N	2026-08-03 15:47:19.866905+00	2026-08-03 15:47:19.866905+00	\N
0aaef31d-edb4-41a4-bc12-c50977730963	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Marquinho MM Instalações 		21993003589		\N	\N	\N	\N	\N	\N	\N	2026-08-03 15:54:58.579828+00	2026-08-03 15:54:58.579828+00	\N
2d9486a9-74e9-4a70-8205-04fe791da471	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Marcos Antônio Correa 	01138095737	21991763525		\N	\N	\N	\N	\N	\N	\N	2026-08-03 18:14:40.078121+00	2026-08-03 18:14:40.078121+00	\N
b727602c-6f4b-4320-88cb-2a2f2257224d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Osvaldo Gregório 		21969598351		\N	\N	\N	\N	\N	\N	\N	2026-08-03 18:35:32.119907+00	2026-08-03 18:35:32.119907+00	\N
c36ec798-9741-47ed-9023-5bf16a351310	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Geovane da Silva Rosa		21973874944		\N	\N	\N	\N	\N	\N	\N	2026-08-03 19:27:09.075149+00	2026-08-03 19:27:09.075149+00	\N
e1b5efb0-6686-4fdf-931b-fe77ccbf90e0	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Mauricio Da silva Soares	82296057772	21993212248		\N	\N	\N	\N	\N	\N	\N	2026-08-03 19:46:53.167357+00	2026-08-03 19:46:53.167357+00	\N
2f600557-66e4-4a2e-b4eb-9186657fd5b9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Victor Brasil		21991702120		\N	\N	\N	\N	\N	\N	\N	2026-08-03 20:51:09.523063+00	2026-08-03 20:51:09.523063+00	\N
2844c1c6-fad3-42c7-81ab-1b32dd636bff	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Marlon da silva Salvino 		21968522271		\N	\N	\N	\N	\N	\N	\N	2026-08-04 18:06:09.034607+00	2026-08-04 18:06:09.034607+00	\N
43469404-5d50-4bd6-8d99-20e7149d0625	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Bruno Heróis e Pizza 		21999899723		\N	\N	\N	\N	\N	\N	\N	2026-08-05 11:57:16.616367+00	2026-08-05 11:57:16.616367+00	\N
91d59fb5-467b-4c8f-8bff-c86d5228ff55	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Giomar Santos 	78623570782	21997568641		\N	\N	\N	\N	\N	\N	\N	2026-08-05 12:21:54.951832+00	2026-08-05 12:21:54.951832+00	\N
7c0d2ac4-9c4a-42fc-ad9a-589351fe76cf	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Pedro Garrido 		21970354441		\N	\N	\N	\N	\N	\N	\N	2026-08-05 14:33:17.057892+00	2026-08-05 14:33:17.057892+00	\N
f7f561cf-db2d-4cac-ae5b-93464cb24478	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Adonias Nacimento 	09995135752	21995497248		\N	\N	\N	\N	\N	\N	\N	2026-08-05 20:00:47.610321+00	2026-08-05 20:00:47.610321+00	\N
0c1dd29e-f9de-400e-8a38-2f892eb5ff47	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Samuel Loredo da Silva Júnior		21997269254		\N	\N	\N	\N	\N	\N	\N	2026-08-06 13:07:33.576431+00	2026-08-06 13:07:33.576431+00	\N
6773f1ca-eca1-4b81-af32-0cd378e46029	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Jhonatan dos Santos	17474714701	21968646123		\N	\N	\N	\N	\N	\N	\N	2026-08-06 18:33:30.040858+00	2026-08-06 18:33:30.040858+00	\N
6d251427-82ba-49f2-9ff3-5ea16132fd31	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Valcir Avelar 		21979110280		\N	\N	\N	\N	\N	\N	\N	2026-08-06 19:07:00.02643+00	2026-08-06 19:07:00.02643+00	\N
286cc1b2-56e9-4f30-a86a-180f5f76f679	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	André da Rocha Gardona	01383054711	21990378717		\N	\N	\N	\N	\N	\N	\N	2026-08-06 19:28:48.635069+00	2026-08-06 19:28:48.635069+00	\N
585f5754-0cc4-48da-95eb-f5aa1c5a18d4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Marcos Roçadeira		21987343856		\N	\N	\N	\N	\N	\N	\N	2026-08-06 19:46:59.620644+00	2026-08-06 19:46:59.620644+00	\N
58e98858-df83-4786-840a-9f17793767a9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Marcos Felc Pint 		21994955842		\N	\N	\N	\N	\N	\N	\N	2026-08-07 13:14:46.828392+00	2026-08-07 13:14:46.828392+00	\N
2a65b2fb-d1db-46d3-a786-64fd38b7942f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Diego Paqui	06038659765	21967020050		\N	\N	\N	\N	\N	\N	\N	2026-08-07 15:06:08.88011+00	2026-08-07 15:06:08.88011+00	\N
6339933e-c4ea-4872-aa2c-d994b9ce3584	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Renato Pacheco		21998467992		\N	\N	\N	\N	\N	\N	\N	2026-08-07 17:32:19.78536+00	2026-08-07 17:32:19.78536+00	\N
6abd1720-bcbc-4a30-9d39-6a3fd2122e7c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Júnior (bruno pizza)		21996302724		\N	\N	\N	\N	\N	\N	\N	2026-08-07 17:44:31.883566+00	2026-08-07 17:44:31.883566+00	\N
04b89c89-6035-43e9-aac8-04962f87d879	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Eni de Carvalho Mendes	28650450725	21999735280		\N	\N	\N	\N	\N	\N	\N	2026-08-07 18:52:35.343177+00	2026-08-07 18:52:35.343177+00	\N
803f2cee-aebd-43ef-802b-fbc729089cba	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	João Claudio Guimarães 	46887243814	21971865904		\N	\N	\N	\N	\N	\N	\N	2026-08-07 20:46:12.848711+00	2026-08-07 20:46:12.848711+00	\N
0122a7ca-f7d9-46c4-8e29-0057a2c5ff77	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Ronaldo Ferreira		21996965679		\N	\N	\N	\N	\N	\N	\N	2026-08-07 21:10:56.827111+00	2026-08-07 21:10:56.827111+00	\N
4523c826-c75e-469c-9c1c-f8363b8d1399	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Ronaldo Ferreira		21996965679		\N	\N	\N	\N	\N	\N	\N	2026-08-07 21:20:35.502818+00	2026-08-07 21:20:35.502818+00	\N
d7df166d-9b91-4bdb-a519-416da5749d53	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Esmael Correia da Silva		21994292893		\N	\N	\N	\N	\N	\N	\N	2026-08-08 13:14:55.088915+00	2026-08-08 13:14:55.088915+00	\N
c7079ce9-b13e-443c-8358-aa710b5b6b7a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Marcus Ramon 	12670035701	21998960405		\N	\N	\N	\N	\N	\N	\N	2026-08-08 13:46:42.386865+00	2026-08-08 13:46:42.386865+00	\N
12f0a5b3-e339-4cb1-8515-765765433e0f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Marcus Ramon 		21998960405		\N	\N	\N	\N	\N	\N	\N	2026-08-08 13:47:01.185636+00	2026-08-08 13:47:01.185636+00	\N
bc3296ab-2800-49ff-82ae-3e18868b9b78	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Wanderson Pata da cruz 		21968343934		\N	\N	\N	\N	\N	\N	\N	2026-08-08 14:32:24.908403+00	2026-08-08 14:32:24.908403+00	\N
7a400294-a24d-4af7-865c-98471e92dfef	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Leonardo Carvalho 		21993809200		\N	\N	\N	\N	\N	\N	\N	2026-08-10 11:47:34.837352+00	2026-08-10 11:47:34.837352+00	\N
e97a2ab0-58e1-4bec-bd79-3999dffa351d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Osvaldo Luiz Souza Martins 	11717929800	21970381424									2026-08-10 13:40:14.79586+00	2026-08-10 13:44:56.172+00	\N
234e738c-9db5-4494-a7a6-cca5e0357ee1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Carlos Martins 		21987181065		\N	\N	\N	\N	\N	\N	\N	2026-08-10 18:02:59.586536+00	2026-08-10 18:02:59.586536+00	\N
89c8d185-2089-42f1-99e2-cc516300e786	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Marcelo Soares de Souza 	00035377739	21991572857		\N	\N	\N	\N	\N	\N	\N	2026-08-10 19:28:26.721148+00	2026-08-10 19:28:26.721148+00	\N
0a80a79f-aaf2-4636-bf71-9306ff16b44d	c8659485-b234-4723-9681-1e71ee94ac3b	João Silva Ferreira	\N	(21) 91388-1184	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-10 22:23:57.211+00	2026-08-10 22:23:57.216+00	\N
736ba25f-7c54-4d0d-b03b-2dd93402521b	c8659485-b234-4723-9681-1e71ee94ac3b	Maria Santos Costa	\N	(21) 96626-2297	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-10 22:23:57.524+00	2026-08-10 22:23:57.524+00	\N
42797565-96e1-4694-8895-b3fc6eb607c2	c8659485-b234-4723-9681-1e71ee94ac3b	Pedro Oliveira Lima	\N	(21) 91296-9564	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-10 22:23:57.83+00	2026-08-10 22:23:57.83+00	\N
6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	c8659485-b234-4723-9681-1e71ee94ac3b	Ana Paula Rodrigues	\N	(21) 95617-9494	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-10 22:23:58.138+00	2026-08-10 22:23:58.138+00	\N
f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	c8659485-b234-4723-9681-1e71ee94ac3b	Carlos Eduardo Alves	\N	(21) 92249-5776	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-10 22:23:58.46+00	2026-08-10 22:23:58.46+00	\N
d8c8fc87-860f-45fe-8990-6fef1a273bc9	c8659485-b234-4723-9681-1e71ee94ac3b	Fernanda Dias Souza	\N	(21) 91033-6840	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-10 22:23:58.764+00	2026-08-10 22:23:58.764+00	\N
32179aea-8524-4cfd-a67d-51c69bd54f4b	c8659485-b234-4723-9681-1e71ee94ac3b	Roberto Mendes Filho	\N	(21) 98996-9479	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-10 22:23:59.064+00	2026-08-10 22:23:59.064+00	\N
3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	c8659485-b234-4723-9681-1e71ee94ac3b	Juliana Castro Reis	\N	(21) 94969-4896	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-10 22:23:59.364+00	2026-08-10 22:23:59.364+00	\N
741641ea-2cc7-4213-9975-c6584bf9da43	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Manoel Olegarío Neto	09264306706	2173937618		\N	\N	\N	\N	\N	\N	\N	2026-08-11 13:04:01.308911+00	2026-08-11 13:04:01.308911+00	\N
98559b9a-797f-4c70-9b80-4f1a67ce4557	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	João Alberto 		21994793356		\N	\N	\N	\N	\N	\N	\N	2026-08-11 13:59:18.076087+00	2026-08-11 13:59:18.076087+00	\N
de4177f6-8c0d-4c23-a44f-a3d39f372235	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Daso dos Santos Costa		21993833400		\N	\N	\N	\N	\N	\N	\N	2026-08-11 17:31:40.834721+00	2026-08-11 17:31:40.834721+00	\N
cdfc8003-9858-48dd-8092-5f757783a973	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	MJ Auto peças 		21993918214		\N	\N	\N	\N	\N	\N	\N	2026-08-12 12:41:47.363324+00	2026-08-12 12:41:47.363324+00	\N
28b4f382-aa95-4d51-a6b6-73326c8c21f9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Rony Moacyr Tayt Sohn		21972069096		\N	\N	\N	\N	\N	\N	\N	2026-08-12 14:25:27.2287+00	2026-08-12 14:25:27.2287+00	\N
69f8f47a-c4bf-4f67-a288-0ec0eb5441e8	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Marcelo Machado 		21984770229		\N	\N	\N	\N	\N	\N	\N	2026-08-12 21:05:08.914585+00	2026-08-12 21:05:08.914585+00	\N
53f00aca-04ae-4f15-b319-10bb674f8516	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Maciel Costa 	64391949768	21980378465		\N	\N	\N	\N	\N	\N	\N	2026-08-13 12:30:58.84267+00	2026-08-13 12:30:58.84267+00	\N
7a880a10-d8e2-4046-ae5b-0f28652edf53	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	José Carlos Pacheco	58806776720	21988844826		\N	\N	\N	\N	\N	\N	\N	2026-08-13 14:13:34.363994+00	2026-08-13 14:13:34.363994+00	\N
4f5ce24d-43f4-4205-97ef-5be2fd76cb81	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Devanir Rosalro 		21971823027		\N	\N	\N	\N	\N	\N	\N	2026-08-13 20:35:36.522193+00	2026-08-13 20:35:36.522193+00	\N
f9c8a6ad-8969-475d-9b01-602745488b29	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Cila Lino da Silva	01619854759	21999045148		\N	\N	\N	\N	\N	\N	\N	2026-08-14 14:46:36.067879+00	2026-08-14 14:46:36.067879+00	\N
8f5fbd44-307d-47cd-b4b4-60200753035d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Wilson dos Santos Ribeiro		21975853361		\N	\N	\N	\N	\N	\N	\N	2026-08-14 19:21:16.299997+00	2026-08-14 19:21:16.299997+00	\N
838eb4e3-bc0c-4826-b08c-136b0f53cc86	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Leonaldo Luiz de Lira	02557408409	21966072445		\N	\N	\N	\N	\N	\N	\N	2026-08-17 11:45:41.523438+00	2026-08-17 11:45:41.523438+00	\N
8ad3424b-b360-4264-a21b-41ccf11861b9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Zé das Calhas 		21996263445		\N	\N	\N	\N	\N	\N	\N	2026-08-17 12:20:28.092561+00	2026-08-17 12:20:28.092561+00	\N
2d5e2fba-c3ce-4745-8d58-a62f465abb93	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Aristides Oliveira		21995454334		\N	\N	\N	\N	\N	\N	\N	2026-08-17 19:48:31.490273+00	2026-08-17 19:48:31.490273+00	\N
f31790ae-24b5-4a6e-a898-c9b66eded923	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	André De Paula Carvalho 		21993614745		\N	\N	\N	\N	\N	\N	\N	2026-08-17 21:18:41.58791+00	2026-08-17 21:18:41.58791+00	\N
48dd2e2f-01e6-47bf-8178-7ababf413267	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	José Maurício Rezende 	58822607791	21991953427		\N	\N	\N	\N	\N	\N	\N	2026-08-18 11:44:22.375027+00	2026-08-18 11:44:22.375027+00	\N
d8c32459-3650-4257-81a5-4275c1951d6c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Aldemir Rocha Filho	39210812700	21991963363		\N	\N	\N	\N	\N	\N	\N	2026-08-18 13:24:07.33635+00	2026-08-18 13:24:07.33635+00	\N
0a5fa56a-053d-40fe-ac6d-858567de03e3	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	PHF Construtora 		21970086993		\N	\N	\N	\N	\N	\N	\N	2026-08-18 14:06:31.594888+00	2026-08-18 14:06:31.594888+00	\N
951aad4b-8f2c-47fe-ab6b-2f3cb9f53a9e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Wilian Da silva Nogueira		21968736381		\N	\N	\N	\N	\N	\N	\N	2026-08-18 14:43:35.130687+00	2026-08-18 14:43:35.130687+00	\N
f4c86b23-1d2d-4118-a5c7-f61338b007d7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	JSW Anderson 		21993777678		\N	\N	\N	\N	\N	\N	\N	2026-08-18 14:55:09.888255+00	2026-08-18 14:55:09.888255+00	\N
pg_dump: processing data for table "public.company_settings"
pg_dump: dumping contents of table "public.company_settings"
9c4f572a-e599-45e0-a3f2-f0c9645cdb1e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	José Guilherme Júnior 	05937487788	21998862266		\N	\N	\N	\N	\N	\N	\N	2026-08-18 15:11:28.392534+00	2026-08-18 15:11:28.392534+00	\N
4a95a4a4-174b-4a0e-8ff0-28695fb7a812	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Cardoso Posto de Gasolina		21966510484		\N	\N	\N	\N	\N	\N	\N	2026-08-18 15:58:27.493399+00	2026-08-18 15:58:27.493399+00	\N
49d5bbeb-578c-4e9d-9669-0fe59af3d6b9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Sidinho 		21975279121		\N	\N	\N	\N	\N	\N	\N	2026-08-18 18:18:19.744889+00	2026-08-18 18:18:19.744889+00	\N
9644ebe1-3fca-4c7f-b856-ea67ec6318fd	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	André Marcenaria Mondello		21975420932		\N	\N	\N	\N	\N	\N	\N	2026-08-18 18:40:54.163722+00	2026-08-18 18:40:54.163722+00	\N
b10a2175-61de-4a7a-9fd9-31de3bda7ec4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Gesiel Rodrigues da Silva 	97237973720	21998726855		\N	\N	\N	\N	\N	\N	\N	2026-08-18 18:49:29.076473+00	2026-08-18 18:49:29.076473+00	\N
3af3efa2-c68a-429f-b636-baf65551923a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Niki Marques 		21994754688		\N	\N	\N	\N	\N	\N	\N	2026-08-18 19:44:06.599022+00	2026-08-18 19:44:06.599022+00	\N
25d739a9-fd5e-41db-b01e-52f673619302	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Francisco Faria 		21991385660		\N	\N	\N	\N	\N	\N	\N	2026-08-18 19:53:51.054349+00	2026-08-18 19:53:51.054349+00	\N
7fa572dc-5575-4da8-9556-6b278a421005	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Sr Paulo 		21995851948		\N	\N	\N	\N	\N	\N	\N	2026-08-18 20:35:01.502258+00	2026-08-18 20:35:01.502258+00	\N
\.


--
-- TOC entry 3531 (class 0 OID 24763)
-- Dependencies: 227
-- Data for Name: company_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.company_settings (id, tenant_id, name, document, phone, phone2, email, address_street, address_number, address_complement, address_neighborhood, address_city, address_state, address_zip, logo_url, header_text, footer_text, default_warranty_days, admin_pin, created_at, updated_at) FROM stdin;
b41f075a-4fd1-42b8-8dc1-3d457f825972	c8659485-b234-4723-9681-1e71ee94ac3b	Empresa Master				\N	\N	\N	\N	\N	\N	\N		\N	\N	\N	90	\N	2026-07-23 18:01:31.526+00	2026-07-23 23:23:00.081+00
b5a64b2c-2008-47f9-92b9-5edd45b2125d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Eletrotécnica São Miguel	50115416000123	21975473524	21968161250	feliperebello6@gmail.com	São Francisco 	Lote 02		Nossa Senhora de Fátima	TERESÓPOLIS	RJ	25957152	data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAYGBgYHBgcICAcKCwoLCg8ODAwODxYQERAREBYiFRkVFRkVIh4kHhweJB42KiYmKjY+NDI0PkxERExfWl98fKcBBgYGBgcGBwgIBwoLCgsKDw4MDA4PFhAREBEQFiIVGRUVGRUiHiQeHB4kHjYqJiYqNj40MjQ+TERETF9aX3x8p//CABEIBDgEOAMBIgACEQEDEQH/xAAyAAEAAgMBAQAAAAAAAAAAAAAABQYBAwQCBwEBAQEBAQEAAAAAAAAAAAAAAAECAwQF/9oADAMBAAIQAxAAAAK1AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGIywMsYPTyPTzkywMgACgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADHiNjV4zd+ObMu9za47PMZzk1iuaC1a6lqLnmjeaveKHgvuKJ7Lzil7IuPqqbls2YDqSWzw7ZerPMs63Lmupz+9Ta85syKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGIy8a5d3nl85vV4jIos+uj8Re+GqLJzj0d1kVqsvWtQ83nfLQvd68TVM3WjxnVe9TvmWFTBqGxNZIHVZMpVdV12axQ1+xc0L3dee5rfd08ZId1X5D6Du+b9Mt/VKRzbBsjek688W3Wehr97mQBQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB51ZbvGjznW3ERBRcIqotSWi98tVd9XXZnVXldvFjvL+4DPPvM88bidenXp9TbGRjOOlOdNeryg3Zz5668z+dcq+nxAOnvmt8L37+/h5Yzdr5+vzs8Zx6Oroi/LFh91xrlOR/Nv1yjY649W+FD6rXFb5eJmo859I9fPJnNtm2GkZerPFv3nc8+tQKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAPGnLdq1wuNTXJUOOp2GxO6ld7rdz43yd8Tp5+qY4OXOPQx2ejiWTocqz2Tuq869LQ1i1Pezkr942avWaIz0irTX7HOnGgt2+VjrForWbtlqtYrrvg5mm3nst9Ttud6ubmgNZsELplc+iV7swl8szCxuu9Ono6pfHSnZ2ds7x6dgo9dXJ5mppCt8eiDsEh08tH7LND9OHbM0H0fQ/dPsWNSvvj3am5497yFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGNUbNXiK56lYSv8VnTy99i0rNg6Yvl6ZaP4s8/Wx28eej0xNWDu0Z6/L3wkD6vWS6Yjsm7RULdAXhDWmtzePVJVO5Y15ERM0uzrtFTtefRW8Z122qt2SuXzcNhrth5+3sp1xp2+HXaqtaca8+IqJ68N8hA2THplKdcKPrhtx6cvp2Xt1bN/JguzZsus1OehHW0aJGFcYj1rnef0IZZue4g+/l550novn6d+ava7hq7eOJsdQ59Z+ibqVacWS9ceyzoYz0gAAAAAAAAAAAAAAAAAAAAAAAAAAAADGdMeeTZReeuyJ2Te5F2LXG8/RLx2ru5ezh3Tne5Vjp9xt3b6raIi+WIefXL6U3KV6xdPnQ23ZBanPs0buf0LdG9Wd/NqkrE9+Pfaataat1+dZoXpkM7p1vq3bPR1cFi9Xz5rMnW63WGvTfP2SNOtFW3wkLPV7HlER1r9a50+e4szvOUi9Rd4V/dIc+PbZImXqHT59tZzmVvzzy+u8vVrRSXOVsXD15vDrrmdbs1d07899mJSVxart6o11mODmdPPG+bHx9vD0WL55KSXbfw9BvHTIAAAAAAAAAAAAAAAAAAAAAAAAAAADn6PMcVNucby1VNnL067bd3Njn7ei4U+VzmwUy5wevHA9Nigs+2e6YWfeSmbOnmz7vVtqdgcOODuWN8K5zWypZ9U5K1XzrhzbufZn2WKD5s64btvMnXznO2Xl8yHu4iuiQ9yxvmWxNQ3uWxZF6pjWRee/TZzbM4akOyE13jK5iPVl2pGcSWvtrfa41+2VW6N8lUmuCy1RkrWXKN3ec8/qZ69FocdqN7unz4aJ746e5s16c+j22cfTz6JyEvnT53vfokIyOkAAAAAAAAAAAAAAAAAAAAAAAAAAAHmM6fPJjW2PhYZPfjZjc6NvJt5fQ97sasdrx6iZZ8+BiPfXe/Nbq5KZ30ZxE68s7Xo7W7zcdz+p01bN/fOkXid6GYDr7+HXDo6q/xa5XFRPOud310tc27XVVWXzXCWJXfZP+60LP6qwt+2lpbzsoSW/wDPTOubnuXm7s9Y5P8ARntVtdljp14e3k1tevehc3fhgpu+KM4bNFzvJ9ueR5qzccZsqnHt53uxtaJ1xx7sdvm5t9LXj9F3VCz8992eTo3n2NwAAAAAAAAAAAAAAAAAAAAAAAAAxoy96dFXxqVq+vv3OGwSHDjrrhenU68/Tx79c9vRoxy9nbb6PYpzkvdeiNeeaiPHvPs1bOmQIjolea8t3XW43fnuHBW8a5SPB5zqYZxQBt1mDJgBs6Y5bPqsnO/Nkpy9Jys4oAbI1igHvwJSRrTK7qV7zuw8fmVx6YTzaODPeEkubw1Iw+zNzK2Wq2Z5aW0ZvpN3FceN+no3wno/kmue6x1WCu9fLbJP51Yc217OL2nUxncCgAAAAAAAAAAAAAAAAAAAAAHnPHm7I71T8Vq19PTM90Z18fRD5z45/T9cPU1y4Ne3X3+d1e+Ls5+nHrdrx6fHuQl3KGl+KA35bZBwrpwLFYU+evovmX53i9xGpW87dVZ85DHXacXiirr546+dLlU++NJnT3caVvw+iYx78nXFVlqT6MYM9s4ZkojLfvk+G/n3P9Aguma5nOOkYzgJXoiI82HlIROQhsmYEXfVTe/n07uSf2Y9db9dHPPRp3etFmrTj12+bs2+ern7fXrVu4+vZKRkpfNEw9qrfo+b7tlHlS5dXBsze0dcgAAAAAAAAAAAAAAAAAAAAAI+QRD+pHh56hoG7+j57L9kDvNxja9NY7c2qywHP3c/Pv8AO+XJ18m/p5ZCxVvgxbBX9ON8WTTOAsHZVMZXaQoXTLd/cFN4uKtafep8182Cv7iWiZiLj6r2zz7r/DKxPpxkUlIrZFvjIFm3aj+vNm3WaYzgWuerurz7sdAutI3nww6x18tnjtgfecuKV7uUlOKc2y/NNdyp25gyY6uUWzto3VnfXxzdenXzu19Nm3Hju5e/xK9kC803WuPf18fN1WCZiGkPe7OtPT0++mA0AAAAAAAAAAAAAAAAAAAAAAAA06O1lweOrnxuuwd9oGs2Lm7Y/n6+fm6dc9PL468dPJz53yiQ26yQd4adGrzqZYzZhnAxkbrvQbtlJ+vOOes/Pr3VdyH9+camBXvwyHROZV33derOqZtuWJaPx/RCfN12hdyDbtNnryVn14D37uccvPy92bxee+JS6aoO0Sw0zxcVTVbseqPm+zui9yZ5+GYzqN13KGz2hMdWbrX6b89tnZydfL1a4ebhfT8awzGxzuvb17dzXsNwAAAAAAAAAAAAAAAAAAAAAAAAAABz9GjN4KLdqPlaoqYhefuwdGfXxdE7CdPnyUXE+enmzj351M7NcvHJx/RaVEdk0Yzg9X+q23ncbNGzF4I/XOblD8+87mvZ39Zibr3Lm3TZ8/xm33VRc1eM0UXz1QcH0J8/H0WAr208cvVz7z57uywQgvc3HLI7dubph7BrKNPaIjUv8dySssV60xZ7hffduROcK2TkBiLlCxtg59ojdY4LHt1dGnbz9O6v2Ster4l+3x3fiyA65AAAAAAAAAAAAAAAAAAAAAAAAAAAAc/Rz4sXSbhTy4Qk+5+nxzREbvjs1OrfP3KTlZxYzzh0ju4cR9LxFSfPVbgb/iyhTVk4k9dXH05vvX6q1cF6qNtqt1/6TQ9Ti9Ymai+mc583m383OTG+t6i0+6gLjoq/onNEftMcMpF2ebHHWU7YvZIZuvfr9xu5eui1Ieq173L3A8sxiwcvC+tSV16I855UqHM1mXh5PLl5r1UpfFqpWauUPiz8fVB1y21Lr5bbJcUhnUiOuAAAAAAAAAAAAAAAAAAAAAAAAAAAAGjfzYsJUrXVKmofXLpHWqR341QN2nbvN3oV8oWdacevPTIyb7LUeiLh7hM5TWqN3S9iNjE7oXZs0nZeDl8XqauiWlRf0OqdMw3rDTLCM+cqzjODDOB78ozhipyG6NEa9urJdOyg23KcoNq1RTHrz0dNp4POERnX507caumOXt7+WWCG566ObfF+p9uqHPfBZK39D1n556vNXPEU9alyk4mW567R1yAAAAAAAAAAAAAAAAAAAAAAAAAAAA5+jlxYGuXDpzY+XM6yxHFSzp09udrrHgHuUIjNv85tRdXLqO/gwTuqGyTPdWBaeeuon+LVMEjI0OxYs3ydIrldu3HqVXLGzLBnDJgyDBj15D0uMcWqywXO1nPbHdJP99b6IsGuD0xKwbFZ6E+eObRDx2ceNmmtJCN9PNWGOj2W/wCh/OrpnXdn056h6p9A4951yHN0R3jtkAAAAAAAAAAAAAAaY9+dPnnrozzZl6MaB0Y04s6GnBuzoLuzoRvaMm5pJuacVvaEu9oJvaM1u0tMu1BQpbIOvY3nq58d+pwZtUpm1eVmojNlMVeJLFDcTeTLRjKMY9eaMjBkx715ixRPPOxsnaTKZtojd/VlE1C1Z3KlljbOMjDPo8M+Ru2XKNe/Ryc7sjcQ2nrXtkNSL7OHBv8AMnGGOzFkzfEBq4rBnTG7HqLBOfPdudXiK4prKs8H0HRVFWeD1lN1kXro+eyWdXD3BTeL3edPjU6mhG9oG/GnFdDQN7SNzT5OjGnB0NODdnQjfjVrroc+I6fXN7rf74t9bhvLm6dEclGvtJxrmaZPpnlxJIj/ABJ4I/EniopK4IxKCLzJiLSgi8ygisynmIv1I5IzMiI7XKZIlYZeWozEpHxI9NP5lu0BX8Wb9OM6gUxnZGt2byMxN7SvrPsiqLhslpa8eyh5v3CU8bk9EaUSXiP6DV4m++Kt5ue6WjZvQoq76imLbpsreZvWRCS460Y8qk43CAru5daJrg5AZVj35GPflGzz5wZYzXVIQuMrNms4WWjPCxnGae/G6GZD1Eb6ksLG+pD0kYk8kUlVRmZTBF+ZYRaVERiWEXiVEZiSEXmW0Ee1dpeNvnbz3tHTm8ey8VdsnFy3RLRV9/XH0Dl6IDnqXzXNllh9RG4k/cfuOv1zbY2tY9tfk2NPqVr1ctdGInwS2uB57LErnmrRyQGs6OU1M7sfQ4pHRb+LHSJ6d/Nnp2b4fnz0s/qo6Z0uOqqGrPrrmZqe1wqblcRhqQzHZLTBztL7fJjzf1xpmZ+V52Lk9Ojl07fPF7mujzr9GWMxnPnFbM6cHTnjJ2U65/OO3LmlonZ0l6dkRw69aE8zvOoIs6g9iTFC+mUHr5OFjPSYZD1iyR2b90Hw9MviI9Tct5jPRI5jexnbH2Kkb88bt0+uubH1VX3m2vZVt0tn2wHRE1sjuw6M6cZdLVmvbXg9+deut3nm02d3mO4ydzXesn4eXpRG2Kv3iuzp4++XI6ZCOfR28PPVOjLvSdy0SlFukkKl4tXbH+klt0J6Wd217EWT1WRZfFcFkzWsROc8T6s6dGrxWrl6dFecbM1p19Xg5GM0s9X6ovlPvFR83v5s7tePfhsxHlnNx5zs9ManT7TjSWy4h01khNu/2s388uVN9Py99609+K5XRy68/RuazjLGs5efMbGnEb2nJtePVZ0b9Eun55bal25mcbXbZwTfDrVHvPD6+tsLrxt8Jaq1Oc3o+PS8nbmPcdl74+Lj1jef374/W052YmvDZg02WCtm/DWa3s1+rwPfnaY242Hvfp9RI74tFi7Kt6ls/qtiyqwLN5rnqJ3xCZqX5+DzWzTn2mZvSzeSp+vHSSd0j+/lvPZr2dcABTk68RwQVgzy386zYK71xb+qiy2bJ8MvIRVfNn8FcxavVVNbPRUfVvwVTxbtZU9Ns5irLL4K1izCtLFrIPVOQVmvJpjq5ZuLpUbZTvN7/flnl7s49DqlsRnb5PZ4pWO3G46aoSzaa+qb310fSMUS9c9Vvn4rbuSnJtzw6+9hrBjxXnk0wqWHXSdOpesUYXrZQcl+UbtltvVXZLKtxO3X3yx6Vd9nbC+f0cHjZ44fVyB49klJCDs3b5vzJv0ejy4tkNecXmrW7X5/q+MveO3gzTVt1L2Tkdu7fLpA9Hm9+90/lXMWXMVvFpFX92jYtT3Wb1FY3WbbVUWwVTNl2FW2WfJWfdi8RH93LAk7UtLUWNZM607tfaehvIUAB54u/GXHBT2jnv5+zjrgldRHZkMkb6kcEakvRGJPyRySEYkfZG+ZP0RWZAR+JHycPrq5Azgxa6pf8vVbl4nzfU85Zx6c4x7ubPUbp869PxuUz1yyGAZ85yeejRg9fSPm/wBM53Rv8e+PTLDWc8+/EQlN+l1jpmtt+npGCjOTy3+Y1PfmmQx3cNii2VWyVfy+/HrHvn7deOjWa85Lm11Sw9PHVoi0vR86U4e6A4e7xnPnl7/TOEx6ZPPP081WOMnan6Pjw2Xrtz8ve6OZ25OHMl5I/EjkjsSuCL9SXoikjg4EgI9IiPSOSNxMQ5i01i+Z1tz5kMvPs65AAAAA59PTz8t0Tksdb3i899Qtubr9V/yWNXuwmPcV0R3Z4/cu/PKN2rRpN6H1VOaa9z1ZOaCxZLwG/VZ4YadH0an2/lqvcOzX5/rt3jVN+urlmLz7/nn0rX3+V88937UtM6LP5moLZYtGsUTGM9cevOcD6X8zvGLKY9eOHTLAyK07sas3oj93rUgIq8bN4+Z4+kQ25UNvbHanRp3ShC43aTzeqxesWNgpKN831fec4z26ve73vyRDDHszLRPZrhNbPUL08HDo9uX1PPrHe5+OPu4aZwz0aN+zWbR8/v8A819Px8Zw6TslIbGbat1S3ZWrNa3S2TdB98Seeb0dDTrOjz48Wb8cuo7MQmup7ZBTEuiizMLvPXeYGxY366dO7eA0AAAAAxw9/Pm8VE+hwmLU7vSd/TNthbFx87Ge9WzU7+qI2rL7ITGU2ghK6ozTXfo48WObbrrXj0rXr96jG7VaYmHXEcO8T5xjl9XZjCXBis4xizZnVmNrT6J+Pmaj6PjxOcZ7c2cZPPdxeY+maaZcuO87NfJz3II/e1041+0a/ZdPnowvnfzapJCHkOjfP5v4vdE78/PZx+q+i7NOrh1gtevzy+x0eNXhLN0et3T5VS8+dfP62/dw+izQOrXefS0JvtsXH37+XW9HMx9Tp9cqXf3RE/rz9lBt9N9Py84zjc3tqPO/X7jr6ODfEl2QOxbDvrHuLJ5r/onNcNglY/Tg98+2SNuzopByeVk1Jfoxv576MnbmCgAAAAMZHJjo5uWqfEfQanqctxoubLtw8M7iwmLF7Kziz5qqrT5Kp5tPkqPiyearSzbEq2LP6Kl5moXTHfwyJfKxZ6Z5/b4w84+nlkYzKSOvDWs2DXrjC+5XVcc3Tr0zFl+dy8H1459ec7ZzjBnz78nn3jBOT9DYfSOWkSeNTvjTJ896d/jmz07Wr016eVeOnT5kkaZc6/289Sw99c33jl61w9XBj15x9TGzz3udm9ade/kQHBNwmPr4zhO4wJjmnNfM7ObRqvCu5xnP2TBVrqd0vz69WJyE9Hzh709+rQxaziz+ir7LJ7K7m1ZisbLJgrSzitZs2arfZM6Ms5g4Cuvhz37my36tvLfvr17emA0AAAAAAAadyI91c/LdXgvotY1IHONm8+PWwas+hr9esmtsGlt9GlsGrPvWZwxSwV+4ZS1Nstb4fTzhnHuwYubVGz1O6fEhR35gGcnlkbPGOg584kIj8z0Aes+N9ace/J5esGMsEpaqD34twxtq3D22RWmfRZMVwXOI74jr82pScZZ+3OzUyzVXzfSzjOJ7sWGu214uTVH6e3zbJVbvTOX0fAz78bvFkvk3VCVrvb5V/hrDVefr4Rn6gHq7VC46+XQo/Zp9Hjzhms5x7jGPeTw3azGNg1tuDW3ZNGejBo8dug05Tx6sPpy356c795DcAAAAAAAAAefSOGKltfLfz3v5NfXH0vVx6sWQV7BYtkL2R3eNHNG/EZz2zWqv89T8Lza9TQ9edR9Bon0jna5EdHPx+1kxns3aZK8LT85vtB7fG5vUhv6SHTm2K8snRFTk7ZszuO4rPRWY6z1e+6SEfycfH06oa39nTl88X3jvOnLV4sq60dK1C0yfBnrmFxnj9YYnbPrx23jZarb/AJ52+LzXujfSdSEherj4fY9YYnf3c6vZtfLomjVj0eP6ZWpnj4emAeezH0u/u6qJ0+RzSMZY+vO10q203h9HLGc+8YSRsMR07+RSMM+jz7/GrdFg311lbd9O6M21Ygd0s9sjek6mnRZ34i+GrDmt9xM0S3UKxbKxe5rPbz9aB0gAAAAAAAAAAHNzyHBz1W6/9AolnZePm9lT1y2CGl0S0TuJvRF647NPP5rzy7/GpzaOzgrPj0Je5QHfy6VjPnPL7eRKn6+1wuWqonntWqtLuw64FLM6Ywu3Zyy9zYPnVzpPX5m36RSbrLVOLLl9nAm/fTxZZkcxpnu085cmG8sFzgZWblltfNjKbv5+/kkb3WJfG6x5x65fZYeVsG7ohd/HrQ78rdK1e5cd0i0+dOO0PAZx6PMudN+h5vHWpqG4fVZwnqz5zhmz8MvXOvxa/nGe3Nu09EGz0Y6dO2JDoj/WUzvghOaI3UvRz43WbZ/ljs2KiG7pJqyeffLe3oxnrgKAAAAAAAAAAAc3SiOjZLxy3QFirnXFknfn8lmznDJyUVbVbNRUddt0lT82rxVX17depjDoLvFWKnef18+M+Z9L084T1jGGfTz7ucNvtnmx2+2Y9Je2Yqz8E+4Vmvd/B6PJaZbV1celNTfNj3xrt1N6Hvy1hjC+mPRjG7YzyJORvGGnevkebupWjl7cMbPFtsmK3YKvw9fM609XJnr9XNppl2+c7+dqznb1zn6L8y+g87uoElC6Bub/AKNRrzy1VODdo5fWywdPWPOWLzSrrUOvyYPOM9cN2mzRBLdz5taWb0Vr3Z9kVjZZPZWd8/7IyS5q9EpVmOkzbuOcxrZ0c/emR0gAAAAAAAAAAAAHmOk/OUfFSnvnug6fold3mu7N3NqdPnQN+eYdDm9hjFLHXfoWLpqt24+HorG6y5WvbpbluPG/i57ia91nkubqoeqr/wCaAsveukYq6c9TWZMbWfvpLF+gdPzdl9J1/PuiW7YqW/KyK9lZ/wB1rwWrZSuWy+RVR87knGG4FTtw+d+Od+i8tBxL9B8/PyX98/F1pRubN+7tIGTjcUM0x68lhtnzru520+IDr567ebZ0zcXosO+a18cr61y+ZZ26e+M79GDqco6scw6M83o340ZOnR5wZb5YhbPKOe/Ofchc59HSAAAAAAAAAAAAAAAOfoRwZ7dGNaq9Pe835ykY7rjO7RuN2mxzONfPFirm8yU5U8RYOCOG7ThQUAdGY5kj2EEnuWI1K+Kjd8v5ji0SHEc/TKQB4GhnJ5esGGRhkYZGHryZYyevHrAxkYZGGcnlkZ6OWcjTLRevN9R9r2RB+908Urlu0PqQDt11zOvwc4pnA39cajo52Rsxkx4SJHdFqkMaqOq0Vqzi1mpiyx9xxo8dGbz9HRnpnDLUAAAAAAAAAAAAAAAAAA16unVm8dLu+eevnOLRX+mOeUi1WaD5dsZx3dpX8WHgqNevIy2Gv35mzv6e6lYu6Nxjc3TtcyWWR8dfO6ubpgjV18kPuZM6YZwM4Hr146Y5lmj5YnOzXYxnzWWPceGVZwxDMnLZtZ9WGsWZZxWMlYBMeoTvy3dmeeWw7WMtenFQ1J3xA40tXZS7xm12H+j/AD6zSdVcrdpD12nDMzkpjUf08FblslfjW8jqs5ZGelcaw190evecdM5FAAAAAAAAAAAAAAAAAAAAa+fsZcnjfr57iK7evFfOsd3npjj6teCwyVK6M2zxXbMY1QdV/rm8wk3CS2pb/nf0Cm5seNQYqwWOt2XnYrikKfZ5N2mrPZyHkkDg2PA9eMln2eYTFt9S7LZL81T0H0zusNY2Zvnw96nm09Utz1zQMVvSz0S4U7QzjUJHhNec7TQ7OMkZypS0TfdWrJi0zk3aekCvUjGdcX2rWCHxawSe5xStkY1G90NCljhY5rPrD1XmU4b7LwSWcc9ePXTt3nx7NwAAAAAAAAAAAAAAAAAAAAABjOuPMTGQ+LZPMJw1mSj8aklx46Di1yGsj9mBKylUxG7dyYqzyVcmc2peLtwWVnonewSWrkxYKIzjpGcZLJO0Cd825fVKe/Pvgql61dJ89z3x/t5dNopvTm2Cxx2/jvoq8102fOkzF98ermkOGyI95vvXyVnrn1rx76Z82nol/NuP1yPjz7xr1VDtn1xnr54MVLzFalsM1+5V6o42VrmemxZu2oWGimJmF9akrF+cmMug0b9mg6OfUFnrCPomfnsljV89Q8lqbmM7gAAAAAAAAAAAAAAAAAAAAADTu8ZUbRZqnLZ6rIbSK9S8NqMesG2VgvRZopI41W/Nu4rK5js5NTzJRws/fSdkXb1StUtorWrGo2bNB68+9xzZ6uYkrd896eV6eeTgtuzkNTOGDdLQaJHuhNi5t7r5a2cvPqxdVZzp9HPLGdG/V5ju59G6LZ5jITjr14bu+dOO7WaMefZ4kOfmLZ6q01m9klF64meOAja6eVnUznZMRCS07pzrzAbI7U96s7bNsvBXDN2eNzneLjmt2pRp2cpul83U+1xuHSAAAAAAAAAAAAAAAAAAAAAAaKBf6Hi6rFA4LtSOqeioYk4zczgBmpCUrWMrlwQ0jnXDHW/xVSTcbrPKyrErGYi+eadL89+Yq3dh8967PCazxeNWLMY3q0+sYrGQxnHVC17dHLXV45+WNlb8TvSQOu41CvPpizOGTzn3sNfRq1HZozJywshP74jZSPjJZer+PGsjOmGeiOdMystemJTizZDkguAkYz153nHrxIHN42bTvn87eO+CqdGnph2+tlTHdWrFjVKtXHC6n0HZy9VBqAAAAAAAAAAAAAAAAAAAAAa4Cx8+L87l4iaSc6Y7bz3vo8773mtY9Ok87PCPWMjzjODZJROCz7aluzbJG+pTNq2m/cdU3Fjj9SM7+PxZapf597zq9xMfL5tf4rp5uaZ6mo3c5cMVmYhprKxc8BqxrvgTpmUmalLZs5XOvQRmfOdxn1IxGbJ+Vza7K+uAmY+C5CWjdbUy6e8hs2iQzalLTsdL76oKNLFGQvrWdnjz6rPrx7Gv16NEnx2mIOej9mbYs6tnLfzzXIR/o598tW7Rm526tUTVDvVTW3yNdsR6HTIAAAAAAAAAAAAAAAAAAAAGObp1YtG92WmEh1Z35TPNBF4+mxCkYnYHpn1nzimPfkx71oYKZxvjx3xuCyyFKzm37jgM5sjxb+tYLluvWlA7Lfy1XszWoh+KwaLK8m9NkTmQ8VxOz0cOZDfEPmx9Utbm5Jm4wxL4j+9ZVvdx2VU+mc5TR2xvAWvlp/kskZG51n35xismawwjPvyoYj28+j1ZKtMRjn895IzNW7ca3VD6PCVUZmMbz39nBY8XXW5mslqtEBYKDcAAAAAAAAAAAAAAAAAAAAAGI4qDe6Jm9nrxussEjH9XLfvnh4+zohbVq1K1jGOk9se4a8q859eYtc7x+uO9sFEzOpVvXj10zZvc1556qMTu1dMtnkdnVE+YntlcLattRRdd9Dwt990DMX7FAyXnNFF48UoXDXVfFlo1V1U7oiPSd3Lp2Vr9dvGec2KTimbL9yS1ayRdqzaBxSUf0zjLFYPQzhGce/J6x59mqZiNxNb/AHtxdUfI8ZMd1Os2b1audL0R/rksio3zNdM23t0b1DUAAAAAAAAAAAAAAAAAAAAAefWIiKff6fjXLzdHNrMlz6LNLsmHjnrxyR0LqcLHrrn08+owYrPnOIsdo+a2DF31v6NBFUlIq36k7559fHdYibRWO2J6zOblvqiq7ebPnWu01bpl78d1dHL9A5ed+f8AnPf0mrz9Cj8Wi9vj6BXzznskNZqlrTjGq1FW2G1I+0QF0ih9vPvq20G/ULNuOzR1ZUritHD1my1VK2c7Ro+SjOufTHs8evKjPkznzg9+vG2POub65YKyVPYSnB02CIjX1RUOL153MZx6M3rgm8a6PZvIUAAAAAAAAAAAAAAAAAAAAAB5g57gxfn8nz+7OSU8ayY5OCTzc89kiJavI+9e5H4sscRPv3qsznxtJ2Eushiwk3jxi0O+VO4aQqX95vDSfoVB1n6BDzMPnVL+kfN/pG8xtIu9JrPZx9ep9A8+tPn3UJjdI7m2P7OPNqN/+e/Qt5rOXqrFRrzRpY31a/W8w12pF3xqkbdfrUuNBvtFzbX3x+7NjIPi7OuOu5Uu6c9UnVeuSqzCz8BvLPlpnOZKI3qm+jN4O7MbLK8td0Wb9HVPWVnFkjTg89KubEl1RC2br7s6z3Z9agagAAAAAAAAAAAAAAAAAAAAAADXsRG1248vPXzzoudW1OWXjNhaemIk+eoivXivbzyStYxpbOLg7MuTgtGKrHRIR1nZw6MVZp355nN9SUTnU+lUuX4eerTGxdqj5n9K4u8h6ZP1/pHdx91l7hpunctWzV5gpZY92U76B8/+g2Vj1nlq20S91vNk+jl6paldvnP0TWabtteZVBstO1LtJ1bxm2zXSOGu2Wrbeezjz11x5n5KWtSUrrzfPTDRhZYLg86jEtMkDNdu3FbfXQcXuQ8HDr7/AER3qTzqcvUxqZFAAAAAAAAAAAAAAAAAAAAAAAAAMZHJwzHNzvzzu38OpI9cNJ5vbzw2g38+26VQFyhbI3vi/FWXvpvrNtPDyd0vJxWneUbNw47K1mT5NTn7eITfLGoZ85099fCj6JUohGWM1eNtDZvXffmyyz1rzirpJfOGbf4Ou4M9fG1Jnmjx687ug4sTPZLWuq1b8q11yvFLv6oCNq1xdeandxZkrIzrnunN4JR7zfXjt664evc3kKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAYyiGpf0SExqB4u/bqc+rZOx7k8yER23q0rxQNmzL898fQoLWaz57OTUzv5thKdkGlsvbR8ReOWudEsjzY3nFqlukrWq29BR8XnylJxdclKxdFUxdfMtLXL2UvZdPJVNtn4yM3dWk3dMVoLN5qXIXHgreyyW4tfPZjyUb5sgJid941p3OrN58yW3eeTqy1AoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADGjoZRvqQLFb+4mMmgDTuRy+O3Xm8kbLeM2mxn0fgqjb5CK3mSzGdh45bBvzat6k4zUxj1tNPt5NvvnHbsjskl6jPcSenh9G/Gj1XrTnUZ87hqMnlMyMte6+2KTq4uf1XnMzOy1mWl/fPWnHR16nB2dTWcZNAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHn0ObV3YzeDnkdeLVIP6Nx1ReyRiNZnuuodEshD2fvim++6K1Nmvdrrx78SJx2bokPJ1omu31r0c+T1hue/erUbdc1M5sLPR8BLYYDj96z49TU2sLMdOeetGzr69Tj6/beQoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADTyyDLg55DTjVZgvoemvn3XKQ2s2TqpvfLvirfulpDt495tkvX47ydZetTte78847rBtCWHmr+bYa5y51nzsm5uWFnM7ca593T1bzzdOWoFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAaebvZQ/vs041WIX6Fx1RpbEXvNz4qzLYsdou3FVcs3bAROVuOann33WuWCm97Gnrp6d55uk1AoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABjI59fZjN44qY0c7SuH6FCblcmoXXqbdawxDWOW089+vO2R1Obqy3kKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAa9iOHlmOXNjIOwdONcW/wASFmjr2umQoAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADzp6EYyUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB//EAAL/2gAMAwEAAgADAAAAIQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABjhjCjgggAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABRtInj+yVYeambnfDBgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgDHAh5bGCOc/LMwyy/sYAppxQgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD9ByUGvVtIIadc/OC3S8RzxkX8+boSgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADbiuJyX9V4iXRsqEneB5VzhiLeU9IzyeiigAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADXi+ImX9axukJ/YaGRS/G9IrWG6jNyxPJr6ATyAAAAAAAAAAAAAAAAAAAAAAAAAAAAABf9dRJyQicbmafwdLS/4lrzzB6fbsTb0MF9lhVnAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFL0iAjgMwe2xY3QuNup8+o+iVSV41oq5HeYagA2QAAAAAAAAAAAAAAAAAAAAAAAAAAAAvJ9wWr88IzEytGw8TzPz7zTj9c6cYlV5AgaCC+/jgAAAAAAAAAAAAAAAAAAAAAAAAACy1AYOJxjToSAVipHOOKCubABPiDIE97riuseYTVbcTwgAAAAAAAAAAAAAAAAAAAAAAHCZJYVWH4luwOVuaEGBtXD3YONIvABAEOre/SYSaEw3quQAAAAAAAAAAAAAAAAAAAAAAEoae8XKrNr5KFzChXlbzQPDFwLGLQAO89pv7uLX4Ja/1mQAAAAAAAAAAAAAAAAAAAAAAAAMzBRcbNR5GJHPbDovGAyAA9HmFGDG48Kht7W8gbP6oAAAAAAAAAAAAAAAAAAAAAAAAAAAAJ5QFHdHg6NGt0mvGb/MjpTn32at9zZsLIZkVGBQAAAAAAAAAAAAAAAAAAAAAAAAAAAAEn/IJo3LtOj+7Tk4VpZThlf52QVGNhbcPDxzk63AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAuHxy9PKKGSE55mm4FkDJOhCugS/N9F3vFrGQvuQAAAAAAAAAAAAAAAAAAAAAAAAAAAABs1AGVRJsvnDPke3V2NCPEJMS1qcamU6udL3hpWwAAAAAAAAAAAAAABRahhUZJig/Rh2ftl0cNCs9BtKCDrxj06EOFLC1sCiCtcIlBbO+2DnTy7zfcbRb3X+Tgl41E1wRXbDAR7+U4i5AqqGgFbZhIPCGM0oDMW/GLjHjIBLpiFxLqBhYCR1eBODeTJPWAwjsEirYQ1bepCp4d1oVHt9nMi7ODVo58GW4ce54gRznXfOCOPik8ureheDypNHTjt4/gApfB2GfKsHCj3fzGPKY/Pj54tXooA5ApCgxyXn9L8xP/wDQa+paPNy7RKdbxBrZQ/M1+kIAT5GpGrA4JDzzJJORgINbPQ98+Ji3IjWV7vGPZRzr5O4quHvkezz9tOjIxggTwBcpUIAADdo6aqboL7Bz3EqZf45SrwzhDS1LFftJzi5gTTZzq0Svgf4gd6RKElS7qo4Jr5ysAAAAADyf8F0uJRs2ja/hI2XzRYpAgDDb/EGR2RAyo83t471iEdyeGGSzvYZq7EOJ4fysAAAAADSvQ/8AAjzSPdsqiZVWx5D8FAs2q04bawn+Pm5g3kTbVRTmDuMUMff8mU+q2BbvhAAAAAAQpxGnu0emkrbsYZWymsc/lkA0gvFPNCs10KVB+dKr2TGIQbb8YwkCIegWEYkbAAAAAAAASqOmy6+e6CuEzpa0C0sU4AqsAQgQulrmq5Okrv2LD3K8Bjm4qKk8q6walAaAAAAAAAAAASJ+FZinUIw078l+fsvzmv8AolDy8sO92eLZEIdryjf8CQe2PrQ2rNUN/wDZMAAAAAAAAAAAADEdjo4aGDq+ycRPw+/UfLnvufYF3bg/FmRxyHBDDKRoGDbhXuuSlujWAAAAAAAAAAAABCDXLwMvAZoPRF6ghhFij0FksecYCggcOYHaI+zz77hMQBCIBaLGX3g8AAAAAAAAAAAAABMkVppL5BCPPZDMCHR/T4XyOz5MRLzBgG13Obzy09oOm4646rJYnz2AAAAAAAAAAAAAAAAJ6WYbL2dorDwITNyVN+QgwgzDTighCQggg6JWIbjDLpoorK6LJjAAAAAAAAAAAAAAAAAACBZ84OtH4JY6by0A2BTgYD4S7AZq5aTy/wA5lWoZK28ycMOkpWAAAAAAAAAAAAAAAAAAAAAjCki6JaRAy6k1/wDuUEkoaeFqhNyFjKpoQlrCiUtGr/lOuoAAAAAAAAAAAAAAAAAAAAAAEezcnDsrahEQTzvh6gKRoh9ANZpOPrCDB3QujHOhvuk/oSAAAAAAAAAAAAAAAAAAAAAAByrjPkdt6quWhIhUP9AXmzKGIVAvYeEQpokdGg3CDuL0fWwAAAAAAAAAAAAAAAAAAAAAAKeqUPsIfAMdNdrtb/PIOixZAIsvlGB5t2NmKNBqgu4yZQSAAAAAAAAAAAAAAAAAAAAAAFe0swJilvUb6mmtEC3LD9kesqFphVxhaZpN/tvvb4+GlTFgAAAAAAAAAAAAAAAAAAAAALpn3EuVMDqLuY23t0XPU4UI4o0reKKSq8lHpJmkTfTLfu8wAAAAAAAAAAAAAAAAAAAAABrUae96InMqmqhGrm3KVPurvp3HyJgfCEZPAiincTH/AHE8gAAAAAAAAAAAAAAAAAAAAAAbQsAqBw6j42E9o17ef495WAOKjXpqPB21IBhw6CbBtqr0IAAAAAAAAAAAAAAAAAAAAAACGvGV4ABbrttDjuImTTf+u/XiniYzL2XRPSg874NGkczAAAAAAAAAAAAAAAAAAAAAAAABIfboGWS+FcFiV4qOyjSzls7YbOqm+avWTTDgztnZZGYAAAAAAAAAAAAAAAAAAAAAAAAABDMGa9pGWcCWumJPgInrL1myIL1ri9fBxU0GJEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAKhCtOxS1aIDUI4J7d8kJI6GmULcf723ojIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADNDEABKTEbFX6TKoY0cPkJorxexxriMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABASFjMnPtxyRSoSKSNh6yAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABP8A4jBgWY5QQXjm9SAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAjxsxzt3VuaRCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAnFhL68yAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAASV19QAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA/8QAAv/aAAwDAQACAAMAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGONPBFCCAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAF9HWuaQYcPYh+5WMNAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGM8lIgXuRdSRIYeY+t5Szf2HACAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANNxFGlM2Z2ZfJ6o8jc5AL02GEIHukJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANfgOnW4VOuQGV2lf8Kur2UovdXPap0gHAJAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAM7HBA86SAyYUJJVstyKHmIZO54vlH60YCD41vIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUgaiNTImzwVVmv32rdBLCbD7F666h+vOluHkT+LAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHTioEX/nbG3qI8F1JlzERoPZKlLRV70mX0IiZoHAAAAAAAAAAAAAAAAAAAAAAAAAAAAFmZE05BxUQX2JXgknJyhERTTXPGPOcqYom6lp+IarAAAAAAAAAAAAAAAAAAAAAAAAAAB0qmpK9IBnH7YHZcs0YUxlV04G80cOo09xlrB/ADd4nKAAAAAAAAAAAAAAAAAAAAAAAY5nxCbf8AmelKvXHNGFquuKXuYMyD+EOyxsm1qmSoB2wW1wAAAAAAAAAAAAAAAAAAAAAAAZ7jRp9KEspFCDilhGzeMH4nHKAfzP18s1Qg+JsdeekwMwAAAAAAAAAAAAAAAAAAAAAAAAAgLKps9hd/JCHTZDjCG2908YhCIYLYO6zdDYCQ84wwAAAAAAAAAAAAAAAAAAAAAAAAAAAFD13S/HFaTGEilrq2nookKOZKpSVF9OQcJIuHwTwAAAAAAAAAAAAAAAAAAAAAAAAAAAAF4BYnT/BoJkzX6VHmVseQ7v7dDm2dnscSF1aGRlgAAAAAAAAAAAAAAAAAAAAAAAAAAAABxVjK6cGP0Xt6lfoICuBNIpJQg2xCb4IgATc0eUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEYqaXsM9xkru71bIC9PGOJGHFhFa44UZg2J1FZpwAAAAAAAAAAAAAAAsYlnZbAltyUu/ZI/Lo88nTHlGCKlptqbEJIIWWD4jSiTGTPsut3cxu9yITJGFd+ByQggy70shEkK07Ki74aihxX2Es4BSCZkFwUPHZrsr5MsHa0LNptP3AbLr9k9FAd5cNDdxkw0lR6rWgdo9cqCba1KxyrfrJuZt4Q4url7u3VCdTZ8dOdSPOVH9aLChoEBQufkPVZamNQAmzI8p+BInf7V1DeSFIhlgVzgKcg0J/nfx+/sU4FtQkdYFu+Vq5mZghzGsXU6KORhPKAgBytIGOe7FhuMNMItK1nvo4EgIgfTIePR4dMnYcPykCmxuqH8mGJPQ9aqeNPKJhjsfAgAAFrekFAilgM5QJNdmyigo2CABCHtfw8qnIEpJN0x9WifVMOmq7WJXLDcZDkGCNguoAAAAAJJ6CwnhsyCKPfjIqTIoGoxCFKSTwbibwavisDgAbqdAP+lPBILipF2PpaAbnvoQAAAAAJlfSqQGnCxbkTY2WSr3BYnXCKhIZgplLE6CpGHI6cMd50D3YlMooYrKrPnqu8AQAAAAAEE3QZO22UfSff/8AYTBBxTbOwwhQ0rsz+hPtLj1QwOX76bARuLCLrC1tBgNecwkAAAAAAAAML0aziRy1VRi3FrSyhygDjzMCDyxTVLUTBTHeXYW4r0XnSTjNU/PATbSREsAAAAAAAAAAJREnY3nnhhhpB9N+s4uDmx+e9uXygyD0wWox31XvLz0mwCpvpMsCJRPKsAAAAAAAAAAACU+vc5elS/K5LcEsC6mgCtA0O7uN7vi48Ci+DYLUfH2RkiKi6cG6mxsoMAAAAAAAAAAAAMWRR2Ajk5LKT7OO1D3tXkJajZgL2DjA0vRc98AyXTAOyguBedtx4RX8AAAAAAAAAAAAACJBaQCmjQr2RSYErgY0AyLB+dI7X1QNBn14y4QQm0QKz6ZP/kgUSZcgAAAAAAAAAAAAAAAGxL01Q1TNcwD7NYUZTbjDjTCTTxRSzjAeap8nDCRz14onZb4jKDAAAAAAAAAAAAAAAAAACSA8XUwRabga5vJ8YjDzGh6DqA65vIBC7HxkzkfsbPmyDWIVYAAAAAAAAAAAAAAAAAAAABKyAVB45f8A0iUBpHA7KCvAz+qIFEmtlJffMcg5lbQZaNtxgAAAAAAAAAAAAAAAAAAAAAAQNGMLpzvHofDfWebn6Qy43Bd0oK0Dxh8PPidxvpS2W/LIIAAAAAAAAAAAAAAAAAAAAAABHE/i4IQXmvGrd6j3hymqwASDI5yqb4Glcqjaj+/SP1PoRAAAAAAAAAAAAAAAAAAAAAAAeKTH+sTPw5wmky+Xf0kBouhUeappqIYt4rh6WpWpsD9yZoAAAAAAAAAAAAAAAAAAAAAAA/qB4uSCiz3tIx4CHJUaCYpMI5z1+xNmQINiKKzOH/K5tyAAAAAAAAAAAAAAAAAAAAAA6RqDRg4oCArqJPizMzRDizTl3wbHXg/dKIOo261Js0QJ/wAAAAAAAAAAAAAAAAAAAAAAAAiCHDzkPrCuhMspSYyd1OmQ3jUvzwKZeklLJlkkKV7aDciQAAAAAAAAAAAAAAAAAAAAAEQnq/P+CkFq0GCo7kBiB6ZvnBHd5EUXPSFgMEBssEnlLmIQAAAAAAAAAAAAAAAAAAAAAAFXJcqrhsogKVeo9I2633LqT2OXosYC7hsoCyCQpQ8DUegAAAAAAAAAAAAAAAAAAAAAAAEVoXSswj6T3ozgBKLL/wDnR2nOhcG4TZa7wYIhLEbOugUAAAAAAAAAAAAAAAAAAAAAAAAABCfP8xHm4R/ajRBYR5fITED1zOwF4P4cxDp3hAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD7yANIYqgno2WHwJdPGrIlZrYDBd6ggdsEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABJEMAAIPXDJim92tma0p5FnJ7Ic3diKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACCN8rLfBufrEqfnK1UcZMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABNS+eg7nq/A7ERb4IAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACEM9jdj5PdvGMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABBQ/GS9avEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABLRrPMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADKAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD/xAA5EQACAgECBAQEBQMEAQUBAAABAgADEQQhEjFBURATFGEFIkJSIDIzQHEjUIEVJDBikTRgcoCCkP/aAAgBAgEBPwD/AO22ROITiXvONe4nGvecQ7zImf7vkQ2IvNo2qrE9Yd8LBqLm5CcWoboZ5WpM9NcfqnpLPunpH+6ekf7p6W4cmnk6gT/cr3h1F6wayzqIuuXqsTU1t1gdTyP9vLAczLNTWvXM9U7flWcN7waQndmg0tY5wLSnaG6leoh1tI6xviNQh+KL2h+K+0/1U9hP9WPYQfFV7CL8RrIg11R6iHVU9ZxaZ+0OmoblDovtaNTqEORvF1FycxE1iHZhiLajcj/anvROZjapjsoi1XWc4ukT6jmZprHSWa6pJZ8U6KJZrbm6w6i0/UYWsPUzeKCxwJ5DmFSDgienfuJ6Z4KLA2CIho8sKQJrfLXh4BAz9ILbV6xdXaOsX4m45yv4opwGEXUUWDfEbTU2biNpLUOUOYNRdVswlesRue0DA8j/AGWy9E9zC9t2ygiJpBzdsw+TUOkt+IVrylvxCx4brG6wV2t0M9M3VhE06noTDp1q3xzECjg4iQI1a27DnKVwPfMsNaKgweJoa+NT3EW9H+UJgzjSussy5nni7cLjEJqRFLZ3l1lVqKi5zmV1j8qzyq3BBYGLUhXeNSws4Y1LqM9IGdeWZXrbU6yn4n0aLfRaOkfSVtuu0Nd9J23Er1WdnisrDIP9hstSsbmG2244XlK9KBu5zGtqqHOXfETkhRHvsc84yuBkgzOSIiqSuABGtpqOCSTPWVEY8vc9YrlQ2O0Wx2f5jCfk4feUgZLHkJWclv5mqGPIaVb8Q9jKP1TNSP8Abf5mlHyt/MWsFQWYS1EXUAJjGJ+WmxorN0MA2jAFFbqNpd/6dR3MStWwpG2IaSzsF5CHTOBsQYr2VntKfiTpsZTrarBGprsGRGS2g5GcSnVK+zbGA/vrX4EJldZuOWMZ6qV7S/WsRheU4rHJ5mJRk/NLKvJdWAOIcMCDHHCxEpbKLPKDfMwG8t4VtIXlmVzld/mVFQH2+mLvkDrEUqzLHy6qGHLlF/pqXbbaafewmakY0/8AmacHgMsUuFBztPJNbqSecfepki0uCCRtmIF4XYjpNxtL8ZrTsImVSxvaVrsB3j2UoQpE1Zq4Bw7mJQzLkzD1mafVWr1lWpRxhpdpkILLtNLa2eAn99YoZCJp3NdpUzVIvDx8OY1LsCzkIvaVsoJCDaI/CrYG/SXC5xktK2yoM1SYfPeafIyDHYPWFB5R9OQvEMzTgFAcgYl2PNJE9RUE5HJEruKdMy13dgcbxbrgOUsNtnPMCOpyBG89lwc4iebXyzBdaOcex3IJ6Rb0YYZY11bKqgbZljItLBWyTKVZwu0ccV7noNpYAtKr9xlfMnsJcxZyZVXxbnlCuEBmoH9NIlYcDgbDdppUZ7OCxNx1mofgrwOZmjQYL9f3rMFGTLNQznhQSnTHi4nM23EuqGWa6zboJhn/ACJwqOsB3lzhflReYlSlSQRzgqYjcSzy1A+bJhvQfkWPZdYCIlFh6RdAzdDF+Hd8RdCgg0lU9NV2np6vtE8in7BPT1fbPTU/bDpaj0h0VRjfDx0IjaBgNhG0lgii1DtmV2cDHI5y2zzCvTECkrt1h0uV4s4iIei7CWPxYyMS9XPDwcwOUUV2bbo80yMlY4jvLaltE4bqD7SnUK+3X93batY5wCzUN2WKldKy7XruFlF4JE1FSMOMpkjpHSxt7TwJ0WKA2Qo2nlY3dsR3QY4OkLWv3iaSx8HEr+H/AHGJpal6ZgVRyA/EzovNgJfrq0vQBgR1i21tjDjxJA8cCNTW30yzRow2MbQ2CFbKzieec4beG/5QE2EOX4Zais/yNhxKKmsb+tXgjrLbRXseUOret8k5Uyu6u5em8s0xU8Vcq1OPlfYwEH9xqLfLWUKtrEu0IIU8ImoOobPEIQZRYKyAgyZSxK7neaiqtCXscnsILHJ2XhWYZz3lWhJ3baJp606R9QiHE9UnaLajdfHUatNP+dWlPxI+pd2/IeQlN62jKqceGq01d1Z4unWcB8wjmJ8O0y4FhOT4O/ApbBP8TWfE0ZOCsEHO+ZptdXaFXfix4mxc4zvAxPSBgY1aMNxLNApzwyzTunOK7rygK2uOL5X7xB5dQ4mye8vtdTh1yp6y7HNTtNMbdiuZpjcV+cS+pGXOwMouZWC8x+4dFcYIluldTlJXqbKzhxA9Vqy7RDGVgS2tuEDcyhwjAcXEZdWLADjcRNIW3baJUlfIeJpQ9I+mHSMr1mV3Ec4pBE1IBpfK52i6C/hD8PviU48pNsbeFilkZe4iaOhFxw595TQtPEF5E+Op0dl+pcomAOs+H0moOrLhvB3VRuZ8igkiByy7GIWVorZHgQCNxLNIjbrKKCGIdRgcjNQ6gYYHHeWFk5OGVpVo3t36SqmuoCXasLsgyYtd9xyTtKqET3P7p6ksG4ltD1DiU7TS2O6Hi6TWsfMODKH4fy/5Ji6oAYX5odS8rNrThyck/g1AHBASJp2P4HurTm0bXL0WHWv0URNaeqxNTU/XEBB8XsVP5nAC3E5z7ReFgV6ThKNDvuILeEzZhHrtXJVsxdTYrYaDVnqsstO+CGB6QnNuwwJT+iv8TisusK5lelROe5gGP3mp/SM0Ywh/ma79WVjPOUJY/IYETTqu53PgxwpMqtDjx1Nm4UeC5QV+BZuix673+sAT0XUvBoU+4z0SdzPRJ9xh0I6PBp7k/JZE4uEcWMx7cbDczhC5Y7tGcmAsm8BDriHiracAbcRcrjwepH5iPpnU/LuJahBJ5ETiJfM036CyjI1B/far9OaQf0/8zUI1lxAGd5RpFQAsMzZViXPbZgbDwIyI6PW+RE1BxuI2oY8hG3OTKU425bCXt86jtKrAwxmOxVcgZnmXnlXMapuqiGrUHnbBTbj9UzyrhytnBqhydTKzdvxgS12zwqN4Q6b4mcjnKU4m36Q1qRynB5dnsYVyN4qEHadB4WhuHKncTT6jzCVI3EspSwHIl+iKNmaX9FZVtqj/ACf32q/Tmm/SEIrryxlmrY7LD+l/+Zo92fxdQRDUP4nlNFpzzMACrhZaCDkytsGJYDz/AOAL8xMIBllWNwJU4VyD4WHisUCbEYmSDONjaAo26nwYfK38TSfrNNTa1ZUiVahLRg84qqowBF21X+f32qP9OJeK6gOsex3OSYlbsdlgGUAPaV1JXyEZ0XmwE9UmcCA5EIB5zgENYPMmeUvQkQgjZhkd5bQV3G4iuNgYluNmO3Q/jssCDJiXO7EwEMI1QO0FLZ/MYlarLbQnuegldTE8bneAATzEzjiGfBaUV+ICatGYLgTdTKdURs0rIbU5Hf8AYOwVSYdXaSeET1d3aequnqrodVdPVXdp6q+erunqru09Vd2nqr56q6DVXR7LLNiImlsbntE0ta+8+VB0EfV1ry3hvvs2QRdI7bu0SiteS/ixOEj3EsoDbrAxX5WErdlwDuPwvYEEZXsOTKqvaZAhGRFbIltpB4VGTKqcfM27eBI5GWaQMcqcTh1NR2ORF1vR1MS6t+TR6a35rH0XVDBXdU4YrDqru09Vf2g1N/aepv7T1V/aequnqru0OquPIT1V/aepv7T1N3aeqvPIT1V3UTT6gu3C3heCammjIJYEQhBzAn9L2n9L2n9P2mK/aYr7CcNfYTCdhMV+0JqHacVPdZx0d1nmUj6ljamodYb7LNkEOnsf8zxNJUvPeAAch4ZHecafcJ5tf3CHU0j6p6ynvPW1e8TWVswUA+AXBJEKpzIEa6ofVDrKR1g1tPcwa2nvBqKj9U82r7hA6HYEeAAHgFUZwIEVTkDxIzAMDwaqt+awaaochAoA8DjG88yn7hPMo+5YLaPuWcVXcT+l7TFfYTFfYQeX7T5Paf0/af0/aDy+mIwUKTNLvcT4EZBErby7se8deJSIqZJBJzPKHczy/eEMOs4m7zzGhtbvPMJnBnrPIBi6SvG89JVF0tWeUAUchL7jUAQuZ65uwEfXP0eNrWP1GerJ7z1R7Q6k+0OoaG894LXJABmhTNhJ6CEgDJl2s4dklmrJJyxM9RY3JDCdSfogXU9p/ue0FmoHNIt9pO9c0QJJaMCVIEey5Scudp6qz7zPVP8AeZ6p/vM0NjMGDHxscVoWMbVXcRJcjM9TZ95nq7PvMGrt+8zRvfa2Sx4YRkYh0lJ6Q6SuenUcpwATjInGYLDBk9YFnlg9YUCjnNPlmJ6TVPwVn3miUYLeOrrKvxjlNPZx1jvLUIPEIrhxN5iGsHqZ5QhqXuYKlnD/ADB/BgY9jOP2isSfC1A6MJaOETjJnESYtTtPIeChswadp6dsSqohppEC1lu81epySoOAJiy5ttliaetByyZkCF1E85J5yQWoeolpGUHczSrw1D38NUo8x47NxHecbd4jHjmjIBX3HgZq9RxMftEe5i208xoHJaVAEgSqsIgAEMzCSehhB7GeXnvPTAdTPIXuZ5A7mCsCDwdy7BFErQIuJe/m2YHISpAiAeLoHUqYC1FmIjq65zLKN+JOcFl6/mSC8/YYLW+wwO32zjbsZ5rD6Z57fZBf/wBTBeftnnn7ZWSdz4OeFGM1bYAhMUnM0tXGUX/zBoqu5g0lA+mDT0j6RDRURjhEv0zVnK8o7eVpwPaPmxwv+TF2GBC0Smy45Gwn+nKebz/TavuMPw1OjmN8MPRwZ6K1WGREHCoHt4auzh4277Ti8FbeaWzZD2MG4BmruwOEGai7fHgZX+aaSvidD7+D2Mp5Q3/9Z6hvtjahh9E9Q/2Tz2+yC5vtM85/shtf7IbLPsgS5+ewldS1g45y/UYBVZpaPraD8FlSuMGITVbjO2fDiEysyJkTImRCydxPMr+4TjT7hPMr+4RWVuR8NS2KyO81LEtjtOcRcuJokHPsPxa7ZVlYAdiZkRmBE0l9YTgJwYCDyP4rDhCZrWBws5QISvFOs0j/ADERblWgNNVqCSe5mSYQRiEynmZok+dfYeBZRzInGn3CeZX9wgsQ9RMr3m0yJkTImRARNW7KgAmmoDDjbeAY/Fq14bAZS4atTLkIf2gTP1TgP3GfMvWNc4POeexM4c9YKFPUxdKvcz01crrVM48NZYMgSxuJifCkEvKNUKlIIzG+JgfSIfinsBKtXbaVwdj46xSUB7QnEBz4ZdD3ETV8ONyImvfbkYmsrbntAysNjCzLMzWWgLwAy5+KwzGTiBP9uRjrmYlB4bQZZdwruY7Ek5lNZZpqSPMwOS7eFGxmh3DHwspWznDpEA5mHTIOpnlBeRM42HWea/ecTHrFBPWBT3jgr9UpUhBmat+KwKOkoXhrUfj1FfGh7iaSzhJRpYgdcRHKHgbwKgw0ZPODTqOsFUxAcdDOP2MXlLXNaFgMy+xmDMZgwgxSwGIOPsYVf7YK3yMjafD0GR7eLKGBBmo0rJnAyIxdTsJ569QRA6nkYVVoaftM8x0O8o1BBBUym0WLG5GW8XGxbpDWxJMSoloq/Jj2hrOTPL3EsDMYtJJlKBB7x6iWJzPIbvKa8ETRrirPc+GfaEmEEnkYUnpwZ6Yd55A+6BeHrC4WUoXfiPKWWCtCTKEa2ziP/DqamQ8S8pp9QHUA85bUtg94Vur5jMFx+0wXexhux9Jg1G/5TPUjsZ6kdoL/APrFbiUGPjgb+JcNv8zA8FQHGBvFosP0GemuPJDDor2+nE0tBqQ55/ht0lNnTEf4c30sDLNE6c0P+Iy2JyOYrQ7xfkcYmjcizEM1DbvjqYIh3iAlC3SW7E+GIi5IQDcyxBWxHhmVLKRipfA6jf8AKZ6gdjDqR9pnqP8AqYdR/wBTBcT9JnmnsYz2HZUlencnNhhKIvYS13uswOUprCIP+FlDDBl2nas5XlNNeWIRoZ8vtNvabT5faZT2mU9oOHwvOKmlxOQPBRkzRpm4dgPxEgAkxLEcZU/hv09bKTgAyxApmRCRNHvYkubhrYy4+CyunGj9+csGRDEE0mmCA2NzIlx+Zj4CU84owo8Pl9plO4mU7iZX2mV9pkTabSx+BC0LW6hpRpxWMnc/8ZGRN69R/BnMRgQ5BMKt0aEuOs4mMFOfqiab/uZXSEOck+GrbCqstbLHwr5zQlcMxMNiDmwhvqH1iNqqB9UfXj6BNK722FmM1T8NRHeJaUbZyImtwNyDF1tR7z1VH3Q6ygfVLtYGUhdpYxY+CrNCnzFuwmsbCAd5YckwCVLlgIFAXEuTDOIFyd5pNP5r8R/KstIWpv4lx2Hgs04zYg8DGoLH8xh0nXjMOn7OZ5bIfzRS56wFzDkDJMoyRkzWv8nD3mjTCZ/5dZXuHE0todMdRL0JHEOYiOGHvHXIgrHeAYikAcjFOfDV2A2/wI25gGIsD4GBDaZxGcRgUTQpist3M1pyVEfn4AkTjbvOIzeYMVN4EYkKo5mU1CusLNW4L47Q84o3mkXiuHt4asBbv5ERDa4VZXWtaBRNY2Ksd5Z4LNGM2j2HgZmMwxyMODOEETAgwBMmxwBygwixy112BEXhUD/ldQykGYai2V2K65BllGTxJsZx2ocMs84faZ6kdjBqgSBwmCMcAy1iXZpwkwVmBJwDvOFOrCZr+4QskBBwBKV4alHtNVbm1pxJ1nyHrOFe84B3nAO8wg6ziTERbbDhFmm0wqGTu0utWpCxhfiJYncziSBk7z4eMlmmdwJr6yyqQJo9OKkyR8x8Ncw4lWNuZwzhmj4RaR7eDsFXM9QvYw6kdjDqR9pg1AP0w6jshgS647jAldSoMCaq7PyLNLSV+Y/89lauMGEW0PKtUjc9jMhpwr2E4V7CcK/aPDV28FRwdzDZ7Tic/lQxatS3JDBotW0Hw6483EHwvu8Hwyoc2MHw6gd4mioQ5C+D6Ohukb4ZUeTGH4X2eH4Zd0YT/Tr/AGg+HX9xF+GN1eV/D6V55MVFQYUAeGo0j3Nkvgdp/pinm8/0uv7zB8Kq+5pRQtKcKw2DihUNz8dVpXufiDRtBqBywYdPqV+gwreOaGUM6WqSDAczAnCvYThXsJwr2E4V+0QKB0Ee1EGSwlmqL7JKNOc8T/sWUMMESzRgnKRGeq3cxWDDIhz0j6l0bDIZXYHUMI9KWHLbwUVDkggVRyA8Sw7w2KOsFqmeZDcOQIzFbbLGKXY55L/zOWAyIyqw4lgvZdiIzur5Dc+kS/JwZxCcS9/HgT7RAMTeFgoyTH1ig4UZlbWP7eGqvwOBecr0rvgk7SvT1p0/aX0iwbc5Xc9LFWG0ruR+RjKrDBEWoJ+SGwjmILUPXwzGbCkyvNjHtAAOkZA0sZ1YgyqvJ425CBCxy3+B+BiQCRE1CliCCMc8wEEZHhkeAj6lFbhG7dpW7OMlce34GTB4l5witrEPI9o5JYyqonDGcKy9WXDLKbeNd+YhIEEZ1XmZZqjnCiLTdacscCV6etOmTCQoyTLtWACEGTKdO1jcT8oAAMD9tZSj8xLqjUcgyrU2AgHeA7QgHnH0wO6nELX0n2lWqVzgjBlgysoI4mHjqP1JShOCeQjMFGTyiW1v+V1P8GO4QZPKBgQCDkQjYxQlhZHO84rNM/CTlYliuoIltBd0YORwmchNTrMngrP8mDTrXSXJHFjOZow/llnPPwWxHJ4TnELoObARHRxlWBEsqBYOOYli4YGLjAx4MPlMo2uIjsFGTG1Dk4URaLH3cxKUXp4ai1kXaKXubGZXpUXdtzAP29r8CEwVeb81hiaeriDKfHMwDGorJzjBmNsSxCrcQ5iC9Mbw3oOs3ttzAMDHh8U+EuSb9KxVuqiJrviKZQ2se4M+HfEtTp3xaCayf/EqtS1A6HIMvp4xldmHIy6y82cNglVltLjMVwV4prviOc11xNPcFV8HeU0vYq+YTgdJ8qjsBPiPxV7A1Wmz7tBrdbXhA7Ks0Hw67VMLLmbg9+srrStAiDAHhau2JU2wDc/C68AcI5madCPnMZA3OBFXkPDJ8LaxYpUmelsTdGiagg8Ngwe/7i9C1ZAlTArjqIma2b7TEdXGQfCxOJSMz+tV7iJqVOxgIPIwgGNSpg04iVqnITIPIwsw5jIiurcjNZ8NqubzEADiUIrVAPWOIbHIiIibKoHg9NdgwyxqasKSNlms1Tv/AE6x8sp0gZ1YDPYSmrgHzbnwZVYEMMiCmlAStSj+BNP8Ma29r9QOZ+VZ8qjGwED5OwM/kz5XEauwcjkQ13NtF0w2LQACWXV1jLNG1LvtWsqR1yWPhqrCq4B3MRmPUzzbVHWI6XrgjeVu1T8D8uh/cVb2vLk41wDvE4dON2ye0VgygiDwehGhquT8pi6kjZhFtRuR8HXiXGSI2mtQ5RoNTamzrBbRbzgVhurZHYwMeq48WYAEmW6hreXLt3i08ZHDz6QKKE23eUXi1exHPxJhFh64h8pNycmNeScIs4LrD8x2lVXl9fAsBzMfUIOW8a299lXAi6XiINhyYFCjAHgSAMmXXF7NpTWEQHG8LA8xLQE+dIcX056iad+Ksdx+3tXy3DrLScDEZHLbSkirCs3Pp+Fq0bmI2lH0nEzqq/cRNYOTqQYt1TcmEIVh0Ms0aNupxODU08txE1R+oRbFPXwu3XGOcGlYNtyldaoNpdUxHyypChA4ceBdBzMbUAbKMwG5+uIunH1GBVXkBGtrXmwj6uteWTPOus/KuINPaxyzRKEXpAB42Ph1EuyyGAbiIQUWXLgZEwCGB7TSNu6zT7W2D9vqUZlGOkrbjTHUS0vjhQRKQg47WjavGyDaVWCxA34SQOZhStuYBjaSo9xPT2Deu3ImdWnTM9XYPzJPVVHmkN9HYxNRV9xguqP1CcafcJ5ifcIbax9Qh1K9o97t1xAR1MVwpnqz0WedqG5JPK1L82xF0m+WbMWitfpgHgPEyxSXSMVAMspDDiQcpprxjgYxgGHMS50rQheZmjrwCxlG72n3/bkgAzTnJc+8bYEqI/mMd8mV6bA4rCAJVfTxcCDbv+G0vZcVLdYtOoqIw2ROm8NyBioyATEACiHh6gQ1VN9Ih01J+mHR1Gejr7mHRr909EPuM9Ev3GejH3mDSJ3MGnq7Tyax9InCg6CBlJ2Ij6mpTjMGq4mACzVXWLZwgysngX+PwDwtXiXEYnkecTIMvqKvkDnP6p5AxamJAhxXWfYTTD5Ce5/buMqRNO3CxrYbwDpLXFS5C5MdntbfeUaUqwYkD8Oo05Yl15zTak7I8vfhrJnCeHj6ZlL5qBj2PbbgHrLEtoIPFKbONA0Y4UmDVtxYMLBVLRNXxOBjrNRqGqK4GcxLM1BzG1jsxCLKbNQWwy7TU2OrgBukcn0xP/WaDm0fHqTnlmV2VE4UCa39YSr9NP4/CSBPOTIEelX3HOO3lj8u8QWOckwLibCW2G2wVry6xFCqB+41A4XR5xBgCpzHAdcAQqEGBt7yu1OLYb9zC5KZWJep2O0BBhzieodCQwjMXtyoxvNZYflX23nmnyeApNI+a3EpH9df5muPyrNH+l/mP+Rv4hByY+ozp1XPzSna1P5mt5rCSNJNFgFj7T1NWcAzWH51h30x/wDjNAfmeWY9QQepiV018sZmt/UETVWcIVa5SbCuX5+DOq8zG1I+kTFlhiadRu0e6pOZi3VMOYgdO4jX1rzaPZbceFBheplFC1Due/7l1DKQZwPQ2RuIl6vtjBli8Qj1sr5WUuwOSNjGpVtxOC1OUS9gcMIHrcb4gRBuFEfSq78RMZFKkY6TT1PXa2RsYymm3i6ZmovFvCAJplK1AGP+Rv4lFYZnHtKqGNwUjkYRjU/5ms5rAM6WaV1ViGPMRgvn/LyzNYh+Uw6v+jwBd8YmiqKgsRzlulue5iOWYmicEFrI1KMQWGTPkXsI2oQct419jnCiCm1+e0ShEGTvHvRdhHtseLpHc5O0OhHR56I9XiaOsc94FCjAH7y+oqfMUcoCHQMI64zwjJiUsTmxv8Sy4VYUbxdRW3XEKI3QRtMD+UzgvTkYNRav5lg1VZ55EFtZ5MIVVhvgwVVjko8CMgiVUCtiQZiHTA2ceZdR5hG8SsKnDG0aE5BIlelrTfnCoIwRBVWPpE4lHMgQ31jrG1f2rPNvcwae1vzGLp0XnvCUQdBH1Q+mFrbO8XSEj5jEqRBsP7CwyCJW4pYo3KebUPqEe6td85Moq4lZnHMx9HuSpgN9R9omqU7NsYrBhsYQDzEamk81h0iHdTPItH5Xn+6X3nm6gc1nqXHOuesP2GesH2mesr7GeuTsZ6xeimerJzhINRceSTi1J7zytQ3MwaZz+Z4NNWOZzFrrHJYI9iKNzH1bE4UTyLrGySQJXpVXmcxQAMAf2R6ks/MINLUOmYmnrQ5A8SARgy3Sq3LaeXdUcxNWM4aB0cbbwqw/KYb2Q4ZTEdXGQYTiDBnCp6CFE+0Q11DmogpqH0CcCfaIFUdBNoY16DluYpdumIFCyzU1p1yY2ovsbCDaDSuxBZolSINh/b309bdMQ6e2o5UxNSV2cQPXYOYMbT9a2wZ59tZxYu3eKUcZRovFyaO3AhbBOJr/AI8nm0rUG2bLTRa+rVjKK38nwwepj6hEGFGTAmot/OeFe0Squsco+oReW8L33NgZxK9EBu5zFRFGAP7m9SPzEbT21nKRNSy7OIHrsHQxtNg8VbEGLqXRuG1T/MDKwyDNT8Gu1eouuACAn5R3nwul6dMK3ThZTLdQie57RRff+b5ViU1oJZqkXYbmZvuOxlemxuxzAoHIf3d6UfmJZRbXuhyJXqcbPMV2DoYaHTetv8RdSBs4wRC11xwnyr3iUVpudz3l2pSsdzOO644Eq0oG77mBQOQ/vdmnR+mDGS6o5HKVakHAaNXW+CQDLLK6l3jai23ZFlOk6vFUKMAf34jMt0wOSnOC2+vK4MrostPE8StEGw/9hEA8x/8AzL//xAA9EQACAgEBBwIDBgQGAQQDAAABAgADEQQFEhMhMUFRBhAiMmEUICNAUoEzQlBxFRYwQ2KRUyREYHNygJD/2gAIAQMBAT8A/wD24wfEwfEwfEwf60FY9oKXnAHdoaqx3n4QM36vE4qDtOOvicdfE46+Jxq/EFlUJqPicOow6dexhoPmGpx2mCP6gtTtOCB1MLVrDcOwhuczLmCuwnoYuj1LdK2P7RNla9+lDxNg7Qb/AGTB6d2gf9uf5Z1/6R/3P8s6/wDSP+4fTe0P/HH2NrkYjgtmPs7WJ81Dj9oaLh1UifijzBc4gv8AIgsraGpG6GNQ3bnCrDqP6UqM3QQUqPmM36l6Q3t2n4jHvKdn6q4gJUx/aab0rrLObsElHpXTqPxLCZTsDZ9f+1n+8Gk0NQ5JWIK0/lCy6yqhN+xgoh29s8Njeb++JVqaLqjbW4ZQMmf5k0X6Hg9R6H9Ly3bOjXTLbvkb/wAvKWai/jPaLyzses9PWWW0uLLN/B785ZVpTydU/ePsnZtwP4SftLvTGibO6WWXelH612gzUbD11Oc1MR5HOPVbWSCCDBa6wXIwwwnDrboY9DL05wgj+irWzQKidYbv0ifiP5ml2TrNSfgrOPM0vpTobrP2Ep2Ns7TLkqv92jbR2ZR8ItTPgSz1RSueHQx+p5S71LrmP4YVJq9ray/RU/GysGIYjlmVrqtQzBS7EDJ5zZm0btLqFDMShOCDPUdzNfWgPw7gImm2ZZfpLtQG5IJsbUtVqxWT8Fg3SJtbYo0dXGFmQW6TZ2gOtuKBsYE2rojoqqKi+epmztmPrg+64XE0egv2TVqLnYFQnKW6jU6q4lmZmYzS17S0uoqbDgZ5+DNftzV1axlQruqACDBtOn/D/tZBI7iaHaem1pIrzkdjLdHo78h0RjNV6Y01mTU26ZrPTmtoyVTfHlY9VtZIKkGJcwMD1WdY9P6TCCOv9BVSx5QIiDLRrvESq2w8gSZofTWpvw1nwL9ZpthaHSqGZQxHdpRqNK7NXS6Er1Ahzutjria2/UtdYttrNhiMZmi2BrLwlhwqkZBmq9NNVVZYLei5xNnLWdbUrjKkzbukpTZ2a0AwwM0WtbSGwqoJZcTT1vfqEUdS09R08O2j/wCsCbGbe2Xrk/4maU7uqqPhxPUfPZ1Z/wCYnps/+sb/APGeqD+PQP8AiZp69W4Jo3v2l9uoGwCt2d/eA5zYte/r6xHVNw5UHAmss4mpufy5i6thoW0/lwZ6ewt11p6KkGqvOsNiOwLWZ5GajaFWi09Tag/Gy/KOplfqfRMQr1uo8x9Js/aFYfcVwejCa30nkk6ezl4M1eztVpWxZWRA7KecDV2dZZSR0/PqMsBHbhjAESu21vhBM0Hp661gbSFEXTbO2agZ91Tjqes1XqVFBXTpn6maTVvtTZl9b/xADNm6htLrVOT1wYhDAHzNvUcHX2eG+KafWbSsNa12uQuMASk2W6UCwYYrgiMvA1pH6bJrlF+yLf8A68zSUcbUV1k43jiDi6DWDI5o02yPtuko1VfPA54ml2hdpKrq0A/EGDNnaS2/U14HIMCZ6irc7PQKpOGE9Nq32xsgjlPUwY6xOXLcmz9qW6EMFrVs+Zq9W20tlO4TDIwJAmx9XTpdWLLc7ss2vpL9FqHpbmqmUUtqLxWO+YwwSD2ml/A2PqLe78hNl1cXX1AjkDkzbGrOp11hB+FfhX9ppdhW6jT8UNg9hNgaXVaY2LZySaz1DTptTwgm+B8xBlFui2np94KHU9QRNp+mKWy+nO6f0zU7O1WnYhqyMRLWBw0uRcbw/PA4IMtAZAZsKwtbwd5Uzz3jK9bQjrXQput89pt/R23aRbrCOInPH0mhXTNqVF7YTvNm6/ZZtNFCFeXzHvNrac6baFgHQneWbJ1S6jRo2eYGDPUqV2JXajAlThsTZm0vsO/+EGJ6ZmyNtW6y967UUfpxNr7O1H+IOyV5DHImjrZtCtVgwSmDNP6dsq1AsD8lbImt2VptS4dyA3eaarSaak1mxd36mW1bFLEs9YlGs2Npx8FyCHa+ynG616kSvX7ErculqAyzVbH1JG/dWY2k2NZ8r1n95pdLpKEeusgq/War02rWFqm5HtK9gXV0XqLBlh0mxtl3067ftTAAm1tG9OutAQ7rNlTNpPwdm6Oju3xGbGVlTU3/AKEMpQ3aite5aaaoV0ovgTbW1BpKuDUfxWH/AEISxO8e89MAilznqZqdRbpzm6reqP8AMJtnU0JpONVcrBuQU9YmXsLGXMen50DMWsAZePaDyWKxVgRNBr2NVVWz9L8ZA33PQGMaKkKai423MMFRzms07UaiysgjB5A+JsrTaSutdRdcFwZt00avS1amg53DumVWavdNdbPg9hNnbN1VldldikK4lPpytRm1pV/hGgIJsQNNT6k2fWfgUuZqPVmoJPCrRRLfUW0rP94j+0faOrfra5/eHUWnqZxX8zffzN9/M338wWP5gusHeLrdQvSxh+8q21r06XvKPVGtrI3irD6iUerKDji0kf2ibT2RrMBnAPhprdn6TW1Jgqd0YBE0ezK9Np7auofrNRpdTodVlQfhPwmab1HetdnHQE4+HAxL77L7Xsc5ZjHfeVBjGBNgWUVaMC7KhjyaWnV6YFlxqNOf3IE23qabtWxoQqniKxUzNdgllRX82qFjDuVj6wl7DNFsXVakghML5mq2QlFDgjmB802Rrb6nOnW/hrYebTT26atuHok41x+a09BNv6S0Cq9iGfo2JRpNReQFU4mztmGmp0tOVYcxHfZOiBG8uR+5mo9TJWWFKfuZqNua6/O9YcHsI99j9TMn7wBPQRKSVY4hUj74dh3lGv1NDZSxh+80vqi5MC1QwlO2Nl6wYswp+st2TotRUdzd59CJpNg0Uli43ptbTcDVuFTC9psu6yjRJ9oo36GHUdptTX16Or/0Or3q7Mgp4mj2f9srZxgnPTvLfTjvXvUglh8ynrLqLaLCrggiJcGG60eruv5mtN9sSzKKAonU8zNijZgvX7SxHjxEFArXhbpBHLE12i41bG5sKBNo1Ilu9UhCzZOu1V9SUaTTqmB8dk+yUV1/jWcRz1J6S/amg0QKphm8Caz1Bqr8hW3V8CPa7kkmBGM4ZhUj3Ssv0IjUEIB3jKR7VuVMyN0S9+eB7AZMqoIOT0llZUn3wZj2DEdDNLtXVaZgUsIE0HqZXYLqBj/kI6aDXJklXU9xGS7Q0MaCLqAOaHqBNQ41euc01boLclE2ZoNNYgai013J/IZpd8KBcoDeRPUX+EtWwsI4vYrLBWD8JlbkGPUGUn8wCQciLcCMNGqVuawqymbP21qtGwCtlfBmm2roto171hIKjJSbS07X0uwr4dfbM0GufR2OMndPWava11x3VchYzs3U+4YwPAVaMg9k+YQ3r0jdT7A4MNjE9YzFveu4JWMmXvvYI9gCZzPKEYhGRCMQDIMBImm1t+nYFHImq2w76f4LGDsMNNj6a+x9+hl4mflPcSo6S2pnvoam2kZYibT9TWsTXT8Kjv3MtusuYsxJJiU55kwtWgwI9jN+aVyvSJYr8iJcoDcp6VRWucsucLNoacXA8Qk/pQS7Yr2OWcioDt3MbZ+gpTNjkmXvRvEV14EFpAIAH3EPP2fH3Frdu0XTnuYNMvmNpvBhpcfcAzM9hOY5wEMIOXKEZgJUxLlBGUErTZupABTcaHYFbDNds0eiQlRYpqdcBbF6TWhhsq0OwYhPmHeXc7W/vMKiZjWk9PztX8QS/wCYT0hUCLm+gms1FWmTfJVfqZtHbCOx4fP6yy57Dkn2EZce6L39upb2wPMVq17Zn2nlyWfaW8T7Q0+0t4g1J/TOLW3zJG3c8ukC9z0mc8hAPY5BmQZmdfZWZTkGaPattOASSJsramn1AFWRk9VaautV0Nir03DLv4zf3ln8L89V84l3N5snay7O0tuBl26TW7S1OrctZYTOpjVhF+vuGDCFOcCQR2wIneMMRRk9Zu192n4I8mb9XZYXX9M3k7rN6k/ymNufyxcd5yPsxwIDC2RMzPvXjOD0ltW5gg8pXa9bAqSMTQ+pr1pNV3xgjAJ6y871rHyY/wDA/PU/PLfnnxNyi04GTB8/7y/oPcGbxm9N6Z5xYeYhH+kGhGR7DkPfAA5n2XqJqOdaylA2cx6yhmSesP8AB/PUj44ai7xUVRyhZR1MJ+ImM5brACekFLY+4DMwfSK3mYhX76qSYyqo9t6b48QkmKuYWA5D23GxnHsbGZcGUMBnJh3THp7iPkVY/IKpYgQUIOpnBr8zg1+ZwavM4VfmcGvzODXODXODX5nBrnBrnBrnBr8xURDkGNeojXOZzMWpjNxF6mcUL8ohsc9/9ANidecIH3QMxSFjNn3IxFXuekZ88h09sHtFvI6iFqnhoPUGFGXqIHYdDFv7EQujriCpPM4VfmcKrzOHV5nCq8zhJOCnmCqvuZwqvM4NXmcKvzOFX5nBrPeW0hRke1Zw4moBwDMmZefHPinxTLeTMtMtMtPi+sw/1mH8Gbr+DBU57ThqvzQWovQRrmMJJ98Gbp8TcbxOE/icF4a2AJ9+cCse04b+JwX8ThP4m43ibreIQR9znCxP3g7jvDa5hOffds8Gbtngzds8GYefFMtMtMtMtPinxTnFJJEuOKx7A4IjfFXAcGM3iBjN4+IefviYm9OLDc049kNzmEkxF3jiVbP1N38Ktm/sJT6c2lZ/7cj+8q9Ja4/NuLE9HP8AzagfsIvpGjve0T0poQebuZX6Z2UBzQn94NgbLH+wI+x9l11ux0ychma5kNtm4MLvHA9kqJ6yrROwzu4H1n2SpfntE3NGOrzOi8mY0R/mM4OkPS2NpqgOV2Zae0BwZotH9rtWpN0MfM/yrq/KQelNX5SP6V1aKzEpyEvTdPuoJIE0GwtRrKt+sAD6z/Kusz/JP8p6/sEmo9N6vT1NZYECj6y0IvL2F7iC9pxc9ZvfczC03zN4mWHGBKVy4mobmB70Nld2WruvAeWIRj23pvTegeFzM+x9iPZThgZ6V1GLbaj3GRKyxbqMATJznORL9bpqDi21VMbbezV66hY3qLZi9LSZb6q0IHwBjE9WaMnmrCbS2zpX2bY1VgLMMASxiWlNJJGBzMAq0wy3N/Es1V1n82B4EPObpm6ZuN4hDDsYnRz9I5y3tsy16tTp3XqHEBGBMw8wR9JtOspq70x0c++zNBZqr0rUdTzPgTTUppqUqrHJRAYGaeqtc5tShWwoXJhJJPvj23pxDA5m+ZvTPso3RkxiSZUNxMx23mJ91JUgw4sWMpUxX8w7h6Gbo8zAmB5mBN0eZujzNz6zc+s3PrGGPYdRPSNOb77D2UCfKzHzGYBSZtrVNdrbmzyBwIbGM3m8zeM3j5i25GCYo3nlWKqzZ36LGJY5J5+xsCQ3MZxWguYQalpx8giHqfbYWnN2upHZfiP7SvByd339SaY169yejqD7U1l2E2Hs1dLpgXH4jjnCMHHaEAAqp5+ZXnp15T1FbvbQu+nL2CgjrNz6zd+s3PrNweYV+s3frAB5mB5m6PMyFhJMqq/mMus/lH3VYqciEB68+2D97Bm6ZutN1oQR7VjLT03QadnmwD4naFxlQepmsbh6e5vCmamwvYx8kn71PzSxt6utR2mDN0yxGzn769RPSdB37rt3IwFEtLhCU6xdRXxhSfnK70zhjPVWnBpptHPBIMKnfxPTmy1Z11Nq/AD8A8mZ7QWVszgNkqcGb2ZxAtbt4WbRtNmpuc93PsAT0E3W8TdbxMHx/oadQWORLrCPhH36DlSJYu6xiH4Zv/SbwmR4gUTdWZxOJDb9JxXjMW6+1Cknl3M2ZUKdHSnhBGQW5BOADyIm3bjVs67HVuUbT2ueSn/qJs3VP0qf/oxdia5ulDS/TNQ7JYCGHUe9Rw0TmsxN2btdgx0MbRt2AIj6cjqCIammD70rk5np6oU6BBjmeZm+rbw8T7cP8woCeW7uTsSOZm26+NoL1x8oyJoNA+r1K1qOX8x8CaepKaVrQABRgTau0E0dO+T8RHwibIDHQ12N81hLn95ia20VaPUsT0SXHLE+yWMvScZj2nFM4mZgGYEz9ISJvDxFI8RjkmULuqTLWy5+/U+60uXIBEU4MIzzHtvQPN+bx9jMQxRk4myNNxtdRX23gTBWQuBArqQf+5ZUtgwyg/3n2aoHkiiGsbpHIfURhw6iSc4HWbTuNuqtbPVvcHBldwERq2HM4MFDEZUgzhkdVg3l6GCz9S5jaeqwEpyMupK5DCOpU+2jq411Naj5mAlNArqVFA5ASyta0ds45ZMs1B/xA3Z6WZmmrFtKOD8ygy7Riyt0z1BE2VsZdFSRy326makpp62dyAAM5m1NbZr9X1+HOFE0em3dLSo7IBPsxPeepH4Oz3XPNiBLPm+7vTfm+ZvTMAzGO6MCIu82JawRcf6NLhhumW17p5QMVMyjQr9Zu/UTc+s3PrOHNz6zchGDBPSlRbWtZj5EijlG6TaHqa3T6i2pEBCnrLPVWqboFEf1Frz/ALuJZtrWuCDecGWNvtn7q2MImoK+RK9e3cg/3leo09oww3TOGO03MS+sWUkY5jpLR8Pt6b05t2jUeyAtF5zbF4p0NzfTlC2Xnp3UC/ZlHlRun9piMwAzPUu2DdYaEb4F6zZdZv1mnXy4icgBMT1fbhKU8mMck+25y6zcPmcP6zc+s3PrN36zH1mFHeFx2gBJigVpHYsc/wCiCQciJarcjLqgPiH3sGYM5+yDLCektPu6e23HzNiCau0V02MegUzXW8S21vLH75BH3UYgibD0FmuoYhsBTif5ct/8oj+nWVSTaOk1i7j2LnIDERBlhPSWmwt1x7kATGJ6svxQlY7mF/xcz0lq90XVE/UQHK5nqPbA0lRpQ/iMJbaXbmZ6Xp39eh/SpMXMdsKZ6pv4mrVeyr785zmDOf3VXeIEASsS2zfP+pkPV+06GAjdmR4nLM5QOPENv/ERnJHQe1I5zYWnFGzqFxz3cmcpt/UCvQ28+eJdnMwZut4grc9pXo7X/lJ/sJaFQYAlS5cSjYGr1WlW6tQc9pfsjW1E7+ncftmNp7F6gzhv4gpsPaaLY2t1NqhKWxn5j0mydAmg0yVDr1YzM2vrk0+jubP8s1D7xP1OZSPimwaOBs+keRkyw4XM9T6ri6vdB5IPbYGq4Wvp8NyM121a9Jpmc+OU2hrbNTc9jnJYxBlhPR9WHvtP0A9rflm37A2vu+nL3V8dpxPpOIPAm8D2hxOUyDHxmadfizLyC3+rQ3aXphs9jEPPBjKYJmZzMGH20GnNt9KfqcTT7tdSqOwm9Nr6BtbWED7vPnF9J1fzXNF9K6Bepcwendmr/tk/vE2Ps9DkULNp6irS6KwKigkYGBLmy006kty7mbMqFWkqTwoh3e4Bluk0loxZQh/af4Psw/8Atq4mzdDW2VoQftF3F5KAJvqO81GuSpCS2BNtbW+1sUU/hrGOTNDQ1t1aD+ZgJpvw6UU9hNRZ8B5zadvE1N7Z6t7aSwoyOOqsDNrbTOp3QD8IEJJJMqGWnpioV6BT+okwMPM1Vm6h/tNoOX1FzeXP3AJzgb3+UTqYmK6+cY5JP+qCQQZlbEjKVMDmfDN0eZw/qJwvqPf05pxZq1bsgnFQcsx9Wgja1O5EfalS/wA6x9s0dOKI+3NOP92Hb2l/XNsbRp1KotZPXJjHJJmiKV2VM45BgTKvUGk6b5ETbemP+6INraf/AMiwbTo/8iw7SpA/iLLdsaVQSblmo9Q1L8mWmv2rfqc7zYXxHfeiqWOBNhppaSb7rFBHJRP8Y0uf4omp2vpzS4WwE4mobeYnyZjlKWwTLH3j7UAnM2c1dOlpQMOSifaRL79+px9Jqs775/UfYDJnDPmCs+YKj5m59ZujuYSghJMqTu0ucHkP9dWKnIgKWrHpYdJjHtn3rXLTQ7UGipKpXlj1Ms9Q6s9N0SzbGrfrcY+utbraxh1JPUkzjmcZpxWhsb2FrjvOM0F5g1H94NT9TPtP1MbUQ2sZk+yWBO045nHacdozFjkwKcTOPeu0IINa46Ow/eV7U1KdL2i7b1Y62Zlz8Xebzz98zJmTOczAjHoIlAXmTLLOw/IgkdDEvI6whHSEEHEEWpWHIx0KHBgYiFmPeZ+5iFTMTdPscAf6wx3gOOU3RAFI6Qr93J9wCegi6ckZY4jBVPtTXk5Me5V5CNazflK7CpjIrjIjVsvUQEg8oXLdYFzNxvcc4cAewMABEJ7Qn7gxDWfcc/cVsRntCMfcB7GYIBg6QmZlZBODHXBgHsFJiUDqxjPWny9Y9rNACZXTk5aPaFG6IT+WV2XoZXZv8iI9S490uI6iYqsj0leYMHWPzA90+WNAMwqw6iAZPsISVwwmBYM94VKnnEfAIx7JVy3jOIWbHaWEZwO3sQR1gBPaEEdRAxxiKeWPcR/lBigkwVqoyxhtUfKIbGPtUgcxgtYjWs35hFycQvucljWtgg+3KY9hYwGM+ynsZuGbhh+FfejUjG5YAR5jU0nBxLqa3Ax1jKVODEfHI9IiIFysZEdTCCDiU6f+ZpxEyRHcKTicyZVSAQWnBqYZwCZbctYwoGYSScn2U9DGHj2rQnnLGHSAkQknqfuI5Q5nGVuTCGsEZX8xWwDRxg58w/EB5hUjr7K26Z8DxqiOkII9g5E3zCSeswR1EwD3m6RKr2UYPSOxDcmMLE9T7K7L0MDtk47yqtRzJ5x7SBiM2T7AkTeYkZMe7dAVD/czmZjyfbmDAVMBQQ2noPZUZuggqVfmMsZTgAe1a5hAm6rGEMhyOkZQ67y9fzDfw1iNumEGw8hgQgg491sYTiI3UQ0g81MKMO3srbpzBejcmENNbc1MNdi9JkdCJgefcDJioFjNiD4zz6SxNw+4nKAO3QQVgfMZvVr0HOO5b2AJgqbvN2tephvIGFELE9fYAkyuvCc4zFiYBE5jBg/Df6GWLhvy6HeXdMHWK646x/i5gfdDlehi3eRM0v8ASNp+6nMNbjtASpiahh1hap+saodjCpHshwcw2CFiTEcDrHbPtuk9oKvJnwLDaewhJPWBGPQQUsevKbiL1MNqr8ohsY/cVcgyvAYQnIMPUxDM4IlwOFMt/hofy9bAE5jDBiherQvnkoi08ucZSpx90CBmU8iRBqHnGQ/Mkxp2n2dD0ecBx0M4VsNT+Ia3H8s3W8TdbwYEc9oKjFrUdvYqSJwfJm5UOpnEpHRYdQewhsY9/vr8rQZiWEHBllZ+YQZERWZsmXPzAlvy1j6fmLOiiDn1i7oEa3svMx0fGW+6mFTML1sJ35TdJGTCcmAmB3Hczj2eYNQ/0n2lvE+0f8Z9pP6RPtB8T7QfAhvbxDa04jeYWJ7mEGCtiJw8A5MrRSuSI3U/eU4MI5ZEPTnK3yvOApz6RnxmDLNLfm/LjqJYMgMITFUucZi7qCPbkEfdrsxyMevusQZaA892OMNiKFVOkBR+WI67pxB1nCyIBk4hqwDK0DZjLhsCCkAAsY6oByMqUEdIv8T95fFzwoysOZlHNDG+Y/eFbRXI5QDePWHdA90UIhY9YTkk/mKjkMswRkERTg5gJaMjY6wKM4MNR99xT0gG6vOUjqZujfzmXL8SmOfg/aUfMZd80HUQEcoExYTHOUMo7z/cl2eQnDbEp6GL/El/aLnhiMzGU/KYahnJaNu55e2DFr8z4VENniLWzQo47TdbxBW57RQiAlusssLn8yCQZvLYoB6xqyvPOREbBgZSuCY8WwiBkbrDWD0hVhMmLZgYgYg5ljhlHOZ3lxK03OssbLQdRLDgKY7jc6zOapSes/3JapIBEGeHzlR6wVne3pawYxbVVAI1w7LA7AYE+IwVNAiiGxR0hdj0grYxUQQ3KOQg1HkTj+Fhvc9OUJJOT+crcEbpjDdJEHSFx0URK98ExqnEBIi2nuIGqPWGpG6GGhoa3HaDIhZj392csPbifDiI+7CSTmC1gI1rGAkTeaYMFbGCnyZu1rOKg6CNYxgDMYtXmYVYbsdBGdj3/oTKXAYQVv4gRz2wJY+CApi3/qExW4jUkcxCCICRFscd4Lz3E4qHqszSZuVeZwl7NOB/ynAPkTgN5E+zt5E4B8wUDu04dY7zFIm/SO0Ny9hOK0Lue/sFJi1KBljOJWgwBGuJhJP9EV2XoYbn8w2Oe/3FuZZvo/WNSeohDL1EGO83Aw+EwqV6wCcxMkd5vHzA7+Zvv+ozfbzN4+Yc+wrY9eUbAmYtTNBVWo59YbVGd0RnZu/9PW1lgtRhzEaoH5YQyxbezDM4atzVpzHIiHHaKMkCU6NgrliOnKWUtX19v7Ray3WFq06czCzNFqJ6wLWgjXn+UQsT1/qa2MvQwWoww0akHmsKssFvZhmNUpGVMIIMTVLWir18zUMGs3gcgxKy39oTXX05mM7NEpY8z0n4dY5xriekJJ/q6uy9DBcrDBEerPNZ8SmCwNyYQ1Z+U5EAROvMw2MYlTPN2uqPcT05CEk/1tbGWKyP1j1d1gZliozmCpE5kx7+y9Jkn+vpaR1hSp8HMaxEGFhYnqf/AIFk/wD8y//EAFIQAAEDAgMEBQkFBQYEBAUEAwEAAgMEEQUSIRMxQVEQIjJhkRQVIEJSU3GBoSMzQ2JyBjA0ULEkVGCSwdEWQILwJTVE4WNzorLxRVVwwmSgsP/aAAgBAQABPwL/AP3G7q4Vwrjmrjmrj/HNws4WdZ1mKzFEnovqUPQsVx3dBOiDrq5WZyzlbTuW07ltGrM3n/iq4WcLOi4oOv0E24gJ1TTt3zN8U/FKJv43gjjlEBpmKd+0EfqwFO/aCXhC1HHazk1HGq4+uB8kcVr/AHxXnOu9+5eca337l5wrPfuXnGt9+5DFK4fjFeea72157rOOU/JMx+e2sTUP2gHrQJuPUx3scEzF6F34lk2spXbpmoPYdzgfQzFbQraBZh/iG6zhFxV+/odLE09dzR80/E6Fm+cfLVSY7TjsRud9E/Hp/Uia1PxSvf8Ai2+CfNK/tSOPoBrjuBQp5zuhf4IUNYf/AE8nghhWIO/Achg2Ie6+q8yV/sDxC8x1/st8V5jr/Zb4rzJiHsDxC8y4h7oeIRwjEB+D9UcMrh/6d6NNVAWML/8AKjFIN7HeCsekPe3c4pmIVjN0zkzG6xvaDXJmPs9eE/IqPF6F/wCJl+ITJoX9iVp+fTchCRZx/hu6zhOcVmKc8NF3PDVJi1DH+Jm+Cnx934MQHeVNiVZN2pj8Bor66rTUXQzE6BR0VVJ2IXJuCVx35R80z9nnevOPkE3AqJvac4/NNw/C4/UZ8yg7Do9wjHyXl9I3cfojikHIo4qzhGV51/8AhfVedXe7C86SewF5zl9gLznN7LV5zm9lq85y+yF50k9gIYoeMabirLaxlec6fi1y8soXb7fMItwuTeyLwTsMwt+5g+RT8BpD2XOCf+z7vUmHzT8Frm8AfmjTVUN7wHwRBG8K9tyiraqLsyuUWO1Le21rlHjtM7tsc1Q1lLL2JQgVms4d6zlCQf4WLwi89EkscYu94b8VNjVKzsXepcYqZdGWYO5Plkk1c8n49DWSP0a0lQ4RXS/h5e9yiwAfiS+CZh+HQ+qPmjU0ce4N+QTsUZ6rCn4nKdwARrKk/iFGR59Y/vrX0CjjgoqbPJbvKhnlra4WZ1OXcsTZSU7W2Fnk/TpbLK3c8ptdUt9e6Zikg7TAU3E4TvBC21BLvyfNPwnD5uyLfAqX9nvdzeKmwquj/Cv8NU5jm7wR0RVtVH2ZSosbktaVl+8KDFaSX18vxVwRcG6utoUHj/CFwjIie9Oc1ou4gfFT4xSRaN657lUYzVy6NOzHcnucTqSVcfNQ0NXL2Ij8dyhwB5++lA7gmYfhtPvaD+op1dSxC0Y8BZS4nKewA1OqJ3b5HdJ39Njy9CCmlm7I05puFt9aQ/JHC4uD3Kejlh13t5qMXe0d6820/f4rzdT9/ivN1P3+K820/wCbxVZHHBMGAns3UeHXa1wlIKnwuaa2erJA3XCipamnh2cLoh+a2qnw2rBdNM8OtvN+nK72SiCN49AEjcU2rqGbpCosTeO20H4LyqjmFpAP+oJ+FYfOLtGX9JVRgMrfunh3xU1JUQfeRkdENVPAfs5CFBj0o+9jDvgoMTpJ9A/KfzdAk10KEnNAg/4LLgnPctd6nr6SHtSa8gqjHJTpE3L3qWeaU3e8nogw+rn7MZtzKgwJosZpPkEI8OptzWX8Sn4kPUZ4p9bUP9a3wRJO89NimU8z+ywpmGz8bBVMOweGk30UNBTZGuLb3CbBC3dGFZvJSU8Mg6zAqqnMEluB3KJm0kazmUxgY0NG4KrrYaUDPvO4BUlfDVXy3BHAogFTjYVLm8jcfBefQPwFR1PlMO0y21TjYE8gvPsXuXKqqhVVLXhttLJn3bPgp544GZ5DpeyGKUPvViFbTPopQyUEmygu5rVTUTIwC4XcrDkixp3tCxKCCFjZBpc2VPTmd1geCdh1QN1j6Ie5u4kJlfO3eb/FNxCJ4tI1Giw6oHZb8lUYBxhf8ipqWeA2kjI6IK+qg7Eh+Cp8cYerPHbvChnimaNnIHLcE2V3FNeD/gcuARfdEgC50CqsZgiNohndz4KfEKue+aU25DTojiklNmMLj3KlwF51nfl/KN6bS4dSjstv36lTYoN0bfmVJVTyHV56NxQa924JlFUv9S3xUtHsNmZHaF1jZMoaZvq3+KEcbdzB0SVEEXblaPmsUq6eZ8RidcjeqR2amiP5VXSSR0srozZwCpcRrA8F78zeIPRjA+wY/wBl/wDVUP8AEx9GMi9az9Cw0BtQ2w4dGLaVrO+NWHJYb/Df9Sm+6k/SVCAW7kxgzD4obgsb/hWDnIhG2y2LVhsYMzfyjoxPEJIHiKLfa5KZiWIN3vzfEKurX1eyBZlyrC2dRzvl0VbNlWSN4HUfNYdCyQvzC4sn4dBrYkK4O5WNr206QSFFXVDOOYd6ZiEEgyyst9QpMKoajWM5f0qpwSqi1ZaQd29Oa5ps4EFNe9hDmuse5U+NTs0lGcfVU9dS1AGSTrcjvVrcU1xQcD/gMusi4pxAFyqrGIYhlh65+inrKioP2jye7h0QUNTUHqR/NQYHAwZp337uCNXSwNyxN8FJiE79xyjuRJPoRUEAFzqmsY3stATntaLucAsSrqR8Do2vu7gjjb2Rsa2K5y7ysNxGepmc2S1radGJQ2rpO/VCNqw116UdxU4vBIPylUsMklg1qtYLGngUob7Tlh5+2h6MZ/ioP0qiP9pj6Ma/iKc/l6MM/h/+pTfcyfpKg7Ki+8Z8ejKHDUXXk8Hu2+CrcjKt0bRYWCwpush6K120xCbuNvDosFh7bUze/oxmPWGX5FYY37AnmVVybOmmd+VQdm6o48tOzTfqq+KnZA+TILhBwIv6DXuYbtNlFico7YzL+xVmj2j571V4FbWB/wAipYJYjZ7SFuOipsWq4LBxzt5FU+KU89rODTyKFzZyEhCDgf8AADn8lcFVmLQU92t67+QVTX1NR23acguSpcPqKnsizfaKgwqjpxnkOY9+5S4kxvVib/spaiWXtO6ACdyjoKh+trfH0KV+eCM9yqtp5PLszZ2XRfaTDM+Qn4psTVZqonZKiPoxdn2kL+63RhLtJW94PQABuFuitmmqKnri2U2tyVO7LNH8UFjv3tOe4qkP28Xx6Mc7dN8+jDP4c/qU/wBxL+kqn7Cp9Zo/1dGL1U9Psdm6173QxPER6/0W0llnMkm8rCx9m89/RfPPM7m89MDcsLG8gswzBvFYjHtKOUchdUTctLCPyrGZMtJl9pwVO2+RvNNFgAscktBHH7Tv6Jg0AVPhosHS+C8ipvdqTDYj2CWqeB8LusPn0sq5mDtX+KbUwTNDJWDvupcDgkuYXlv9FUUc9O60jfnwQ5qkxaeDR3XZyVPVQ1LM0br8xxC3KOYO/np0ROZVdRFTszPd8uaqsWmmuxn2bO7opqOepdZjdOfBQ4ZRU3XlOc9+5PxE2swfNSSySG73E9EcEsnYZdT00kGXPxWGvAntzHRXR7GtcODtR04XJ9m5nI9EeEMGbNIbX0AU1FA2CTI3rW3pjrpps4FMOZoPcsWbemDvZcgsKNp3Dm3ofUvpcWfqchOo7ujFKb8do/Ugdb8kx+ZjSOIWLUr54GlguWHd3Khp5nSsJYQBz6MbfeeFnIf16MM/h/8AqVR/Dy/pKg7CpP4iP49GLU880kGRhcACjSzj8JyyOb2mkLDPuD+pO0a74KHceiFuaWMc3DonqcuKU7OGWx/6k5uZpHMJrcrQ0cAscf14GdxKw1maob3a9GLP2laG+wFhkOebMdzeisxKKmdlsXO5KDF6aU2ddh71iUkbaV2bj2VG7ML+hHVTxdh5TK6OVhZK0a7+RVRhUbhmgdbu4KWGSI2e0hMkfG4OY4h3NUuM5rMqR/1KItLBltbuQdb+eScApXmOJ7gLkDQKonlndne65TI3yPs1tyqPDoAXuncDk3tT8RyNyxtH+ifM+V13OuUFFQTycLDvUWHQs7XWKFmjksVq6V0eQPu8HSyiflc14TCHNB5rGIrxslHqH6FDow+TLUAc+itxBlJYFpJI0UuLVUmjQGqMFvRROzU7FWsz0sw/Km7lh7rVTOjFmf25p9piw6fPFszvb/REBzS0jRVEGwmcw/L4KirhF9nJ2eBTXA6ggq6qsTggBAOZ/IK75pTLIdT0YdPEyAh7wOsqqrpvJ5bTN7PNQ9hUj2tnYXGwW3hO6RviszfaHRjbiHU4HesMnDXmNx7W7okwuFziWnLfgqmgZBA+TMTZYcM9SzuBPRWSXxGVw9Uj6JjszWnmOjEnbTEH/lsFhMdmvd8ugv2tTLJzcqCLZ045u1T3BjXOPAJzjLM+Q8Sixp4J21Ia1ziQNyZYCyoKbOdo4aDcpKeKQdZgVdStpw1wdoTbpZUPj3H5KKohkYWTC/cVNhWZpfTm/wCQ70WlpIOhWGVs8UrIxq1xtlRuoTcHu/nc+mV3irnW6xKm2FQ4eq7VqgnfDJmaVtnHj8k0OcsoaEJdeqqabbQMd4rXWyqaysne5rnWHsjcmw80Fh8ment7OimiEsT4zxCF2ktPDoYcrmnkU05mgrG4s1Ox/su/qo2l3ZCbRVBF9n0YW/qPbyKIuCOYW4uHIqF2SVjuRUmLUTPXJ+AVdWx1UkRY1wy81FM+J4e3enYvWncGt+SfPUTPBkdeyIuFZzey4hHaO3vPihGh0EXRiCaLCyK2SyEcUHTDdK7xTnTSFu0eXW59EWLzxANkZnHPihjVLxbIFW4tBLA+NjHdYcVguUZySOQRNgSgc8kj+blh8memZ3aIoOMk8r+biVRMy0zO/VV0uypJnflsPmqRuYgcygLADksXm2dJl4vNkzd00lMZ3/lG9NaGgADRBwcLhY47qwN/MT0ZhxWUFPa5vwTKySLcUSXEk8VglOC907tzN3xKcTy+qpR9nm9o3/nZAIsUWnceG5YjS+U0xt2mahH6qHJlN96M9tyGeQ6oABYXUWlMRPa3dE+GSPqnOZYNdqosMgZ2usVUM2M8kfh8FhkuWbL7SKxKLZ1Obg/Xo2cmUuym3NYfJnpx3aJ7WyNLXC4KbHGwWawBOmjZ23gJ72GaXIbjNooKt1OXFovonYtXv3EN+ATcxJJ3noLGlZGjh0WQB5JsMp3MK8jqT+EUMOqj6i811XIIYVUc2rzVN7TV5qm9pq81T82rzVUc2o4XU9y831XsJ1FU+7KNPMN8bkWkcOksasjeSI0TZKlgIbI6x4Jgs1UVa2nzB97FT4rSup5Mj+tl0Co2ZrDmUBYALHZbRRR+06/gsOb/AGiLoxl2aqjj5N/r0xROleGN4qGJsMYaFiVZsIsje29QNyQxt/Ksad/aIW8moJzAVeSNRzNd3FVJbnIaNyY1z3Na3eSqOnFPA2McN/xTmZ3Bg3eshp/O3ycAjqVV4pT0t2t67+QUshlkc8ganoZGN+9GRrVnc/cFF9m9rhvBTHiRjXDiEXBrS47gp8cG6GO/eU+WeeTaSFMcWuDhwKY4SMa4cQqqkZUtaCbWKioqeLc2/eVKwPie3mFQVbKfatkOnjuUuNt/CiPxKkxCtl9fKO5FjnaucSmtDelkUj+ywlNw6qd6lvim4TJ60gTcJh4uJXkVGzeB8yjNh0frxI4rhrfXHyCOOUQ3Zj8kf2gp/dPR/aFnuD4o/tE73A8V/wARS+5av+IZ/dNX/EM/uWr/AIin9y1f8RP9wPFf8RH3H1X/ABAw74D4oftDT8YnoY5Qn2h8l5yw5/4jfmEHYdLudEUcPpX+r4J+ExcHkJ+EyjsvCfQVTPw7/BEFp1FuksCjc6O1tCE3GKph6zQ4eCrKo1czXZbAC1lBLs5Wv5FMe17Q4biqygbUEPBs8BOw2pbc2Hit+5UVKII7ntHeju3XTm1Mlc3btILnjoxY3r/gwLLdbRzTZyBa5SsAFwiqeofTyiRtrhUOJQVAy9l/slDefihJz/nJcAnOuqmqgpwHSO+SrMYlm6sYyN+qcooJZTZrVktmad4Qe62UJkBOrldrAtoXHqhYVL9mYnHUajong2VVIy3wUNFPL6thzKq6M07WnNe6wuXNAWeyVNXUsPakHwClxsnSGP5uUtRVVHbkNuXBNbZBoHRHBLIeqwlNwuc7yAmYawHrlxWyoKffkHx1T8YoItxJ+Ck/aH3cHin45Wu3EN+SkxCsk7U7/FFzjvP7lzHNDSR2t37lssjdzyEzE61n4zvmhjlZxyn5KPHwbbSLwQxPD5tHEf8AUF5LQzDqhvyT8IjOrXkKXDalmtsw7k6KQb2kIq3RS18tNp2meyo8Vo3+vlPepa2mET/tW7lg9GSNvJ/0D/XoZX0kji0Si/TXnNXzkcChLbtI5XBGMt1anOc8gFMidI4hqdG5h6wV9dFQ4y6OzZ+sPa4qOSOVmdjgQgS1NcD/ADZ0lkSq3GI4rth6z+fAKWZ8ri97ruKa1z3BrW3KpMFI69T/AJVVzRxutHbTgFK5znZjvQeQ4FOnv2U2Iu1cV1WBUtTs52P4cVvWxiL85YM3NOc1ou4gBV+I0z4nRM63eg52XQkXQj5rKOiOlnl7LCo8JP4j/kEIKKn1flHxT8YoY9xzfBSftA7dFF4qbE6ybfJ4Iucd5/exsL3taN5Kxehy0UBb+ELH982R7ey4hQ4vWxfiX+Kix/3kPgocUoZhlL7fqU1LSy6t8WqTDZPUcCnwSs7bD0ZVkUOJ1EADe03kqzFtrDkiBBPaTY1hMk23yZyWZd3RLIPKp78ZCi0ORY9mo3Iz9Xv6IpXRnTwVH5NPE9jhqfVP+iq8Ikju6LrN5cQrKlqp6Y52HTlzVHiUNTp2X+ym3CD/AOaPepZI4ml73Waq7E31HUju2P6nopsNqJxmtlZ7RUUdHQMv63PiVU18s2jeq36pzb7kWtHaPRCWh2qM/soMLtXLRUuIwNphtX2LdFPjbjpDH8ypJJ5zeR5KDB0RU80vYYT3qPCnfiP+QTZMNpm9a2bxKmxyAEGKEkjmp8ZrZTo/J+lPe95u4k/uYonyuytGvpMikk7DSUMPrTugcsKw2aOo2kzLBu5Pa2RjmO3OFlJhFa1xtESE6iq274H+HpMie/NlG4XP7kAm6ZNLH2HkKLGJm22gDv6puMUkpFwWfHUI0lJUNBFvi1S4VKPu3ByfE9hs5pCssvRh08UMpMhtcWQkY5hc1wIsgM7nE8SuvH8Eydh36KVzXPJaLBN3rZ5tyaS0qGueGgSdYc+Kmo4Kxt26Pt2h/qqimmg0eNOB4IEAXuc11RY1YBlR/nTXNkbma4EHcUyYcT/MSQEXZlWYhBSi3af7KqauWpfmkPwHBMa5zwGi5VDhLWfaVG/2VWV4b1IvFOe5xu43KAT3tb3lPDnm5Tm26Iw0C6MrQhnf8EWhWQUNFPL6thzKhw6CMZn9b47lNilFBoDm7mqsxmebqs6jVqVZZXclr+5wKm0fOfgFidMYKp3I6j0WSPjcHNNiFhuJCpblebS/16c2UEk6LFMV2t4oT1eJ5+lhNGG0jnO3y/0VTA6CZ8Z4H9wyN+/ISFbQ3Bv0xzSxG7HkKnxyZttq3N38VHXUdVxH6XKfDY3asOXuU1JPF2m6c+kbSO+R5CGZiDg5StaN3Rs9EwujTSxyso5XxuzNKhmhqGmN4GvA7lV4S5t3Q6/l4q28blSVs9Mbsdp7KoamCoj6mh4tTHOBtbRA3/l73XuVI87HLE/KeF1UQVEbiZWn9XRS1T6WTOyx+KgxSjqm5JOoTwKqcLPahPyKLDGSHixV7rKE7K1qNyrW0QvuUcA9ZZmhakqDDppNXdQd6ZTUlKMzyP1OVRjkLbiBmY8zuU9bUznryH4cOnC8MjkjE02t9zU2CmYLNhZ4LJH7tvgtlAd8bPBS4XQzfh2+Cn/Z+QawyB3cVLBLC7LIwtPf6FL5LmtOHW5hRYVhuUOAzjndMjZGwMYLNCnpqeoA2rL2VVQYVBHnkZb571M6NzyWMyt4Dot0U4c6eMN33XABWWNBxoiQdx19Gh8heck7SPzXQweg9g+KAAAA3BT0NJUOzSMuViFBh1KL533O5itfd6FBhctUcx6sfP8A2TqNlBVNMzM8J3FVuMZH7Oly5BxtvQxUP0qKdjx3aFVOGMfF5RRnMzi3iPRp8RqYNz7t5FU+M0kthJ1D37lU0NNKM8Wl+I1apqOeLtM05jcr2WhT4+ITiTvTRdMfY9ZdV3egwBNKEUknYaSoqBkYBlPx5BVOLUsOkXXI8FPO+okzkNv3dGHUlY+QPj6gHrFGT7NwJ1A1so3BuXX+Xz08nWydZp9VZ2kOGoNtxQaLZTrpxVRhEcnWg0Ps8FPDLC+0jCOiixSensHddnJbegr22uL8uKnw6WLVnWb9VqiwneUWgJ+u7ozkhUlK+d4F7DmmxUdE25sO871UY40fcM19pymqJp3ZpHkn0YK8eTQsE5iLRy0KbXVXDZSju0KjxODNaQOjPeg9p6zSCgd6BUsMM7MkjQ4KvwV8V3w9ZnLiPQwmrnjqGRN1a86jpxCeeWpk2p7JIt6ODszVjSdzRdVmMQQaR9d/0VPjs7HnagOaT4KSrpayklDH65d3HobIWtcLDX0MDqJ5Gvjdqxo06J3vjgke0XIbdTTSTPL3m5PoURgFQzbi7L6qvxFtLZjY97dDwVPiBJMdR14nnXuVXRugmy+qey7mFS0YjF99+Kpo9m7M3T2hzWJYU2YGaAdbiOayWcQ7q29GCsqKc3jeQqbG4n5RKMh4ngpaGmqW52EA8wqmlmhOu7mE6V1rdDXDcsrSEGFp0TWucbAKHDXb5PBT11JSMyjU+yFV1s9Seser7IXAqnoqioPUZpzVJhcMTuv13jwWV2Zrg1XaewLutYgKKGS4dI7duA/mEkMcg6w+adBKxwNs4+qjd1yANE5kcrCJGgqqwTeac/8ASVJE+N2V7S0oaKjxeWKzZes3nxWSjrmkxnrKcbF7mcQsjnb04ZeiBzBI3Pq3inVuzd9lqRud/spJZJSXPeSf3F7JlZM0WJzDk7VRVTAbsJid4tVJiOd2ynsCey8bj0BA8FjWHiI7eMdU7xy6cFaPKTK7RrGk3VTjkTbtgGY+0qTHIX2bP1Xc+CxlgbWFw3PAcPRY97bhp371x1TrZjbcg4tNwegehhUsNLRvklcBndp32UuOybQbJtmjnxVNiVLVtyXs4jslSsySPYeBI6QLqnwS9G4yaSu7Pco5NDSVPDRpPqlQYeC8seCCPqFHTtMRpp9Weo7koHPop/JqjsHsuTGZejF8M2w20Q643jmrelBVz05+zfZQYnTyM+2FiB8inuzOJTLX1QYHKz2fBU8W2lay9rrNS0URzaf1Kq8UmnIYzqMXHVQUs85tGwlUuDxRZTMc7uXBW9UCwCfnB6ls54IU7322hsPZCaxrBZot/M5IWSWJ3jiiHs3tzDmEHXu4WUkccoySMDhbiqvBSLvgOnslcP8ARYE3rT/JVQHlUp/MnuTmk6lELVZXLIVsydy8jk4+CNKGdsgfFOdGL5Rf4rcUdSrH0IXgOs7sn6d6oZnSU4zdpvVK1HwW9Sxtlicx24hSwujmkj9k9Gd2XLfS+7pLnEAE6Dd6Gbq2sFHFMTdjHeCbhtdJrsj80cHrvYHin4fWtGsJTo5GdphHokk7z0ve57szjc9DGOe4NaLkqiw+OjaJJRmlO4clXYrJmDIXa31I/op7V0O2aPtm9tvNUFc1rmRz7h2XcR/7LZs5aKpo46iHZu+R5KiqXwv8kqe0Ow7mOnGsP/8AUxDX1x/qraXULmBwzi7eKFLBK28dj8N/gjQv9XVGGy2ZWQrVBosg1zdyY7MFR6VLPmsb/iY/0LL1gG6qkwe1nVJ/6FltlDQA29rBFzNb5r30A3qOCVxueoOV7lMjYwWaP5vJA1xu3qu7lkkGj/EKTqxSn8p6MBH2cx71UG80n6j0G5OiMNtStBuQBJ0Cgw1ztZNPyjentoKNvXeAfZG9T4k51xCzZt+qLiTc6/ucIH9lzH1v9FqgdB9VUS7KmdIOCxuO1ZmHrsBVj6UNJUTHqRkqDAuMz/kFFh1HFuiB+KIAy2FugoXunNa4Wc0FTYRRy7m5T3KbA6hv3ZDlLBLEbPYR6UMEk0gYwXJVHRQ0MdzYyW1ceCq6uWrm2UN7H6qKmZR5WtG0qXbh7KdQln2kL/tRv5FVMbZs0kbbPH3jP9VhGJ2tBMf0HoraJlVFbc4dlyoK14f5LU6SN3Hn0OeLG+7isQpWxuLo+xfw6Gvc03abKmxQaCdl/wAw3ox0lXGCyz+/iqnDZY9WdYfVWVlkN9EDz6KP+Ki+Kx4Wni/SozZ7D+YJ3aHW3jRMjfJudlb9SmRMj7I/nU3BVbiKWf8AQVdYGLU8p/MpNXv+JVlmDdydd29RUEz9SMrfqv7NRdohvw1eVUYtK5uzhGzZ9SiSTc9MMTppWRt3uKq6KakfZ+7g70hr8VC0QUsLO4IOOcjNv3I2G86rFn5KC3MhYtHnoKSfkAD6DIpJDZjCfgqfA6h+spEY+qpsMo4fw8x5uT7i9rDlwW1hH4jfFGrpRvnZ4ry+i9+1ecqH34QxKg9+1ecaH37U2to3fjs8U6pgtpNH4pj2ucbSNI+Kexj2kPYHDvVVhMD9Y7xk8N4U9JPB226c+mioJqt9mDTi5MZS0EJy2/M8p8lTiU2ziBDP+9So4m032FK3NN68h9VQU7YRxLj2ncSsum5VtJI0+URDrN+oVTE17dvD2fWb7J/2WD4ltGiCU9cdk8+jEKFtSy7dJG9kqjr3uDoJfvm//UpJ7gEm4KmkZtQH7njK/wD0KmidFI5jt46WSyRuuxxBVPjN7NqRf87d6mho6mPOw5vzN3/MKejmhJ0zDmE02XVcgLKm+/j+KxwawfA9DTm2Lja2VUnamH5v53JvWJaUc5/KrrCB/wCHu+J6aeilnOgs3mvJKajZnLhfmVU4q8tMcOgv2uJRJOp6MhCt0YIAa8fpKmgjnjMcguCq/D5aR/NnB3o4RRmeoDyOozUqbMdyjGUtHdog2562qxuozSshHqrYbXDBCd+y+qIIJB4KMMLuu6w5pr8Nj9R8h79EMa2YtDTsaE7Ga13rAfJOr6t2+Zyc999Xkrhe/Roiei+nQN6uRuKFTUN3Su8U3EKwfilVFXNUZc53K2h1WHYS+pOeTqx/1VRU01HDlbo0cBxUUNVicuZ/VjCY0N/s9IMoHbf/AN8VFC2JuVv/AOVqiE5uiqqZ0EhmiFx+IzmqiFotPTnqfVpWFYl5Q3ZSH7QfVbZvAqso9uczDaZuo/MjVOc1wItJ6459471JKXcTZVg2tJS1Hdkd8vRhmkidmY4gqmxmJ2lQzX2gn0NJVMzxkfEKejmgf1h8+iH72P8AUFj9rQfPohOYU/6B8FR9qb4/zuTesVP9gl6MM0wvxTGOe4NaLlU+GMaM0xv3cFW4vFF1IACRx4BTTyzOzSPJ6KahqJ9Wts32juRpKWjgMzvtH+ryunvc9+YnVX6MNn2VbE7hex+fQ5rJGlr2ghVmBuBzU2o9lSQyxOs9hae9Mp5pOxG4/JUuCO7dScjeXFRENzNhs1rdA3v5q3V62umq00spJfJqV0sh1ATS+epB4ucqbN1rrG6LZS7Zo6r9/wAekJjJHdlpPwTMNrXboHfPRR4LUu3uYPmm4G+/WlC8xxW+8cvMdKPWeV5noQNc3im4RQaaE/8AUnYNQ20DvFHA6bSz3p+CAAlsh+YTsElsLStKfhlY1ubZ3HcnNcw2cLHowrCs9p5x1eA5qWUAWGgUeHbebaTnTgxSX+7i6reJ/wBlGGsaGjRqGirKyKkjzP38BzRxKvf1ttHGDuCbildHq/JKzmFDNFVRbSM/EKpi8ll2kYvG7tNU0eyLJ4D1DuPIqOrNRDtB22/eN/1C8qvax+DlOzyvrt0qGC5t645hPJLjdQdfCKkexID0g2N15LDUQiVhyHc7ldTUs0PaGnPh0U1ZPTOvG75cFS4pS1bcktmu5HcVU4Zxh/yqxa8Aixusba7ZQ8r9FP1qOAnshu9Yf+Lr/O5O0saNqE/qCusNZmw5jeYUklJh8ffy4lVmJz1Ol8rPZHTQxtlqomO3ErZ7mn5AbgsWnzz7NvZj09HDq3a0rXbyzR/w5oOa4Ag3BWb5La3tdt1tdbBqke5zusOOi3OEjfgUwjUtvrvTNW31t3rFq/yiTZs+7b9VhcV5NpbduUBU0TJ4nRvGhVbRyUsuVw04HooamkDbSRMDhucRdHGqZtsod8tAn45fsw+JRxiq9UNHyTsTrj+MV5XVOP3z/Fbeb3jvFF7idSUTroTZCV49dyFRON0r/FNr6tv47vFNxStH4n0Xneo4taU5xcSSsLpxUVkbTuGp+SnxajikLDmNuSZiuGv33HxUb4Xt+yeHImxQ3ILFZzNWScm6Doa9zTcFYfVbGqYR2X6OCqRrIxNk2D3MIzMPaC69LIyaJ128D/oVNlLPKYB1D94z2SvKpA5rhoWnQqaNlXEaiIWePvGf6hQzxNwupj9cuHz6B0YXPkl2btWyaJtKcmVzvisQhZDVPYwaDpocWmgs2Trx/UICkrGNfo7+qx7+Fj/WtFQC9FB1j2fkqNuV7/53JbMsbFqMfrRBCbi2xpI4oR1gNSnPdI/M8knio4HyyZIwSVRYNDHZ03Xdy4KtAFXUf/MKwv8AjofisobuVT/ES/qPo0tVJTSh7PmOaZOcm3puvGe3Fxae5QVMM46jtfZO9X6zmm45LN2m63HJO62hutpuBdvH9FBKS7M09Udp3BYpiu1+yhPU4nmoo9o/KqZmTK1u5RGzbDXvTN5U0EVQwskFwq/DpKR3Nh3H0SLfuN3Tghyyzu5QlPJc4k9EU0kTg5jiCqGvjrGZTpKPqg6x/qmOBOhVfEY6yYH2umlaX1ETfzhVnVe7cpyS8n6KCUNux+sbt/8Aumuko5bjVjvBwVVTMyieH7p3/wBJ5KCofBLmi/8Ayq2lvF5SxmXWz2cj020VH/FQ/rCyfmWMD+3P+AUH30X6wqzBWOu6DQ+ynxujcWvFiFBUSwOzRvIVXiRqqcMeOsHdGHj+xU+ullDYSH4fzuTNn0ssd/hY/wBfRxVHhM89nP6kf1KgpoKdto2W/r0V38ZUf/MKwz+Ni+KZvCqv4mb9ZWlvRp6iWnkD43WK/sdfq07Cf6FF2L02jhnb4pmIVrv/AEhPwug/EHbqQN73FTPhZY1VRtSN0Ue75lVFbUVVo2tys4ManwSQZDILE8FFPG2+lrnVU1Y1rm66FMk01tl9oLNYE3WUPbr4o5X3gnAN/wD6liOFvpjnZrH/AE9ME7v3FHUbCYO4EWd8CpBle4Xvr0se5jg5psQqOt8si/8AjN3j2lFUNvod29YjQ+VsE0X3gHinNc1xDhY9GFUmyHlUot7AVZU5fiU55O896yuLXEDTioJ9Nk8ZmHxHwTM9JIY5m3jfo7v71R4aGymQWez1HLEa9paaeE9X13c/Qpv4iL9QTZAdOKxj+Of8lB9/F+sLiqilgqG2kZ8+KrMInp+u3rs+vQHaWVCA6ih0OgUH3ny/nb+2sd/hoxf11DBLPIGRi5VFhMUHXf13/wBPQrv4yo/+YVQPayqjc42AUmNwM+7aXlSybSR7/aN/Q+WnTxUGJ1UOmbMORXnKnkOZ7Hsd+Upz6B++eZN8zt3mRyixPDYPuoSE7GKGTtxEr/wac7zGVNhMjGGSGTOO5U9fNC6ztRxVPOwjNHq08E1w0cNyexsjS13yKEzmO2FRuPZfwKxLByy8sAu3i3l026Gkg39ErKct/Qtc2CpcGc2Hav7fBqqKaOa5BGfjwPzT2Fji071FI+J7XtNiFK8zMFXDv/EaqWuzMu12vsqWWCV32tO096vSs1ZAwd6mxFovrmfw5BF5O9Bpdew3J5H3UNyOPesPw9rG53jrf0VfiMJ+xjYHN4n/AGRrJGxuhiedmfRa4tcCOCpsXZn+0ZbvCxKVktW97DcKn+/h/WEUbpsmfh8VXYTHNd8XVf8A1UkT43lrhYhYYM1FCO5RC02/h/O36uKrKHylsbM1mg3Kp6aGnbljbbv4np4XVRitHD6+c8mqok2s0klrZnE+g2N7zZrST3KHBKt+r7RjvUODUsbbn7Q/RTNY5uTZjJyAVTT7F+hBB3fuqasnpzdjtOI4Iw0uJRmSLqTDe1NfUUkvFpHBUlbnaS3/AKm/6hMNxcblJHHLHleLtKZPJRvEM5zRHsSf6FYhgwkvLT7/AGf9k4EEgj079B6WtLnAAXJWHYSynAkm1k5ck6oAzdyqiXnPufzUzBL1xv49FLUvp5Mw1HEc1Vw5Ms8P3b93ceSbUPe23LeU+V2mqDi0/JAc9yDpZssUbdOQ/wBVSUjKZm0JH5nH/RV+Jmb7KLqx/wBelrC5Q0W2OUad6mwurj9XMPyotLdCLehC8MljeeDgVBitHN6+U8nLeg3eibacSqmjhqx1hZw3OVNC+npmR33cQoWls3y/kBeAtq1bRq2gW0C2rVtGratW0CzhbQLaBbRq2gW0C2gW0CzhZws4W0C2gW0C2gW0CzhZwjvPTPXUsHbkF+QU+PPOkMdu8qarqJj9pIT0hjnGwF1BgtXKLkBg71BgdMw/avznkoWwx9SJgAU80UXWkcAFJjccTS2CO/eVNiFVNvfYchor/u2Pcxwc02ITZIsRjyvttR9fgnsnpJd5HIqjrzJu0fxbwKjlD23G4nVPhjkBDhdp3hZpMPIDrug4Hi1V+Gx1jdtARn/+5PY9ji1wsQt37mGGSZ4YwXJVBhcdGM7+tJ/RSyGRhcHEAHVSSaWtpwHep5gGO/7ue5GV2YnnvVi51hrdSRvieWPFiFR1Abmhk+6k393ep4XwyuYeCN9y9klRwyVJs3RjVFSwUcOeQ2b9Sq7EJKo23MG5voRvcOFxyVJXUfVv9n/RNyOb1CCn08M0dpYwdVNgMbtYZLdxVRhlXBvjuOY9CCtqqf7uQ25cFDj/AAmi+YUdVTVF8kw14cVBrmcQRqnHPuNgondcXPC11nC2rFtAtoFnC2gWcLatW0C2gWcLOFnC2gW0C2rVtGraBbRq2gW0C2jVt2LbNW2Ys4QePQkdaw6LdGqGZWViiD0EHpt6fW9PVTTxQtvI8NU2Owt0iYXd5VTidXNoXZRyHoU+HVc+rYzbmVDgEY+9lv3BRU9NT/dxgd62ti7Nu5qfFaON1753DkpsbqX9gBifJJIbvcSfS00Wlz0aaeln+0zM010UNRFXs2FRZsnqu5qenmpZeVjvVHXbQ8pP/u/91DUXGm7+idleLEXaU90uGSXb1qd3D2VXeQVcIk2rWu4FOFiRfp06Opk45r9NLSy1MmRg+J5KmipKBmX1uJUlbGTcu05KWqzHR4s7gp5w1pPyUkjnm5KjjdLlZGwlyvFQaCz5+fBic4ucSTcnomZt6Knl9cdX42Wm/iqWlfUuueyrw0EOeQfpaqytlqpMz93AdIQDDxsUWSN14cx0RTzRG7HkKLGpgRtWhygxKim0vlJ4FOl3WCmpKKftxj4hSYFxhl8VUUVTTn7SM/Hh6FNilVBoHZhyKhxuBxG1iy94UEsMozRvDk69lZ2YXtu9DVda2gVn3voutbX0bOW7SytxC15dFuiykDrabwhnG9Frr3Cs7h0xOvp0zb2lZhIxzcp3FOkkDiM7tO9beb3rvFbeb3r/ABW3nH4r/FeUT+9f4oTzW++f4o1E/vX+KFTUa/av8U6on987xXlE/vXeK8om967xQnm96/xXlNR75/ivKZ/fP8V5VUe+f4ryif3z/FeUz++f4rymo98/xW3m96/xW3m96/xXlE/vn+K8on96/wAUJ5/fP8V5RP75/ivKqj3z/FeUz++f4ove49ZxPxRRUNBVz9iI25qLAHW+3mt3NUFJQQdmNt+Z1Kkc64sp66mh7cg+CqMa1+wjA/MVNUTTG8khPp3/AHtNWR1MYgqe1azX/wChU8ToJS2+4pmIuaAbdfiefxT8RqjfLJlB4BFzi7rOJRXL9wHObucVtZPbd4raSe2fFbWS1sxsnPe7tG6uhX7GHZ08eQntP3u9BtY9tMIco0dcFPfndewUOMyRNa1kEdgqurlqpM8h+XodXL39DXObuKc/NvaL807L6p6YayoiHVfpyO5MxVmSz4tebTZMxyJotsXeKOOxe4J+amqcPm/9MWHm0p2W/Vvb0Gvc06Ej4Lby+8f4rbS+8d4ryif3z/EoTzn8Z3+Yrbz+9f4rbT5S7bP8SvKJz+K/xW2n1+1d4oVE/vX+K8pn98/xXlNRf76S3xXlFRcjbv8AFeUT++f4ryia+kr/ABXlM+n2r9fzIzzafav1/MtvN71/iVtpfeO8VtZst9s7xW3n96/xQnm98/xKM8vvHeKEsnvHeK2sp/Ed4ray+8d4pskpcBndv5pjMrGt5BRDrHpm3A8imEW0WIxbOsmHffop8KqaiESMy2K8xVv5fFeY638vivMVb+XxXmKuPs+K8w1v5PFeYa38vivMNb+XxXmGu/L4rzDW/l8V5hrfy+K8wVv5F5grfy+K8w1v5fFeYK38vivMFZzYvMNbzYvMNb+TxXmGt/L4rzFW/l8V5irObUcDqxxZ4oYPVDixeZqrmzxXmaq5s8VDgZOs0vgoaKip9WxXPMqSteNwsqjEQBrJ4J2IyX6oT6ypk7UpW/0rHkhDMd0bvBNw+tdugchg9efwkMBrfyj5ofs9UcZWIfs9zn+iH7PQ++chgNJ7T15joeTvFDBqAfhnxXmqg9yvNlD7gLEqSihpJHiFt9w6eKNybnoipaiXsROKjwKsdvytTP2db683ghgNIN7nlDBaAeoT815noPdLzPh/uvqjglB7J8U7AaM7i4L/AIei4TuTv2dPCdH9n6r22I4FXfl8UcFr/djxU9HUU9toy1/+eggfO8MZa68y1n5fFeZKr2mIYHVe0xeZKr2mIYJVe0xeY6v22LzDV+0xeYqv2mLzDV+0xeYKz2mLzDV+2xeYKz2mLzBWe0xeYKv22LzDVe8YvMNWPXYvMFX7bF5irPaYvMNX7TF5irObF5irObPFeYqzmzxXmKs5sU+D1UMb5HFlh39GHRbSshb39EfHpeLsIVmkbljkGsc3yPRgFTdkkB+IUkjWNLnbgvL6bmfBeX0/f4IV0PevLIu9eVR96FQzvW2b3raBZgswWYLMFtAtoFnCM7RwKdVsBtZy8sZxik3ry2M/hvXnCJp1jdobJ2Jw9fqu6u9ecYW9XK/s3TcUhJZ1XdYIYpBlzZXWvZVGNsFxFET3lS1U82r3+HQNdEymqH9mF5+SbhOIO/AKZgFad+RvzTP2dPr1HgE3AKUb3yFNwegb+Ff4lCho27oGIRQt3MaPks8bfWARqqf3rfFGupR+KF5ypPb+iOK035j8kcXj4RuRxflF9V52l92F51n9lq861P5V5yqfyqlldJE0u3r9oJvuYv8AqPSCbiypcFqZ+s/7NvfvUGE0UPqZzzcgABYdG0Z7S2rVthyW27ltu5bYcltgtqxbRnNZ2c1cc+jHpc1UGeyOjCW08lRspmA33fFea6D3AXmyh9wF5tofcNXm2h9w1ebaH3DV5tofcNXmyh9wF5tofcNTsNpDG8NgbfKbIixIQFz6LQSbAaqmwanbC3bMu/ivNFB7n6rzTQe5+q80UHufqvNFB7n6rzNQe7PivM1B7s+K8zUHuz4rzLh/sHxWI4XRwUr5GZri1uiGTZysfyN0MWj7RY+4KbitPd1w7QIYlD9no7rAoYhCYwdnJv5LyyLX7OTQcl5Uw/hvFhyTahhG4oSgraNW0F7WKuFdXWYLaNW1atuzvXlMfejVxd68sh7/AAXlkHtfReW03tfRRyMkbmadFjsuWlEfF5/p0YFBd0kx4aBHmoxZo9C1iQqyHb00rPBHeqWcwTskHAoFk0d97XhSxmN5aeCcdR1rDimvfG/ZyfIppQQQQQWtxy6TfgtPFWTlJl1vlRDecX+VdTnF/lUrm2J+z37gE615OrpbgiOsRld2EPw+0uHHtJ2mYd/TTzOhmZIOBUUrZYmyN3OCklZG3M82CdilKOJKOLx8GFOxd/qsCOJ1J5J1bUu/EKMsh3vKJ6bFWVlZWVlZDWwVM3LGsUm21bKeA0Hy6KenlqJAyNtyqHCoKYBxGaTn0OmaNyMrytShG/kti9bB3NbA81sO9bD8y2B5rYvWyesjuSyEWv0Vku1qZX83dEUhjka8bwbqJ4kiY8cQq+epgl6r+q4aLy2r94vLar3pXltV70ry2q96V5dVe8TK2pztvJpdN4LEotlWzD81/HpBt0HfuWC0Fz5Q8buyq6p2EWnaO5ecav215xq/bXnCs9tecqv2l5zquYXnOq5hU1bUyutp3p8jWML3GwCxDEJKqTkwbh0Be38V734IfeM7PYUdrNHV396DG3OrPqmsbbePqomAbk0JzdDda3Dc+8XCCPJXXDVFFFFORe978jPm7kmm7tHEtUcRc6w4pgEbAOACxKq8pqSR2Ro3ooYDDSRt4nUoDrNHM+jK3UFahYrTbGpJHZfqOjA6wW8ncf0KtgMrMzRq3+icE1zXt2Uu71H8v/ZBz4DlkB7io5GuFwbppQKBQI9oLq+0PFXb7Y8VdvtN8UXaGzm+KDm6ddtldlu2PFPI5hOJN7Jzpf8A4n+QI5//AIv+RTCS3r9r2U8H7TtrKQ53Uk7K4R9v/vkrabndpSb3WBtfj07lgNXcOpye9qnjEsL28wiNbLK7ki0hBpKyq3p8FdXXBUzc0zVPIIKR7uTUTc3VNTyVEojYFR0cVLFlbv4lOcGpzy5Nie7uCbAwd6tb92dZfgsSm2NFM7usPn6GCTZ6PL7BWKxZoA72SgOayhZQsiyJ2ipHZ6eM9y/aGK07H+030cPpDVThvqjVy6kcfJrQquczyl3DgshWRZe9ZURZa3WH02Vlyscrs0nk7Do3f08lbtaFWJ2mjuym5g5p6/3SjElmfeeAQdJzl8AmOfbUu/yqIpmX2gud3t+CBjHrNurt4PaszNPtB4rPHwe3xWbf1mq6uEVJIxmrnAK8lScsQ6vFylcwfYQHT13+0o48hAVLFlGc7zuWM12zj2DD1nb+4dGF0vlFSL9lmp6IW3kLvZ09FzczSEc2U6qspBVU2T1wLtTmlpIO9Nc5pBBsRuWG4g2rZZ2ko396qqR2r2D4hOjuCUyokiaGuAcz2XL+wSHtPiPiFsMN/vb/AAWxwr+8yLY4R/eJFscH9+9bHBvfvWwwX371sMH/ALw9bDB/7w9eT4T76RbDB/fyLZYP7+VbPB/fyotwvhM9Wwz3j07yHgSr0tjqVem16z1en9qRXh9uTepjFlcGvebnj6FFKYqqF49pFVTQKiUd615o3urdFnHctjMhBJxIQpn802jd+ZeQyHg5MoH+yV5ucfVCGGfBHCgfWVRQTQi/aasNZmfdY9LlpA32nIAkgBYbRClg/O7tFPflC6zymRBvx9G4W0aOIW3ZzC27PaC27OYW1as7VcdEWrnu71+0Uv2UMfM39D9ngckx4XVVbyeW/JBEeg5YS+9NbkVj8eakDvZd6DGF7g1ouSdFQUYpYAz1j2isSqL/AGTT+pD0TuULftAh9nF+lqleXyPceJ6Wlmm9fZ8ymmmv1i5XpdOu5f2DS8jvBZMM1+1k8Fkwv30vggzCffyoR4Rf7+VbPBT+PItjgvv5FsMF/vEi8nwf38iFPg/v5FssJF/t5VscI/vEi2GFbxNItjhdvv3eC/8ADo7aSSW56BSzzTAMDMsfsjco4Q0btVTU25zx8Aq+uFJHwMh7IT3ue8ucbkoAk2Cw6l8mpwD2zq5E2UbcrQPSmYQc43cUG6/6rFcP2l54t/rhAXO9MkdE8OY6xCocViqAGSHLJ/VS0mcuO4/1UlDUn1LhGD2hlTo2WstjEtlGvJozxK8mj715NH3ryWPvQpor8UIIhpqjTxX3lbCMahOhAQiHf4Jsf5SUYjyK2R4NK2bvZKDH8ish/MpOWvoUMe0q4G/nCKqnZqmU96jtfXoC5qjgL89kYaWFl5CPiUa/C2+uxHGcObu/oj+0FKN0bkf2iZwgKP7RP4QhH9oan2Go49W/l8FBj84d9s0EdyhngqY8zDcKKmjhvkWPy3ljj9kLBaXbVO0I6sf9eg3e7+iYwN9CWaOMdZ1ltppfu26c1sH+vKi2jb2px4ra4Z75nitthnvm+KEmHe/b4rJTP7Mw8UKU8JFsqgesgapvq3UIIYLrGZtrWv5N09DBYtnQtPtG6xJ9oMvMobtdyJPoFYSbOkaeIBVfHtKOZv5fQwSgyt8oeNT2FV1Ahj7zuR1JO/pNuCaLnejvKddUDM0ixB+zopz+XpaLlZDp1Ssh5FZPyrZHXRZPitl8Vsx+ZCK/NbBnNeTNJAv80KWMLySO29eTxt5ryeJbGLmthHmNrpsEY5rYRkm+gQhb8SoqSVzRplHeo6NjRe9zzVbikNP1W9eRTyySvMjzcnownD7f2iUfpCF7BRDM7NwG79w8ZXWd2TuTQ1rdAsTwzfNAP1NVuimxiqg6pOdvIqDGaKW2fNGfottRvH3sbl/ZbdqG/wAk002e94hpzWal9uL6LNS+3H9Fmpvbj+iDqb24/os9P7cfiFnp/bj+i2lP7Uf0Wam4mL6J3kvtwow0xOtRGvJ6Yf8Aq2ryaI/+oZ4rySD+9MRo4/VqmJ1Iwf8AqGLyYe+j8VIGxNLi5unenuL3Fx4+hgMWaszew26ebMce5G+Yn0aCPLCv2hktFDHzN/3NHWS0sudnzHNU1XDUxbRh+I5Kum21VK7vWEQ7KhZzfqpTZqibpf0JH5GFyyMyuqag9UKqx2Z3VgGRv1T55pDd8jj8/RumzzN3SOHzUWLV0f4t/jqof2i97D82puM0UjTZ5BtuKe4ve5x4npaMzgOZULNnDGzk1Yk923FuAV22/p6Nr8lRS5KtnfojqLKqj2VRKzk7owui8qn17De0iWRs5NAU8xnmzHdw6d+qDc3S/gsKZ1rrHX5aK3tO6aL+IaM2W+lyvJtP4iPxWwH95j8UIGHfVMXk9N/emoU8d/4hlhuWwj/vDFs4cthUsvdbKC3Wnj+ivSjqgxW53UYpBvkjK/s3B0azU3tRfROdTW3xfRf2f2otd+5f2bgYvorwe3H9Fmg9qP6JxgIsXR/RbaljGszB81Ji9CwWzGQ9yq8WqJ+q37NnILXU9GG4XulnH6W/7qyF3HZg/qKAsP3DmhwsU5roxYnTg5C2ixejiMLp2izgde/0dVqrla2vdXKueaueaueauVrzWq1TmuadVc9APejv3q/pfs/H9lNJzNlXSZKZ/forE7vRp22hYsdlz1pb7DQPQsek9NPUSQOJad4sUNSoW5YYm8mBS7whu9CdmcMH5lj2YUbLbs+v7/DYtrWwjvv0VD888h7+hrczrK3TZXy5bcDdMN2grHYslZm9oJjXPcGgXJVDStpYGstr6yxGoudk3d63Tpz6DorW39Du0sLZaK6/aKT7iP4n0L+hdXKuV1j0XKvovmr96+CB71crXn03R6MLoYhC2ci7zuvwWqbnk6rfm7/ZMY1gsP3bwASAqhm0p5Wc2rcT0eZ66wLWBw7ivNdf/d3LzXiH93cvNOIe4K80Yh7grzTiHuCvNOIH8ArzPiHuF5oxD+7rzTiHuChhWIe4KOFYhv2BXmqv/u7l5or7fc/VHCsQP4J8UcKrSNIPqvNVf7grzVX+4K81V/uSvNlb7pHD6xouYldX6cOh2NHE3uusUd2GfNNOn+qsnNtbXggohmka3vQ0A+CrJNpVTP5vPSHWVzu9Df0s7bfihuHwTm3Kurq6urqRjJGFjxcFVeBSAl1Ocw9k71LTzxG0kbm+lo4DQaItRHo/s9DeWWX2RZVMmzhe7uRKsmG1+8JozSMHNTNySuZyKb8FzVvkqF+aBvdov2hjvHC/vssFw/IPKJBqewFWVOxZp2juW8XzceljMzXu3AdHx+SCIRG/4qiblgasdfmriPZaB0CwO64Vi51mj5IUdSfwyvN9Z7ooYbWndCVHhtc2zth4rzXXE/dfULzXXe6+qGEV5/BXmjER+F9V5nxD3H1XmfEfc/VeZ8Q9z9UcIxD3BXmrEPcFea8R9w5eacQ9wV5pxD3BXmrEP7uV5pr7fw5XmnEPcHxQwSstd2RvxKsrXUDRHTRA8GhM67wLafvZd46K6LY1Ure/TowmfbUbObdCpJWRi7jZeWQe2vKofaXlMXNeUs5ryhnNbVq2jVnas7eaztTpWo1DE6pjdzQq4RY2d4J1bT8c2/kjiNOM3XIsbblJiVNf71OrKX2/onVlMQRc+CO89BVLHtaiJnNytYWVec1S7rdnRFAE7k1zLWd0ULC6cKrk2dNK7k1ZHn1ShBMfw3eCFHVH8F3gm4bWu/BKbgtefUA+abgFSd72hHAC0EunFh3J1sxtu4dHA9De0PimHMxh5tCPpZy02TXAogEai6mwqhl3xWPdopv2e91N8ipsKrYvw7juRa5u8EdLcp42KfA9oVj0HoweDY0TL739YrEpLRtbz6QbKjYXTs5b1iAyz/qC3dGqw1/bZ81PTxztDX7gbpzmsaSdwVRKZnl3TYuIAapxs4IYxx6xPosGaQDvUQtG0dyxCTaVs7vzlDopXRNzF+/goqilBHXKZXUjdQ877bkK6jBf1joLlGspTs7+sLhMrKYi7edl5TCOydPghOxB7SFmaswWdqzhbRq2rVto+aNTCPWXldP7a8qp79tMlY8HK66xGfY0chO8iw+fRQwmaqjYOaDNblRdv97KLsPcjwsscg7Ew+B6MFqtjUZHHqv/AKqoh2kZbx4J90173uyh2UnsqGe5yO0cFdNQKunB+XRbv90DvsnJ2qktc9lcN7fqpX/m9YJzydp1nb+SL3XddxPV5LM68eruzyQccre1YOTrkuPj04FTl1UZDuYE42BKdfM5x4m46BoOi9gsLb1C4o5TvsrwN9heUU49dqNdTD115xp/aRxKLkVTVInzWFrLFZNnQynnp6WDVO2pA31o9EfSIBRYszgtseIQkaeiWnglHXjaVPgNO/7pxYqrC6qn1LLt5jogqnRaEZmcWlbGnnbmgN/ycR/7KY2eWtdcDigLrDqM1M4Fuq03ceiudmmPIaLimA2J6MMbq5yxRmjHLW6Bs7mm311VA61QO8dFfUZjs27hvW9XR03KGBxIHrHf3KvP22Qbmtt6NIw7cXCkdkjceTU43JPSzq236hXOVu/ei92V4zHt33LaPJkDnns8lG43YNoOxyUcjco6zf8AKVCWkGxaoxYWTFxGm9WXEcQj0FFVEpzhkeryn9WTLfMR2uSHwvyUMezjAtrxWNVO0qNmDoz+vRgUGj5j8B0Qjq35/viMpeOW75qSFs0Do3cQpY3RSOY7eCuKw2t8qgAJ+0Zv71WwamRvHens13IWqd+kw4+3/wC6bO6M5JhY80yUX7QQeOaa5ttXt8Vmbp9qN/NfZetKzfpqi9nGQH5pz2e0FnHtfVOcfeP/AMzUZHbtq7/ME91+Lr5h6yde0urt/tLW57XZ16yA1Z1SdPaWmXsnfvTrXNr26Io5JntjY25KoqRtLAGDf6x71WvyU7+/RHpI6Gl3Mq55lb7BagrfoTpdOsDpr3q9lho6p71+0MtmRRczf0sPrDSTh3qnRwTHtkYHNNwU8OYbt1HEJkjXblf0dEYwiwoEhCY8U1wdu6K7CIJwXRgMk+hU0MkMhZI2xCa5zTcEjooYG1FQ2Nz8oKhgigYGRtsE42BKkeXOceZXyWbQgbuSOgusMbaC6rGZ6d6Bt0X5KN2V7Xciquq2cfV7TungqeO783Af1UEWRtz2iqp2aeQ/m6b6J25YcLzrEn5KKc/lVhYG/wAukA9TqndzQvZlr7+aINn6Ht+0gH3m39nXrpua7LE6R+8V5LNtm3+8TXG7hc/500j2vqmPZxePFZo+EjfFOLPeDxQMQ3Pb4rM33jfFF7Pbb4oyNseu3xUlSXnJAMzinWpGkA5qh3ad7CiY3fqqKPTOfksQqhTU5d6x0anEkm53prC9waBqVSxbCJkQ4BdZ1mnifp+/nbpmHDf8FYkrGqHO3bsGo7Xw6Keokp5WyMOoVNVsqo8zG39pvJVVKY9W9n+ifCOCbU9XJPHtG8+KEOGu12z2dxWwwv8AvTkYMKP/AKorY4X/AHpy2WEf3hy2OE/3h6MWE/3l6czDeFQ7wWWi/vB8F/YdLykq9Hl7et07ybUtJ0KvDyX2CkLdzDpx6cAfCQ9uUbQce7oxR/YZ81dDerrOLWug9XQfbVF2t1mHNZ281ntorh1gN6omZYljcueucPZ09OgxKWkNt7OSpqunqW3jd8uKlpw7VvVcjt4+0L96bUfmQn7kJGnj6F1oizktQmTcD0YjQsqojp1x2SnNyuII1HQ0kEEcFSy7amik5tVfJkp3d+izlZu9X10WpIHeqUWganC4Kfdr3t7+klPle83J4WV0Ha6pgc99gqOCwB4DcnuysceQWdxO9ZjzWY81ndzWZ196wlvVLlj0lqQN9pyuroWvqv7Ov7P3r+y66nerUWvXco/N99ZHBZcNt9+UGYb/AHhy2WF/3l6EWFf3p6EOFf3py2OFf3ty8nwn+9lbDCf7y5bHCP7w5bPDG3PlDz3BOqwBlp49mOfrFRQNv9pyUFJn6ztGqR8UERe42a0KurH1Uped3qjkgsIorXqHj9H+6jz8RZQt3v57v+QtlOXwThf4LFKE0787Pu3fTopaqWllD2H4jmqWvhq+y7rW1jKfStffJoeSkpns3sK2bCVsI15NEvJ2XuCvJ2LYN4LyZqNO1OitotkDxPgjHZBh71kcsneniyuejDJTHXQEcXW8ejEn5qkjkifQ14LZyn1StjKfUXk8ttyFM7mm0bj7Xgm0Dj6r0ygc05hG5N+ygufVbdTPMkr3niUPTa9zDdpIKpsdqI9JRnH1UGK0U34mU8nIwwyC9ge8J1GfUeiyoZvbf4IT25hNnPxQkBV1dX6CLKB99D0Y5Bs6rONzx04a3LQwfBYs/SNnzV+mEXlamNysaO7oxFmSqd36+nQ0tzb/ADf7IW3Dgq52Wll+HpYczLAF+0T9YGfP0Ld6DO9bL4rZDmVsm96bDcb+K2AQgZzTado4ryaPvXkrOZQpYhzKFNEvJ47oQMbqoaZ5tljUdOxrQX6m6qayKlb13fBvFVtdNVO62jeDejDKI1MoLvu270LjTKLBZbuyX+P/ACL2Zh3rPoeYTmiVpY9l2ngq7D30rr2uw7j0AubYg2KpsbnbYTDOOfFMxCjk3TWPIrLTSEHqFbGn9hi2VPyYtnT+wxbGk9li2NLp1GLyalzHRlvipKWDLZjWA87p9HrpJH4oURt2meK83j2meK8gAvZzF5EPaZ4rze0+uzxWLUgiEJBHJDowmPaV8Pcb+CKmkzyyHmfRoIHPYbcSjSxMbmll0V8Lbvlb4o1uEs4jwXnfD2jT+i8/0w3RuR/aFvCH6o/tDJwhCnxyolifHkaMw9Dd0dW3pRVE8XYkcFFjlYztWf8AFQ49A77xhamzUdSNHtKdQt9QkItliPWH/UE19wr+g05XA9H7QMvTxu5O6I255Gt5lRtyRsbyCxF+eqd3aKy3oaLDYs011PJs4ZH8mqkm29NHJzCxhn3b/l6VHTF5B4ncppYqGmLv+yVheZ1MZX9qR11iz7QNbzd6VILQMWPOvW25N6YrbRl92YXXkEfqmO3BeRDmzxRo479oLyFnCRq8iZ7bUyiivqW+KFFS8Q1eTU43Bm/VbOmv2WWWwg5MXk9P7LFsaX2WIxU5A6rFsaYcGIMhb7FlLiNHETeYHuCqMdNiII7d5T5XyPzSOJJ6KGgkqn8mcSo2thjyRN0as1m6al25Rsyjv4/8lJHm1HaWc66WI3qVjHhwdutqFV4U4NMkAJHFvH0AXDcVtJPaPis7/aKzv9orM/2is7/aPisz+ZWZ3tFEnmszuZWd3tFZ3+0VmdzKzv8AaKLnHeSen9n23qJHcmf1VS/JBI7u9C/RhzLQArH5rRxR89f3OmTfrfd6eR2Uuym3Pot6AJG5U2LVcFutmbyKo6+Ctbpo7i1Oh2ZNuz/T0Lophuxqx7+C/wCrowiLaV0fdqibXKe7O9zuZ6SVhLOpmWNTbOjI9o2WAy5qd7PZKxCPPSv7tfRgi2ju4KCIQRl7tNNe5YjXGqm/IOyqRmzpYW8mBYu/7RjeQ9Fgu5vxUQtGwdyxSTNXzHv9DO/2is7/AGis7vaKzv8AaKvJa9yg93tFbR/tHxWd/tFZne0Vmf7RW0f7R8Vmf7RWd/tFZ3+0fFZ37sxR6aHCHy9efqt9nmmDZgNYzKEXZdN7jwUMWXV3a/p/ykkLX67jzVrOOfQnirOsscgDHxyAb9/QyKSTsNLvgvJ5/dP8F5PP7p/gtjN7t3gtjL7t3gtjN7t3gthN7p3gvJ5/dO8F5PUD8J3gvJ5/dO8F5PUD8J3gvJ5/dO8F5NP7p3gthN7t3gnNc3eLIDpwCK1K9/tO/osWfany+0UPQGrgO9QtyxMHcsckzVpb7IA9IDQ6+gKaXZGXL1Rx6MMp2z1bGOF28VX4LJFd8PWby4jphqJYr5Tod7TuKe5pNw23d6eGvc2thtzVabU0vwW0f7RWd/tFZne0VmdzKBVFpTMHcv2hk+xiZzN+j9n4dZZfkFiEuzpn8zoh6FA3LThY/LeeOP2W/wBVgU2Srye2LJwzAjmnx5JHsPA9LGF7g0KipmtANtBu/wB1jlf/AOnYf1qBmeaNvNwVrBYgc1U/u9GlF5QicrSeQU7880jubj6GV3JCOT2CthN7t3gvJ5/dO8EYKkgAxv03aLYTA22br/BbGXT7J3gtjNu2bvBeTze6d4LYS+7d4LyabhC/wQpZ/cv8F5JU+5f4I0lQPw3+C8hqr/cv8FJDLFYSMynowGP7SV5G4JrybaLPm6rBmd9Ao4g3U6u4n/lnNDhYhNddYyzaUh07Bv0YbPsayN3AmxR3p0jBcXC2sfMLaM5hbRvMLOzuWdidKy28J0kbjvG5NkgZ+IAOSdWwNvaQbwEK+Fuf7VpN1NUsd+O0qreHNcSQT02WHxbKjhb+W/isXkvKxnIejTNzTxjvQVbJtaqZ/N56L+jYqnwmsn1yZRzKpcFp4etJ13fRY/JbYxD4rev2fg0lm+Q6KjDKSo1cyx5hT4BM37p4d3KWkqIj14nD02tc42AusJwt8TtvMLH1QsUqR9y0/H0WC7wO9QD7MLHpL1Qb7LejCItnQx/m1WMSfdx/P0IhmkaFC20bAsQl2tZO7839FTyGKaN44FAhwBHFYpHkqb+0OnD6a+p47/gsRrRRwads9kJzi4kneVg8eevi7tUdxUz88rzzPo4Y286rH5KWZ35emd0By7JpGmqibme0E2B4qJsJIvM0NTfJ2n+Ib1jom1MbWnLLH2rXXlEQc8mRthuC8oAI+0Z8Ex0ebPnaSRqiW3PXCzNvdZs3FXZfeNFnZzC2jNOsEZGX7QW0bwI6MSqNrWPdvANh0YOzZ0gdbtuV9H2Gv+6a0NFgP+YcC17hwOoUjM7LO4ixU0bopHsPqlXWFVflNKL9tmhVdDZ+04O3/FO0JCEkgi2jQMrTZ7eIUUzX6hBaWTgnt10Df8hTgbbo/wDKU8m/4e8eqU55Ik6zN/spzxc9js+yndfIBl8E5pa4g8Oimj2k8bOblawtyVW/aVMp7/Rwtmae/JVMuyglf+VClqX7oXn5JmE17/wfFeY6/wBlvihgFZ7Ufiv+HZ/fMQ/Z1/GoHgmfs/AO3M4/DRQ0VHT6tjHxKfWUzN8g/qhqFi021rZeQ08EFhkWyoYRzF/FYtOQY2g24qHFKhna64UeLwHttLU2rppN0jfmpKKim3xM+SdgNGdxeEf2ej4Tu8F/w7//AJH0X/Dw41H0UeB0je0Xu+iHm+kGgY3+qqcVLhlhFvzFHX0aGLPLdaRsudzQquYz1EknMpjczmjmVGwMja0cBZV8meqk7tPQw+PPLdTv2UEr/ZYUdT0YZJtKGA91vBYwz7ON/I9FJBtH3t8Pivs6aEucdALkqsqn1U7pD8hyHR+z0f2s0nJtvFVcmSmkd3elg7Os4rG35aEj2j6EfHUbuKEmUssWbvZQeCGdZva9lbXqn7vt+ymSB+1uYr/oKBAt9z/kKjt/8P8AylM3er4Jnw0VwPiinkNFzwWZ5YZiGhl9BxKaQW3dv5KgizyZ7aN/qq+o8npZH8dwRKhY6SRsY9Y2TWCNrI2t0ATRd7fH/makaNdyKdKM2XeQsbpiCyccdHfHow2s8lqQT2Do5OZG+Mjg4IxiJ7g4aprzFIXDW+jhzCcx0VpoDeP+nxVPURvG/XkuCKe4X3vTnfmcpHO4Ok4IucBJ13p17u6zuzonaW14IG3DowOLPWg+yLqZ+SJ7uTVf0cMYGR5yd6M8A3yNXl9I38UI4rScyjjFP7LkcaZwjKOMnhEjjE3sNTsUqncQE+aV/aeSqVueZqkfsadzvYYnuzOJ5qFm0ljZzcArWAHJYhJnqn92noB7m7nFNrqlv4hXnKr9pec6v2gjiNWfXTqmodvkd6bQXuACw+DIL8ljlXsoNiD1n/06MKi2ldCORv4J7srHO5BOdmcTzPoYRHpdY3Lkoi32zbp/Z6W8EsfJ1/FV8e0pZB3XUbDI8NCo4Axt7fBYziG1fsWHqN3956cCjy0Zd7Tv6LF32pwOZ9LCm2huv2hf9nCzvv6EZtn14K/Z653Jhtl657XJGQkHru0fpooXOzyAPk17kC7TrzKPNbfIgHfm+aHAHcndykmYwdYrrTdeQ5IR9VJK6Z4OXqDsNQjzHq7yoYxGwMHBYvXeUTZW9hm7v6MEpSXGc8NGoNtqoBoXc/8AmSAQQUyJrXO5qeMTRujd2XKaF8MrmOGo6MJxLRtPKf0H/RVMG0HfwKlYdxb1gmmWGQmMHdqOCJoprZiYXfRGmH/7i3xXk4H/AOos8VsmAWGIs3806KO4/t7fFGOP+/DetjFrerai2EXO3ROqBtwVlgEVopJeZssVky0tvaNvSzHn+5KwqPr5ljk2zosvF5t0YLFnrmH2dVI7KxzuQTnZnOPM/vrpjHSOs0aqkobfHiVNNFSQF7twVTUPqJnSO49H7PwHPJNwAsFik2SmI4u06B04czLTtX7QydeGPuv04HNkq8vtiyIuCFT4bHCSc11i1aKaHI3tu3dwR6aKPZUkLfyrGXfaRt7vSoW2gC/aB96ljeTPQhaD+KGoNYLfboNi/vI8Fso/703ehHF/fBdCFgItXsvaybBHb/zCPejTtP8A+pM8UKUf/ubP8yFMy3/mLf8AMg6hiOZ0jpnchuUkks+pyho3MTWWy2F3HgoItkN13LFcUaxroYj1j2jy6IYXzStjYLkqCNsMLIxuaE65IaOKAsLf81O31xw3/BZmZRbjuWJ0bamHOztt+q3XuhvWG4vb7KoPwenwRyM115FPppRq3rNRiHsp1O3fdbEc0abTtIRc/kti5bMpzbclZW06MPi2VHC3uWMSXlYzkP3F1dXV1dX6cMjtHfuX7QSXniZ7Lf69H7PR9WaT5LEZMlK/v06Lq6v6d1dXQUVK9/a0CpaMAbrD6lSyw00WZxs0LEK99XJyYOyOiKN0j2sbvJVNTtp4GRjgNViNRtp9Oy3QdN03VwHeqYWhYsYkz18ndp0079lNE/k4IG4BVTUMp4XSP4KoqH1ErpH7z00zNpURN5uCssSfmq392nojeFC3LEwdyxo3xCX5ehE2+bctj3hbG3FbK/FbA802m715P+ZCmHtFClA4ryUX3oUrMwI8EyCY9UizeKgiiYw5R8ysQxWNl2Qau3F3JXudejDKTyaDan7x30CJ4+JUDT2zvP8AzjojG/8AId3cpHBpb8VidAHl01OP1t6aPE6im0BzM9kqHGKKXLmdkPerQyjTK4I0lPfsBGigynqryKE2tGvN4O+H6rzey33L/FHD2WJLC0DmpntdKSBpwQaSL8uili21RHHzcrBrfgFVS7Wokd3q6v0X6bHkhFKdzChS1HsLyKfkhh8vMLzc72whh3515u73eCGGdzlTR7OIArEptrWyu77eHRhMOyoo/wA2qqYNs0C10/DG8nBHDvzo0EnBwRo5x6q8nm92VspPYKyP9krK72Ssr/ZKEUp9Qryac+oUKKXjYJmHjiSVFQW3NDUynjZrvKq8WpqfQHO/kFVVk1U/M8/AdODYfsm7eQdY9lVu32JEQ1O/4LyaU8F5HJzC8ik5heRP9oKOlLXg3QIZF8GqZ+0lkfzcmi5AU8eR3Rh8u1o4nfl1WMV/lEuzYeoz6n0MHZnr4u7VE8VMS+V7uZ9EHUKF2aJh7gseiy1mf22+hhVFBLS53sucy8gg4Q/VGhafwPqhQM9z9UKGInWO3zTKGG/3RTqKAW+zuvJIAXdTcEymhIzOjt3J1JFm0ZwWSKLKQWttvupsUo4S47TPfgFWYrPU9RvUZyHTheHWtPOP0tTZG8BfVRs2jvyNPif+dc0OBB3J0TWvAk/6Xf7rIGyZgSsQwxs5Lohlfy4FSwyxHK9pB6WSPZ2XEfAryyr9+/xXldT79/ivK6r38nivLKv37/FeWVXv3+KNVUuFjM8j4r4IucT0YBTXe+c8NAsSn2cBA7TtFkedzShTzH1UKKU8Qhh/ORDDR+YpuHD3XihQfkYhRnmF5L+coUsfetnTN3lvitrQt/Ej8V5fh4/GYvO2Hj8X6I45QD1neCOP0fsvUv7QQlrg2J25E3N0NCFDj7QAHwaDkU3HKE784+SZidC/dOPmhPTv3SsPzWziPAI08fsryZnevJR7RXkn515H+deSfnQph7ZXkzO9CGIeqFJU00PalYFPjtMz7tpefAKpxWqqNC7K3k30MIw4zSCZ4+zb9T0OLLWLgtlRji3xX9hHrR+Kz0Htx+K2+H+8iXlWHj8WNYhiNN5JII5QXHTToYwu3KV12ZX9tvRHXuioXQNOrj9PR/Z9n28j+Teg0lzvTqEn1Wp2HD3Q+SdhzfZcE7DuTyjQy8CFQ5vJmB28LG6fa0mcb2egypnjGVkrgO4ry2r9+/xXltV79/ivLKr37/FeV1Xvn+K8qqffP8V5XU++f4ryup9+/wAV5TU++f4ryuq3bd/inPe7tOJ+PSxjnGzQSVQYW2L7Sa2fgOSazN6xv/VRxZ+q0/qd/smtDQAN3/POa14sQnwvYfaj+oRAcdPFTRQzR5ZGXCqMCcDeF9+4qajqYe3GR6bW3vr0gEkAKip/J6aOPjbX4p7My8j5uQpIhvKJo2b3s8U7EMPj/Fb8k7HaIbsxTv2hZ6sJTv2hm9WJqfjla7cQE7Eq134zkaqodvld4rO48Sr/ALu5QmlbueU3EKxu6ZybjNePxEMerPylef6n2Gr/AIgn921HHqr2WI47Wfl8E7Fq534qfV1D+1K5Ek+l5VPYN2rrDgtvN7x3ijI8+sVmPNXPpU8Oouqil2jd3WA09Ejj0Q1U8F9m8i6GNV4/ETMfqxvDSm/tF7UHgm4/THfG4JuM0DvXI+SGIUDvxmoeTP3FhTGMb2U9oexzTxCqIjFM9h4H99FSVMvYicVBgcxsZnBg5cVBSQQC0bfmi3Ln+G9NjdNbSzOfFMa1jQANP5C+Diw5T9ES5p67bd/Bda/CycTlOl1jFGDGJ42i47YHSMt9UImnim0zeN1LA5neOfThr6eKbazXs3d8U79oIPVhcVJj857ETW/VPxavd+Nb4J9RO/tSuPz/AHmU8lldyWV3JMp3PbcELYMZvunbNutvgExjpDla25UlMyJozkg/1/f6dDm2sef7pouQFJTSxAFzVSzt3O0d/X/3TXDNbf3jh3KpoJM2dnZd4Iwyj1CsOw9tRdziCOQ3hVGCVDNYyHDwKNHVDTZO/cgkbim1NQ3dK/xTcWr2/jeKqKh88md1r93S2KRwvbTmdyc0A2Dr9MNO+TuHNGjh9oryVnMqQRjRuvf04PSsax08jL+ygeWidl3ndZAk6Rtv38E2Di/Xu4fyV1Ow7uqe5Fjw7K53wKyhwdmAsViFEaabQfZnslceiGYxHshw5FUlTh0umzDH8juQp4eDGrGKOJjNqxtjfX95BA6Uu4NaLkoQ33XsoqKSXsRkoYU4dqSIfNHCptS0sd8FsMujtFsrLZ66KOjf2rLyfyZ2e14z2xyVSY4WN3OJHU5W5nvVLRzVcmm7i5Sz0+Hs2UAzScXKSR8ji55uT6NtfRt++t6GH17ANhUasO4ngq/DXQfaR9aP+ipKrL1X/JRuF+4/T4Ixwi7zoBqVCySvq3Oj+yjb7KIyMEYcTbiU5g47lUUkZN7ap0DBzQiaeOq8m71JTuYM28fuWODTfKD8U+R7956KXDaipOjcreZUOGUtPbqZ3cyhHESfswqmqw+n7QaXcgquu21xHGI293FW06MNojUyC4+zbvK0tpuHBBji+zHW4uKFM31iXfH+UPbmHfwQPjxU0bJYyx7bgqsoZaV+ouzg70KTFain6vbbyKqcRp6ulIHVfcaFPjB7lsXJ0bx+4ijdI9rG7yV5GMop29hv3rvaPJPioqZm0mOnqsVVic0ujPs4+ACzE8VHPNG67HkKGsgrQIqmzZPVkC8iqM+zI1Hrdyio2Mvpe6LD1vZaqmojpY8z9XEdVvNUdFJWymR/Vj4n/ZVeJRQx7Ck/zIm/o89VyQikcxzg3Ru/pFuKa4tIPJHpvp0jp0UcUkrg1jSSVPC6CQxutccvToMSMP2U2sf9FXULfv6frRnkqSsy9R5//HJYhNana1pvnPBUUQpqSNvrO1ciE9u5S+TwDNO+35eKfjFMD1KQfNDFaN/3lEPkmMoapp8nks72HKGgYNCN4s4H/RYlhvkjsw1jO79wBdUuDTy2dJ1G/VQ4bSQ9llzzcjm+VlU4pSw8c7uQVTilTN62VvIehQ0EtU7kwbyooWRRBjBYLNbqhup3KNmRv9f5VJHm1GhUfEceSyte1wLbjkVVYKx2sHV7uCnpZ4HWkYR6DJnN7xyUboZNzsp5FeSPFuqjQxntjXuUuHSt1Z1h9UWlu8W6S1uW4ffu6MDjG3fKdzGqNt7KvqX1FS9x3XsB3ejhtT5ZTZXHrs4otcb3uPgVNM2np3Sv110HeqalkrpXVE5tHxKr8R2g2EHVhb9f3NLNLFLePfy5qKnwyrbtrbMjtsTqTyqQ+SQ5WN4kqenlgflkbZNNjfRE3J6XRva1pI0du9GiwySY5pBlj/qmujojkkga6E7nW1U9WMj46CMDq3e/dotSuI9OirX0zubDvCqsPFSPKKUg33tVTTbFlE3v1UjjtLAaW6y056KsqhQxXH3j+yOSklfK8ve65PS1xaQQdQsMrfKode23eqiBs8L43cVNE6KR7Hb2noEUYF3yfIJzxazW2H16A0ncFFROd29Fh8FPH2YxfnxRVVilPBoOu7uVViFRUdp1m+yPQpqKoqD1Gac+CpcGp49ZftHfRNHDLYcl9rqxu+/go4gzXe47z/LHxtd8eaOdnaFxzCu1wFkWtlZZzRbkVUYLSyas6h+iqsNqafe27eYWuVWVrBQVtRD2X6clBiFLPpJ9m76Lyc726jmpKQPHXjupsIzawu+RUkMsRs9hHThrstHVn4KPVunJHtG/P0cAP28o/InB2VVUXldVHTjsRi7/AJrFqtrGikh0a3tehfS3QOjZkRh2mp6InFsjD3p2HRT1Uj82WIdr4puLUccjYI22j9pTwxVEeV4u07iq3DpaY33s59MXk9vtc/yVT5C7D4Cc2X1eal2Wb7O9u/osSbALDcIDLSzjXg1Vb4YoC+Q2tuVOTid2Pfly8BxQo4aemmYwb2G5/dYdXOpZPyHeFioZLSsnj1AddR1Ecsrib3blPxFk03cSdyrJ3T1Ejzz09AfBYTMYq6Lk45T81FJnB7nEeCx6INqGvHrjpjgkl7DSVDhJ3vN+4KOhto1tkKaOJt3Ed5KlxWmguIuufop8Rqag2dJZvILj00mGVM43ZW8yoMJo4xuznmUGtDbBOIF7lNZK/f1R9U1jWjT+XvhadW9V3MIZtxRTrZSTu4qZzZZnvOjSerlTKUuGYagdocQsoO7U8lx3IBQVdRTm8chHdwUGORuFp2W7wo5IZW3icHDuUkQksHAEa71V0Ebdplu1w1twPRQXNNWMG/KCqOUSQRO/KsSg2FZILaE3Hz9HCA5jXvt2yGBcPgnyeQUj5X/fTG6c4uJJ6IYTK7KHC/epMPq2fgn5ItI3jopoY6huz7Mo7J9pSRyRPLXtsUb316AqYirpwC7R33lu5YhQupJObDuKwnESxwglPUPZPJZGluUi4WKYVsbywj7PiOXQLX1W2fsnMvoSOhjHPeGtbcncFh2FspgHyay/06K+qqJ53bXTKexyWExVO32se5u+6xet2VNkHbkHgOnioaK0e3n0j4Di5SPzvJygdwVvmhTzndE/wTqKoazM9uVvf04ZUC7qaQ9SQW+BQJo6mLMeGV6jbe7e5Txlk0jDwd6ND/Fwk7g65+Sos3k7XHe8l/8AmN1+0O6D59FLTx5WucLqKFmwjGQKaelg7cjW93FVGOHdAy35ipp55tZHuPoFpba4UL9nK19r2KZIHRtc0XBGnQ1j3/lH1TImt+PP+Yl1wVPidLBoXZncgo8bpnvs5pb3lYtVWiETDq/+iOXlw+q2zLhhdfd9oN6e1r731y+uN4TozqbZh7TUWuJ0HS2R8Zu1xB7lT4xUs0k64706rpatrbOs/kVI0xPewhUVRsJ2uO7c74Klm8lnMTz9i/VhWI0jauL87dyc1zHFrhYjpp6d07w0fM8gqOMaPGkbRaIf/wBk0ZisZqtvVuAPVZoPQw3Er2imOvBydEx/bY0p2G0Lz91b4I4NTg3je5p4Koo2TxgSjrW3hVdFJTP627g7ouVS1TqeTMN3Ec1GYK2ncDqz6tVBhDQ/ay6gHqj/AF6HbliWFWvNANOLemKJ8jwxjbkrD8OZSMzHWQ7z01VBS1bw49oHW3FVdXDQw5GAZvVapZXyvzvdcnoAJOiw/CGsAknHW4N5KqomVBGd5DRwCZhVCB91f4psMLexG0fJVE0cEeeR1hy5qrq5KmQk7huHoSHyum2nrx9v4c1htRtIGX7Ueh+CxyntI2do0dv+Po4TRmZ5eewgsbnEtVlG5gt0RVEEOXOb2G4Koxiql6rDkb3K9z1tem1929CC33jrd3FNA0y9Qc+KdkINhrzPRg1W3ZOie7s7kHty9UhRSkaK/wDMHb1i1fJtXwRmwG9Mh2h0c1o9pxVfQOpREc+ZruPetXcblC+/foh/+UJHA69kHVq2oP2m5zvWb/qE5jX6u/zs3fNGhmMZdHaRo4tVvQJJ3noo6mF7PJ6nseq72So5paXLHObs9SXgpqekqheRuvtBPwSnPYqLfFMwaBvakc/uavJI2tDS0NZ7ANy79RQWI1gpoLA/aP3f7o+jQYqW2inPV4O5IEGxG7ospYWSRlsjbhV9A+lfzYdx6aeqkppM0ZVHWMqmZmn4t5KeZ0bLtYXnkqWsZUX4PHqq4CxSGmDs8Rtfe3/ZRRPle1jBclUFAykZzkO89FdWeTTM2fWce2xRVrKkDZPseLeKqatlELDWc7+5PkfI4ucbnoa0vcA0angsPwxlOA94vJ/REEjVaX3rnbequvipm9bV/sqpqZal+d5+A9GlqDBKH2uNzhzCsaOVtRD1oH/05IywviyyG8Em5/LuKrKCSlvpmYey/oYMzrZL9wVFhAzB1TpyYmBrbNaLAcFX1YpYC71z2Qi4uJJ3n0mxsyhznfAcVfKOr1P/ALijJyCufQEjm7iQqXFKmHjmbyKpsRgqLAaP9koP5/y9+9Ysx7a2S/HUKfLI1k7Rbg4cioyzEKDK7fu+BCex0T3MdoRomuA4kFHLffpzR10ag43uNNFG/KA4OIdzH+qo35tQ4ZuNtFJFBN96z/qGhU2GSA/YvzjlxUjHRmxBCO70KTEZYBs3DPH7JUE9FJ91KYXeyeyhHMTuYR+VyEc3sIsDdXvaPmqrF4YerD13c+CmmkmkL3uuT0Na0+tYosc3eOngqDEpKY5Xax8uSZJHNHmaczSFXCemnczaOtw14IVlSB9+/wAV5dUkZXSFw5FHegL/ABThY2UMronZ2uIcFFjc26UZu9T1rpKjbRjI4cRxVRiW1p2HdJy/1TGT1UwaLucVSUTKGIkDNJxKY9sjQ5p0VTM8DJDrId3d3p+TDo87jmld9f8A2T5C5xduueCuTv6YamSHWPQ815yrTf8AtDkamocdZX+KwmAsh2r9XO/osQxMQDJGbyf0Tnue4l2pPoZDx0TsvBXVFXGAlrhmjO9qhhZYvpHhzHdqJybFNHdsZLB7qTrN+RXku0AJp6b4qCOOLhGD+UWTXN1t1nqsxOKm0ZZ7/oFPVzzuc57r36B0BtzYAqnwmR1nSnIOXFR01PD93HrzOqmvBNIzdrfvT3Zjut0R03VzyvyN+pVFBA5m0EALc1hm3lZIuFOzwUkNNnN4WEW5J+G0By3jLb+yVNgjfwpteRU8U8ElngtPBYbirtGVJ04PTXj5fy5zbrFKTbwnTrs3KIgHKey7QqkndQzubJ2bap0UuJy544sgG9xU+BmOBz2SZnjWyhkaxwcWB3xTjruFr8FfW/HkrJry25bpyKjxKUWEjQ7+qglil+7f1vZO9aP0kYHfFS4ZBJrG7IeR3Koo54O0zTnw9ESSDc4ryqo967xRe929xPT5NPsw/IbKya9zVnhf2mZe8LyQu+7cH/DenNc02It0U1XNTuux3xCrJ4q6nD26SM3ju/cRSmN1xb5qKOaqls3VxWHUkNMHMDry+sU6URvDH8ey5P2lNVN2QzCX1VU1MVAHHtTv3qeeWd5e91z6DWuebNFz0wx55Wjhx+CqcWdl2UGg3XV771ZMglk7LbrYwRfeyXPstT6htsscYaPr0MjfIbNaSVPTSwZc439EUskTszHEFQ47OBaRgcvPdNbWEp+NQ72Qa96qMUqZgRfK3kPQjikkNmtJKhwd2+V9u4KKlhhbaNmp9Yqqq4Ie0+59kKfE536M6jUSSdd/Rna0dUa8ymNfNI1u8kpgEAjhAtl48ynX1PFFrGG8j2heUUxFtuzxTANCDm71NBHURlkjdFXUclJJlOrfVKwvECMtPLuPZKabafy6RVbWCpmazdmWUR2MurvY/wB1QVl2sHVDbbhwT5GRtzOcAO9Vnk/lLtgbtKbl1H1VzferjdqrcOZ3IrSxNzcKHEZ2NGfr/Hf4qGrp5dzsp5FWI+CmoaOX1ch5tU2GTs1ZZ47t6II3j0qPzfcbTNfv3KnjjtdlrdyqqGlm7UevMaFS4G/8KQHuKnpZ4D9pGQtyFZLazwHj8y/ssntRnxCdTSDVtnD8qBc08ulhyuvlB7ug9FlS0k1TJkjHxPJR03kVL/ZwHvv1zzR+3Y2eA9cf92KdNHWU5Zk+03ZPZKqqltBFkD885G88E1s1TLbtOcpYnxPLHixHoBxbqD03IumRvf2WkryZrfvZmt7hqUJ6eL7uHMfaf/spamaTtP05cEN6gwyqqNWtyt5uUeDwR22jy/4aBNjjYMsYDR3KaOPZWmcwDvUzYmvOzfmHP04cPqJfVyjmVBhMLdX3efomwhrSGNy2PBVGIU0GhOc+y1VGKVM2jTkHIdNhZtr34pzLC1hcHfdBo3HRYRA3PJMdMmg+K6zWG1n97lXVnkoHE20HepJZJnlzjclCB+iiE9OQYZNba8lQ4nHUdR/Vk+hVVTsqYTG75HkpYZIZnMcbFqwyu8ph633jN/8Auo3XH8tfvVa10NXL3Oup2Gcbdg7XaHJyY7ybjd3LgEynra4hz3dXmVSYfTwDs3PMrE6HyZ+dnYd9EwZuKublXtuWpW5X0QUNfUQiwdpyUeJxP+8bl702zhmY647lJCyTtsBUuFt/DfbuKlpJ4u0z5+jBUzwaxvIUOOv3TR37woK6mm7EmvIo2IsRdT4TSy7hkPcp8GqmdnrhOY9hs5tk1xadFt83baHLJE7svseRRBHTw6KWHbzsZzOqtDRsawR2Ye05XNDJbfA86HkVIJIahr6Uh203s/1VXXto87I7Onf23cl9pNJxc4qjiEAJzWDe2/8A/qFUUjKqnD5RkfbenNLXEehqmszbyAFeBm4Zj37k6okItew5BcdVFTTy9hhKiwc/iyW7goaWmh7EQJ5lOl01dZSYlTM45z3KbF53aRgMHcnPc43cb+jHSTydlhUWFH8R3yChpI4x1Y/mi1sYvI4D4qXF6ePSJuc/RT11VUBxMmnshXRGUjpgi6m2cOqNB8VI8a21VLS1FU6zBoOKpqUQRMjHzPegwbjqViU5mq5DwBsPkocpO655Jo3fBb9D4cF5PtR1e1wPBUU+2po3nfbX4hY3T5mCccNCsOqNhVMJ3HQphAIt/LXhYxQbZm1YOu3f3hRSzMzNjcRn0KpKaJp64zP+gUXLoqIGTwujdxVRTyU8hjfprv5rTgtei+4krgdy4b1a17rimPkiN2OLVHijxpKwO7xoo6ukm7MtjydoiHt+CkpKWYdePKeYUuDy67Jwf3bipKeaI/aRub8vRp8SqoNzrjkVBjcDvvWlh8QmSxyi7Hhw7lJDDKLPYHKfBYnX2L8p5Hcp8OqoO1HpzGqstU4kgX4L59OFOEZe5/YPVJ5Jk1nbCa2vYdwcFsZWSGnLc9O4afkVRWMpGuhpnXd60n+yJJ3ql2MzQxgyTjsn2lSxXY2SYZGx6Bp58ys3lV3E5admpPtKve6SXa5LNd2PgPQuVoo4pJLhkbnHuChweoeMzyIx371Fh1JH6pe78y9XTRT1tPEe1c9ylxaU/dtDU+aSTtuJ6DqUN64qDD6ufsRG3M6BR4Ha21m+TVHh8EXZZ8yjEBvOnPgpcSoYdx2h7lNjU7xaNrWDxKdNJI68ji74lHf0Eb9V+W4+KK4qYyuZDStjd1RqO9MoQ0/am59lv+pVDLlsyzWtvuHQFP8AfS/qKCgqes1kh6vMb1sB63/t/wC6tw+n+/JYa/LU1EPA9YKqjEkckftCyILHEHeCqWUSwROHsobv5bJud8F1435+T1fI4FvZOo+aikuqivp6cdd3W9kLyjEa7SIbKPmpMGZsCGvJl33Ru0kO3rivgraI6qxsdUeOi1Q3q3RHUTxdh5ChxhzbbWIOUeJUUju1kJ5oZXDQghTYdRS/h2P5VJgXu5vFSYRWs9S/wT43sPWaR0skew3a4g9yhxiobpJ1x9VFidPJrmyu5FNdbI4m9ypm0k51hDu9S4S3UsfbuKloqiPey47vQifFHCwZh2eu3ndNr8gMdtpFwB4KbEquUZTJZvIdIJG5R4iHBoqWbTLu1UuJNnIY4ZYW+qOKrJWVEbJMwBGgYOA6WRvebNaSosIqn9qzB3oYdSQZS+8p+i2otljGVtuClqIo7lzgpsY0sxnzKlrKiXtPNuXoRUVTL2Iio8EqD23NaosEpx25C5QUtNHqyAA/VOlaztvA+KkxWkYe0X/BSY3Kfu42j46qoqJ59Xyl3Rw6N/HguHRyTi3LYN+aph/aIv1BYi9wqLbhlQKa+3W07QP/AOFrz0sm3WKQ7Ktl5HrD59MEuengcd9rXRcOW5U0n/iUR5tIUzwCTdYozJWyd+visHk/sduTk3cP5a67syxKldTzEeo/UKjeHwuicQCzVpK8omJLae9+L1R0MebaTdYrdopqynpvvH6+zxVZK2tqM0UJufqm4HU5LlzQeARBYSDo4Hcv9ugngAr/ADXx6C0NuHdN+hkkkfZeWqPFqtm8h3xUOOR/iREfBMxGjlOk1vjoixrx1g1wT8Mon/hW+CfgcJ7MpCfgk47L2H6J2F1zfwT8k6nnZ2o3D5KOonj7LyFFiVTu6pXnSUXzMC85adggo1NNIftWX0TxTlvUJB7/ANxbosVDSSSO7Jt8FDh8TfwS496DC0aAN+CyOI1cjFzeqoFvYntpuRb8ym0tS7sxOTMJrD6oHxKbgr/WlHyTMLpWb8z0ynjb2YWhZrDVS11LGdZQpMbiH3cZd8VLitXJudl+Cc5zj1nX70bX03Lh08OgN01R4K68UddygOWeM8nBYlc1IsPVTqiNl76nkFtJ5ngj1d3IKnxE7RsVQAL7nBALFqI1MQfH22fUKx6IpMtPE3uv3p9X/wB/7rC2l8z5juYPqU/M54GnWOvwVfUbeqe4btw+SwYf2Z36/wCXFhHwWIwCakkHEDMPkmixbn3X1si1rbZB1fV5LatZGTI/L/U/BT4vNJ1IBl7/AFlTYNPN153ZAf8AMVDSw0zbRNt38USWu3rGaYaVDfg5AlcFfUdy16xCtfRBfXT0BTVLrfYvt8E5j2dppHRrvQBcbBeT4lSRbQFzW9xTMWrW+sHfEJmOEfeQ+BTcXo3b8zUyspn2yzNVwe9Op4HdqFh+SfhtC78G3w0Xmih9l3inYVR2JsdO9PwaPhfxRwTk8o4JP6r2o4PWDg0/NebK0fhI0FYPwHLyCr9y5ebqz3JTcMrPdpmFy365TcOiCZTQt3RoabmLM72V9sd2VbKU+uvJtTe68maPUCYy3qhEc3WTqqkj7U7U/F6Fu7M75J+Nn8OAfMqTFKyT18v6dE6aV3aeSnanQJqDTw6bLXU9F0eggjerL6d6+ivqsRe+TYSN3PjHio6Xi/wTW9XKBopoc7e9YZX3Pk82/wBU/wCnRiOFCoO0h0fxHNS008Rs+NwTpJH/AOypcNq6kjq5W8ygI4I2wRf5uZVTPkimkvwyM/1QWDR2pWd7r/y+oIDX/pKB3qKu2cBjLbkHq9yhpKirdtHGzfaKpKKmp+wLu9o9BUskUTc0rsoVXi+1Y6KCPqnmtm5pIcCDZX3dDGlzmtHFEZXWurF/VDfgtOnCMPjELZ3i7ju7uh8UUos9gKrMEFi+n/ypwsdU12RwcOG5U2KbSIieE2OmYDRUcWGU4L9s1x71idXTzuAiZYD1ufSyaYdl5CZiVYzdMU3Gavd1Sm426+sSGNRXN4jqhi9KbdofJec6Uj776LzlRcJmoVdK4ffMW3hvpIzxW3i943xXlEPtt8VtovbajPDfthMng1+0an1NOCPtGeK8tpLffsXltGARtwvOVE38T6I4vSb8rijjcfCEo42/hCEcXqzuyj5I4jWPveYhGR7z13u6B8Oi2l0InOaXAaXshTzWzbN1uaoaA1UzmZwLDVRYNRx7wXfFYiwR1krQLC+iHQb9PAIC+i3Ai29bir7vh0HeqEksMD+0Ddq2aazRWVXTn7xnDesOrBVQa9tva6HWI1F0xsd77NoU0pDbNTjvAF/Z+axKZrpGxM7MenzTGlzgBxKpI9nHGzkP5fUyBkMrz7JWW/A34IMhptZRnk9jgPio6l0kgLzfkOA7lBKHBOma1tybBVWNMGkIzHmdyjpK+vdndu9p25U+HwU2vbkHErF4RNAJm9pm/wCHS3tdq3eiWtcdM2iDnXuHarQAc1mLn3W8klYa4OooLeysQM4pJTD21FidbCfvLjvQx2MwvzRlsltBwKvc3PNNDnGwVLCIKeOPkNVLR00vbhb4KePJPIzk4qxXME7tyEbndkE/JFjxvYR0cenX0La9J6Pkrejfgrm2nQ1r3dlpJ7lHQVbxpTu/opGOjeWu0I4KjwNksTJJJT1hewTMFoWb2ud8So6eCIWZE0fJYm7+xzD8qwH+JlNrfZ9GJi9fNc21QG/o1v0Ftuauee9XWffduvDuX9UNOh13O+KaTFZ4kGa+5RSR1EQkbv8AW+PQ51lI+/FYfMY68WNw42Tpoo3OG2YPiUypiId9szxW2ZcZZY+83Rl9pzSb8Cp6gQxTPuLnqsF/qr6rBaba1G0I0Z/VM3/y525Yixz6ObJyTH7KSOTfruVVEGSAs7Egu1DNf4IV+zF7DMmtrK+W2p/oFR4NBB1pOu76Kykj4gJ/2ccrpB1MvTHlzDNuXFC11udoraX6MErQz7B+49noxHCL3lgHxZ/sjpcW3c1bvWDwCarafY1PQCCLhYzFs6xxto9t+jC8MbINtMOrwCaxrdGtARa07wFVYRBKCYxkf9FLE+KRzHixHR/so43SyMjaNSjgtePUB+anoKqBueSOw6N5Qoqoj7l3gpKWdgu+NwHNMYXEAbzwXmyu9w5TUs9PbastfchZQ0887rRsJTMCqzvc0I4BON0jCqmjnpj9o34d6w6kbUVIjkuNLpuDULfw7/ErE4o4at7GNsOSwH+JkH5Oiv8A42f9Swx16Cn/AEqtmfDSyyM3gKTE66XfMfloiZHk5iSsC/inA79kejFv4+ZC+vRw3dDSMzc2o4rigdyJF13XV+jhp0UlU+nkzDdxC28csW0i15jkpayPgSjtJnWY0nuUWHmJpfI6zuAClp4mg3uSpGw9a3yPBFXK1Kjjc94Y0XJVDS+TQNj473fFMGn8vd1Vi9MIphI0dV/9VFNEaaSKQnTVic+9vgmR69e/wVHIwNysFhdNOZoKmnhgbmkeGhVOP+rTx/MqeWvnY58hdkG/kuXQNCgetvRutOfSOCoMZyWjqN3B/wDugbi4WL4aHsM8Y6w3jmiS7wWBQ5YHykdsqsl2VLM/k1UEm0o4D+VY/FeKKTkbeKYLva3mUxgZG1o4BV1R5PSySDeNyhxSsZKHGQkX1CaczWnmLrHqcZGTW1GhXV5lXvZYd/HQa+t0VcInp5I+YRbvbbUXWE0+2q2cm6noxT+An+Cof42D9fR+0P4HzVDRvq5Q0buKhhjgjDIxYBTVEMDbyvDV54w/330KxmuhmETIiHDfdYI4nEG3Pqnoxr+Pf8AsB/in/wDy0N6xDSun/UsJ/wDL4FVQmankjB7QUf7PxDtzE/BYrRxUgi2V+tvWCG9be34Z6MWt5fJ0g6W796K5IgkZuF+gjo4qKGWZ3VYSosOA1lf8gpqRs0BZGwAjspzS0kEWKimdEczHEFNkopzeYFh4lu5MfRxxAQWPw3qer9Xd/wB81LUXuN/9E55PS0EkW3rD6DyeLavH2n9EzeGjhv8A5gdyxdmejk7tUBcHVSUzWUcM8OvtnkUHEqjeS4MA1/0U2KNgbs4us/nwCiopas7eqkIZ3rymjh6tJT7R3NHy2qdkllEYdwRBY8sdwOqlw5+TaQ9dn1ViDrotM3QCzNqDl6BmJtZPwB+yaWSde2oKmgmiNpGELAXyupXB25ruqiLhOi/tUkIPr2ChYI4mMHALHNs+nZHG0m7tfksEz+SljgRlcsSjElFOD7N/BU338X6x0Y3pQu/UEN6i+6j/AEBYz/Av+I6OSw/+Np/19OLU+yqyfVfqsEgywOldvefoOjFf/L5/l/VYf/Fw/rHR+0O6D5r9n2WEz/l0YpI6Stlv6psFZAd25YJ/5g34Hoxr+Pf8AsC/i3f/AC+jEf42f9Swf/y+H5/1UsjYo3PduG9SftBAOxE4/RV9fJVluZgGVYH/ABv/AEHoxaN7q+TK0ncocKrZPw7fFVOEGmpnSuluRbQK6+PSE0tv1r2UVDUygENsOZUOHwR9vrn6K+mVoAHIJsdr5iAOZU2LU0FxC3O7nwVRUSVEhkkOvQBodULp0r3Wu4myvvXDoYx73WaLlYbQNY/O8gycOQWR7iW3/wDZNaGiw/mM8edrmHcQqmhnpnm7bt5qiqNm4xyfdSaHuXmuXadpoj9vuUlTHGww0/Z9Z/Fypixn2jtfypjHVD2+UOOXhGEyKIMsxoA7lUQFj9Nyroc7TMO03R/+6oKpzDkzW5KYRy/exg96kw73TvkVLDLGeuwhcFwUbspDuN7qjxGnnaBmDX8inNY7eAUAALAWU0zIYnSPOgCwmLyiuMpHZ63j0bSO9s4v0EBwIPFNaYqsN9iS316Mct5Cf1BDeFH91H+kLGP4B/xHR81h/wDHQfr6A+73t5LFaXyiAW3hyijbGxrG7miyjkDwbc7LFf8Ay+f4f6qh/i4f1jo/aHdB81gH3c/xCCqGbXE3xk9qRDAKYb5XqbB6NkEhF7hu+6wfTEY/n0Y3/Hu+AWB/xx/QejFBavn+Kwc/+HQ/NV5/sU/6Cg19rZU2hrJMzmxOt3rBnf29nwPRYb7Katpoe3KFiWKxVERijad+/wBCNhe6wUOGTntnIFHSwQtuyPN+YrrObdO2cVjI8BT4owOOxZ8ypqmeY9d5PRDR1E3YYVTYJGBeY37lVYJreE/9JRwqtb+EfkvJKkX+xd4JtFVO3QuTMJrX+pb4pmD2+8ffuCgpqZrRl6otqo4sxGVuVo4oNAGn8ye2+5XkLyMth3rFaJ7JNpGzqu3jvVzuzEKnc25a61nceR5oB8ctjvCY+7QRu/73qlfoAdx3KWJsjbFSR7J3WDcm51+PwVVBsJrA6b2lQV7cmSYHT1lGY5NY3Aok2sdRyKfSUknq7M925S4XUN7FnjuWVzSQRu5rko66ri7E7l56r/bHgp6upqPvZCVgs9LDCQ6UB7ncU+eMRPkztIAvvT5HOe599SbrD66eOpja6VxYTYg9GLM2WIOd7VnKF4kijcOLVjjC6gNuDgmC72/FMFmM+AWNm1EfiETdN37lh+tdB+rofPs8XyHc9gHRUy7CnkkPALC9aKM87lYr/wCXz/Af1VD/ABUH6x0ftF+B81+z50qPl0VbjFiUjwNRIsNq31UBe8AHNbRVX8NN+grCyfOEF+jHGEV1+bRZYFC/yl0luqGb+9WWIP2lZMfzLBv/AC+L5otaRY6oNaNzQFNLE1js8jRpxKo6htNVNl3gEqfH5PwYwPjqpsQrJu3M74bunuUNBVSepYczoo8Mp2feOLzyGgUYa0fZRtaO5CG/FS1VLTtsZr/lGpU+KSv0YAwfVElxuTdC50Chw2eSxf1G96goYIt0dzzOqZa3xRts0DERf/RZLtaAdOSftGs1KsTYbtddVfKDbUchqhFM/czL+pR0rGanrHv/AJq9t04cHJ1LAb3jaQVX0fksunYdu/2X30f52fUKmk63/e/mod3G/M9pQVDJOqO0N6qPJ2NzykBTXrGbKKGzQdHuTmOjeWuGoQJabg2UWJzt0dZ/xQrqaTmwpma12lStEmkjA5Pw6N19m+3cVJR1Ee9htzCsejVZjz6LkFU+N0xY0SXBtqsanppxC6J4JCwfEhH9hKdPVKOVzeYKZh9EyXO2IX6MbrWvc2Fhvl39HV58Fhn8bT/q6MZcWYhmHBrSoKmOWJj8w1CxysBywNPe5YT/AAEKxT+AqPh/qqD+Lh/WOj9obWg+awF+WokYfWHRieFzSzGWHXNvCwulkpqYsk3l11Vfw036CqeYwzxyey5MkZIxr2m4Kkiik7bAfig1rRYCwWJYmyGMxxuu8/TooMWhpqRsZaS4EqXHqg9hjWqTEa2S+aYoucd56bXUVBUy7mWHMqLCoR968nuCZDBF93EAjncjJTw32kg3KTF2N0hj+ZUtZUTHryGymDBIQx1xzTWOcbNF1BhUjtZTlH1UMEMWkbPmspvqL3QGVmu9CNz9zbd5TYWjfqrBGNh4LyeLkhFGPVCt/OZWsaRwuq2m8pp3M48PimmSGXvBUjRE9jxcsfq22/4Knee0bBvHl8zxTat7jsqJnxkKZSMHXlcZX83bgpK2PNkju93AN3LEJRJN2Rdos4jiU6nnY0PdG7KRv6CFA+dpOzeRZR4rJa0rc3eNCo6ujk/EyH8yDHWuHeCkZftRtKdQ0rubUcKeR9nI130T6Woj7UTvDo3+hBiFXABkkNuRXn2r9limxetlBGfKO7oB1Wlz9Fh8jGVkLnaC+9CspT+PH4rGXsfXEh1xlG5X5FXKwgjyCLULEiPIajUdlUVvKoT+YLaR+23xX7QuBZBYg6lRyvjcHNdYhUmMU0zQJHZH9+5beD30f+YKXEKOJtzMD8NVVY6HseyOLQi1yrE8FT19VT/dv05Lz5XW3t8FLiNZNo+Ugdy16SLdDKOpk7MLvBMwmb13Nb9VHh1K3tFz/oooo232cQFgmwucLlOno4M2eZvwGpU2MRX+xiJ73KbEKqXe+3cNOmGiqJtzLDmVFhMDdZX5u4KOKJjOowNQG+/yXVILePIb0yCZ2rrNH1TIWM+PM/4AIB3p7MvZ3LGoMk+0A6r/AOqjmZ5OY3gmzrtTA+S2Y6f97l5VDTNt/wDR/qSqiuqKjQnT2QnMmgc07iQqSlfUSgcPWKA7LRu5Kpwqll1y5Xc2qfCKiK5aBIEQ9l2m46OCZNLGbseQo8VqG9qzvimYnSvFnsLVDJTv+7laU5hXkkUg+0iBU2EQHVji36p2FVA7Ja5SUlRHviKtY6/vA42V3c0FqifQv0bkOlsT3DRjrpuH1bvw7fFMwh3ryAfBMwykbvzOUUcTDZkTWpzZLIhg7cgan11FCLZs57lJjMn4TA1S1lTL25XHpAJ3KDC55NXdQd6hooIuy255lb7FWsC48U3O8ANbf+ibSk/eO+QTI2MFmtA/wGdyxKASUkg5C4UD9nKx5bex3Kedg+5O/wCncmhz3AcSohstZBl/+4/BVFQ6dw00G4KmaG08TSw7usAmx1LW30d+XkhIM3WGU96bc30VRRwTj7RgPfxVTg7gfsX37ipIZIjlewg+h3hMq6lm6Vyjxmpb2g1ybjULxaSIj4JlZRydma3x0WlrtddOhjObM0Ep1BTO/BCdhdKd2YJ2EDhN4hHCZeD2FOw2qHqA/NGjqW74nLZvG9hVjyVuki3oBFW7k2CZ25jkMPqz+Gm4XUnflHzTcIPrTNCGFU7e1KShQUg/Cv8AFNgiFrQt8FsXcAhAW6vcPmnT0Ud807f6p+J0bT1czk7GX+pGB8VJiNZJvlPyRc528+gxj3mzQSVBg8hsZnZBy4qnpaeEfZs15nejYZ7lOyNIB4eJTKeRxu1mUfm/2TKSNva6x7/8Dvvm7lWYVDNd8fUd9EMMqc+U2Hen4Y8N6rruCZQ1Lzq23eVSYbHC8Htu58Aoo8zjyv1j/p0FrXCxF1sA3sad3BPLgOsw/EIZLXFlLHDI3K9gcFPgrCCYXkH2XKajngd9pGbdOfmLqNjH7na96NPIN6LHDgmuc3cSE2uqm7pnJuL1g3lp+SbjTvWhaUMWpj2o3BeW0LvXI+SE1I61qhq+zO6VnihntvVn8ll1sWC/wTWNd+CzwCMEfuGeATqOn4wM8EKGlv8Aw7V5HR2P9nam0NJc/wBnbYLyenuQynZ3aIwMH4LfBMj07Fvksshf3IsaN8jfFF9O11nVDbfFOq6Ab5ro4nRt3Z3fJOxr2YPEp2NVfq5G/JPxKufvnd8tE6R7+04n4qxPBNhkPBGAM1fIPgNSjl4DphpppzaNhKhwVo1nl+QUUTIGtyRtHOyLA65zcd6YHOtkuT9EyjNyXnfwCZFFH2GAf4KfEdbIwvv919V5I8jti/LgvI3A/djxTaT23fIIADd6LoWHXce5OEjeGb4IEH1vkjq3UcVPhNLPct6h7lVYVU0+tszeYR6GVEgFt470xzJQADY8in0ntMITqR41bqrc/R1QkkG5xXlE/vHIVlUPxnJuI1jfxSvOtd7xedK6186GMVo9YeCdi9bzb4LztW+39EcRrCb7UrzhWe/cjWVR3zO8UZpT65WZ3P0mUzzv0TKRtj1SSpHti4i/IJ07ju06AL/FQYZVTW6mUcyosIhj7d5HcuCEcfYbYNHAJ7muPcPqhBJIezlHem0sYN3dYqwH+GHxxv3t+adC8dk5u4oO4FtjyRIYAFPh9NVA3jyO5hVOFVEF8v2je7euPRBiFTDoH3b7LtU3EKWYaxiN/PgnUglHWjBv6wU+GTsF2DMPqspub6dAbG7c6x70+N7O0LIAnchdW6Bv6Nk/Z57dW9rrW1kIic264F7IsA5cOKsB7On1WUOvr0RwSSbhpzO5OaxugOY8+HQASbAKnwWokGZ/UH1TMObG3NkA/VvU9VRQ9n7V30UtbPJxyjkOgZndUKmwaWSxmOQcuKipKSmvkZqB2imXeDqdTonO62mp5BMpCR1tP6qOnhj7Ldef+HS1rhYhGEjsH5FOkLe0239Ec2thw8VPRU0/bj1PEKqwWZlzEcw5cUWuabOBCba+u5U1ZVQdhxyjeOCixaGUt2zchHEblJRwVbc5Hwc1VGDVEWrOuEQQSCNU2VzdL3HJWik3dU8uCdGWHrCy+HRa1tFl1KlocuGbP1m9dXu0XN+7ktR8QvmuzmCZC54vaw9o7leCLhnPfuUk8kvadu3BNaXGwF1TYLO8XkOQfVQ01NTRtc1rRpq471PjUEV2wtzHnwVRXVNQeu/Tlw6GRvebNaSVT4NI6xmOXu4qCnigb9lFrxJ3rMXG/EFRPfJuZm5ngmUzt8jv+kJrGMFmi3+IjAPVNkczO03TmEDc34KqhpZurIy55jep8Fk7UD8w5cU9s0V43NLe7ohqp4NY32VNjcb7CcZT7Q3KakpqtmY27ntVXhM8Izx9dncufNRzvAyHVvIp1t4O/hyV1QOpM2Sobv3OTcNo9Dk3ajVBSYZQ2Jy24k3VV5OXWgabDe48VqmuaNSL9ykmfJvOnJAEkAKmwWZ/Wm6jfqoIqeCMljAPzFVGNRs0iGd3tcFUVlRUH7R/y6GRvkdlY0kqnwg753W/KFE2KAARx2vx4rKO3fdxTdpKDs72Prbgm0bb3kcXH6IAAWA/xM6FhNxoe5GIxvLy2/eFtGndqpYoqmO0kYNlVYJI3WE5u7insew2cCD0U1ZUU33b9OI4KmxaGUgSDZu58FNh1NUjMRld7TVU4TUQdZo2jVl1PBDowYyGmJedL9XoxoyiKOx6hOoVxr9OjKVTYVUTDMeozmVTUdLSi4GvF7lPjUEQc1n2h+iqa2epPXdp7I3dEcUkjrMaSVBgp7U7rflCpooY47MYG8yFkygk/JRNkewWb8ym0kembrfHd4f4rfAxxvuPMLZvZ2usOa6u+91UU8M4DZI7348lV4M9p+xOYcuKdE5j8rwQj3KlxGem0Bu32SocWppsuuU8lVYdBVN3ZX+0qqgqKc9ZuntDchcm3NGvjooGQs67wNeQTcVq2ymTPe/Dgpq+GspHs7LxrZEqnw6pnF2s05ncqXD4KfXtv58FU4rDCC0faO+iqa6oqO07Tl0MY95s0XKpcFcetObDlxUbGxDJFFltvXVyAn1uJTGPdbZiw5nimUsbTc9Y8z/i90TTruPcnte3t6jmP9k7dmuO1opooZ+rLGDpvVZgz4+tD128uKkvexbltwQVJjFRBo7rs71BX09SLNNj7DlVYTFIbxdR3Lgp6eaB1pGEdEFPNO/LG25VJhEUIzzfaP5cFU4nTwNAdq63YaqvE56jq9hnIdDGuebNFyqbBpHEbZ2UcuKip4oWWjYAPqU0BjMrjuWye+2zGQcSUymY3f1j3/4zkpmu1boVky9tnzCysItdVVDTVLbvGvtBVWEVMHWaM7OYW5XN7qlxeWKwl67fqo5aWsiNutzaUMDi2hdnOTknPpqOIbmN5cSqzGJZbsi6jfr0WVPh00tnEZWc1R0lNAzqN14k71fMHC/zTGPdl2bBp6yZTNBDndZ3M/43dAL3Zp3cF2dCLJxyt1Knw6CqGbsu5hVlDNTO6zerwPDoY98RDmPse5DHJdjYsGf2lLNJK/M91z0U9JNO6zG/PgqehpqXK4/aPTHl5LRvGvdZBpL3BnXJ3ngEym3F5v3cP8dEXT4XAdXUcintDurm+IVgbgi7Mqq8IieC+E5T7KkjfG6zhboa1zjZouVRYQMwNR8ci2bA1uU5QOCJbo1ozOtwUVE46zO04MG5NaGiwFv8evja/eE+NzLE6gcU6O7e1fMdSqqnp54rP4bjyTMFqDKQdG+0oaSCnaNm3f63FNec5LhbSw5lMhkcNeqPqo4mRizRb/8AgGWnDjmacrv6ot2bxnDv9E+4FwUGSySHJr3ncFDTtj45ncz/APwIQDvXk7Dvvbkrf/8ALP8A/8QALhABAAIBAwMDBAMBAQEBAQEBAQARITFBUWFxgRCRoSCxwfDR4fFQMGBAcKCw/9oACAEBAAE/If8A/Y3TmdadcnTTpp1JZzMf/b9aI7ynEVx6bzzl3LXeK3MTRpXo3KY/yTOOAby5VuzxEGre5OuzqemKKwQGiz/6lDeJRfE5cROcc+m6J1mdPGpl90xp45e+QzZTzNuPj0oGPpZ/uz/dn+zN5O8B2+0KkgWF2ifxh9K38lE1P+Z8Dz62wPeEzcgu/wD9Cg39RXcQ3sWzSS8kmtn9tp8sWEafkpgb24BEHzivpjd2nmCZXia2POaF7mfkLEX/AFen3+Bn+N9bgt2+ya37FygCXymhLuohqQ9NM3Zn32ZhAhdSM03WVFkpfHmPXbLGesIiP/zSDeISlrRLLozte8Q9+svM1wYk+R2BVR7D4l2yXvDGocMGWvYi+h6lTO+TFDA6QI+3p/IRPieEdMeIHovifzhGR2fe+v8AQCz2b7yqLPTMH0nclPCXXR4E0Ex+4/cPqOyAYP0is3Uq8qjWQesssmaNulymAe1TXM6Zl9luziKjdeNJYma0VzKesRriCP8A8ooQWkRLlOd1VL8tdMEaW90jT3GjmICDgLnAT0If7ZmVXeu5ZyAIgpmu+Cau/mWu/wD6jwLXQjzOq+twSh/PNNOqVH4IPl6ZNFmiPzPzBEDwE+3dc0d98KhF2+ZUF3dDGVUeZJU51IKaMT9rdwdJ4jFwb+MYV6HJmW2gDTmJ/wDkEouxLXMUgvKqZ1fbe8vBcOv3lrV5W2KBR2axsxeWHzKp8qsOz3N0qxelSJ11DVjtu819pblVYOkw9Fw5Xt9CvuGkq5L4SphviXnhPzBY0QMOGXT9bgbMvUhJuBKDEq+giN8Vunb5hE7LWeo+nsTUQ7y4aa+j+Q7NT7w8z3DMIeMKyZc3MMsbxgxKur7RZfOh3iO0Rzgxc6Pwm1mkUpLDGiP/AMWKWPEXI4p3l7U90yxGeWWJF/Vhbtc+y4EGs56GhA2PNDbpcYRe0e/pUs9GS9cs/ptGWgDlmjXxKtvtEBBkO8jijQCmglkl66lBkgBEwwazB95mKKt7yj34rtB58faO37kVSQ0mIdMw81e6O4dyVruUa6wF6rpBrdbaB6CF0jxMoPC5jetqufbTN/oavtjMXTjBr8kwK53xYmbc+/B7QmzLlkhEHUKB2cy96oY3E0N/+IhB+COEAMq0EbCksUnZJmruHuni5RkHci5VjeQOr8BNDbgwQNYtm81ib4zKamOVUYjUuBBD31NMvYmZ7dblEY3RVRU7BD2maoAy9dp0HSXiUb8PaKqd/t6LZ0T95g4tHpleCdBK+56KG2JioaIKLoRdkfaKGJdzBLaz0qGHvNXtEbDoCIawYu7WVUuPRzGeOFcwhgvm4WrWXU3x1Vj1QsaeSUp2kYMDyQObx3VntAH9waRfwQlMRBtWpleT25LwOzjeaQV3pN2z/wDBlCogQA1WJjOXZHKJ+mPTMKueAhaz30RXtjY0TFQCiqr6YmLIeBub6Q0AOhKsDq1NLzNNLIDgDcqnmUBXprHFffB7SgcpL63ldY28YIUDgm64fiUfpt6Yt+8yruehr9jMJq93pbS7wWXTNo0h92YtrJU2GI5Z4KHpedq3wgTMYl36n0Eo7/xSqX5lH84h8kIToW8xTgGExmEh9FkK6TEkPmKY4+A8zKvTu/TmW5FV6LK0dTr+OC65faa1kmk//AVxV1ufYDh3Y8/DiWVqvePX4UIKpW+MB5Fb6QlbvTb0QoKu0EtXFa9GpgjxPHt8TNVqV2nyBoPa5cVRLYaXXv6VcxrxL4l/E9xNofQDoVHSKxMRxQl9MwIE/W3KmlmqgnzMxhfdmC6PSk/j6ch7xseM10nc0jU7hPz69GmIbgKeJzhR8TtYfedpb2zLJbglGaBUphzJSCXIbdv5mHTNTD3JTtbTYwgpmUTFxlKZteQ8O0MUNrzDxNXW9SwMV/eGp2n7bkzLcoDycy/+4gRlrRxB9bgawVQXbW92eZfFyeiCgR3/ABzHvwx4JYCdfR+k6tpQaY7RE+l49KC0/egvpYrkPM1EYrkrQViaKJ0m2UbjCbIyktwznAfn0fu5UzUtOpd5LKscQcdJ/OVAaq/aFp4GWbFepRwH2or0I/W98oTU7pjGXyhuZjhaJXeah7EauQ0siseqKwcpazr6sgCdez7CAvoh7wNKUS/j+5xNFYMXUzngTzrAqN3zLuDudhqoIuWmz3jNRfklBFR1plxjCONSDfb1X3Caurc2uzF73rDVLY1Md04/mJCT0dDG7YNn/cl0+3kqM7x8QE59giMUYXA9WDg80rAlpUkuN5XvfRXP4UFQAEopvtScJEYAdBcp9mlg8emSMGvRq99TSWo94ywSnWYsnZ2PaeZXtHZnc9kuGU/6JnXb7xbiRSRNNavmM917PvD6Y7jEmqQqe1+aFpiXGJh7asQSVYEVD3hfQ3Yal+EE09yHebqi5RYMu6VEvWWjSGZhuXrb8BCJxLQAugPvElE2PwwKPekwWvmXRuJLy8iaNbL4mRGx9Mc9BXSGJ2UTllGR13mzCZj6XxidVpD020/AwsftdDCjo1GWMnpddyXOtStXdv8Atp4A12MGAPOkY4/eqXAllNOsb94LfCC5wQtrqUB2OsPcarujghbWDrFTA1oQGq8QUEz9yo0iGIQClI+PSldQYYW5cxDn4opBXsXFDQBeY9pd1Z7w3tw94HX0lpYpWbgYZq4Lpm5QzTbmXPirfeJP2tJqE+25Sb690wP6mBVS7lbJEQZBZmIu5SaXvNHvZxq2ba6i8QsHXVCy/CDL3mi6EwnNFjUB3QFi8tMqTr9uOi9if6lidaD5TN+bdzCKPtko3YExB+zGsNCVN5XdNTKCwKCXRsvWd7QDM9KolyeZ1WNyCtGOxassB3DUwhUAa6qjZivgf9t1oMGPeOSKw6nV5hrbqlzUpCwz6w3FiC4JpQC+4hNZ4j1mY8rSPsg33pl+h+SDNzFNL3QzNqXWk1XnNDr6oYSE9CF2H1YAZFbpCatpTEIBb22t9GLSGggCAl7DfE1V+IaCPAfMP7Gbwo+mIxiB/rxP+0DK0+FNWZ4hKIpcTPDtSAVBTbEw0r4qnE3D6wpuIuPIBmxUofkQVfW4zjA4MTrUIDK9ptx6vLMw7R0OZ0WEu6592ZkBpi3DiIg/gmHDd3hpXUCav2T5UqtTbX4gABof9unk5mReWtIH8IjvBGG6jSZ10uHBRrD4grSOYl1iNxpsWR9aC1h7/c9oIsPtiargJNMomInzhIAZXcjXoFJ5sQaoHhXhlr4BqI2Dq3NIj6fEWSqw7ke4p0zCSr9zmoF5JoKPo8mwSbOLYycPvT/fn+jP9GEMceSbE6D2muyb6R8QCQKz3orPzU1RnXE3R7krjLhK9Ei9sxRvYMqHvZ6bVlVc0Q+wsZi+xeydZkDDcgcDK9JUH7bpLiSwMHPSO2HhMVwSphuJOJpmCIJimX6rpLXrO8KIGD852ir0EETH/YJzF7JU2xg6sIfutLLLAn7RtwYUOpPtDHbAmE8sdvnsjHIlYdYWnrvtYdZ4xE/SqcaMvJz8TN93cZefpuJrH8HsJRq9dZoRKlAkVz81KZnMUUSlZbl2gFdNM/uM+OqNiHhFbV7sv/wW+AvqP/C58HTAqGOMvvD1Oet93D6LpDON76njFuZYgQfI8QSktI7hY5X4lTa4jHi7OgZQLG5D8SovtU4uUNOHiXEYaB7EsUKmpUkzxMQFbwWKo3lUUgquFShT7JDS3uTTPaC/9YrBmXW3MUpBoXMiolwBllM1HHV7zH9Sto7y89xxBm2elrpQlSaWuxmgRxEFgFC4j8K3WoaC3wJs+M0zkQDSVpHtBy4JiMg3zDlwN2ZUonVw6nDjCM2r3/8AUO7EE3pF2n/2+DRqBAU8Zxbxd3KglwKlUFeQglqeNGI0DiIbxDKzGozVtOr3X4gBbrMyvLaXccurJ8wLMyLcBc9LZpTqtGMRvhu6Ztb0WJkbg7XqVpA5578TAd4Th1/6ahrGRpomDfF3ux79w6zvxD9P7NQ0NuX8Ut/F6u7H6HMtMU6TRHow9BmZ7e0oTjsTdqXlbz/EtPerj2neQKn4tBOPYvVYeWeMtHli6PYmAA4wiZ7yt/TWL+gjeovtEpr6WEVNjPppP15duYalsXmZp3hK0miSERp+ktK+0fRS/SJTYuM32dlUpd9IIrAyCIZ2d+yKqAbOGXpvWNcSl4JtK/ikw6qtY3A1srfeeSGqXlpAM7Eqm4ALBa/cnTKNiXLM3+LF8e2DKlWUMKxUO7PA/MG6IDM0QPWCJY/9AW2P2RQngH5njtdEdNtBKAh1m07zR5TXYdo7Ym7LtYJj8BGmbrKFkYcGWbxcPQjRQJA4maPDIFTuwgfNHagtPa1YqWtsEmJ1PtKJSIS/orH0Yhma1n9/6Kjk9IkqkKVd/RFBgysezH1cYeCpI3g7et1H6E4ma4iAxWx63xfRlSA+EYDXOBgRfO7SZ3smT0SNshKaeZpUxAsPiOlsu03hipzLYbzqcwXSmY6e0BLGC2PcIzcBl2Iaiqc7s3emVozZZ8Ud6CAMf8+kmkVkkpC5nMXqHzKH2uVUSsgnENKYfMVqz9qYtEtmNeMEwR0HBxHgIpWmgHWAyreIgrXtNF8Sm7jqexKfNfqEZY7X7IzWHDA8Qz6D3T9TKwEf4KP4KQRwfOMPfDJjbo49AVxGJ550fSOZJpoTa1ggiW1LtDsGS6Tq8ov0Uano8SI0kqlZQIQpop8PUJvK1wuDh5gab5BegoISw2rGpZexSXNSnpfoE7h3i6fP9Yo0wJO/+iVjs3rX1tiQJ3smZO8ZOGE/TGo3k8qBdRLPHtGMtRa1HylHTEaL0TQpsM1xOkEouuVeaVp6azT5joLganOI772B/c1g1nylIE6H/PArMWvCPSCID0GSbLNRumQCQuQntM1cN7tanae46wZefikabZiNyMsxUexpvBgVbtKGn3fiPXTvxalv6sRz65VWYzAJbdA+rrsGDp1x7zFtdUzCbnxFojJI5guOayPqntKLp3lZYQAyi7AOJWITMYeqkpYVfEmUVHD2TP8AjzhhrStNmnaX6XHH1s6nSEMesB6RDeqfoW4oq4gp/ZNkZDrfcmZLz7SSrC/u9ukwuWMWi57wUxOyHbkb/T2iTZnR/TXL0h24rpezSly/QgIqBJV9ZZHjiXprwRgPXT+ZhWZ/rH+AZNAhTZrtBNnVwRLsK3olgEUS+IPBeMHllayjhH/QqWXbcQMU/B/mH3U2R4SE1bTMJ/UuGJuHUqJQjVbkoC7WxKZ6aoUneXM2tTVOoG6Osp5kjF1S9GLAC3frvGvaCyGpRLwlIb6HNniGG45i8g6aTRYV0m6mox956MG6Ji0LxCeoLSGClPeLwb/SM6aabyqxOuSN0atghRQ8kW24q2nb10GaNx0Ri2rujajzBNce2PqiALWFjCu33yzHi3L+OZe5v3Ca5h13xNwP2pSDUgUYm3uxbYoa34+p4rbU2iws2eJ6tuUXjPsH4zHWoXLchyRi73e8crKdVodjuzLI6HRDWTTVMVZRyUJbqz9VlVI6f9OmFaRwk/NxeSZVRNflP6TJnBgGc32d4wnQR78sU4MvoQVThUOKdeDAsvEMWh8mG33Fn2I0K1awNCbR2NVccF76fQU651cO03k3dreFlFHLeXl0YX90mIjVj29Mu+9nZfq6l0HHq5jY6Ru94CQrci+1e+EQDtxSqZxmfOEV9NNY0UXx6CjZH1p1efRvaqAgLDdGX4RtkHZBWYNBs5JeZd+FgYKCj4m/076g5q7Xxeto0dhCoZWDZr4i5fZeSm0du8zBEesfQawGJFETvM4gcDxLoI3EFtYIHfiErxdB+YUDXagl2pY9imwFqlnuytE55e//AF1jPJ+ULdGHG9K9VPiFYsniWX83hUxAiZOJeklWRXYhwr5H9ZomHK5WNyb/ADLGq6w6+lXpM4+lka9PwlW18RLFOI+VOAZ4koNJmP00DrVYmMoz1nOcobSA6GPS9YgGDjWV43UuXHdpQa32Zb99T6m3xJEzG0fxMobVZr/WGAi6HUxs5r3d58YtejpNn+79n0uV1XAx9sJpuUU8bado3dvTz4fQslckJhvixSA4YMQex7I0aSUdSEmvBphWszB/VQ689NE+YsmqgRxwOMQOqnrv/wBqsO9cXtChrOpn4x2jf70yiKsmLWQYvTVursQpdG0/xJ3Sj7zESKu76bTYApKhWtDRm3r+9pesBQBjfaF5mHVcMzi1aDNb5JFC1cdyOmufW4D6LgBxzrNInlXxKI6URvD8ZpJ8Yjr88R/viP7ow3MeakK7D2zHFCgCyogNBfoSAd07YOj64PDraENGKP3c9JneOb/XxMWGOFCcNXXVicGnSYlteVUqT+/u2nWxDb6AtzfhZgox04w/MwpDFYD+yZd5TtezAey136+tSq3Got9BpgMo0W+mh+wG3jKzMwfiaa46nP5CYNGZhFFc2kqC0/7bR7QZTfLgg66zP8xd5lJ34D0j+6/0Jao+UD6ivL6IsldGW9L9NHJ9qSpkop6QZl4q8X6Z/T3HYnB4HDLeTPUzFQGW8BnjX3lyOQ9mSY3FVAYm+C583ykWNV9XYR+bcf8AIJl63T0Gxd1AVrSKbQFh9EanEuZIIV43X75mrM0kCpWzaHLx9+yULMU3kNI+2DpAkvh/bmBp0bu65YiKlssQ6M2tpsB3gaGWT2TKbCsPGNKZtLlnqw8P5lXc6eH+yJJqcDKw193p+kONcRkpfvuVxF0/PKli2OjDQuKmgLcXCv25i+iPH0f9t0O0+PPmBe1zVSmNNiErjXggH7mxLIHrNZ3EGCG42AyeX1vLaX56S4D+F6I546jHjdfqRJ0MRv2dMZXzyl2SqZl5JaiNqMACuOkzg63l2jCzditsOddJvmvD1aIij6bLmjj9N57PuT8S9MJ2JRkj0IGzFctabV9CB69nK8LjoyuLIlVp2cT3ki45YGo+mijXNosMAfibNmnsdYsSp0/tBYHB1YaBbNRy76lbuYa1O+Y/pmQDZ9Toxm0k2u0NBsve4mVo4TVJWsTkvx16SqgVBojMmrfaDoJ+cerkNScdobI536HK9MfputUqEv8ArGUX7z8S1YjY4TMHYXbT6WYoG6YHrDTUOTJp/wBsTWeYFCiEspdnvMurifnll+wazNeg2WWydeNNES74J3hXq6xXNm7wMsCxIsLGG4HyeIPRCoKLEyR0Evuk1w6uiG6wN265SLl90sXhh3Q66MsFHF2Z85KauNjxuDvCbpNvRZLt2fEWuPtiOWTzi+r+UsXupW+mTag6M0cec0L5U5F3DLA71VfaM1atsMm8X0i9edYYmPv8iFa/dHMShIrkaTPWavt6XNDEw5OPmZhpk8RtDlyn8kMsnzwP6hqwTOUkbPR0MFC/6PQC5aJWLguFKx12mHDeisdpUcqo9My9TwPwQMhmR2TYbRo3uUQz6PyjB6f9sLVDD0wgsriLo7V27RosOTrAS04g9L2SAQV/LDcZpdq6Rv72sJrv6OpGa/A4hUeq94QGRRrgEDiV90SifeCJVmCJtU1a6tOl9URENa2TMnZgDV6vBzOkfDz1iVFLhOs0wy6e52l+13+sfQ06xblgzneFmcejnQ7zH0VQ0d6jvj0ovVpFEytvoHZcSxIbT8InFWBNTE5tz7+pD3+7NJWOvJNMQtbNJ0UBx0QtWTz4DINpvyIJvNqc+Uq8z96jp6iU8ehBWtpREpmL/llv+u0i6dky2h+8GyXLN4EBJpmYaN1/7fJp3MRKytFSsLzPwErO5O7uyp+h5nJgVkXlZaBXc9WJHSD7Jwz/AH4QvBt0rDviBNJvs5WhwjJhGdPG9RF+IitccLxsEuMOPBdMUGRaaPmARsbVxMOnkGE6kQoAxwOTrH9j7790r01fXXSUqLXEdDPiV63L9Hc1heBhiAGCb+iI0xIKLEgZEC7Dkllghji6LjHShqPpbaJT6rzFyyaTB0TX3dZoiK7ZTm3pu8xfxhGw4dSYVZauDv1l4i3d9On0JITi6ptPix+x5jWqNwPtHmXndzR3JnQJQ6Gd5mP4HSWBkS//AG67quCspKgfsd5R0/D9D9rzC+utWYnlGhHdKVp3g1Lv0p1tG/pdWh4PNZpglLXPurzP61wKuqVmF0d1Li0hPeqISIMkCLdEOsNvUt3naJ3AmkhruDyQ2I4fgXrOVp/AlQmbhx6Aw0kdWVMU8wPR2G69HTU9L6g7Soa1s5hQCrFD0QIaEUkuxmgF97mPTJZdUFtUcLhuaqoH8lzL4lZLwRtCirbuUYupXQzFluXeC41unXt9OssrgrZusLUKFMN/t5gMwUzmtuZWA7DtFKfxwy9WRlraRj7Oev8A2zE2tbNXxO72+49VBJo5cEsz3p8wRKKDi/WtaYf4yFsq+5efaZJHziF+SKaUozlZnyR1r0fRqj6T6uTqhmgO/EpksqVSzM0Ya45jrcTp1i+sGbiPbLzhWAjSMHM5mr6ExcVSGl3UC6yazBT1TMigN2VrbWycU229JQuLJ0deSEIUMDWn+H0N5DD6CDZN2Z7yFsrFWfMXgytAlgKtQ2XrCW9DWVKlu51UcVtcIkZs+WV9NOMcyrgWNddlGrS4SvoBixw7MTo8clAvU5hFqq5Srf2O8ra98f5FmVaPBKg8/wDgblO5633fVtfWd2Jwfmd3/wDBKtaq+7b1GfdBlwI99njT3iOahCCk7GYU90MyBDZgmEO1olMEczUiWtGXhISnWIwNY4lc+lYlelej884SFRB/6ghSRw7xMcH+ROsEOHcCEfLk+8uEt/R2mcgL6Q7dVIxFTXQhL1mrHD6NbPov+LFanXbtlFR3JhtP33qY6NN7mOr+URhG0YJUjZYre5vgUTpTOtsO01E1rz1ldXGs2QNxS+8HnoBdiaDdbyysuNfn6EdllhqLI2c+6IKZyNxwr3OsBhOfbuJERpIeiBT5MqacCbqAdkKjBYy3gl5OqdZS92fUYjOp9K735350Wd36L+7BeZo6wbn6WXNWbq4LpbBS8zuTpMX9Hfno2lJgzKtkgbnB3mOhDelorTeZ4ioDRcqWlMp4lMpmZTMqxXSZlMpmZniUzqlGh1lwk7BPgSsVdXM8wtidM+kSvWfZJgdkdbNkBLFgiQLQTeBzxljnrVPM0hm5WNcE4+Y2MKBpZWoxsxY4Uc7zHPpZXoVZcuUOIbT4QFXD1jobWKEIa4NpcuWHmLUBKSKTXZ3qHGHy48Mw4adTSWkErrHRUs6xKs7g2qNAU9/Qd9kd0rZGvXYgTV26w/htIpLTZeb/AIi+8xF0u0dunP6Mx8yLVhGKyC4qDQBhG2r+hGmJx6ssph2T11S77a9IU7xWx8S2eFvZWanhnwKH5mRIBreiQewL0oefDlJQOOfdMtHoKNiz5ELLXkdQlAc5xrAkFX1mmsdkpmeJTMDJMre5iVvg0uVYjwQH0piPELW8FcwWgUHbA1XSIy8pgtyVzIbMHiuJcbG3MqtoXrcZe0oKcnqAYXhiF0JXtGlck1SjT3c/2Mvl5C9caj7+PShXXCP5MQIxa5wtZcc5/opb/LnCvOf6GFv5cf7PP93P93P9HMn5s069zK/5M/1spfkz/dz/AEcW/lw0o9VwaSzq9pXd+YPmVCA4vzKW5+8uGvNGYNq+GWXo84vtLdN5ce3o/Uy/Rp9YyhqlnuQQeWBGX7JxZg9HMZK9KzeQZVuUtqJVvUrf6bYJ2ai+vvI/3aZOc2uOiqCi5TAmL8w03RWz+IqqvqCO4UYtkuhiB0jjDPDQNA6fR03PxXo9bnaHV5QYuEpY432h6IhbnNFEkPoGxeJUdmM89MXxM+62Xr9Fyd5VRXX3s3fnzDCAuJd/NhhiXRvQqnz4ULR65sPcwtNHvm18zczDH1y1SzzlC+RlNqzqTQvIR61cnV+fDSHOl4/3WKG4SDL8Zyz0OU5z5xp/Lhyzg1Q+OSZHp6496SwRRdzAmGrzMR9urY8v0XMPqw630XU3Wl1Pd9Bcx/aT/YnVg+jF/owC2T+XPShKM0TpItI+qzAVJUrHiMvV1cwxKLtFVa+lbemp6X6KaiI/GucV7sZrJtFP6+Nx7UNq0A3Y3AgLZ7wOIO2PdZcIC4ax2hV5lZzPhZIGObyyrlvo9Oj7yI/UxbdCNuAvko/xiZNfkhdEgtnAYDUx0f8Ao1eJtMUZjXE0foPU3+tCrdLanJWf9if2KJfyT+xSwrB3h/aT/cn+pP8AQlf8k/0J/oQktdQNNN/sJV/PP92P93645/tSgq7agems3Mq74i2zS+vqfSpiHVMYMVLRuAgyPvxGk1MX6C60tie2C/1nQ9sXtHTgfZ+mKy7+j341AFaXguOFwKaH8wPjVrb+Y6AsvGrGF+2EtZTshpClOxIEK1VjeWzHZCbUXbAl3is3rA1IvaK12lwIou6E1P3rfabQn+I0n5qJpm8XC/hkdd5wQOs347zE975QGkG5Ht6K/wBeP+vOh7WX5+2Vd3LxMQvP2D1I2raoQZj9KlY+5PiAgA4MRQ1Yhsj151E/e4T6mdFneg8dDBdBElI6fO+lGac9I/12f77P0mfpM/eZ+0z9dn6TCkWC61GcMjKguvpK2k0HWZrMt3p0n6nP1qfqc/c4v9Dns9TVhljL6YruunaLXHDXZlZHm7y9nrKDJU1/tJMHcZH0jFzrlkPKTmpRq13nJPNYnWleZV3nXiG8etEto6fsg8fbGUnqiDm+6ZUuUy1+DHScaE8MllO+hdFi5vC1fcQoh1J1/jtDI/lZubvePzHLjrGS5120fSX0bROg5RIzFouYuqixGDmGnyhmE0nFmYzEy1HILm3MGG0MpoGqr+e0qWwW7f4mzH5IbUJw9Kms3dKpciIOpJoPaEr58bou806vial4sTV35iLlYETo+leXl4PVZ3StwXHdqVvH8TlEkuWwD47wEXN27RmIyZvldpSbsXJ050vpbzeOjnWJVtE5tIVbMBboTq3V6aEqHiaaRsOmoMNKl+76MzKd8zmwX2iEUrvTB8vW5dD3hrEKShxHHG0evM1Ft/zn6SfrIcT2nQ+0P6af4U2SmqpQ6VrGdL+rfTURaADVfRRZWF6zU1pV0QHguuJF+M/lNjfPphmWPO0tEewdJiaRuAZd45a3zOEG836g9FjwxfA5mhjwLq9YFS3RMMTKZe6NrtmaaQ8jFouPcr6dY9IaaayhP6TKjnn6/wAJlE1jmOaBcQ/qsY93cx05JQmIPPqHHPMu1Y+yFL7tI/1yFexC9EzWWYLLGP8AAUt/klQTdYqmUtfcQv8AojlbmAEEzWbYXVHmNpweRfPSUmMIo8RruA/XmHSOzqO/q5T9CvaOHod4g1qNQ0ra/M1nXeWmTBcRbv1leJXSVNNcSup6BcSg8xFynaO6dqZjL3/eMi1W2X6l1eDmEjtedhlvtL62jiZ2u5NRygNAH/nhnCZfy+djFgembOaZRpn42WHqqkpMxD/T1E2+j29GHp1bxwQpBXtATssHpOad0HGG8pXcpAN4Qf6MT8gr67atZmZNPH3lqia84/SKqCtgXX8Ri3npAV8UkX1+iIDiwa3xH/ZjeoppbHmFfcEWH3bLXArozGu6N5KSlZXGdpoSz3iyAl95pgVE7xt4brGOso7j8j+JYjZsy6GvgQJGlzEX7YRuDZLSvd1+nsBOuzFdZhOs55NoFaBpI75Fo2ZZQH/YS5bX7/SWBli4m6VnjiXr31gFY+CBjPpRQVd4l/o3lnqxpoXiH8MwfjmgkjFauIBmb66Spuve+tQ0BmOuSt9ZoVjcZ36Rrc45DzLegV2MJWsY3GhvswTRdtg1Mm842ljvW4UxWT7xtu83NMbltYPefyBFDufM0OXj0kD87MKSutfEE/jGpwR1Zv8AadDb4gIWrRD1mK/wQLnwTuVmWc/QsiUdd7k/05/swT+SDce8G3g+/p7ESkLrs7eh6dHwmtMXgaiDSVKlTSZu0sueT9f79D0TvTCdTxyMrab9VBvNd/oZFp3dZiL+r7EYjKvoQBmW4anfzE3o1F3iotZriUjI3nolmBxpekXVXG9u94zK7hv4ZT3JWGsZ9JzJdmGXgdCaxGjBATjaw+XM0oy1JewhEr4X6sbcm1eYCC1cEI99348Sh12nLm/d+rfI/bGuq4MfwmN7Gh95jEneWVFhISr4oCizYdo4ycTV0DoyvD5giPxF95auGxcbMHJIkqsaQ7POL1EtUZlwhdmk3V4YXbcQefjlt+5JqfZmNY1pRN53XpKDlbVsqEv06m+gqzpjFcJuyx73XaZpe86uUQGYG/vPxIXNQL2nWP8AE/nSfz3Nica4RBv2GZW2+px3j1TS6cdoZruPmdcRFx4faAca7v0WIvum9zkl2a/MW2/JlXpPL0iDZvb0DU4vNVqlbKXLK0OEP0WhrJVbvtxNTsRFW3MvqbjYsgExdnI8R9e1cdOYgekJdTU23zFtwSnO0dylUZvmV406wAF3mHAnuITwCPPris6bQ/gMRs3L0i1bVsy5facU9kHx7ZS/ZUBGiYjO95USKi2LXGsaYqDhuMi6X19FwJpco8s4jfHFN/dFYzATB3iuuJsJleorod5azmf4mtEvFKtf7xHFl3j3PyHn69ZXda8PDKxQOZe9ZH7kput8VNDEqQed95kDqM/CDWu5SKc4GW6JgZhAFkRb+WBfz+iD/cj/AF4V/LgJaE60xh8II4hT4n9bTJkPM3KO8SLzdYZ6bMp700A3NWxXNpWsd5ofCR04UNhurMQq4GrsShsuuOsq11YO6L7f/EsmN/QQbh1m17pQOjj4l4rIv8RaOZV1PoNrYgG6yIo9t1hwh6xf0CNGfD8o/hniTaH3P5lVjSDUcbLr59HEcPUD3hgbRKWsffhdwlfq/Qt8euJbFcxLPVe8Ay0SoqBqS8VEHrP4S0NexBHlvFwRqA5TbMaLTNZ6RkgW1iBKipgHurOy09CZ0+VaEAZTiuhUWlc2pJx+8TQOcJcNd98mPuA40lqIgA5sxcGzfcg4UeckD/nheodrYu7dqvKLwqQH/JGKj3oXIneHQSNaRn2cw+8OflfywEWStqbj339+8Ugz0Hh6d4AAYP8AwSnYy6R9p3hoDNbykqmGxmPRj0l8pgGZ1GFlsTqM6idRDkTqMu2qLyhZ1lWnqS3liWWqjypJLcwVhisStZfpWg0x4n7AzA+GhdQ9CdK1qVTpOBPyHpUpmIawypUIUb7+uqGQ5uYPVnTw/EOGCgcfQm00vtKSdL4fRX/k6dY3cbxGe0PxNWUAwO8VL9NQGYlPXY6JOrRPIuXmhQQCZcrrEJMdXLxM1Cq6yqt0dot9MZ6wZXfJCzbZtN48p4nPkn0r0tyy3mW8y3mW5Y8jOowAUvGst5nUYLcxXlBcorbZqZ8qo2YWXvUtuhYiWOsRtuZmGIStRelFt1qaoomEnR/54WjWGhuREHHo2wJYhGcN/RP9ch/ZEq/rgz85Op9yZNXuT/eIOnS7R7a3xP1Cay3smqewgwr5aZif9MP8uIf1Tq/cjhNBepCKRr4lzE2WzzHQ9VVKKaW09EWKcQMZbt26TKJsUENxGavQXEDge8uLOJcW/QOjSV6fAT46EL9SBcnpGDB7IJagdT1uXMZzAYApn+ZwBnSdKpUqUXS16WYbLzBvNMJu0XuwwGsQ6XgZiHUDMNcEVXyIndW8t5GDmUZ1yeJibR+6LomybHMKv9bWI27cd+87+iK4evK7TaYbs3UaEmQ3UmTlQnffouBV5latBztcNaK4E0CF0yVw4mOjoqWVSWLrrgMa1e5M4+BmT+CXf1QP+qf2Q9L3vtT/AGyf7xP90h/KCH9Yj3SkGil74eYcG9TEtlS7FLZvcgAUFf8AoM/OJXXvH0Uy7GXMjfx0J5Zogk9fNLOdVDDnDeYI1eYk0svajrQOcy1WkSzctqt6jUE7DOJ3TQu1GUwYqrcZZvfplmEipxcCg2uY5i+0xNoQADQKmz1AfmLWjsS3poZlqRyNZXrBq+diOjtOrbXeWNXxNC99NAi0af3Cehuo7i2oJBqHLpCagHXx6YrwIYuiPcm36hZZJu0oQDhzLlDmlqPgZnXrs4xTnUqbQUYhpsezAKjW3D2mLzCysfzFt6YEr5jSMDqvtOIaSxcsvRDrsB8Q9y4Y1rWIOgvpM7a3BP2H2TEUE5L6dCFwzKixXE1QXeV6jGOFvHRqOwR7YgVAmZZZOIlg5HiAoDnYL8Fg7xHpKm3WUkoclQElA1q0wUWupCDDmjPqRi87Up3YlCBdfSX6OkZCrxNN3ncOJ1MD2ImTaacEybwf+uMa5HiZ8EZ9N6bMcebi6korGfmUCA1aLxF4kU/aCd/TbMC6uKVKaEJdroceEBKHzj0ACJBVvdyTFODmMjvNC4dna+rvNdtrkuh6ofwgW4HvDnet26y30BL8lgubFxoK7k7wtxzHbi9aOOsrMbJztO41ERVYcMdVT2j/AD8m0Z1XtD6PMucOvWZSyKeYw9HT0B53PbaaJf0l5Ihpmc2EjfqgmzKB42ZhThyS+8iyJUaoN0XjiHm+4d3eYAuwabxEVrH37YuIAABQaEsma8jmLd9PxH49csN3faXK5qOnLzTHhGtpUNRnBq1ncwejsmTyeICn7QpnZltW86xu9VwhU0EPUiWJHHkJ1Pn2Ijmqr7+qRUNmQu4VN4Y4lLU+Q9estQXunlKavBxKQsGhCnFztKq1+b9DdFvsxzGxT8Qwg2Y6/pBHAxRyi1mowTvXY8EpfPs5hmgWacxeLforO19PyC//AGzBnR6QWmKuzDmqkwUCOSdMg8OZWBideEYwjTLBTmLaz3b940aHeM2e8EkHGESChuaQoPgCpv27Je/OR4Z1pNdvZ4faZCA7X2JV9oGPXp0s9+Yte+r/AFjpNZBtf1USzZzDgJZvTF6+fS8gsTMtq5ItW4p5idNuPTSxM6yrXXVjUOAV99Iv/JLxNbjgIWQyKjFtXONOnWU7OscdOcpZ3Hp8TSpS55jNevgUOeOxIkK3w9oJav7wDp9FxtqXE6NQPWaOpD6LmrPToOx8hEibaWplVY1BnLbnPSEUP57wXNAuZF0zUC9Mqz2gxFHDoGt32iit5XNws8ShqjnTiXWb8w5cVrK0TAyoFix06y716zTSbgC79olwtcHMD3gncZ8euxtxFVyZaZG3nvN4W8jWYziXBWMipxuMYlNf48TYLS7+7l6zCK6Un9ZxzAw09oLfpqx/ibUfT+SD1s1uWbE+EEDA7Jw3wgbTdsIjl9lLn4c2oGuEG7QMRvNyAdjrBOtfMvoYH/cs1tvXmKlirvmXWkoOrO4z7woULte6BRX/ALYJZgpNKJR7T6+UqmfnjHSD6BxvOK1KowrOLYiapps+YTTK0IehQdci3qikDw4pHJCHvLEooN3U2goy2HeYHVLWtwoJtGctQ3lF7J1ehKLm0zK4iThKNq5moYakAvOsKjnWAwakNVquc8NAwjczK97Z3gD7e2JlrBJJVE5o9K9N+tz/ABhst7vRFruoRppuE4fBnN7PRl36X6G2pC3TPwwl3eYTZ5/0RkQSk9H6pVk5gK+86nwSg1bmofKN6LEc81p6doXJC81GPiKzaJhuZen4JfllVrMBNl1eCEicXnrDR3GXi6m/f0Rc9PpL6RlG6zpc/EEaMs1MXZeYANVjjIahQi5GMY3n4lTH5Ypb9iaPFxP6BKsxvox6R9B4sxLdMQA1M289Zg4X5hwv3CdA1wpXeH2CYT0xvLvA7P8A3SypZF/iIadjZz0lLL0urj0+2uBAhp6g8S96rXKzyzJLRpztcC0J1kzcRsYvhY51MbrFmByRKJ3vSKsJA2y9MTSUr4m9m+ZbORetkCmdpgq8em1gPthHWZwwQgumOZq5Zfo7QvYuVr+OWNUGWB3YurJ8zkHadVXxC6CaWxmmWrxNUB2aohW98Ti8QvQ5iPzr6lSjcaZRE9uDwy+n8zUiQPmvozanzCOlXrOjEJsfHr2jnWeJFN2TT0rMFrzLxUGMJnWHKlcntCn+fRjnN1OkIIy97E/H6ldDOYgI6uKcx0cS39Z749Lw6x0mI752nic8MfRZTCF76+Iju14jZbfZEu5xOv7YFJotpADXuyzVjzBKLxwZHaX6TUte4y0ue1z9TLQwVZndxHiMTpcZp9PVLWqHHoTNXAx3Vz0l/CYCnQhfCRy+nEAADQ//AAFxDIzQJmpISzFYTi27PRjeY4oGRNSMzZQsUOObH3Uliv2JQ/xTS0DtHft8RuDXm2yL4DZyiHyA0Q70Isad2lSTGVu8N+TaQcgSplbyXx3if3Kz1MOhZc+bai1f3msPxGyIDB1OhMYHLQm9EOava0cZYYFu2P5TlGHRZ6neFZb8S2d247SvoVvtLNYl0TDPcmSeOW6zXq+5PaloeZRPouXGmdOGXB6He80jhbJAB2yVm8EjUfFzVXLNSnOkyI0xOrEx0HOTvMPfcfoXYlFfsesRmuxzxOVqc/cKpc59audxFzt39CIubwHSWN9xSrTLAqlPNwywpv5ZnGnEZlrzMf25pHwDWNZdV4WzJFW33pze4QDNfOmkEY+KNXQOdtYyeY5TOZL9Yiyu7N9B+5EZTF36zAPuzr2mPW1q5/8AxcbBh56MGK2WEyUvIm+wLo7REadYaku7uaonmYPzp/psab+dn+7MFTf6UMf3Zy/vAv5p/qT/AG5/tSrT3Z8njLjMbydNn6V6WlvtMVVZKtda/Ev/AMKNuu6eZeIsziyJBoRIFj0lmIWuET6SFpHpKl77jExDPGRrOnL0uXGFiEy9po9vpRds/iGE0CXu5V95wLiLliYL0mV3zMOZsz7vvNL5x+Jfq4msnN/EooWS4Rujsj8+i4s68j9DROjhm91UlcylqvSjT3J/ozUv3Z/oRrKt3uf2aYfzp/ps0fuT/YYU/nT/AGof37LHHvo6jq5YMxVreAqAWsAodrdBjmid4SeyImiUezg//JV5DoIo1AUbGKU0YKszFy+l8VGsJ63d05PeT/fSt/OnF76f76f6qf2FL3HupVznOU/2U/1UT199FadcJUR0lemKs0xT9DLZD0bzBqd5R20fR9lSoF7y1aFbcxo9UupvMX2jNZ2Jlj2cRGn0pXdp3iIxl2aHaDPaVK9WzfV7Mv0P9mz/AG5d/JP9KLus7CinlPozM0JWM0KeYI5xcdDtMMrsrXme8ZFosCvoEZciro6+mryz8/AY+5n4nS/fMwDgnh4lrj6K7vO4B7ROQHpfp1vtNha6Ylq/fS/+VKprQtvG89NaV/kpj+7SvX30MP30Vb9xljXxylRLuF5zaqcw8omQZv2gJ6q4fzL7cxRbg5fuMvcz/wDmEloh0KqrPbERJmPhNJaTXgDBwiqGygJ4riCF2wfeEC7ITCzaX5rEa6zT0OWJlrT3kyHncXUVxdRDpa1uDGCZg/OT5TvJ+84+nxgBxOFqHv8AScb+gjQSs9h44JIBwzWEvRMyJMYfBeXCTywxseIlfUaUnYgfAP7WOrqP4y/o6lglcv3+v06+y+ZondLlxWd0J2pnf2HbCapRs0ygJ5nmJLlxVRy6OE0p0fyRu7S1nl9+IqTgnUN+h4njanRp/Mcvo3iuvuwR5GVpU8z2NIxuCiDVFHJrDAeQEiocg6pnFQK5fKMEDsTJAJoHSFbpJixJsPyTC1G+Zbh/Bctn4OYI27YuWhkz4jU6KgfDEP0g/wD0XSLPc2l/vRd4JeVJbDvMp/p3KsGx0Q3W01hhfkj/AIgY9xlXUdGCwLe7i+DAtDCANTY4TV7MviURhgMIz1mukqYiVe+kQ40iAAaCjxM44uHiHq+gQcIq7x75hNGZ3BB9mX6l5Q3fbfRH8TKMaqdd+YoFp2P4RAJo6S5Dlr6GCM2flEXrg1MPTqazVW9yDUjp/aZVF74fafdXGbedxL3MGH73NI8qemZdJPk8RKVbX6HSIHDTuxWJV17EQG/7RBdQPeaAx+yXbZU8erUfhE6+g8ESi6sJyaX/AAnjB7xY4OwNDmDBqBaZrj4j0FTtCP0rn6x9Hk9K39GFnE6BY9I6MDf90MEXJvR3qV57fVf+TYoCOp7RIa6zllo9u1AOJqXH8oHhBlwsONWLMQMxDx0T4IQSlugdrYK0yPOxFX3mvqMWSaZxiOJdMg6af/pWp/tNLULgr+kdKS9Jrok6QywfK5PciltOTfogMFK5esWQzYH3mpWm8zOdVsmhBYOIl0tY16TS3a3bRXdHv6YHw0df5llXn6HvK+hzhn3kfxCC3vEJokD+XP7ZNlK8DsSZzvTK9xmA3uPsRF9UrHE/mGBJ0FHj1qZ9HsTsw6jzQ4vtP8qf0eXo7zFtv129Fqa8TCwMaHl5g9VfT08PW/lDa3GIvuPv6syObOXh9WRttHIRR4mvIwvpVX8o2vj/AMZnj91nfxK+UvURsDFZpdwVsGuGnSZWjcbOssbUfzMHcRvGTH9BwR/m6jyH3ARl1slyIeN2VbqG/hDJTDwnMYALjTbvC40ZZk/PXU5nWC9j3nMyUxFerx2P/wBOkglQnbrr1NmH4VUPDzKlyw1myLT8qLdQH9GBbvB0/iZCDJMjrLX2Pb7MTnFLJa7cEdIXKchabsvbK23MuhtcaxVK33hLNiWbQ0l9cTxLYuS9F+iqy5hq1d/orf6VfiX9z7TCXD8DPpfxgvtgtbjEV3H0vH1k5ly5eseEC3FO8/WEeGjwcvE113pwcelxnyJlO6vopm2seiw0dJ2wn65/p8bMJzRKlj1+mhLT4/5EStvoFoTGehXzmK2sF/S6l+vg5M7/AN30ALc4mgB22l7Ab6pjrnby06srVlUESAdLqZo3u5RuIgW3pCXZD8hlefRUCKhsEcQ7tDb26S1KVDJ8RUSZihoeZuV19DmEQ0D/APUhR2jDmKbV7XMC0VY6DaVgEQWz4gUtG9t3lyoNR/Evws33hylGdItEwNo1sVKprXVj3R6c1ra4hQLSmV+PTlDN8zuFe8NNPV9V9FPpK/Srp/qde1fRTyaM6yxS6+gWS5jmXPMslPRaWWgzHL/KmH8tgoF8ybz9CgxdInWbnLvL4f6ly5foHXhKFW017ivpRGKA6yEJuXNLYYOXiNdl9jj16YiYAGxXqQfRcTMupO0idgU+Por5cMlxsgaWtS1MdZieq/Q2JclXDqKW8ms3LV7w0SgB24TLRu4h+mvilyivoXSam2XMBcR8CDBTViraUEeE4OP/ANlDxZb5u0D8FWlqWtD7kpv0/TgbShNxaIEKT5mQlzDriNxQVvMpDsTate+EpHK23EBWXw6RIRrU8eihbXtKA2+xOIWh2Jj6Lx6LlyzRM1Z+IjN4bgPMTtw3ZfpIHmhXfijKdycVFHw9Eta5YSpA3UzJKtF5IfUzknZicUdfbn+PP8Sf5E0T24bC7x8CPhCV8By6zOO4wF+KXdmlXsaHrtncHYjV31F1UXtB5h64fL8tMsDpd7EflJnUxqUZyeh2fDwm4i/s9CM/UGIAK2JWBysp+ihOGBy8nLYD7Y+i4BHm+InwdYUWO9zuXt5PdEoqrlxAKZGmnSAxbmvmBMvpaf4UuILiZbiVQoc8/kAu83lZl7vN92ZuI7oJfsPsf/tDu0TOWe506oFDJiukG/qv6czuNojn0yXdwjofLn+rlD+TP9vP9XFLhqKlW4eIytzv6VdwfOx73ooYCfEf295rxy78BOPLDx8pVoUDtdiHOIDNu7HSDvG89lH+Gx2/w5uDJ9H8EtJ3BWMi3Y7FXTpK/oUS1t3Y0I+yFfBJyftG7idWXZh3p+lS/P2g49d+Z+doNpO15+JeHXkDknavoyIzFy9olUqU5m4n/wALEZqf5PRIh+0Or01Vm6OrHraeu56LC1Lx6qx6XUtr3jkqOiHyTUF8RZnyPTrgHchnL+JVwSzGGe/D67zJR9KD6BIwt/Pn+3n+viuvu4f2eI/k4rfd1y+kIHetguVVil6p1w6rxF0EZaK8P2gO6Bg//c5vDBY3Zr+mISNxnoig2l1jgY88Urr1Ymk6zV+jahReYrMw2LVohbet3tYZcC7XtBLfszJp5ZoM7x/bafg3Dud3YzRQROxk1KWsWHVe9Lc/VS/SFos05+Z+dc5H3ITU8UPT/XoHibGsbtO0s7HmKWq/VSYCoDgi2sGpN5nVTqS2X9GtDq8L+Zov4RszfPqBMDqLq/TrbVTaD3Ij8fU/vnp1fdJGNPPNX2RgrTWaITD5m4tn/jfpt6bxH4CZQQcoqeOdzKwcDq6VxHKIirajpKQw0P8AghfbG6U3pdXvlIOXIbgcHoYOR7s3lViVN5amiKKS0J32R65fhxC7g1+SQnz5Rc2rcAnyxKKur/59VOslV5YgypesSqFVb1nibQ/TWX9JxtGqiab9hxH/ANtRMf1GFBWYXfo/+CmVa7tSvFcXoWSstDuW5TEw2o8uksLw9LmNp0tScxB4Tglb2pWo/wDhqwdovZvKb6eyIjvM0q/WtK3rS9zKsOaaeqt2c6UTh9/RmxVGv8Jrt6XljgptzLzEH2mBehq4lS3np98BRb7bH/EoZkr8mETX7zIsSCnGp1iaxW/wRpwmM3LWq66ULF3RXZgc+EQwfFpo36Z9X686dgZM9wN+Y+HILpMF3GzK3Q2G/vHGlSuX72iLGhb7xRYnfclnOnbt4p5ZAKIdWbQjQG7bMRrql+ijGY6FzEqVAzmW49AtqVzp9G2k39EqYqaMqaL419E9KnmFkf4iTlciQVG01/jzDZUs1+mkWoEwaVHQoZcMfzGrzUpaxAmPyjrzjFy1uaov0RXI7kKjum3/AI2hixSXtaGx2mWBH2igH2t9ppE9p4iXbAO6U1d03Lmk1+i+bpKNKVVTpE5uBt7SyPxr2gBp/wAc+gyoDY4GiBv+F1jDKPS+iqTGa+lO3xMpVpSjZLRqzp9RKgsXSJSW3iGvCgP7wR18Y/eKrUveGmx1nzpKdYI62rseRBw4mV/Edh0LlFCg/K6TAJt6B2irYBhP4iJVtdZUr1K4MR/RGDOs4uW0RTYqK+qASuHEa0pDmc3MEVnmY9KNC0cxlsNV3NMswR7d1a4aOdprbcqYmktqpup45/xK/KUyqMDCxS60irfw1ENuAu7yy+0S8NtsxavdBlTIOcyhpffDC93ftLxPQd6w2V1Pjo/+CKgtnvctXiaWd8mJvAwDBcsq8zruy5ItVysOL9AeH9SSjewS6ac9YNGru5f+Vb0nR56MpecLlan9RHJ8Ogx26+7bjvJmzGOKr0xL3EeD2B95kr50TT3lyU8sGXq/FDVMuH1ODp4Unos7VHdmilC2+YouC4Q+gajWsrEapDqbKK2TeJA0y/YSr2Zb7EKo0lGPWRlK1NFPUm1rCtDwkbLYZogk5RM+8v1e3D2lbTDkuXijPxL9EHgW+a9LdJexM5IOZzOvZODccjvFj0ZjDoiorlg0hG77+nX39H0/dj4hUCeCEy3furCEj7Y2mihE00HWPkxpTsr6tWEsSa12+vrNLo+zzNloPoKF77Ho/v8Au9G6RY0KpwawjGrrzGhmaemsHmX54RIjxBa6S2oPv6uIrUp22xAACwD+oNsl4bh6y8T+g8f8yhvA0Gsqtn61wXOzpLgVshcDfDwz81Ep6NJariwXeP03XySs77vlpacRjUIRNwleV9SVrNplrjK9l+0uCM29MerdVBeTHx+z9Y6cKfb6Biwz6Ko3dxW8GDkqLAK0hbgHNBri9TKNI1FYZMGp1I+JnwfzDtKnXG2MDuDiu7rP9DTnEMgFwEAv9fH3lZgdPPBOfX4E3wfdXErrNmCviM8/Tl9v+9FsArnWVGQwaJunGhftGJ3nQH0IBKK7zLEQyfV/yqG9y9yOsGPV9gjiNJQJh0HsJWrr6Rl+ngJdZZla1MuJc8+Qm/aEvfQYxtNBd6Vqyo7nl/EoRr/nq3PuHcgK0qbm8AmSMpYF9kLe+KDHcie/S+PEzZWzK2igcMGhzB3zPnaC8S3dvXIQlimu0QXrL5ReUOkRKXfScGB8QU7m+5H+1N/SEmX5zFBZaH2m+604X+IlFq36AhXoKrgWaTfKJ0w8JXpQyZm10PWMEHZiXJLzMNvMqgrQeRFHvKaX+jZZcWuT/EUhIZHRiWR/X7RTFGeY8xU4IWuzVcJxN4u5VBKcvi7Y3ShbWkIL3A2SsDWs0PSZL01e7MxDFZjWgalleXcOCYxO2gELOPZKG8PDjevb4+06xVmwVlwe7hXialjm+DA4yhNMS5pGV0ATdM2YtpkQPDFRFgOzpOVS6qA2wd3sJfa7y+0Wz3lx7eodO00tPDHDOUjpKTlNIaFSxRLeMpkwvky/9F6DU+fgwhc9NCV+78arcNGdeUKSXtpWTRhVfS6/kmce6PJA2jWKihjj7zNzuVJUF/JveLBljnHaGOsaHp0gao+4gXovFzpFoAFbjgEUnrhpNX0Ldj6rZTfld5Sm28/gSrX1Gm4HTpvsy2Bepc0Z9iUSfKu8wPnsTKvk9LRmK6xqrpUJnaK40dPBvrS/Pket0uUtZfSd/M9u0dfS3A6CY8m7HQlwY5dUvtGEsEw7dWN9w4VuQQC10hLlZg2MLld8pyucSO0OOADWG7rxZK59BpEnbeDnbA7p/is0crMi/W4c+GHr0nZLi/dJvNin67BHoLX7zMU+jMHQC8IFPH5gBQIOeXEAzqWgsoTLa3ZiVfximWrtBq+sC/8AQeEIg1/lYp8rrWzG4PCLqtgUdiJrQp4HWVutjwmpDYHENSUdnpJoxWc3i2l485a/iWNtJWL/AFjd1x6PWi1vLm4Z35US7dmnCzsRNea4diat/FXyzIY98/sR4MBwG0R4RXSQrfopKhqD5ndCECjCcSr0l+Jfl9v4n6EfPqU702ZqgB13/ER3xoh46zeRKqldY5Klw31hm6sEsjif1kuWJVOXBv3lCNeX7I3rzcrL89Y398qzzL+uAG8KU/tNoGYmoO0GqroGZ2KMCLN/XBHC36Pp8zCTUmlaZ7t02otzfgj2orDj0qQr4ID1dv58wcPTDSW2w1+aMBaWvoHprKuCqd6OVF4wXdzCjasy6r5mlmVgeY64lxoe3MuMN6IrPePErs2Nf8/U7Rn01fpGEtBtnfzONK3smWbKtLCidzIzE39QU3KVyVu6wDR0BNomyCfPhM1fVTf2mma9hlwDb0GCVlZEqaP2j60sPr+OBX32qWS2NfwMNrXzEwScxbCc3TFzb70B+RpPvBt6XLwhh39ipVXTNdYLd27RTOznF1R1yxCqKOJZC8mI62gPT5UzxC8ApIS/Wgw1cOHbcfbRCX3Y/qJeWUp6Y4+9L0mvXWBFpWVhXaLFSruwsPzNpdoLxtiPB8y8O85mJo7zUPjbzt/eKM65WX6Zm46dZlM/MtQTcze/ER0l2ZYPdiBahHC4TRKQUlJy/wBw56B+5LCbF7cHoIOY+sGhuw+CGhr3yVXhgrY7XM8EG38+hNB1s9omOHdb1IgJfvhOlHQ6zOvOuCBQve3KMRq/hmqFtNz1l7DfP/nVesuxgX28R8+Ds9fEtMtgN+Eh4GErWUebo6hAZmSuXMsq6hfXObi0UxUwp0veJoUaEAAedIVX2BCFXzhL5XdItrssHMMFHHrW1+zGmpvnYb9bgs9zMsaxUp8bSgZn64iK+nL7JaGuvpo7eBmAY/0ppKxrN4JntMeYttvpRtPRcpM61gnaOxFfo1mi8PWdaa4vMOlZvR/UUknx6VCXy8B0lZ9M8m5bG6bQ51XtFJUrz6MU4N6xPzGfmWKRquYtYd4yCaI6eggK4go3zvDEDD5T1pmzujLv0IP6dSsCPcZiBDGRiW28jL3wmvvESltlfQPz79rtAqtMS2FBnpA8ARJhtitTBr+2YE02y2ktOTtNXL5SLp+N6TXnt/zqXW8tYqqjnCoq2h1fiO5olNEKBvdYhs366rA8EuNBvEKZB2hqLdoJQ5dBK6d4AzYKr+ZjIdKx8YPDwv8AMRvLZyMzlvGe0vU/WYiKIPDL5i/RmKPPfxKhVzV3BsYpltROyyudQ295bRHMqOETfzrHUOg/dhncSv4mAKoYpi648QQQOWkXXG8QuPSnMFdwaDrMwO6kGoRBsFi95a9zJajv2IORXuakoa1arE86o9CK++0aFj0xM636FQLTr1i9dogQf0CxLX3h9hA6To49hNDvEPatFm3emBHVfbMsz2WW+fEKm2UV9NtVAVxKJ9iyu6I0gM1bRRU0Av6LH/ka+Za2t5+8Ww6S7UHh4h82G54inX87RqVBbrlN1FW/hljQX+eehE5uiKUW7fzGLmhr8tpSVfu1N/XPInOGfbiBTtDqNo1PX/nJheaUIX7UX6Zi21P+yJjDpoeCYBbMyf8Av9xBFYIYZkMZ1CFW3trUy4OpByzrnzNQuOq3zpLoXnyTFWOGSYYcygddR3iswGrFcMkqVKlRx6V2mADwGUVJ2TMOw7OZePXZzNehrF7Fwy2JHpH5I3n6Ae8cRznWAZuVTMUKzc7TbsyOkG5wx26sC0t5qXQWAunFtUL2+gnXjKt+srYgoG/R0YodmYLz5mcyyqrzE0VNYK1Wbw5sPZPg2hNoq6x2jOdpg0eQyp8g2FdKjvgqHoPg0+8L+YnvEyVy/QCza1y4JhMR0kVuyyv15UvEBvpFJIvEVDSLi8y0D5m1GzLxHXnmDR5MGhfgzqeD0JkwC3mglNk+J+MyoIKxsdUTPPRvXXgjhQPsEVYmpZ4sbHM6Gr2jDO59rA/BrZs0T/m25lhjOED8AAN5j51tT8syy20gVAXwdeHmAvh2RyTNGxt1n5QTWsm20cgKTbaF2uj7wBpq7SnI2JfQRO0HbF+IvRTXKgh+ltdI6YyzepL1Z9P4gblG780qncIW2NW8elsdPd+P5BvDvHxczFzuRdJ3qM8j2KYLe0unSDNMMYlCcuPUYM5ybozWlX7C7wY26b8Ll0Sx+CFFVrvOoZHHRGP7OCK6ybdUTxc46T/J3Uucl+m5xMgzmAWANRhz9dMQ68Bh0e0ChoBoFEW92Zy3AOdWNX3WDVPEYiFHEYBSziNaDE/QIOYNxdi4kA33GEqATKaEsxejx7seSsuZLhS5jXmFF83NBSlu5q43wjLgKAMwbXYcrmnE1zfgItJ2gWmOd46QS5d+7EmRlyLYUHRbxKtBrg2fyih1WZyr3bOkuWtr0zxESmggVaB7k3ChHY/5o0uUsJOp1G5xBnZigI525ZrM8iKevP7xhTYNw9IL2LabiQTKwfeFWiuZ+eIhXyUdIISqMylAp95orH5iQPhXMtzKpSNaNtePaP8AcRhmqnhYtE/m4hm3vhDc+IwlanruU5bqelNLD/OSqVAHUx7pVDA/dl/u6uID2n8xe58ZvmZdOTKIjSV6q3VK7fyIT+91/ax2jsEv0QFUkT+dXD35iaszpdp0yDL1Rix4JkjyJ7aLpGIHQAqE2zvmW5eFqdF4I+lM1M9dCfy7TVa4MEHOopcFWacqjxFGgMe8znVckxkONAXgm8sty4qVVZuZbhjdDr3ycVvLdmsZj3IeJagtdWWpYP7XAAcG6wt9ZgqjpDJsZGrW3V0lpG1tEYC45N30D3jOPgqhFNzH8953gEpsKRmFmKnwlvIxPhf81VCqmX1nnnHpCK3JmRZ1ntwTIObTUuVQBRsENvpRmAI2oGsWVVXqy9ykttHPNZFS+218MBLGXV3jajZdROjH2jXf8xBmTTrMtxdY2fE0ilpdGUNB0TBEucoYqfEl1g0xc1jyKnzFlxNmrAv90Z95j2GoCq28kEFefaJa9YuJWloopuBOWhx4r6K9K9C2JTBNBlWR5ZQe3lHRChX9EwjPvMWl8Q1uDkMaRVdeaP5fialKbH9lzMFJV+2Q2QPaCNJsZl1bc4EcaDINa2qblb1DR5l4GJoik3n+PS7JXWKsHakg95eDVNgXpUtL/VMJ3HO/zPdSPzA48gQsoCbZlRUJq9mCXStT0Wobthy+0xYC3DvXdLgWuPMA+Rxs0haS+3Hmf+d0kv7JRv5zBUGlTVUAoXyTZy8veJyF317CHCRpuUyXyM5h3rz1eZYLP8RQT9dZo+diDg0du8vu1gXtCoiqKXvxBLIO8vmn+4prjcm2M38SuTWA2QRCchx7NdSpoN+JsgaFroTrRBdXclPY+hfxGGn2vvNbd4ufejqAcIPeWfkjNn9xi3+TKa50G1Uiwg34PSof7wmqQt/jlsbGg7s0yDpmavb4muj4ipkl7iHRyXpFSOjWpZyHVdYXsj2m2PsSvNLq1Pt0z9pY53SkVYXrdONuBHzLNxFlBxrFTrsxF0upaP4mY05mVBg5n6wpWJa75zMhjbMpaalkwaWac8IdWi0TVCqlqXauGpGctdGvniHoQRo079Y1WzJ3lIvBfumgRhV4yU9N6Ryqo0oSgn2cIvNA5WeRhHpW07rqizLQmt/zxBv+GXN/EbJgPq1Jlz9dPxKh92vTRK7R+ekxC4b1Mr6VgcQwhTjzA4ysQ0V801B4a1uhmauZjSFY5zrA1nu+z0rA+pNynP8AEWs6YqPrhXC0DlWoR7O+zxDP2dFQAsdPsxmvLRbIOuZeEX9ILD60z5w0IS0FU2xMdgcWhdhQwjeZdpUAwMIv/JCu/dmoauMxb0tYoo2d4243xHdHtAGju0/N7K3z2H4nBngm8sKjdu4zDW16QxeIIFcXMB8ey4BYnhia2rbprh9UOGGA4mQxZlDYmk38y8FaRWAywWhuFcnachklWumjSGxnJvBomE7+VkpfbQlWiLjWnOX8pnHb6usu86RJooaMoFgaVmb+n7QTfld0Pxi8tzNQ4A8wSdDP+ctEyQgifE1DNfK5VE2r+/8AxLYJMWKdhDOchG5w1VolvMS3b4ngTGtxtHYglQR64gsvX+hCMAwLv3lPQBrdTYHOx2rtMpC9cFaS62t2vdiFwHtNFEba1vUDra2zGVBDrCO8Fs9bnKJMd5wn/LeBIm98H4lJbQvpBdDpKdBRhrOC/NJmm11EjjTWOdHj09x2JoKY3esNtMSt4WoG8ZkYMysGY08ILHeYar2j1N5xntHVZkYbwDqakutJiAnC5UFru4EPazTa6mEqQPM/eA7SqJ6QWUGw5mX6M+g4U3RERkNZRjPniFNW87/3NwG9LNY6lWmYu/EppFVqrxlXm27vpG20zjPWZszaaeJkcCuxMADpZ06ztKHEBUzODWJQrWpenen8zI+LTRuWTG2oTZhcTlx8lvabyGgiATHHqVnrNspY4XflDq6f87Vh8M0a6DB2DkuI8d3B67eI6a14RAtDb+ZUr8EqTyeiVcbcTFqogZA7OZZfEcky1udax5D/AFFs4uveLqUpad4IdjOOsdXWZbpLbzxGW81rIVYatdRNaVxkeYpjETBSWOjC/KwlY06+IRs+77woAdCobSjqQvDGpq7y9r9JjNlQ4vLGdF0XPsqjVpauGS7F1TieZdCXwzw/HdxA7VqOUshf02nMVmxgjsnaGa/5h1udpSquWpFXUvgze3eQi+GhP3vMJjLdu32lAGeXMMHpC0mNbzFSH9g9Me4SrDfWUb85hxV3rM6kul7MN6ilqwMIcBiN0RNzpDVMWGptLyMmviIzUQvOQVSh3++O1HivaLXS0fmOR0dSRcQMoNvlhnt0OHTrFnDOowFAyyzCqCEJ1HKlH/OJZUGd6bdZWg+KLOx31vxFBMVTGIelTXkxaE7AcOT0w7hw3hZsfvpF8UOEa0I2m0xdXZiGGUOdm+mmY0wBsLxEdzQmTfG8SWzrGtl9tBEgiYZi2/aTCu1CjiYRGg7EPm2u7gnbGPiVvzu0YJwJ1zCEwJFH4K7mawVDSCLoHujT5Hiha76EpgM17x27s4ixDdPvFFavZ7TLj8dLnwf3mfYR9M5VWz4JSNXv3lEpte8EkPCshLVl/D62+f8AuehpU/GfvBeDSLBC66KlwDlm6xEw3HNzW+kqXpFNld3QYMzFWiClYPPohtjaDDcPvDBzNR8sY/3ZnDODetonYGkYXIeNIRu7evxtK2J5lu8G0ZXk091+JbwC+3smsqwzoNziBV7OKl1WfO2G0OS/6BFQ8LLBEQgAjx5HUg5d23m8/wCxa6cUbarXpFtO59lGnJSy9uIpWBtPzFotVS4eqYT2lOtxeNPci6C/XacBZOb1lFaG10wS8c4IK7IxXfEybZNF4iNre5jxLQcRPEJByRcQLmd6JooGQZE9U2hhcPh6zZKR+U0WujfeVF3MbJ7k/e8Qj04GtQu8Kawk+MjGbU/OjcMb6HxYa/TajBlgVtcCEs2p2CoPHUnDyZ3j2/8AP1Y8fV9yF3n19jx0dxiO8scN+CafX0T7D6C42VXzjLiSoGMzCyvRY7bRc4MTW4U3mgFRqmeICkzj6WkWpsGFECwiZ0IH1bwFBfSvS1sKisVrOhIXmX4Zj2Q3zDT04nFykDLwdXb/AKTZSTIHzLg9g6JD0od1zKU1Gc8QYKLU/apm047nvxECprY9LgSpYz5ScMt0NQm/H8pVq/XEDprY4ZY3f4GJTuBGgZnKKIYAK8R3VGcXtAcf1LlGQ4MSpRamg0l94WDM0tS4UaE0ihT5n+QRA4O0Qv3pjvvk/R8elArO0zYORvwTDsow7fNfZjUeNXnEwPAHiIugfsnxUPX19T8S9BhJKbmuCE/eIov2Ofj0wnZQ9Gd6X+J+h5l1sEAXzemZWf1XjiVHVWfx6UrVfMCaabDbKW1DfpBN+PR2g41XzMiW7esbXRrllZXFaRVX72zPnxp+CWDpG0rSIFo52ha/4aRbHqGbG90TCL8MZ+YkzUaRaRlvPyy+vkW1e0qQ/wCkgvUS3gLTy7Rxc0o0gDMHDcpPo7eKKAFktFQL1/RcYCoLbi/EQQa4CHeF2BLC55gZUIOgcdYABemvtAsDgLPmP6uXP2My/U/4xoHdgzLrJ0YRg9Ls+YCVt8ZUIptoHiZbWDDG0HCHgGK1CVXWXyIhesdZjnFGadQMSRdxiADKIgnUL4g9XLWSlBsZ0mtu2NyjSvJNpzBQcffaWf1SefQgnpFjxlknmSXyLQQNsfoQ8jh7ejRGLiNs7w9SU1hjtmB4i9774iADqOk+PgmuoIK00kcMV+TpcYHDD4iu84lLQN/M0WdUDGBw9K6oJtT10jA0J4PvPujxa5czRS50J+cI9odg2Mq4ASrRjaoMnBq4lq4vW1L4gGAzMLWCjEqZr5NxMMENuzCioOV/gRgd5dB2P+rRxrAaCje5RdbWoWO73iN0yf79pUbLvZ06nPSVLXk5PZtFbr0E0hRhdfE3VtqpUaVshxS5JQ0nu95X33ekqNi9Ej2nNUz7ylO3s+8eMRjUJRhK6sXFywVtMLl2g6ypRyNyuX0WpLOrCdIHh37PSBQ0LuMFFFx09KuhW+srnEDZptTzxA9LTGCdQjxC1fel7zm9wT76C+1hfGempm89uT3PQSDsFMqwu1NvQhm2HxCBDse8AMXwuVFhsYh6jVibttYgfDplmix7sJwPBiK2r39bYBcrlOwEdyvZIQDfOrAlKzFLw1YRO+GAYJoqOuWIGSukrOlopSDu8sDVAhysASoU6r9Kil3fWdAmyYprOnyAaH/Yq52A72nne+ib4MoiFgXe90VEqgtzh9xGms0tfEUojL9olQVmsKAOHWh/hAMrRTFM47ShC9phCCucYmOogO2LjP5JXCTlYZVQzqfxMyD9MnzPFAcpeVa3yPclPzAtVZlQFQze03qEnnQh/VTNGbGplt1mIpdbTUHem0WsPNTQ/awwWuq5jVhFrvfneDBuzvPu49ZRuDNxM34Ew5FlNxvybITLf3OzMd4IKP3XtN1OnDQJ3mEU5cnplnidsJlcxcw3EUMsayeuB8zDenXb4lredMIFrc0t+YERqpr3fpVCdkYPglnjdlFXK+jmbsRKtK7BOyZozKygdIBBe3VXtKtRGDWMkF9w/wDwAFCyPn4JS1w1i2EwemcNx11FwfwiGC3j+hml3bhI3VuRHZhNKLfCRyrkUbKOYg2/sWTBMdtfaMA5Rx6Xl3niI2ptd6JbkdMk9qC6ZTUY5Zuap+Ic/A0zxNbNQLF61cEFEl0fn0azLmK2l7RrHo3DEbQvaAoXLrFabsSOstuLllm0ajtLlqS2uJWILolLzpL4mcTJ7bYxPzoqfFzKNGT1aPiXSnIR2FzS66syV6CaDq7lmn5xeJfoiAV4JTV+6lX7vy+x2iqJWiFR08e6Z74clCR0/wDgxaJWG3yBBMTcvePZd6pm+yGXUxc+/n2BtAnDGUEkcyU45hot27D0DMOj7Y+01LC8dZUvZAl6I1xMa9UiBehmOLms61eczQZ5mP8AhZkktVXMIGnHFC1AejcC4cKmafBiak+f0sf0cgbXYCEXgdI6I+J13tOyVNyXH7RXHoNcmILZwguTHc7xKBv5xNDRU9Y6Sm+xSt+RHwQigqjtMFmd1TM30H8JarwVgr7y757KXlA4wjlu936BbxsErYSH3YuKC4DtA6dG/ZCK7Jv+EVTYt/4QAKD/AOGJvjGCZrnq8RFTuMRyujN4PE0+Ly8dePKvgJzbJyVoPz6MBjhzN9/ZtGYA7hE81tidMwJLN25j3mKXkZPePoY0Y+ZbAmw/nFEoTW1FPbGpV+6b+8+RWfscUnwrIwf86Lh7yvvL194TGoONm4rt9oFWv6xpqZTBKwQk6q+IujT6QZTFjSJv2Z5nHuX3SlMnQxzA+AlxpU+Yxg+EFJAzyfEqKK8CzQHgE4T9OIvR2Lfefce/CNWv1XBVCYriDqZcyHp8zr696h2g4X9950OJu8wN6gk0ZYgha2x7mMpt7f54ZXUwz/8AEoMCLO9mPCZnMtol0IE8l+MfGc7R5gICj6W8OphCtjnV7Rhq74VA4RulJtPPN0Qpn9tEqoSxHpQKO3O92lK98hXs940UFPphSJV+hwmiPzD+ymg+7NGkf4Z0z2m4sDx7MU6E7Rhzekf7X00tQ9+Kar39WvQIHeDrHYihgODnUIdWL5irMwp4QBHgMqqUL2QCqkHQzBQoNpyl4MGh/jM6OpoeIAoK/wDmBN7wYLovL7yttbaxfZ0lagva4r5jGJgzADna8REhxPh1CESx6NUWJIxqQd0GfhKAyGtwUgvg9D5idLb2e0UoXBqDSWxrTKJcsax6MxsSo5Mq3CoXmMo1e0s7Vih1Ru536u8uIIxDVnXp6Zbr8Q8s8WR/L0FIV2J4vu+aTXVWjngiGP6946/Fz0NALnAErtfy+JWrbjlizRQuVDp9Z/qaclbxn3x2+6Zf/nWAk6w78sTAI+dYy1GrXBpT2hPTGh2gNkmrL2Qhd4GY4nFJXja0rXvNCunrHxHBh51V5JvvXRXWHMFEtXoZGW75gaMIaeZyI7d940qowQc44TzKrS3M0JW2EzF4oapUGi6/D2zigcAdiWRJ2JpK+kat9Thc1aozr6PoB8ZBMSOtMaGygT7pdZjsO1TCZ/Stxcc4GK0SpWCOn/0KCUlkC2/Tqe0t3Z33vCYbMN2Sx9qCGEm2sQZZDaipVaxuzlk2jUtCo3fUTqgr1HcmAsMYYftUwigV5ItNlngd4BPJWGqZWubwzOQnQo8yLLzGGTJpELTHVpUKO2OAg4KugSpbcqMSd8PKzu/FFgVPAPHoUQtALmFU+SDFOFPygNbBu2PMqnUGDtzLZiq9sIKABsf/AE2UHNh7zIi+LxLskBhULhvoy7q+cLTrZKjFNBauV4m3OQMqxp5pgV0TPklqHRrc1Ss1USi4w7Spt1zrS6rbjDrNRpiDUGGfB9okxh/ShAvLpHhjwCPEJcdBMen8nvKFzuHzFJC80XSC46Z0vBA2zHg7aIAaf/VUyTECdg1grHBvDgHyeUvXGOLU0ciZlL4Tvw4Vi2nffzEDXYE1N7ckEQLVUG07uI1OQ4XxouxriWQkw34orkYrvojVFuhpmR7bgI3iCXpsSj6GwnMBaNalU9pZSGajz9kTPv8A+vR9GbeF8ODb7w2rbEq4JYEzdyS/Z9jiwnQwqUstxA6ulqPMpTXX9Mxl9/v4lshzs9n0JP8AiO8wqDTblCHgXdg1K/Tt9BrU0CPuLuuYPKGOfNLe9yzJ3vVp2lc3Lfb2P/s0nJ68PciNp7UaB1GZglr1Jee6DyRsUmjNIw9JRLvaPMxoPdEuzem+Y2taIAg++i22yilXLs7cs+0sNUi92P7TAAbml9I0KX6H/wBvla++5A9nbnvLlUqNiX6aXmbnGjlRm4YeiHvXte0fPbdhLM032PM2w19DtKX8B6kuZwNPzQLwfQ4Pj/7oBSWRDcs/ymsQVwsHCUKHIzddatJeKusYbamgQ7WaoPzHomTRO0AWaqOrniUOA4J78wIIGx/96F828WI6YanclpVXgOJTinA9YdsH3doY5Q29EKWHWpK+fnf8SiP/APgK9PmNO4jj12KrPmEGRMoAlfYuZXqqK/i//gh9CyNASOl8QAUFH/8Ayz//xAAuEAEAAgICAgICAQMFAQEBAQEBABEhMUFRYXGBkRChsVDB0SBg4fDxMEBwoLD/2gAIAQEAAT8Q/wD9jFkslkR4R6cfzUQNwnjS+0x3/vVQ3EdmdknSpQwY1Ohl0k5Yopbx4Fm2FoYrDZOxzUGFbJe6mMFUv0mTwjFruNJaCcdqq8sJ1WCxbISjikHkgdhmal/DFbU9k0xgmkZf+6NoI0BasToEeOkZsqFWvPMWYjby1hiY0RxSDL4c/h/ttZ8xSp79Mc4vqWmvUB+Ea0FJQ2/w+54+0nM/szEvTmAJRP4rvVKRBU5n8Fmd9Av5CbGaZwGwYzRJqTBHT/uDZgjwtx41iKXYF14Yl2GoqN6GReWfVnF6OcNIJ6rtuVBi4xRn1iLEexnI2YVG9ZHEdW702U/xb/hd5Cv4Rws9zH2Pv8X6X9qaE5P+xLlH0s/glKpWtztn6sRNgnsiKSXFrT7UlThHChPB8MrjswMoS5wxBR9nmIhdNfiquJHqQwtSM2p7mgR/21shNRmPsIDNbiw3jKyIPcoOIqvcBuF2Y8OsjLTXtf0SnNXdrhSKuULXxLovgzNhFdpuGhKmdVXkYhT7MTsWrmU6BMZFfqPjLs+wTr+0OcT2o8MV4n/tz/tMB3FHcNmidS/2iRgpKUzfEEi3e4BMm9xC34YmWz1hFATEbv6cLxUcHWgjKxEnI1EBPO1J7M5bKA7BQzLKo33mYJHeSI2NpJZPLxB9X8pqNoJYj/tQC1J2yL1dXolmeeCDCwh8n97OqOMoXkGbViUujqajOFRnXtiTxfzA6GXM2yQ4KCgz3iJz9zNSjrCWK75cdhPtlfg/J/pSPUTsKANqxJ6bAtXqbIM9N3wJEW38kQLBNMFsD01Fj4pTWsdG5SFdqmA17iCBFdg1HpG1FYhXEHrDfRGcbEI+KD2MIp65UTw1eLhvK8xln3SgYA2kYSg2rUESx/2eTaxllXlg5a6uLznYB+5cA+jH7o26f/W4meMrkvtZfWWpVCk33cd7bg/ZDghyMjD57stljQoUgnaTBA7Lj6hVeXVsBRfOvEAwai1YstwxuRfSiIoiPX5sBhacYhw9YAIteQKoetFs9ek/T+4sSD+3P/XR6pPZKlQeciNCpVmLqWuk+kl3+29+2NszrWSowHN9NiVLeCSz77mo9mXcvD/afwmKYdY/3KQ8rXi9G9hhzeNTvs5+oo7l/Yli1ggTvhsvhgLm15gBXikyEFaTIwXcyjWQTuHSvyQezf8AZfI2y0MBkUxiB+0JcR/PNXibH7+gRImC3hMwebdCzcTA7ApI98fAQwXEXRPaucxS6sCAABfBG7X5SiZm17bZShR0KilX/wAxKXBeMCYH4RkizYUkuWieyThUhejbC1gAEVrs2EEqkJburshNkKR0kHyRTvAI61ZEZXv24Roogd0uGU+nl3qDbhes/jghjWAvMf3WSCTkW5GCW6ZD0SWuRBAAPREgl7DDwC2dWLghK5RZDVBHaaQ7GoEPwCWdoSuAfAhyhd2TcvfORQfrBpRHYyljI5iABPPEXmNzbr6KKeSXZ1cwA0U9MH5On/Y427eiPG7OOSYU8u9hZzH3qIMpeWK4JVaTmdF0OvmdnTjFuPGgi4/X6AIkDOdv1au3aG41CgaYplVVF/Qhg66pa6cjz5zHiy7DAw9aw8Qlrc9L9NzPOt6uV5lse8IgXBG4xCnQuzSohcJplImBfojAaRnzBCBP8aoVlBJE6QI/Cy9Vs7omYLqNjT/wS/E22pE1bBrzPGRfqUcz9FzPwxnM5zFbLdJGlPKLcQhctz/bIOImxo5cLkyHxGJoyfcQU4gHtlXRF3QlrrGH1Hf9qzZdX+QDy0lMRQh/3uW7gpCeb6CqfI4tAeMfuhCi5UHsZyzQQPqL933F+HNq11pt5iVl8L3GaD4c/wCww7WYHRA9taKCBhNnGfEHgaHoS7RupUlvYzJoLIM2TZiE+dl2RONvuNnG1bYmoGTTfDCtDgqo+TJR3ABRoAiYX5KCe30diRG7WNKQqZOy1Ccor/jFBbpO8ZddrCfqXr1F29iw1s0EuqYs8ZzLPUEPnmfUt5rJdwe1R9fiUtf9jiC08oBHP88cCuiHhQ3RIvbvwgXdngJdW1NzOcwfEIwS1EWaY7hl/axhK0b+HMVztPonFgp7xShpy1g0rQEjH74rKjI4fxU4hUN0qoUdw6l+3Mfo4E+NyQ9emGVSi0SO/L0h4Z7j2vpRtGQCse0wSgBl/X1AtghBfmUCH5XLtGi7PIkctjGxWpyPh4qGu7fre4ODZcGPznArV6JUR8FofEGCdUAWsehru1T9R5uRHSbIFDG10YSrmnswYr4IvsXGs6disEF+aVLINYgVAV9dReGH/c7OyIxa54ND4ShVl33FHTgD9TBUKg0dwB6nTJ0BP7xLWpudyS+hLW6RamPgzqMygr/oNRntaCpTMGEpq6gN4TiHiEwbrCFGFSjxH6IC9S/DfctmAsiPyk4Kp/qLRw12bQ6qze2RANs9wxBz8KWEJZ+2YQfDB6JyIB9RQ22go7mDICNr2gtP2sOXgJDVJpZh06jwFPJDBXpkLUTc3D8kPwmTMeCaD9BjFNJQSz7yri8oRFhkw3QgyjVR5miyuSyASz+uKFh0eZTmUh1vOuiGzsMRwssRXtg7LePPO6zSHxJgbWBUBNVwFbB6NEy3C/0J9mK5FU4CcQOznPcCQg6ALzvFAYiBfc5KfEShmIlJ4Ze0BBROBWHdazFhKTFjLUifDB077ghlir+jFisiqOP3uUrJUfmFsqA7IMCKBE5GXcwBV1xN9Wh9lxursnsiD10bDmoYwSzSKpUWm/lsLgSk+iOv4oSS+UQ0noz3LGxXgsNh+7nv2kXDG4k1oUc9hClbc5bU5lpPq7ZWp4ItzS97hGRVT6FRvKEfRE41D24ujZcEKxukPLKILhB6vqWVXF+wWEPdhNJVbclqpwnPcg1m8PuXzRLABOxKY2VIO8j/AMLE16GHFPjzJtn4PTD6Znz6KUDrGP8AZmaMFSh5KjWM9IQJ/W1bZ5Y97s8DUUe1A48Q4I+6QJjBsclOJPDnSr4RzEjJo4PRABHoQ5b8l1o94kaOuKAlJYSxDpFjvMm+oh9hD7g3t7jC9IjLIj2TcDxGlELCETjTCVvcm6l9Bhpu03hQC2w95w7Bakov/vJhF/gP20gNbMHfCw4DaNIy6ivtuoUX9zavxBcRWARJcUjtQmkH0WD25Z4pvngOgioh3A9EbCBctYVWOwcqjU8bagn6uIANj0JV4Mx5wDWUVesoS+7+cszDZiYIeVP1FLCbYAfWzR2H0LgKsvfJb4sxV7CC6gBaeiZavxRYRqnhgc9dC5kRO31ONHqaZNFgGDAYJRZ3m0UaeMChFWrhuGr/AAb4ib5izl8QMgaXj+2xY4u48VoprCRnkRTKFoLjxOlY/rZIn/OGHCxulEfcp72p0LmBz6hrp0xgpmhi3dS8P+ZiegcrCMZBH2chDhsQ6O46QtXNDTAxFb1jqmPhdJSgoCglRccvXE/kB7wyqAa8qp0RXdYB4YxeDHzBH07O8+TTL9RuNU1GjolEABTt2y7tgfUn1hH0KiulPx4zUY88XmYF612Z2DeVHUfZCltF2MaAXnX2oiQCWAA9UQaBhmz4Ez9JCNB9HftgUsvwjXANfRxErNECJUW16IBDggZV3FZooB9UiJnxZgeRdeYl2kTIjSMMHsBjNJOpl3akhI8PvCjnIZ6Ljhb+nWMou9etZYtwKzdjKPTFdcIXuBwr9Q8Cy37RhhMCfBBCqQfdFbrcB8jqPaAsqD/ZPLD+FA0BNpOKaUlItxHqV57w8MLpN6MskPMQpM2B3HpMkb4oo2rPsWShlv2wIHYRqvGB1of1sDrCmZ61W+g0vqU7G7JDCAaWBrhqIAs7XiB027Q+87sDHzO4s6BBCOPULdc4SGxlpfyzKQVWqpLITFp6+m7joPZHE8bagQztlYH7wM4YSalARGvNlZC6CpaUxAo7SEZhXQTK/a9rtlxedWPYCEVWKWy4NiyUFoF9E4jfyCcU9o2EvcpgbciM+Wz+yUMDipKtPECtzDoumdn3lExudxEhkIJNIqOKiv2CdhjEjMFqWK2jEehG8ildM/DsP+gweoDrK+uVr4cAuKXvPlXDYLMEdUoal3zY6csPfAvk5FjDi3lfDCAd32ls80s2ZSeuZ9PGUt37jKq04dogoEiOYdiQYyrKdkPsJjkNX+Qz9oJVAAdB/WlAVmCtqLWyzycMWAAoT78cQ1nQvgi4MppUTUSWHEptnSVSCWLSfSY6mPzLlCVLoI410xnxOHn0YAdAi605eSZbSvyXFNVNC+SFBH5UNvooGI4sHlfQlsz4UmqSbYU9qL7YLRy8y6W7uXK0846fctiV5EnwM1UyEcourmYej88ffLFYe/Uk8wb+8Ij+ZL/l+Kf50D19qHL9iF38c8n44xnx5/uOZ/PeT9VMQqrvgbKDjzF5C9NRlvfrlWpA2yXh7tS/cpRl+JZsELoHkGUgbsY3TChN82ws0AR2cwHZ4umY1Dd+lA9Q1QQFmGUM2uAhgiQrpDT6iKCgxZ7mbe1gFsjQoNBRLQ7j4r6GNp0OeYzuPIznkVn/ABMhbLuBenwGyCQ2LbduKsu0UHrccwWu4aVY/wBYsC9EuuOkC3m3PWRvaYsbmhbqsXt7ZeU8uh7ZU1WlrgqPsmyCRy5D7MIiiMELZPlLuP8AZOqNgQdjP+Th/ENK9K+CA/s8oQEn0vvJZDJ9os6S/oR+nXeZfnoEUwQgQu7qg+WBGftUyElETw7lIccR7quQdB7jaA3igiI6CEfK3lH8Lf8AW6BrpQDVn/wET9pWQ6f6SsZmA7mn9Up2y7jBi6b/ALaXHSMeVnjl5iFmrtCKudcQF6uOnGJFoyqe3xDBzSQur3gqkFLqp+1CNqALVl1o+bHSwthRlb+SeJjzKpKH8JCsq7ISnRvUcvtfcVcspWIQsIlqPB7Y0Y+SESXonFczjsxscGUmE14emMW2ueEuZvk/q2yI30RSosLt1AOHneS482tErlaEo+CDVPke/FBYVpjj8+4yIjnFEBW3ZUxihTKxYZTmuYtApStqWZ5xspyeLPNyjX+rSNrUjAmpSurnJEIdETF13Bu7Hl3CUBBKAhi90v2MNgfDbFVqaGs9X9hl/wBDuMQP/jx0rdqWX/rr/S8sBHbCF3A9/wDpcYFPzxRU9BJz4DKKVdRrc7bcivd+QRiwRJiVqE3BLM8REh4MKPDGPAd8DqLiN9eJZlS3sEhRkhb14BQiUQCOkjKzk8e48wmhFVzcetabcNOrtvlPu6YjaAFyVqIyHv3iSWaKMrv3iCyobKT+phLVEAv5xhW/UJ0csefoXkmgGjnCtktSCLix47ZX+rB34jwS8bziwwvgUPQggbDXMEt4XiIg4FpKd17MYtOo0Ko6JQ6C+56ISgrrnfBmYrY1PQwQbe04BiWtRef7ljVTredx7ZydE8cQAzHwGg9FCha5cvt/0VkIsHBfxWYFsVglDwbYyIpGk/0n+S0bBHQ+UVGoNjykjwJ8QTmHeyhevkEdBSNP5D8AKXY4EfyaAv8ApYKbmeNS+r5vBg5qybHfwpIefwOGhW8lp0GaJxFjES5KgBRM3FdhU7BuIKpTDBLfgX7FirY/sIMt3e0WCbQL+4eAkxQVt4ghbDjcS7JzG18/M3i20KcRAtRKvhMFg2LqA5vdyqnMbAeMO+1rpA6i0iHhI/1BgmCJ9cSHjp/z5dJQ6g+Ik4OParFP839yZxx+nhUKZS2WsfiFQA6IMY9uBBLabjtG4xRyLxCEydEyNeaCKHzOuWIp1ggheN40KAzK9MZk1whKfmvcnSEyrFiFzoJ/7KFpA22Sx9VAuVCpkshR9x4lsIZv9zHdXJ4/0NLuNPoV0wuUfQeya7hoRhhL5FAQTWsdy5/ATX4rZp9IoJLHlwfyMYxvPuBP9BV1tFSe4yNhuIBH8CSvliInfFZErXBQCxGJ7MrluphEzlhMWHkDAg0x724lAe3NxhnpEyA8BFE0MkWoMbNCUKlOuH1BVU0QYN/SdM8wOr19MLTLvI9nZKC+FUGQ4iOzVvzKoL6jlsyfUL89Q4r+nLQstbeVHgiVDT0kt4lVWvuXUaysv6JcXK7AlRAODesy3NuuzLfykaj0p/ewWjgjkhDA2xdOKdjiX22VVfMdoFmmj2x8ERgNJjAVWgF3Kyj8ckeJNrFrPSxx+vhks09ToECqlx9C3iEOYBizQFfthwegmeiuxuJ7evnr+McbL4Qv0/gQC2bbGMRVD9pID27e6hEC0cuetdxIi1u/4gnAbLTrtWAriNghYJ6YgcwV5+AmdwulBLyoQtw7c0DuFt/Cbqw3BI4Tr56GA0VLFgqo5uAjkxzxVKypWkUvatDq7QgLoinbNwN097vERt9T0esMC7hinolW77qsFqwrZgoQ4TiV+ANMIQnMvKdYPONsmzMP6IiW8ckeyFoh0cy3EPa3BG0OJYwurj6GqlaZDshtkXSRFyR1fEehbeGM1YuGPlmuc3G+YoXMha+XuMS3BMpKuWs8MzsVbxeA3BAgDuhshhhelyv9PBIuo9hjJXXU4rO4y4PYIh8jGlfyrLmnaSmXpi5G1lv3CmPyga0Wst8Qq6fRQeSOwHThxUV5zwcSoABzzAZbe0UIk4dAYxDUl9lbDywWtMtZ6ng8v7EN5Xbg9H4qAunI4OGZLN1jKK8EHkzDUD+N3xASWCyWmytNX6QaMJTWhr08MX5zEyULYKCY6mKlxIOZf5GcDU3a3GIOqTuhAKb1xFTeZe3Uqt2W8EosE50T2nMb4XIPgSZxc1hIKUh3YkFaduILJbNQRKRLO8rib3iaFTrKI517T+CCkbH8N5qAvB5eyO2M0KsAsobKcuE6a/r2wGAFFBfn1CMIrHRNA4E3iUOCS5YmxLpxX5r8ETt23v3EJypQbi+FNiivZMAeu04prfPNTK1LkDuKQWzSbu21DyvwWyqf2b32gJMe7PKLNcsqKetqv5JVm5YWPTqUm3ohYuNqJIUjPd7/AIoWlEN872/1DU40Ybww+p6KwPWoeVKCH24yS0p4C5e9Zlf9SGUMWoRGs7sj3BtW+ElO4bzS6yurW9MF4x4loYCZlRVq8RlPHGqHmBR2JGB2I0ccpc9EX8DL3ctsvNTiCWLwYRIUjkaZ2UOQ7I/b2OEXSn2URYWF+RJdDU7WyBbl7hWvTLSwLltPExCdnTDEa6nCZweQOVMp96ixT+dWD+DZZA2BohSMToMSHRXNoeYVF6SmIibVtgJUOOYoPT8EyAV3F8QRfLmcVgLGLWziDpSz3V+U7IoAtWH/AFXG6EV7vdJNCzy2jcJrvJclue/LF18Z6o9QxU4HuVAKIrjtO1C+RCooyJ+EEE/NpDrQrapoe62oYGJSrYDREAGondQ6SD6L/UUCkKRoIXE3F5igdYbrzOFGsFtM3Oui0lBkFEXWhIYQv0E3hwaWLeNR8DnG4ECXgV/U2EN7+lZs8MdarbRoef8ADGbKwVxXfTLfrUi6XtsidHCrZPTAGDnF5DqH+iQEZoHRRCNPhiKmepapxARTlGdMQ8SWlPQLWVNroESYueu6NAqz2BMeFQllkHHitDhYDAlL8iVK/DBN9Lng8kALtS9tflEEgFqymYLb+JIKFcnzNskrasW5iAHMhGkNKRhuCUlEbCtofiyJyW5yHOHO+F6iaVCKaZsCzXIchpwMtpLskP17n/l/oJpZ1haHB+DSIjYmyK9o37oVb+KYuHtVl1Eki0+IfIaimEvhPUkjdPVbt9qYgNrsVqpmkjnzIYklNjjRcMQquPdm2WrqAzqogod25J2hS6f/AEahrahsYPwxkO9gpIbUQ4jQBoYXEz3SIG0UbhUraAv1GXDZjNLke04izJ7bv3hXMkVU5A3GIjS1VdVoZS5bMBeXXxEwlytp2nK/1deiPE+nJK9GpZ/HiEQtn14bBcv94R4jHXYiRLG+wYsLrQxwCg/EYC1hZfgbPcZIrYPcY49eOR8xZCG1VrEWZJF4NXBOun3UtOT0RDvEqJT+BjUc+6StYCNluOmEbkvFVp1HKOAh7zAN3GLgbGU4v8H4M0VAfxQh3ztAgSPnzZxgQJohcCxZsjewbY7YuQthxcEnMcfpBvhiP+lkaUAa8sfSeLf2oUL2kf8Aae0DMu31BKTNzq2xLlLnc+T5gz1vhyoqxxG2tVud3qOrEskeEaK8LiGPJi9/jhaXSUxvg8wQp8XKkdrOzCvcRUQI0jK1AwIXHZ0h4YTgF9ymiLH7RM5uHpH6YSpdQ0MvaQmNdt25V4lVCcqyntf60gtFo0RDgryswxAiymjiXPr+CB0BR9oHF1Cpn6SKljwBGXCgFR4GIt8qVP7XUvO4BvzReC1qWv4KorCTsHUXtZXLPcsD5xO5mrrxcLBasOYbGUvkJA8rNOPkItilEAAsjyzBsd1DIcS7bZ0dV8XJi7KW6/Jdz4WN6UTFLdb+kXeIS8ALzepU1XYz+bYnnn5TafXOg+YM/wDXSrv8f3EW+Ik+eBBDlZa0bFETD1SGLMXAyPU/kjY+PPtb81f79DGg7e3jv/iLU/AmJiWh7P2eCLNZXwgiwr6yZFGC23/ooZPTW70y4rRhHGoGwnRV4QwxAtUdFKXfuNTVcHsHZKICU8DgeE/A5q8Qi+MOUOZUmtz1TEL+Z5+DwaPDZD+A7GF8Ae1uLe1OL4iLOp9iQbiWkqFoqo3rGJVUJteyjYVBr+tm4F0+qoV0ACHEqTC13yxEGiAWgeGJVUJnPJNkislcptS1lRI3aEwKPISlunuG4jlc0EkHyuyKh3ajHplFrsJYBSr3F9ImpbVRkNVuBhrBl5KtZUa1TAO8wi+5Wx/xLOR374VUkg8BDPyyHdkW4LyE+I8KZ1RKk0wz/FHX4gyW5JBVbuUmqyinMVgms5mmMRrgRGRXiEEy6YLKAQfMzgqcIpAMKtCmh97BorFAUSrpoe2XCZ68cUFlrXp/yxyR4ArrGYViCXd2KHLT3yzaQEtjiUiybjAiQGuVxe6p0yyJFtgBpnKZMwwq8jDMCWptU8ekaUutrX4D9ojKFlc9+5iXR9nMfwMBdfjluAoBvRVs8ZTs96a+EZJznrqbTwT/ADQ4TmLZOIYjcKoVO2G/1v8AnSCL2fdF+hLipdfBzUg8rhcDLFr2saY+f2bli5P74PRFtcE+OvmdFVlKEVLz08B1EzYmPLpML1E3+tMYguIFJ6PYkMfstr1TRulKSsTcGJHOZC+XlxdFEytU33LCIDEMSAR4hfgRiUJPtmbbUN20qoq7o6fnQLBKSYkX+MBsPsUjJebfpyoTNjxuS3XLLIueIq4VBedqI9iokZkQVYHJlggTObySHaXkHNJ0FSfh7meXuXagqHL4BGU4tuv34K/wA1iFNJIHbyLysGwk7lossOB9M+eWjGhd0a+YwWQfkM4BzKOau4xcfDj5khtAOP8A9HZFfwN/fg5gxyuHFqI3g3ANvUVvP0/+BKvbBLLIChZgr/ZjG7V/ycTUAu8m9pBeDahZJh76384CxaDQRVeCoTbi+HQHwlWDVFVer/rd3qRej8WkpdvLBeA0bCEQLDMtu1H/AB7GPvzEyeZTqUAxQWJeAKJLcYKzTyZgb3wzdVvmUJrUxsRLQ/NZ0JtjkYSOLq8EqNHhE+DLpWQJgg7kqNHiu5vcmUp4L8kAEXAu1QrHyZWG/RBs/H6743FR+UGKGjEIIiPjpIupS+OVyA0bZci+6HDRv8yI2fUuwSgSqmxxWSA8+CG0B0zdKXtUtfMcLA5LTUao5q0lqGeAmC9VUG0V9SA84FAThLyyOdwt63uQy/K1StYqdkcWhtPJEUlGhbeCWM2+3w4SqwsdcjH/AKGRt319ihml804EeJBuvsNDko9toV/Q6OmOPqZsXf3zDUlfJ8UNrXR3NZVWocy3iup/deheARUVSa+D+O3BUKFxXWSyx848LDQXp5IADSAqtZd3io49dSpqCsj9P9bznJNEIruNAYS/IjLGqeHF/wB0q4qOKAftj+7MZBwCBgCRMwwWiWni9zNTOeKGT6ZdG8mWYzU5BieGimuVQfas/wA6Aoypn1mMLVM8faFic+GT0ktiWEodW+4gCK0AJOe0Z07qkcDyzJw0HcnsGzotqG61fO7Ti+UutPNRTXUVf9pron2dxQd/8bz/AC/FBxQBvwQgZUw6Ywo4P4qBQogwbu+Jb+W1UsZJm6nZWgY1xL2EvUovTyy4hE7FQN66fnBPClY4ZVAFTDc1fJmRhCHt/WizCQo5bwETBbilq7HcI457nHkIlmkudgMVdzW3OmfthfWOwQXEeYGTyPwQI1SLz3MG6/lm+Rbhn7SBAQbB0lYdyI7/AKjksRKm4G5xpx7EDu7jmJZM5K+VuFDOT9/1uhdQvYHRBAXkRqcDXu/HiYJpzWGP77Om6lULvl9pAGiJi2laFlTljKLWE3bP5YIUV5Ggns1jEKwGQz7YBrqclYiwULN84eSFgbal1Ndprkkfq+bgFFa2oPu0hWeswSw4ywpXz3L/AOKlmvcLWDhS7qsSBJG29iOQ7IbX7M5cDhlRdb3VAERYK2uE7I18Ykr9d7kP1Tz8M2paxB1ZZC8Ba6I8Fa3KICqCwLsGw7lbgbfIj4VAjWMBLRt+ASXvccHjkNIcMCOgR6SmA+ItSJKb0rw4JvE6tinqHhUHjN8n0OkSArRGf6PCO3Kzu6GU8xatalpe9pYUukBTdehlk7GHZ0/DEeyoZ4sR2nE5W8npN1b8nXBhBjGOShfcdwbg3Z3HcrP/AL+M7CVxwx+piirtro5bOxxtm75FoyV1D+1laDKG4UIR6TZ/W7mdYiIWwr9b4B2o75oZbR61/oXWlNaG1pzmENwGhVxQmzqCXTFpa53ONQbWsS6AZvZELC67uaaw4SVtHxI3YFzCLKfxLcY8keVmBj0DjlPrSocucV5SK0Z6JP0bN6wm66FnFwssmk0LScJLWfuMf6YPQyD35wkG3I1UVIwDaRd+ImMGDmWI1h94mxeb2TwzLdl9JbmmLjEamNubNwgEuo1+AhbkAGVYnh2iilhoDULvZpIIcIJhsrB4PXpjBgULQzCdLw8ody7BSMQl0ItW8S29y/0XS8jA1ZwcH+xLOuR8uULF2Ised4vO3Uv/AEayifZK51hGQiq8qXY/ZikTQq5l6uatigJSjLUcRYtqjDRYTCZLJVsfcGPhk/rZAS5SS3QVOoqECF2U7X4uoKI8qAe1ggU9fz9Yg4Nbbbf4HTd9xtcEHnCxgf0/9UqX2v46I6e2pqMqBEeR7IrKasHx3DA28sjM1vAwZ/FFBnmGSq+ZZ7fxjuUEHK7ndkBcFoYWvaDLpaZPKdzMUcVjk8wZY8OV0eEikWs8EwqTDtecL8cBSJimAC9cy8UsBwRGza5gnWP2wODXDcKixS8hFJpjWgLmcsV7gbQw8Nn4uHPKNamggxUh3zrBu1eIuXQrmfAHy9QyGMmnSP0P4E/ymexjyW9sc/UkJ1C056/yY0WLWNJz8xYqoApo75lpEyeXgm7Xg6/lqj29uufUFyDDx75Z+HxQ5vUuSjVy8xVAHNLEN2pHw/ga/CqRs2hKEPXDjmqCJoNieyUwFD1CRBCzy6RyJaMx/wAxzRgBThzL2qr2t3k/oDVNvUT3A3cR7g5dU9TqVnsgghw3iCcQIrdEHEhLiM1ZniZ4meyeBnjZ4WJVue6eyeyeyeyeyeyVLpcRlxDeNNNHhpDapfeh9BKAGOxZRMxm9YFTOyD4WrfEu9EpjEXL1w8vojnTcqspkZOAETVWvLuAAdLZBpPCCx2abpwzFDZLmzbXUsLqDYjzBM4MxJsC9Ik9KhL5Ub7j4kK0BvWPPTBsMFsIbE7nI1Gj0jXg7bbw9wdLyxqivEjUjKw7gJLMGYMpQy45b3C8G4VbcwFuEuRx1UqOzSgOPLBPdH6JWE0A+mUnOCDT2d0aICZrch8Vo8xA0ih2HoigAIRlaYiyMZ9kvrdH/bSpxA2mhwPDLRPw7/uZRrL7A5Rj2ukrfyxKajb8Z/xNhv8A5X+gdBZbuqN61KEw0ZI2JfW+UCckGL3EiV79xEmJ0oQJsYL4ZdR27EfQYb8w8BRCD4uIiKaviKRDsSu74TE6AUpsNkPVYluXzT2z3z2zxQg05+oJA6o8bPEz3xGu3iWVWrxEkctYmg/Se2J1azwM9kTLbFpwREHgvBKuwmdLsbAmO4J1ae/9A5FZ5giYjUCs7zKoDBxgqDa7QqNRBY434mq7Wf2wO6YHhNLD1C6zUVULLKj1Q708bPDK6TJQQATsRtcrpDonggdJXZPCyhp9ToHt8vonWB4dm9C5WFRW1msGkKeSDok8DnIEEsKpG1i78yueQbiVnQafc7KmEXDZytYtmcF1KVqzuJTctb6i0jbV8xpqFXgGZVa1h23yxpC4uzFwOIc7UNU16ihQScRpeWIihus3+GGFllnZC/jLJb9GCG0kwPXTGruhFmDvUz+IpFDcvBsiuMNliTJ3LOfLx7dgnwwFLYX2vIwsU73Apb6dQEuV5GUWiOSXMurB849w5tUw6/F5vtwXaghQspljfRMkMY4gAbZXmZDQ6z6evct5G+D4IrR9uVwx9nHiO5bcRa1WbQFPK0aQCCgAd9sSojFDbuuDGeshIqqtjccX8IMgYYFWaL+xAJbapbOrijEMND0Tuy8mCnmmuviK8Yuy4kWh2fKZuTBQw4GFnoQG+AiIo7IKEezDBwvLJa9+J6J12VY9nEzOmtCDMkUbcxs0yuyKFAyrCYM0TU/i1oEJmR5nu5TYX2TYRhfUs4lVSz1dRpU0qs3D25dLHgK2isvy6uLRudJlqKFHcetj1KjhidyWeRwkMAa60kJIaOLgQFTfE5R2bIi8sxTB/h/OqiKhC2UKCmNcwmFpfG+4PKvki7lv+vcqZgQk7g3PE+BfOVhw+yJctbiXLdDiByRuRFtpQOY9k1+UsbVkx2HS4hjOIbiqdxStpx4k9l67gvU6nnJg7nkZWYMrgXYfMreIuoMlllZZDiWpC4/3wQ5t2H7xwkum73DzSrVrDF6IaX9ZB5KaPkIYLTWB60IRY3ooxO843FLi3LwauCv+PEvkzuDeCZYx0zs/0kDS3UUbuLR2y8EB5HODw4iV4kR+ej3FUNa7FiUcu/lACVl4ZR7C4/hhwUp1DKZqOIF/g0BUW8Keonb3y0CDfcM4dLUkgvcoroOIMEUsoZQ7Jq+DLRDoKrauVfzWv5KyOXa2jRZT0xSCYl1WL1hH8jcPHtn4LWt3arlLXhb+4YlMu2QUrqKnUtibrB/gmIMiAsMIOBn7QJGXvQ5+yKhB8pEPlX4ICw7riyv1Lex7/wAsNTAZT/LOo9EloOhUYBD/AK/zCVAHJPuDK1tAzQATeGSfCiSwbZrXE6Z7HGlZKBRvuK3W+eKTwmKsB27YMQnpHk6BH/NBgl/69wTKAhnvncpWXmybgZNDk/cblly/yxWvVrJgVDHw+8w1MF1/1ZZ9Yjnfc2aUlyqEEocD81WMA+jib3DRxzHJoj15xQdpLYkawuGI2knT9ceqZuH1S4/F090vHEHmTHEL5ZvdPzSBuGrUtWoDTS3M/A8sbvOnM9TwGlgoseu2cnISqkvSFBK/vbMCjdcqapmQ0RAheVb/AAIXk6l0tEzYOtktoAYUbfoWZ30Cm2vtkoy/kRCy/uhGfxPwN30fwO7z3I3XuRzn7U1c8iXjqdpsa3AgWzgP7RYlsqtlxA1Eii7WpXHcL2BC/p+PlKzNeXPAPpTR+tKgf7znFHsysm9fjX9b6pnKnoRr4I12n/zDvUyMqvFy9KN7iYmVZs0xpspM4Fjtm/xlQtTL+EBY4x/or8Im+ZSQ+J3hrPvEE/FPzUKeC5rwh0TwpVdTnHOckZqzvFPTqciLBZxyZqbfnM8hsLlrASs3ysId1OT8uYegCKt/mKsUH15wUhvsVPj8u425hggHklSpc6VCvTNAP/jaBqK0JB6I4KfqnGGbWiVcu0H46Kf24Nr6pooCcMoBVLnmiWVYiB2j2sf/ADTbpiy47MpCWBaCBdi3SuMXw5Q711FytcYKwlzSbOluFIHdDVROlzBVgkJ7zj0RC5e8R8EoLZLQ8mXgCr+GiBqT3P1e/wDdU7fpRWmZ+/m6P/Zf3oYPVHD699B/Ydm7T5RqfUnr/qg/7akev5ZW0Ptzil9orqcEyB7xO3cUQp1KOn+dNL1D6xLMwp2XFTM8Sr9Tc6HbQIG9AA+CDWAeWWdr6zC6V8R42j0kHL+/xBynBtv0n+QjD/k5tT8/hB7hj+K6U9yoEAl9MUP/ADyv/nn/ANien7oV398h/wCeMmdQYeEphIE6SAibO3RCxGhpjLgLcY4UItVqocb40E8YDyi9CZ2I+VF+6PTgP+TO/wCxFuGDXGBumS4C5mxhzF2uL+UICiInzfwPoRtdfNRgCVtQujGpKI25fgjkAC4ygoG+FGao+RKC1+8CA5QINuT5l10WY4DCCJCsc8+oPj6wy364hEnYiEofun09KjTPySIudQomT3DBoP8AmZSLgl7i2ILjywg0RdksZtq18v5YxMDp8OYYOFpIM0RE6SJiiVe3sifmBfBmFVqvpwwt6rAFoYAVnQ8cjKWyPeWO/wAGCRjGPGLnv4lN13idIHiyG+o0UADoMKmGOYSonKf1LyEt/wB+Yoq2W8yEFvbZLEnGtUDuW9w0Bl4sjV2hGZhvpLakVrRabo8PcQQNxbkrhgahRE3d3M4B2dnJMcimvOyCxNBUvxmA2wFsd2phX6YdQPiCle4cTKvbAHURQPYQcGodcrLU3C+4i6H8s12g4tY21mflqHgVgHoRT2/h0qjFth4HanOCw4fRiAtQiqH8Utwp6gww/wBzSo9xBmsE3A5TP+kjw/pHPUEtNHhWbZQwBCiKpKC18EyRYv0v8I8nywi7j9rI5EqVMsEnV4jV/hwiGJf8EGz3R7gQtiCShVNen8HGRqUOE4FkQBSwcncDwzYNEzjpv5irNbejuH/w4MgH6y8mjxlbX6c5H15W/wBnCyLxEWZNUsN6v78KsFki2kqTch0C0MGnohrLyRQq19E78zRpapx+mc8pNf3o1Ks2OvVweFwhkyftYzUDTqtNAdQqQumTnnPTKnVBVzhVllKloaK7hioAxTQwGzC7iOmNVVQVOcqYylZnnFYwO08BDQYOXTcKtVQeJ6HADBlYll/WHMvENlY5l5c78kW6ZEcoyWGq/wBAZwHPOL2MOIZKvDCrQ7/ek2az6mL9W7nuTFZ+X/MSwaYl9t63K371Arm4bdkQKdojOCIFbhG2W8+6SBhddYZSJoEKIFgb2TUkZwEs7toXgQrp/MLCm+MGqpqvfSxHFusZHwy+cp/ygSWxF3lqoJ6k0gcewTFt5WrydSZus3iin+Jy5XyR4XcC9kch1LpG0UP9yBHGz0GSY5EI8kaApa6wwkgoNB2PUshueahQvD0uGkitp/CGXP1Exzt3HGxC6wypYga8WIagZOZbm6Bm46d+LICK7/4JhavHsRv7UnlivV3wcylaBW+5X9tdDbLx1IlIrHOz6JmLdjP1WH+hgR/0i5yWQMEbC2Sy8kIhXmfFjWMRfrZXjVNeCNlg6mTSRXv7mGEFeKKgMbsD7wg/Mde/xVgF0GoLd1Mts2Sp4cQQeog5XdPjzDlBLFyQa9oGyZxTqS9RKtrA+YK1l2QbUZVfwAcjBo/iCpoGqwruTIusQMDlOYR15W35SW6F8gT4tjZ1cmhhDQG/vCxUBoDr7ZcLs6rC13QUDxgEVLabua8RcuXVildRpVvaFA85lsCu0Mbge8CVDgrQvSOAIugLMbKB7J01RRn1Ho3nBHZcEFNYAbDroyjyvH/DDpAUHZDQVds3BVixlWofHIN4CqPErN7R1uR/pJtq8Hp4lNISVTJBXIL7cvyiYVIwiQYwcUhyMKVWgxWRC4y6e0MraWjrxUZ8aqE9vc3jpFGed+baCGr8TmOLykrDYj1TcZgCog+FYhA0YqsvoTACmAGN5lFMZrBPebATSECovFLECtjT9kxmtYTTtDzRNoZ7PkhjXeQoNstTLtquyK5WCq+SUkAaiK0aO7lWwQLYV4Yc4dl7uALeJsYTWYMjxA95VseJRw05ms5fBaA2dWhjFyPEiQazWAmHuuSQNJoWF2PXFdfpCuG0myLxCv1NCuR/EsUGA2rgIWmg/iSlzLjsYPJiYPfOj1/ooaWbFYZYPZjCI7g0E/JfRNHGkMI3uEPib5/DX4icwvOihZALM98S9abWWZqtPmH4QtdQ0C2rmWC5mVGZD6/FUWKdQqy4TSB9qynAy6pBqlz9SYKysbFukQhtuAQmnMSokUSV0UL+5LUit9sJSWgNZpsvsiylH5vcO6aq2CJVdk9AzCq2uxr0MxGxDVwJyDeGY8GhYZpVVbTyozf3sZmYRJgRoDyiqM9zTIdADGgGUzIzDc4I+Je61A+aDc5Q3PiWzHK/yy7i5xGbti75UaYABysM+fCPXxRVQvQdrogb0WvvIv8AqYg0hThNSlewv2w7PxeUnGD0ZuEu2U5/j8TL7PAMHcApOcXLZpoqEaZW0J8mOWyjPBhNLgjmMTvEYpYre6jkMZCRai2i4YLWvLEKiNFxuy006jCIT0XkggcLeSRXQKLcS+SGUt6b2QOPaWJ6QmQhI0nBzmHyJdB2gyaMaH4byE9DbNlhA7LD4hFUI2DWTJFVt2xh4ohy6SsJYtrm3iEB0IFivaBoDCm6XGz7fT6I/uBND96UTkz6eDBftFcAH2ubwEZQKRtnjGJ0/vm4tEe61EArMUbaPHcreS/0HgMDl6IOSb2uK/ENs/YBNdlXxFi/q5SOgpYHL/DKwR7ZbUeJgSqkHhYl2fjM0/hAuZNa5EV4yY1iqrQ2xG1Q5l5Ep/CQcSjHMtVQWb7We7OWFg4YEuKRonHKSSjdELuyVbUyOx0cQBCFOIC2Q8l808QjYrl6IYABAmmuYio3rzC19P5mb6fvOotsI+BQS0tqZ4uG15RJK3n7nRhEEqOcOwpFRU6ApVSgAldUCs7IeNnFmJbSvRqpROJWmW5sPq3xEpKO56tQ6nNFsYXEqP0YuisLDUqx2PUUBoPdl/NAFWwSnEPW/UWtcz7OwidPS3PLaVrdeBwTJ6I9OM+YyU3dC17ZRs19OT/WQCJYxQ65tP8A0sTOUGj5j3vv9rOsQgUeD3Kblp2cQ8pnj+paHX/5kJlTRen3A18dIIgVNZktP+Wwa1p7i3SIs1Cw/jT2hq7zP+MULcUYyB+yJCV6EH3Ggl8XI5Kc4gkS66MvPtogynk0lHEFVgUlsPEevgAmR9y8Sg8pkaa+Yi4y+0EPbz6Irv8APbK4HuCi7qIhVs8zdSSxwjuVk3rB3v3o1FWW/wCux/r8LsAZS21myNjnjeoOnn8TwZLl1BvmRR4Pxf4FrqO1ikAGrz0EOrsUixus2sxS7mZf4StT01HB9coDSfGCYb3dP9S83JDLMkhJ7dxC94liUufEG+wPtVA1o/RR7cOY7lAisl3e4S1agJ5p9EYwqVRdKr9S4GLKbWMpi0eEqVVk56uFFTbAcJU3csfiUAj1C1RcZRgcRNAHIywmqy7dstcCcq+YxRyFL3GFVpNeJybuQX5T3c2Ji2eEUHuWT4oijD5VYqwjzDOKBerrUrKAaL1/migDmW99C4bZ2EQ1Gm9IMpyfCDiFuHbRWz8VSmjsilcFXPZc+iK4eb3g6HwFMELPMkzg5lZF6KfwkdnKFfzQkwWDeI8LCXe8wKNhoFZuL8n/AEoFAAAFAGiXlLvouawe4Cg/+AKR0jGGldiepLTA294dHFvEbkkad8Qo6qwaiTdqNV2ioXz5n/tQ3ZXlP/an/uMM/wDIyxmj2wW/5mC0/ZBNL+4hArXuALhSzM8n7j/z0YQUlo8R6RC0vJDtzYMxIam71FaV/kjsxjfrQUizkAitbZDg/Aq4zMu05IvqegcrV/dX8RTwROxsoeGFwzm6qF5Sl0uK/C6wunAFRPaP9sI4ogCZCK0K/Fv4KA3b1QoYqeoqiU/6FMplP+m2BdHcpteUA5YH0ZzAXgI17Zc9MYqyuWG3u1bNMyrNGZSvw23Hjz1LyggJVjhgGthstwYOVPCj5WDCDO65n6ohrgkMV4PuG270rqVDU1SrGAcdH9xlqgeGrGUNKWG243hGpeIpI3/OZweDfhoEzs+4f8tHvTzod6Cj/NA4/dP/AEpfJNnUz7QH/NLa7uMy3iCXNHOYy58IgfNU5l9h3jMqTk9xt7LFsZephtlBAmnxE2Tkx7HMpm9VCeuNNzoyi74IsJBoDHrsyrmfa9r/APJBESyZSaqmvUPrXDyFk5wJE9SxQecL1GAZZzGEUY6T5mApLtx3S++H1l7GYafbOqxPTirFf5S8WXTK7/egcZfmKQYvccQ2bNjefEubP7Y3H3wlPE5cnhIphycTUjR+xlRkq7d29vUMtWsLDfn855wDwQ2svMcHSpgE2pTJCVTyDbeUThSzn8KzEYC/RFzwq+ho/HrzBCgnlXklamjYXgfEaLWpYVhuKqHC1rUXcqf9t3BQf9ajCdQ8ZTqesY9JwDSMk2vBYSMwjvCVHEFM7uFsqYh4ms3l/ulgIOE2nfuamo1Xkl6ggGGIfLcdw8Nh75QNFD2Y7WnTtvmu4jiqYe2URQRzL2J6Y2VXPsZ3MLdkclDquVhDQ0dRzKUsYX4RUO+AAc3XxAKv2hHdIRQdeUXGSrbkpa5Zai5dEOCivbhQBOFsJI6BGJgTABw+YKSirBPQke+xOKFqLyxJPHLwf2l3zyhEKiNRvVR+E21LO6mhuDZpdEkoJYMIcB+zjU3TuGkNpvIkTbq+5g/tTCmXbzApiQBT+Pxohu7m1wHuLLiKxKsoIAUp1GNhzo7YzRXeyXLhLSMECHhA0BR/9DOVaMS6Je2bOiEwQcvQNzcsJafC48w0LX5IkbPhj5EWYge/qlVOTxGCodQWLrR+EDH8nRBRTSNCVXBAAOTtgwpBBxysLBXdQI0Mudqjzr8CUZblDSKias2pFwgcnmAItEEzG6YxAXopddxQU130NsxKCHogowDDnmBvEFh2CEXWoXGN5zoeEbDjYDDfD4mkLKJzvyQoloiF4bNpPUv770W/fom5gjhli3peDCCCbQ4Wa6PLKoEaormnBHQHUXmR+49dgfQMOV+b/IcZcDNPR6YuddgD6YsrudhfrIr9XdS/6wZfgQRpIuAylT7upcGS3d+Rm5Qt4onTBUorwGRGKpVLjkhV6ivtD6pOrtvqLtANsKEXXDOn4TvZK3OW0Byly+YsOHYsAbjrkyoLywLdhgbq4Vu1EMopfteorBf9AHBFogKvClTrCQCzxuOLF4WkO7hML8XLRKlbnarRiosNtDlYFmmF1pCPbEnpzvYWLRxzNMUHdRzL4jUZQbosFhljKmyD8EI8hyCAgaqmCty1MatZSnd2VQhUdz7KmA5ghcca4KnpUEFJJilkFjwVwzfj9MSwBNm6hU50vBl4BYu4KwDg4mjRL7CNEHEIUHggKY7/AC//AFRQvBecoAPFFnpgopaLJbYh9eDMAFPSlXORWwME2Qo29vVt4uLRUOg2bUO6RLVsYU8S6h+BNFjDPORl6CAUtB4iTX0hV7L2RpcvQCam0LDKhXFXLsFozGKPjQmLdMsG4BwXfSKfCNv0b0eYcF6ZYcnclfM4gK/5ReWRrQbUNnX5lO9bzr4l+ci+UKpC9FlNSlsOVAFlu9xtUovliEcwleoldO6EZVfombovUC7v9RLSel+F0q7qxygMQD7pNO7hvzXEOt1mx46lFU/DOZfXTy83Dd+ofjf5pPqZk1TjuD6GeGE5fUweTpjC7IzOvKbjrObTZOUwLMsJvrkrz2R4xm6dkTgjxgsVXNo9XqA4tMpXE6AkOwADQGAlgONhZ3IFKruPSC4oM/2PMWaChQeVxEbLVMwRz+aA0BGqZAjCFCgcLE6c4GraMqepXlwU90xZcGzJMUgGL6UREhAMjvPMKCFMBp9TIoZRrphMYa/jvdVAhA74aiLATDBX1GMpyz2rgYu4i5rEWX8UA+Bjxm2g18jyywGjkK7OkKFQ2rbWh6JbB2iq8WW1m4YJ9s4/vgCG+TLB9x4qOsqe+HaM23eEkGY80MlcV4h7qypSBQupYqwR0AFXVwt5SgCELRgpQ4VxHW/5ThCwdq0uWJc3zzut1KFXieuP/qgiMslU+zMfWpWvZnvhSI3WL1zHwCCJwkPEeHJplWvUTh7+YeSEyVmmJTUB1LQXBmnzAKIMpgdIHZ9aVADmDcupBS+r1EiNG0xHslIo/NJFKoRc+kBJcMm5ZIAc3UdL1BQcqp+5rcQoyRWheNQ241UiKcF8wVGwqrD6rTxNZG9FdweYwUrG20dx5JiV+A/a9Eaof3aVl/JMZQMgKnAXc2htitVC5JkriJhRWQyZlw3aVnuCmEwCAfEU3fJlgLz+4UFYGYsPMwVzA2xdnE+pxMhoeDwgbLA39BDygn4y8C6bibDZcaD5ODuFKmS9PsSFZq2EYyXODflGDsbOHsm/D/oUQ2AwiqKW9APEQn4Ah2YYJfwczhHTsm8qBwbqDLjyj9nZM1RWSp2YgCWQdiPbwTpfjt9rliLUpfEWiaIun2RbnJerqNIYVN2nMbKCvQQV83fliA/yaMqUQTZXcEGgoshLegdd7JVMvON4Qgnj8GdqFwtcBXO+YKzkQbvpk8jojxQB3GgjKtC314iPOKD1h+MO4FscGynLHbuJSZtJawaMKH3jNcNQTQObilyeLZkSqiuD5B1EgNcKF+HLzHUmAAuWAQ84WJXS1j4l9cUwTZtOh4l9l5HR4oQTiKAD8Qeo6TdeeypkgCdDK0AxsigBa5dhCYDbeoWFLryhn8xf/U/cFaA2rqI5THEwX0R7QjyqXvDNKmVVayxr0T55inap8nuLLoK+zu41Yc3KVFTYG9be2FsUFFUcqAAKAr/7K2XD5Lf1uHzCd+YOHcE3wStPErYLk4HKhdB5GbE/3GtFiLai9r5mlDmwPiLv8yhwr9catkc8F+Mng+MZm19LFGPhSoFPCtRlAZqKWCbYbjrKeEA4LzA1/wA0BFx6uLI5A6uViqjc101CYGtz/Ghra+CNAb5Qc3YyQZl2VY0sWoeWBBCDUEhQFPqVQC77ldVt44gwuY+bg0WxgIFem0aMLFHtEANtPRiirFILdXGhZFXAoywuudWRwtff4E2c1/zCp9cyoN3+gH2SsIeputQUTE+VKCgX3K5CMWUlIxoGJFqemKNVLTBWFa4P4YUiXn94nlCeEiO6iNhEOEipOQ9WGBlVTASS4UN4qWzn8gi2lTh1EMWD7srHds8qhEv/AGsmtBbbzqLty0fEtFoDoEBc0MMmAjKjJwcyyufhTa5cd7DvwXLLcuT2uYrswyWxBnpERLLiIeURiHJn1CdoMwFFhAhSMW6IVGtiYTW0UKmACNpyw5DVWbdGGmgrlQoQUXcG9NRtMKM404h/vYpAUWqDzRarlVi+dcHbaHuy2/ycRHSiGuesKCOqciWwCf4BysFlB4EQihuE5SlP7i7Rd5Oahpz+Cf8AP/3BEWJSTdgMrv8A4Sqg5Dq+LeJemnP92CZmwIZfgsH1iVT27R42ZeM+IQnHJUfUKiHZUPr8CLZ5BTKFC6pKmWe7w5g0Bey5cBPcbe263pj2lQS6jEKlzoRw6z2MvN0B4VXcbGmfEpABD2ZQ8l6VGilhg/C5NCe4hS/FqgBVHlBwU42wTt4mKvOvdsTHLByL9TEvnRC5pA5SICrgGZA1Zq40r7SPD9CmdyYGUhwi9i2IIqN9suYb1upyX2CcH2S60o0dTuXy4RMHnUqPjSxwfJCe/wAzrW4B+ukqwWij/EfVTnOM8n8TxljCLpfKMM4utrZ+NotKChZOM2tPJHN/c7PwRMtfrB3WTjx5Ihc2z5/bAOcZaChQb8YkbaVu2q6qXYAJRxuXDIZnZ+QIOMUa+S0a5ZcWDUXnRFOa2ByzohdfoRM40CXPSyF2JfctMBu/slKA7y41HbNn7mycjCXJMpnqr4wpkyuHqZoWGdzVbnmD5hrbJcDlLftWuaruAYRcuIQ7QgaEsstfU3xaYCoxsx2Jg6XeaWIyxM2MxtID2Q1n3ggDKF8BEwg+oeC6q7sj9eA6Hyx4rtTW2o0zZDh/79jvbEpL4Y2AbhD6xVC8fEmPEReA63Ae4bQBQf8A4MfbXhs2Cez3T6YSoHnHmbcWhCvZcd+FvSEMIKHAShbI6EMRt9ZF7giU0VF5T2akQDwEub+WhF8yjgiOk1UNwmKJi4S2cIWYAz6YDUdD2KYpsY63MsD7McbN6EfuUZwKvsJSHSgpCMK4f0G4LegVgDrWnVMIlBWqHEFGDyxAq1ajXfMIU85I+5IqLpZIKS5hcfdpjgHwNFz0SVTYSx/uOPfaiqRHtBlw1dYhtDpc2GnIhqNGYVK2vaXjxU0tyWRyzcSvwKNktvfOR8Ikp41xctzcEUeezMAWseQoBMqyAZSUjBGUI6L9TInNtYN01kgDW/dsFGj6cla3M/BbE3BQ57oCeJ9FxvWKebgFeGRmukv2al7r61Er8MFRK6nEdQTHfMJtNTMa2Dw5cqvThtwNlV79ErtyF+s5TVfMaDCKrLSXdBdp+2PbKYqXgWBElohUNmKJptmIp9bwKkXu4ygKlY/kzFmOQ2jTCJcVySNdH0E/cCrqiVz5BNl6kMUemHO3NwRgqWWBpXBI3Vg6h7xbFRbBfMEhl63KHRAYgc061lYigsq2AbcA75Jg4v8A8MBI8Ha5inU+7PLoQD2Byr/8VMpyxofwQCo8XZFWOaxXc3xsHB33IgBA0lZIy9xnKRWRduGXh6JEApMpy2EsKruiSzn7sOYLw2qL2695zDW4bLzBVbO00xelK/8APn/uYq2t8oaS9OGjSdjLtW0Bipe93HVFV35ULxm9stXKK5jRBpqOMkExxGxd0umW7dd9x8uekwqX/qI1Y2pTgpi01G4jnN8ygLA6YgDww7Bsx4iI4BfbAZQ6rguhZVWKitc3qU/keUaVTFrYOYgm/wCWJ2TIDef4niGPwTArcFWSEENnJMfL+O0i0YGMpCvqN91JtKVqU0LohYM1OmBiCN22iA0MPRLezpHiXIWIhFR+OY71zEsdQfN4HuNTkpgHiNjHf58lQ02PaRTtKz3BXrhhgPwwyNIx6zO4g/qEEA/XJg+RZBoyXQSkYEoJ0ODtfuwp9BnKtffgADQlT6mTR/OZlzO+EicrNXgYpGQiYJl9q4LplUCbcQqKucGqCY6guWGjqLxQUBdwg2gnj3QpBKgoDDXeseVYDeGGtf8A5CZsGrDfT2SvINXX/DNJFhf8Qi2RimP7ijIbItJylvMgrdDEqCt0qS4Qq2BkVpb1K8onFlpsqQ0WCQw1sDdL9LLLWfqWvXuHluiUsaK0tHiCrv1AuWXT6YxC2kvgSmhY1DMWxusXLA1BjLSIBJVSrhx+NqWihCmDwnuEygiLfpCiDcvwQzRFuuDlHjtDnUDpV40IMGVXjRoKI0js/CIDhAF6fDOZ0Aqe02WxDNNAv/QEddsSOYVyo4ifi01f3MsZ+3Hm+xMJV7WC63/JmAftz8XYiDRFFfK5ufHPqaLALoZn2GRVUQymbdQaTYS+WKOZXrOBTYR4SoxhQC+GbMV4lYWZVF+jlYxufbfOpv8APH9Sx5f7eKBmAD4nxgxrZJeo04+otY5/FWWjRwWhAU0/0Rntv3jBgpsgwIt9KAQV2MCgibqQyiclwKaK1sqIIveqAApSqSFo2XIz1+5PoTn4JwQPl+wpWVld2j2MzZBsWEsMiUjCikSsnKi7BQppZhuudeKagB1h+1hfwCYf0dH/AOYCDGRhopJB84a58kgUNc4Y9EZ1xwME2NQeZ4Uin97ZG9a60w4Ym3BRNZ9RLXp9EWZLlMrOIELbgpVlYUPZcEoUBSUrIQKAAhS+CEgYRGQQLEQ0pE0OrmiJoZR7YV64ue5E0/F/haDZYTggH1BCbV9PwVjWJYiroi3BfAYGQG4SQroJUTfw5S59CUZT6YwhiyEM5sTULc+82dBlj0RHldSxYj+CIFYfMfwt+qAtZSLcnZA8ppvP1Dh+FqWRCsv3DNXwqnrRKvcCfP4XBN8mZncxAZLQ1x4/Ckt8Uxxi7MDSYr8xuFfrzHgT6exBrevAshoDByfgBKEeTg+UrrovWl/rCNqyjul8bCZ0ixOFWfcvX52LHueXIWq1TPYqNRdrCUroFt9qQ+KdEDLAKqYcwI9RSyilcvUBxWk3bbEDoACk75VY1iYsFoX4IsVkDTSTF9wUDCsDRTMGBiWKNwZfsERuq3hmotVDaktiTVBVjeF0VmanoLiLC6jsUR79pnYlytRecEH8IFB/+g6ABOb3+xDNges0ydI/HMb7EDh9QH20f2Zc6Kk4gEaFgOM+Y/4ir8peVwwXAdjsemY5wwRqsujMASiGENGTb+Iwo2d+hnGaGVsaC+msEokwRAF+3PliTSlblPNu2Vf3KGyyFMYFxdEY2v4+gVHzv4XiSn4uUCDaMUiku6sLVlBH7bPEjrL7i733Y/l5Jxt6WcX+lFB8MMHG2zfvl59gFtCb2AqBaQ/XALtSXDX5+4DPVaylC3xP3JTkZVkjzV+ounm2f9zcPrJG/vNFcD8ypn+JplzyIY0c4yd9cP8ABRayLVyrMUZlxYq8oGS7hMdxBPDFF2DxAdqNDlVQXqPHpHvLN6oEz+FyXTBPV+2GI18wwRxlRVeVm0G//bHBPKV+oscYi8j/APpsEI1aXykQdE6A6/A+M+7uHzww94QVMuWEPwuZZLXbmewVfgsUbpscU6YqYsbQvyG3zAnBau3bY8SkRQCahyPHjMR1BULxwjnaC02iOrHnSZ4JslgHxSB0Fd3z4Iq0tRcouxiHFoplUmEV4fcNFnlhfqJXRfm42QPHuYJ3tdrEDawcZdxfAT6EBmdYoNP/ANJDHZ6gFTAdaF1MbE+sagqgxbO/LfMJlYjNiJhIh2rXGnDKKodNuD/ZjEu+/Dw1DZOvh2RF2UsRZO6DWcN8VCa46a0JZoCHzj02ikFr3KhvCGfv4EaDpDQq7sl5LR0vcyy9bQot6+jIJe0r8/lhprKBL+C2LilyIZuPRGl9ebafsl7Ec0HzNxqQoOZvts7I9fYr/E0o/KwTe0jysCu39QQ+aCXgVAUNjB8TjWZSZaMudJyhLI58pXoeuzH/AIjMaVXoEEDOSwSySt8sBAe/wVyz+AGYNdvKcwq7PcDaXyQi3Err+HyYij6QmQZ+xfhSrmdFy1ulfqVx/G9v5JnMi8CDU5Htnce5ejlhSoMnrn5RJySNfkDm3+oqVyMJsAM/i5W1Q2pn+RnlbvwSwjD2HQN3Y9S5sW139JSNFUrJ6dsA6FAGm3PkjUoUmUbW5cRLFR5Nt2IrS+0F5F5BsWLDOuXFv0ES358i6dsEZ4s7HmVvlZkeHVSiMG9jywc+Z1csp2mN/Pne4Z3L0anAmPDEf/pEq1I8Mu+VCWZevPnHqGCIns7IymaIRXdi/Uby5b4fAgsRqTQ+Q8qHiNl11hCtoxs7xaj6XXNyXifdlgKtygEzZOTLMbCrmrELLeI3YUh2M7XqNgTzkw6lqRgZJMlOCOZyXrh6c+DbYagJcvUASwYbRaorzKpv8WppgajK5irLjoFulEyc3U9QK1P3zy5s637ERrH15Moiw+2XWCIwvnUvD+A7YPl/DYlRW9RMcg2/gGAMn8JM/E4DteCao/RkMBzz3xCNfxeB6H4XWrP3O7dDHrmEDNVY8suZrhsKUxU7g5+c3ZvyxQ98temF5Penhle4kBvkhUiqqv4YDahNDn2DNNiSr5YFFw2E0ly1KrbBOGz+iUVgf3+JLiWasXdpFbu7CwqmVpeyUVoNxZPety3jJL29sZRtVVKIeNCx3QqyfHP76Moz215YLNnT5SK2Zy/35lCwYmD/AAlRBh7UdF4IDsIxUcLcKm0A65WHkEXcXyWGrrG3TuBtoQf/AKj31gebZ7IdoLyJn6zHexNUhZYGqYTThkcG5dfryXxkftTeQeUSwYmNKw+NK2spYUB8GqjqlkScsvJKSx28PaGOHeYEUkfBhGFXmzGuJgZoZRYLWjlB6xLkKR90qa4d+5BYAsDP4V6A9RGrl1LcrbEfgTH8XrLxYCegPmCDf3p/g39qc8uqPmiFL9wgE80S8xpw1K9xR1aFRn8COD8VAh6BcHN78qFr02wCfmDldHbLYqSf3X8JfMM7ZRdVnY5UGzbvL3+BcvPHc/c8VMxCwl+KUkoqqvoczUgQfcV75w+hLjNkOOAfiosHA6kQ9GI+bio+Iyy7M9fhEa1UHni/cAE1J/Cl9fzWNy5IYB2OSYpJDazEtdblg1zxSzW0HSecQiKtsKNywIGopaXIgGZgAuo2Jqb5mnI6hSKUuw70eXgmZYSa6JWjKxW1uMAMxQIOr+iDjIaTZXQRNeq/R/8A62ERNyuxPX7T8PEa1h08Mdy1ZsniiFEpltKa7ggDk0kHcpzlX+WogTxU2C8K1HiWzH9hA7EuiRi41nGVFgCBhhdg9zVIOMa+FLbaOq0a43zCltC/K2UXQY9Aggtp+lIY6pRfw5rlnmaMYF16AlT9llLQ94if2wgIvzpw/wChna31Lv4UaD405O/0Sqm/i/4CI0yXuI0Ym0ywiJ01p5b5mpx30GBt2eou/spRv7MP+dQbX2psr6caa+olHYvdxMs+pIHyhcqQq9JClcC4UllsdI4wLYoVO5u+VCSlLCzLi/aESZH5jZI5ohr8AcriWKq09QYjb9mylkExfmYDQFp7N/hbnAbpmruu9cv+ganY1zqcRfiPfqrtlGyZjctGN1owRNjvsgTP3f8AGRjg14OEOfYhjoOCBmQUOI06suXAfLOmRsPAHmGdgIefBLP7Vsh5ilZWmYuwRa2jILK3gVrpFabGhM+yC/fMVhXOCOYBv7Mw1Vgyv4JXwliuD4gAFH/7MdUklsL4Ro6wZAgk4VxK7j4n+OEI86qiVKjN4TeR+IqoTJbHsWGBEW3IGQNKhIg1wxk3EtFGBgo8Eup/zHrpsbFOw5YlZPDlSF5MJpJ9rFQI+JtT+2lanuWP/E7m8nT53oCWZ+SCl+o/8xHZfaTdfAma5pdR6sIsusLsGkRS1FfLBVIBVpriUtxaQ4odT3jdBkekvniGw/dP7QR+gpHgL5idP6Yhf7JHo4A/wITSn0QZtkAX82f8xYc6IfpAXb6JtB3ivt2xb/BEhls6BFozQ4LAIJooEljFAiDs/wCZgyfuF+v05W/tZbEFnird6GNAAgPKcEHvqy710+T8FVte/wCCMC5azjDXmO4uuUvcVRaRGMTF4IhfZ0/FCcX025Q/ATRH2sCs68TcQr/4e/zKukChCRljP/axXf25/wC7mxkGmWDqRi0QUgQ2lY+pPlHav9ylUgYubmviDlDF5/V5Ltlgki42hYdRbiaaAc+fthnaoOD/APcZ/eGNLUJa6dD3G2gkHhwRwcoWYemcco4ITBr7lKUiU+Y2UF9/gai3+KTr7zfglhXmCMxcgwHKwPAW7vPFxCDcQ/2+k+7yqF36cjNfBDEH0VlRO7nZfLqzzQKai/GahVC+VHrd7UV3Gav8X+S5RdF/6LmiXpjA+rcovsSTVPXYbXvJ5UcP46yu7eiN968IkrftxMs7W4v+giaw1IE3a+U/aUovt/li239zzMt3LYqwLlxiB2Y4T4S1NCXIad6xKQKTZ+WILWcsUA/gnGfZt1CQfRWFUyXEPuOFn7r2aOnoprFt6YCkDFBuDKJV6VAupmH4fyH4I4BUIug2DiDhYC1C2ADz46lyoJGSBCYVufywE2cNB7UW6MsHTPAwQxaCLf8AQFPutL9pFCEP93Br5iO4GKBiwUjxMq44dHSWoTsvEABfP3A6BRsNMrb16Zir81Ufgvf+R1LzKXUSDZI9Nt0kZPMNcoYXCQLRfSplkfbLf/jUF19cEwX+ogSRtjUYeSk2GIJGUcizfgE54jBtXeKl8+HXcuBKzgOb8Rg7wYWd7DyZS8f/AEDFyo6g1WbgWuufpKBpIiguqen8AK8n/wAMOZBQPtlCILxmjhsjd9A9B66OjFgK6reNd4cpL1FCtdoozgNkQ+yFChXFNKcDtNBjM928Jg2BI/61bS7SQwtOpVFeGDD/AIw6Hl+FUDqCLxkC7rAQ+gDAS3Qu/wAAXnEtADf9s5hzLDJsyl5h/qPHjO4fEIWqmbG4FxT68/vmRlKUgswelEABJC2suYd1GfdffxDHnTRXqOZUP6EgRLI43Tl/YjrlqqwbE7hEoiwvKYd0T4HaYM0OhlCt7MEMZKBtf4Z38P8AyCNh9mEdMo9qZoPwCld6JWB/FL/1qgWV6KehkiD51ZVCZqfQwNg9tFg41ii0haGrSFPf9xLaLULuDuFYNU/sxWAfMLkRjFuxsN1cqJFmSEp2+sggtnLVb+AlEqE4PWyBShxsgWpcdyvc2cwPAbjSNqbqVi4xDbKjtlQwFaPwcVEvVjCzUV25OI6qHyRJexqFmeUBTiUQmvBk28MXGck0M5TGTzt+ILpehw8CD92HWmsUxzGQUhr9Nbc/eaQiYrwx3l6qIg9vvEmtHVZi4jlkGXioXCrmCcGt5nT/APC4/wArUZA91E0RhqHoaJQGMxCvLjhFBeXnHkggAPKQheH6JBmNbH92Fl2UENsX2RGohziMnoaOvqD9ksHJoXLlsbBYvdMQQAAaD+ji+F8BhpbNdDLtwAGXp4MV2WA28PTG01rbNrmHc9nA69MSaB81s2lULn0wGPEwfsi5TP5Tz+ALlqWq6ZT+Y/LEa3ma/qJScpop+G2F/Q1/LCPFzapYy1sIobSUDUPEkkHv013rD6qgGYTQQ6XJYIShW/KVMyZik3JIMv5yE7ItOVWWgIGaKl1VbHc5g8pvxCUBFDMMv4rL6rlgKlCEeZF1xGYaZ1BYSltmFwwRqioLMOd3Hav/AMwNAsnoEpDkMa7ltMxrqdLldhQTNfPcNMjGK7jWQAdx4WnFIvFkBlpw8xoJ+IMFFK75lrEnqLuGBJdsi/zBipICCqqVUuA8ZYYDWqrHGSkgPqslTyWGEYNoxsYHFTczagvTZZUT91HEAShIvyZmsnkIuv57X/r1thdyNAFrAcv6/VJY0HE5z+ap0P4GIAwMPRdRo98WH7YioVcrm4xbUO4G6TzHmzZyj1A4g4ra9s2yyWDTl+CEL255Uh/SQBQacA/aRXF23fR3F01QR+JjgaqrfCzag439TFbNhbIlQII58p8dS0abf9J3gO4XoQ85jGMhwocEHpbsEfwGaY/gKWolq8bMZ1KEy4WYHyEuasobcJm0BM1v82L5mUmn1Ganu1oNeXbLXyXsKgmtLihCZDSXOr+CUprqLBw3MOyrxEUGu5bcB4KrcplCivmSK6z4eee8Nd7sJturY9qBVHil9jCAIVgYPSCscS3UXYROiqanPDxMCdLAJSl78xrgfJCwTNVeObvntr/w3cB87dAWkIQo2rlYiG0pycy1KZSy2cZZ14XAucOuPxQVX/8ALFrYBcokBKrjNSGmYC6o0l3gfY2vR4i6528CV3Hj7YhePwHBC1IkDDVA9eJBO3g/TADAn8WfdLMv7dEuwT2V2vwXeuAuKE580KzIBnvllLFoC1ZSgDX3qF+k/wBz3Cg2CoPkh1xHR1cIE2zgIsJsPEbBHhAHrAqHfHG/tX/aan9aVrQHA6/Af0qxDwAI+sgVp6EECObi9ZUoiQxXi3hkvwTLg1eXmXvgNM9AQhZXlFazf3SVSKWCRnfHCZJeIqY/tsfdVsXB0upVoC2Net/cxYBGgvuDg4BXsYhbROlTxNQ4NQFU3xtkIP1So0QLmkrLdTAJcqNRCtZK6i7YrU3xNlnucmbK2yyQF1TWWUA2uiMCa93Ryk8RIFvOpnx5yHSxzLf4aHWcpglwJWFtCK+YNZUieYgCutuuXxCq7Kp6hpSABlZrAadecmsZoqV6g6MAILngf35aD3DNoEUyb4gFXYGiIxRiUN9C8y3M3VmLyxKXqNQMpQP7eAbXdUU4Mr4Fk+GXOEYOAyj2WwOMICLUrA0ymllZgFLiVrQJ9kstDV2reK/kfsiFwJ3xrD2w1ZBbECBSjm2gCH8VhwwEqu18LlSjk4ZZ0d7jiF+pegUL/bJc/v3xVN10EeCHC9UfX1RN/wDKf44qFH9PW81aP0GMvqMYPXDNkKyQfo2zVDNwqtfDY1T3Knduj4UEg3wbZISujdNu7jism6IRO3lvyFD+IzHrl3kKezZGS18rAkztGfvOUgogNpC+7xkxq+GFI1bJ6nNMczivzVka/wBsiKs6rbUEWkoPnonox06yXlfxwlML4DLS7ZR/GPy7aF+58R9etjRbes8MVHuf5JfrKir1RcRpZu/CJGPEFcXxNxsr/ahdF5dvo95UbkawY2ms7H/ORlsFWm4eiQtlWzDEy9Xc9J8GFW3kVWBY49+OXjsSWq3qFhxjQPfjXg+TASp5m20pCBcUhuBxWYK+IwuZW029PG6CEEhQahaDuIAXsCOvRlmI411GvQ2sWkhlV2weQzgLplClN0f2yMq52098kbBiXzEbIyMs35ldNfgL0dO2alDtMtlwIbyrkSKcRM+eYBK2yFigfBK3xwETxJZzQZfhOe9NHE60iNGYS+zNeDzFrCZNleSHUjKtHJmUxDFKpJXHKrAS/d7Z+foidpNvb8/1BQMzEcLLio8NwEv3WVAPbKx1LCJ1DwNxe4vzEH5BjcwWfkLgwwGfiEsCzoVwcsp2I2uoVW23Kg64UgexreH1AdvVhTUhiCVsbA2PsQ9rNLvCylKfH7KP0J/ZemP5IgpE/F6lWNbjtw0tNPuC/cm23YRMng+Ndv4I9RRNJGanbtzB8EeM4vctkyqTEQRwU05uwlGnNgUb3l8VGW4wQYsO5moZtLOnT8oXaVXVV4i2YqYBKsWN8Qnz39tm9rIf3ioaxfzDg1LhnS29OZSwHh77ALkUvh1IXz5yeOiELwHDG/IABarCysL17R3I6xxZRvmuCcMnUSlK+d9E7t0cSwcWqlEZwiNiQiJj5R8fDGFKPtVB6xAcCG3Evj8aaIssM93Ym4UOAODqUCofeWnAqWZMVk8CwKGsxV8wtUkbVtt/AqjL1LUA1UiaC2hv+OJYhMLXOurhdeXUfJUoVbV6ltPfhXMAcFUXMYKJC2rcerT/AFAQM4I/WAPZJrMYQU6HL8S6h260RFs7WN9VPRDXcikwJUEiwoW5J/max45QrVMpbKO5I13TzPHRZbyOXBSat/Dp3jhtFZ7uJzLV48oQsBwQ/mAjbxA4EAVbRCnBCS018o/tG2ABnD1EZp+IUyHijYHfGR/eI3nK1h1To9EwFAABQDQHUN2OLnnhEVVdr+CeJRfZc1bUufBJYCLLFcjMWXMstU3CibaMj2uGNkt6/wBiMCOwdRMyupw+npJUuHG+Z5UObKX0yl4lucEI8Jl0qZtrQck6YPhh6oLwRUjmHcT1X0vGDq0sMv5sdUZD2OTf5csxQoL46iH1GVVKrQPcEGBcEMSxWGxVT8RQncP3nv8A29EvkmAcHoIUIz54lr7icH4L1gUax0jcPRONsTAC9J/tHDElqGTPB/CLDuVq9VcXQ272TIxRaEots8xf7SMeRRtX8MjjiFfUBUMFbn+bHH0aPcSUht+B1CJvg7adscBCabzFDu0RZFEtAIgG0zLOlopz8MV69N1I8+Y6eO1BEEf6cqA2xuK+4ZGJDwTRHRF9jGvIoiunDsjoswMY6SWAlzDiuElVrWrip2+IKcFjEHfuHRttka45yU3Q4VHtHPmDpxv9wNxqDFpiRw7ssheIBTXXJ8wcd/xEqArQKxn2ZARm61/xxmN3awl7yTEMLw1ZnGNZH4CzO9WS/g6PxX024Bl8keyVwMr5JdQ2yksJYqpFuNy9+U3U2RcCkemDJWrEK1GgGqpAnK1jX7iRaMVZahTgr2wVgVTkf2RNbW/7/EDbcIU4uGYwvVHcsuclwBukLBfbodvRM0Geejcw5l+R6ZeKtRKHPSEN6J20dh1Fs+a9G+E3/US1juBi6inNN4GI7jKROhdS0qmgpcvxXuN9zrbVBzlK2/54tLi5a3mb20tIzCXeaz5YkFARM3s+iYA1DKtsVuYJoyPOPcG6Ws8njwwYFFfLUkEOXAb+CpgXGaqfLbLTuqtD2sEWKjgtp2yJfGYCga6D8I2WZOZVbOuGB1HQFToCW0nPJzGUOmbZ8ewBo2cwQkOgIVXynbLaCCuHaQaYQTSx31JRkSVjruUphQIZVG3koxumpFenfha5hV7UtpxIFTgoNmYIln9NCwwIVRofvlKO8L78eylv1Wz3nAjGuQsWzCpsVK1XXULUXj2QeU4SzgVmZiVnzNjgkcgJQipUiZ/iOqZrOmsjOD9HMY4pVcnpgnAqYv7ef8koy9KmVMygv9KEbfT1aPHz/DWRlQvG/BhXYRQgRixj7Z+RHLN9fy4lN7xPvzHwpsCMKFuXcjS3J+SHQWj7VtgXKjIkoX2vUKUKZ5gS5d0DpmBdtGI3I5YkDlRqhBrWvgDtlBaUtl6mh2cDldUC8XNbr49E1aRce3Qn0mlHQfgtCWjruG0AWi2hbDUj8QC3dS6SsPcLKY92jrUiH8BtWVXdzYN2X6lKuGzQe1msHOuL06wR7qyI9sWWqxaY0pnJTJTdJwxi8g26gqVvSHLwcqXrUZaiDAbJ5xQtbYwW7iohwbieeqA3xFNGg0GT2vnqOiOrN+4RKrIu4gf3hIClgv0P94Gr1zbmNoLAWzct0qTJpV1HE6BOXpiMCzZglYCGEHfqDu3XL2oMZuvFByxQPvooaMV5f04vFaJdoCmze9TwdR4Qn9ArpsjYQgFl/NFb7AjQ2trWgPBM2fATH3AOCPBBg20IrY9TRRGwYxhmpRgUi8vCXA76D0blui3S78aMBDTkAfkcMsW/7b5cNPfOI9uDUewRPYw6LIvb+D8MsjP7phLObmoPpAYn9RCcf4zok9G79CFvy2E4ha9sXdeMRMq17/8AEJY1Zf8AM7EVJWxRRiFUNN0wlTRuwaIF7dtvqAtADapdbVXMMjjMyZwrZPK5wu5DOaKk2+G/I7nDmlXG8zeOyAQQlaR9Wq/tLFDJSSjlhVqIEHa0amZChuqnDk4YJKU4QaYJRjUQBDRGqRmlOl17dEsSf/n4ESo8bfegEHu8aS9VEbfvCMbI9WPxuVfvMAUd6F97iXfFMN7Jm4Y3v5G/hYWwOCGAKugjWSf+AlyJkQWsAtS2KoVYoQY1E6R/unaIsXe/KZgF4PdRG7gtyXGEMsmBrfWUtYleYqfMQMSoqTyw81F8AgC1F+XuRyEv53wEVptbqymstEKrA4Sekw92UJ4gOaRvqnaHSQ3iFs8ZDD8ipeuKCHhTD/TStQzzAuD3ccjEFEy7f8e5MRJMhtP5pMG7MH0lfzrC2ozJQZDyblMywprHcCVkawbJaKHnPA4icGdbqOcNDhb4MzfdQp8S2Xb/ANbjHXht/mPD+YYoKpq5H+FbFD0kuXL2n3GFXxiWGkgJv13GlSmibtl7JhZ8zAwkj1W54AYOy3oii59ayYr4RqBhzNqmIq8oK+5AjRu0HwJW9SiGybqauOwViWweR2Rc3hMgVR0Q2onfN1HO1O7Slms3Z+PRAKo3MuiCZzs7lVjrO3WPh7HuNDadU7IkiihqrO4DgyLw0kE4WFUwto7xymIxZ9zoUE/25lhjoeroH6iUvDljMbp261Cc32zGwB2Uu4sEDH/duZaLOxcpM37aqv4aqAt1FABixf6ULXs4qWqWEEB3sBDCw3kzzKLUtMWl8lDkYVp4spQXpid61WJocjG+HBXZuiCRVtpz85hBCAYpw/wfKPFM52zWXMQrkn1ghkjrgfL0RjkNU08/YflhMIsh+Q9+2Z0R002c/tFc5eXI1x/yuJXmp7iaDuGqf6aJ2zVso/ce4oZyAG3PAdMHIBzt1Do5hL04aAFdEKNKig3xCLBSJtxYC5UYZtPfqUlBu6W0Ny7kuuxl8x6hcBr6EDY0msq4xGzqtUNcizGaKDTN9wpZ6MZSEngZWT2tkrVwvVwQB+C/8ozWqw5z+GDWaKi+Y7RQf0xgZuWD4Z6CUAN2amBYEiKMO3Lw4yN/G5GHA2VfcEYw3k+HcrEmMM8f/wBrgjFKLT3AMFy1DlBTUGPNbgioLYXXd/ky5ymyIBbjWtL/AKS0kGz8i4IneyrKSZoi1Nqso9A1q7teliO3S08/29S2FTk/FjfYIgqrwmDuLWyRTiVAQEVZBym63eolFUNT2YnM2o7+uHxeHCadCNhLysBMA7OR+9S6x6c7vbpY+pYoGw0y+2OOkDGTlYuFK4Tgdxsbzj/dJoRd/wAgx/zjTPAncXzHEBH/ABLPfEAz7syf4IxwyqsE6uICWHV4DgdMGgUARW+L4gIvY2tBkCMwWgoNRcimgNrGxpt0yqpAdmcoR4gi6wEk2G+WxaS90QBbBP3jIgexqbyIBE67EXzX5C3AczwhUKS6OSx4E2MgaXvyilooHCmLlLlRPCxu8XfCEZb1/THJUrLb+xBwqdOGsgcrUvmr4dwUppY4NanAGxmletcaFPM8hnjHJJQkEIx20CsG5GAkCyAGyC2g0s7Y9IKIXsFWwpgrAYYgT0u21HIHN3y+ZUgGnAreZbsZ3mUqrdDFZbslPyh4EnkFMGBUDb1lQLFLMUd9CerpcxJDLY5+BgGDcDHNIUpwzv8AgIenZHlfEWAcjBn1xKS1Ygv8CJP2dSgdRfhHjxshHCUy/wAJtogYy9yXMzoW4dwkW5CnYOlI2JWI7VFiNIkFHNWPp1Aes7K0c0M1lf5f5ThlAzDzm9IqHcb11KDECP8ACiBslMZN9S+sTmQ9gQQT2f1kyqIjTBkAVeoSIXchmxfd4iEqw0sbq/uB+v7b4nHyxvujL126dOThfoyAKBxmFqJmw4rsiAwY2nB4ioPF0/RKCS4p+kgK0cbbS+DzKLlQYq2XRDZ4ivhBL45OEh5LWycO1QSgAcKweaOeuY3GhmbylNC8wDupeTBNa+2V/r4bnC9hC3dVeo1VaXLRiCk1Zzt5/wAzKSKqnuLjkdnEHHJ8Js2NFdlP6YoCspSg0cWMplarwciXs2fw5sCFSKMX6TpeGbq9l5ihMyhUEqwEXmsw28zl7Qidss29Mtogwp7QXMovcSpYKKqIVdlVKjGxsA4IRARVUreWUgJJKL5QLIoOekVoYwF2mRPz6iqtNYeUmZobA9XFSDkcX6gkwLLS/j8dO1+W71hnqub+cYt/EGvcsUG8tF16opcDeBVRdPJoYpK7axFSkNWs+mJozTBHmKtKRR/SbkcYDFJKw9XKDpfg6M/klQFWpv5iRlSPVFqU+ocodaqDgdVC+iHakYA+BI/ONYN0n/XljkMgmLhy3mGZfeyzeAKu4R0SuwJ+paSPTO7aPolHD7bsChC9CKN55/w5QuKzr8TwIv8AiKTBhsa5EKpw1DQK275KlLXV5NXDRwqWG/uAjxhLi7RxvB09wWQ6QIGQXSe/TL4LWmDdsl4yY5I7hUgqROcp+ITgmmH7ICPFUauHzLFwQDUSsenb+4GdytykPERuFqJZ0mG5zDfU5/NxwPLGod3KHvkfEsYG+QAiQCwyLfgmH5z6cl/iYYA/piWVLHMGjcL26uwkvNaxU5JTmEZPX7Ng6FYJ6UHnorNVvRYUlBqe574XoblvJGzulH6cYdbIFOq+pToGkQsaxB2VOUttQKWyjgHuD0mS6p1MYaGRy/3JeABBw9IKsLhnkhqGr0zjLCgqITiQ38ogBt0IHHzFSjtw+osB4BysAGlPvWRF26HfarPmBJT4msHPWiDV4bH7h22eQv4djBtX3OLlfPIpeNANY7ZV1AXAO9kzHz6yaX0o1jfUkab6BhHReC91G3fWpTPLjNKqvzJWKByxggBwARWxHS/4gZrIHaU5bVTRcQip5FQ8ggXNr+4WJdFVjCAIuQ/lLjOOFf6hBHwKEnmlvQkjitAhe0/P/KLn18mkV0pZfZVRFKcmjjzOJHvhLVsoZE1xqALiIt7o1zNtHwTmJo4/dPMdDOzgR6lltVsvcYod0O+cS6g8pmFrAl3kK8YmK84bKEzXucC9gV1Gmp/nhg5RJzH2ah2IwCj0za9zBxcr0t60MfBx/XxtI4RqjxOeariS3xcuvshi6gCgoKDG5kPmSoeCY/jmtBbPDd6bEC4feY+Vv6eBzc6SvOAN205TNq560NB6UcH0MBwrkb+ESy1jLTIJd3vxEIAJcr9ZFFml2Yq6qps2AxAtkHL2xsyUPvbKxwaZYOSNfIDNoiFg2pt0XFVZaqUIKNmhKMMjIilYCjojFy4JicTVXWzdJmrpWyFJRyclncQJf4w4bJozZtPRDrJSLkzcQOfEFXBy4NVCfpzolWG+qXviousv3VjsxRcBjaZTQWlBV3gl23pkRJZnvGI14mcIBt+E0v0J/hzBQpRRWZjMwVwSj8WojmC9gWWx3itn8kSKxjSUgrGRsKPtZeOwEYngwGoGK7SKLW5UvcIi8hM6zM2Bo2xCWx+4/RaVm2ZG9Ul2nzWKMN+ZJeiBjzloGCOcaRF6JbX8QaQK/t6gGTgAfOYNjF5wQtJg8tRCsYt+bnVMlcPUcTcxLof5S7SuwTz5gKyhYtswK6OIwsJTRnqBo0W7FIBaUZaKP+O4/kOte6/ywWSvUFJqtHONDqoODqC/WSgA20O5QAI0DdTMZBK6MShWHHHJIgykubN1+oYxyRp5CtfuJUQca/pzLBiIHw2UJwpfHThBqn2VfIW3xle1KF7YaBiGCajvY6Zoj+wTqfaqHolN186RJfiqCoV5f5aoA4VwVrTLCduo0Ys0csK8QYFt0F9SWaOAbADhgIjrmH0heqfAHwjYgsDHkmn4b7ixqmiLF842XJjkclc7oGcLjLWS5S8s2eVVEAYYXReYTwjUffBWsB+1LBKxwL4l9MCFME4K7LI4X1KVD1iFrb7QT7SBZa8ER1MtKjwmwX1LrIiKhyhGCzRqLCRCqnmXdKFx0R2tV8g7gbcwKrY1GUhXuVuMnfiNShiGOfOYnDbQIGULS7wVYgwWIcLy4JwHOztlhHYvKxkbFKLAlLWs6cZlrxOa66sIl0L/AJxL7y7Q9krNtQ55MqMPxj+o7xZmWoFt/LQi6WbE+MWCeF3vRBNaKvmhZmFMpXC3cVnOuGRSAXa5yEFRNC4iOKlNSMA4rhlwBWA3nUbkd2iFG7BAZLj5Du+4IxwPNRskNNDNxrpE9HoAxVAGrV5MUZAo5fV/dgigo6lalAWloDtXRK4MODR8+Dz8SGZnEoYabe96OxmSMrw2wvqI1argAwrfP0ujbC6VarrsDUstbVtvlhHr611zP6f040fxEWppuRLEAjsNoYSFk2XUbN7UqpbMVzjmcXnHWdq6eoEz3lQzF8ek0poCgYJnMaaJfI5tY5PmLmilr66lETfRAESL7RTHlepLdJ0lCLvYbx0e4LCJF/lCupnLwuAWbAcbKlr0brv+IM+17XmHHvWDjplANLdA9I/hsv1O8KSKw0kNwpGc0hFMNnkS34b9ecAx5gKFL1sBI48FDXgEbLQP9x4Ze48jhguwdizXiBqo3sKxnBI35GKUQgozTIyCDotQAbXghyt6aQ8r+LDRIFtMMMmgk5M8IK6DbhpHuLYwCzj2ZeefC3ng7KiAe9FgG1JVwEqlV2iGYY4EnCv9hgz8zHurxOiP31EGDq1kYoq1hEaSpyKl3Kv1Sv8ABTqJAAOx7jbkmi3BeEKa9HAeIITAnJKJnNLS6XMBWGhzREbBbRMY4YhapmDiFGwN7jGJlK+OSCrVInBA5hz4tqw51NxgvhyalWGopq5R0R2vT/dKcA4WOe/KMWlZBWUgQoIfUQYurZA78sxSrEn/AKUsqTRE1AhM2ymVMYW52/04EWmMgAeLZ9Jz++BiWBmHtWr6srfrutn28sCEVMJjP4JUnWjaQ68tQ+wM+4p4NXnwDbAXD0f25R95YqWU1GSXAgaynMRhAFBtHdTA9CJZY1w3NuAhVQtCKFRkseSUwIQo5p5ghWGQg70epeNTkPXU4q3yeMFZIg2I8jA13UuOICqkPBFUJkdetV57u19hgyqWXfqFfIHX2BKIpoPBLIBbe+hj30XPQw88O9G4HLN+1FVFe1X9xYMIi7UN3BL7fxIw8p6nJB8XSd8yopLvwdyn2+sZW5mMueYP1kT52XcSgkGNrtcsNM/Ln0IlVPmVqGeOWNC8rXqWOjjbx4JUKRKVpRL/ANPONI9qhY88tDEDcFq9rE8CISULcSpzZmkXb427CFtOKxKGAtyYCJRw3mBjXOJQa1t2VUD9zRo6EGvnmFCqyi4a6lTFwNCjFUfdNB7dERVWnjeI4+5VlbJjVzDUiTm59kjp7JWTyl8naKSSoLF2mC8vN04qfUEMMvi/i2fmBl4a4A8EFAVz5jSUPcJpADtbBUdDa2LeAD29Hth/T72LrJFIlbNvNq1dAREarfLODoJkINslnt5UWFtqwsrw7qR/VPenU7NoxA6tgTDxK6n3nZCeHoQilF9RF0xtL/peoVHjCBGhUNV8UDte5QljSg5hhJHAL5WoU3coTFdNww9Qw4FcPLKXa4mb0pYaopQeURJ3LkFxBEeRiqDd4SCcETyl56jgsSaUazgofvEqtShd2qGwEo4a7Gop9HMqGa/sYrvLiEYFuWXCouEU7m9XDNmbwc7g04kGh96kTH/tYSg9D+CGxqTIqYLhk5T4EIwBERca3UyKFi99OqlioL/bK7mNum+Vt5/XKoR+2n6380XeuwW0Rd6WlFbCnMvPdxh3zpEPjgeFVH29YXYRS5IgV975ItNJUCqbiMr5nky1CUoWwXqC2qCwdRtaxCpHjcFSq1SYLc69nAzAwN+qK36VAJw0bWYeBQwAB6irVzEbBjuZlcsVGnWqvwOswYCLvWvUaARDk7lQVhDFRHgYBMNVWIMSQGMXg7gQMbXlXa/1Bh3q5+IGMsDLImasF0mppy5GusYfK4H+GGlciGD5OiBX3McDpONmgACW/OAGYDlXwR/biyEW1f3BRZPL4olBk/WsZ5r0DK1RcOOL2MRoDnLBgPfg3ScjKTTDhXAg4xQIaDdCCHBc9k0ET7k18QLCOoJVOxgJQL2huGfby7BTEDsUPplz9hhvsaFuBcsC/wClY6HuNC4KwlyxcACjZwVC5u47IR1i914bGZbX/V2hhUJ8CpUNTkdz/wBf0hq2cBncu+iMxbqaupfO6x+NlcnW+SOybsvLP8MVNvnSoLLnueEB9hMh0j95VRJ11iEavEUHw0v2MKkpf3I3GtN7qX8sWSi/4mS7i1hiy7Xs8MWLAHzNLWAFLMo9yWz0TjOMWhYBSzoEFwuQQ10EXeqCg9wYX7Jeh6JkUysClnMr7M+Bb5lX15shQR7pHNEznG0Z7ZEOPsCWeWMxpmz26g7RyDq/pCxA/qVuwL4ZXO4Ngm+CRux7/RRLLkHG9JL65DDIang4YhHXd1QnIOHxKr0WuQOL/YduiNZxIeauJ1Da9MvLMkvzbG4l31BxwpawnNfAxKONPD2szmQsr/EWq257/clF3c2flxGS8sBnVMzYJalWFzAzvDwvV4favJviqvYxV6RLNm5QYEu5pNQeIl0wSNu4AAqcVBqhHGzJXLs0/ERXD1nIYHKsIOkh5BCddaILIrsoNdVA1CHQvmFKymeZMMOyXv3gFclzzB3Wj5PEJyfnBQ1f/wBhKG0I3lGJliLNB/BM1CFSZdKTB/WgGYTCvyPVXEijRuFblG6VMSxtM/8ATfWM+r/eEuehWjyMNCu6z+CAwKeAckaGEd2YUgoeeuMTFptf0ytVKu25ooou4Bs21UZXBRRt40qqG/5ZtggvVBfzXLKtrlYEbRl4Rl4XRCG2N2f24u65VU/LDWhbBWrCK3ZtPEFHU6aemiZVGC7TcWEFg2YJzcuLYZFX5ZQXca48XTbDtfDtOiDqMygv5HEUhQgpfubgdYUXqZUfkos7HB/VeFA1DrXaA/hgm4VKy2LNf3VLekF5H+WMYmFyNWj6cIrdsylj2cMQJNiyHtjRba1h4hBAhgvUinQDdkDxKRKbgQw+kkK+hn9yI4nJNkSB88Q+hDBnEzepFlZIrIUhsCqgJwLch/MGRs/uInQOEKDKDyKg+qMPklK9aNiSlq/bvkhXme154FFYTAGXhudF2EW4WJc2pM2wKsYrLUY2rwioN3eSzP2zQwKYBJE0ScW85nwRXun+hAQ0YEdvuAPsCNq2X3G6mH8720FUvhLogTMoXLK2dhyQmZTdQKj6U0gQnYABGnWa7BGypVVZ0eIVLJfe8yNB8nrGyt5SxWh6dS7YKFrwWsuBe5xhFbKDB5gZb8ssC5SghTdyC2fBGUkaM/vpPRGMnl7sGMgugLD/ALZqH8Pxb8xUAKB4ll5yc3TqIAFXVT7IPMPnU9EWKWOqmy95iU+WtCtRSyPdQOgP6wgIgkTAM1JVvPEMigetESt/E8NJFh1qzpZpKWzGsoT2Z8JDSjnUTycCOjpbfUsBGv1SsnuV2EOoHeeeEzE+ffyRBcxHIN47g5GoXwvEGOHVJst4lo/lKT6yJUPi4lz7LzLPU9WTV+4FfJ0+qGiJsvkzWRzP9hKHpId7F+ZQvxubGldMQERs7PU6OrLwy97vFYBoxRRb5LBKQZScV1GuGWgRTW8+oPfazBM86QI4VQahSkrbpSoUm3VUW05tgzALiYwzNwHSNGqnlQJ8j/75hPellSHUC48kE3iji/cBmW7f8kqifDtcscEqFlGAUBeCEr23BEwj7WhhxqWUXLEG1kOI7xXBKAwIAZWo8CfN9tCWAnf9ik1KnQCg4lq2Tw2gxCDl0M1inD/olnYBSwD2ToTrwQXUK7VtgXDjyHDwnpOSY0iUoa+g0XIBlfMC7PYX42kcoAcX54GOWW23+wBWVNjkhAFl+B1Frw18MpOWaqxp8IvQYIwHUT38+zwSUhV2N+k3MejznQlxRgiNRJB1xpbEOyWeP3GxAKnE+YSXODKa7hW0Yhpg_dump: processing data for table "public.equipment"
pg_dump: dumping contents of table "public.equipment"
0eBCSHzwsC+efZCC9tiRECv+AZfk44h1/70WF55wxEeWFiVPuh/YlEZebKZUABYKzLDwrHMEQDfJfshQ6XeuZYUG+bgoOQ1MA1uXQiXFYFrWXR0RWwVuxSWkJZRMk2ICU11BuyrOOomQi8wQrodSwVMdBbthqOBiVpGph59qlxS1XLVg5xUAjvktIYIh2EY734XlB+v+ohUOaDb8wEtPOZbJQ2dxkS/VM/hkvA+TZ9SKdsKilRoLWF3Tz/AGY6y98vwQQuod+TCupllCqKipJma1cqjNxPJ8ztgXqMV/sM2OSZ707yYmO6U8kQKUNcD+FyxUbrWbYow4NuXlH2Y/iTfUP8seozcEhXlduGM2EVVV+zTKCADO47lshwf2IIBsMbCMDiqY4qNv8AiUy0I1K4GiCg24hR0bIyYrhbBAQdlogHigpfM95+uNs24mhGYFj6wZj9ec4KVXw0gVw9ELbWe2B3yrIgGORBdU2xYM7/AL0sDa8Q4pWIFlV2mNXKJrNNrSKLOo5xXF2R7NppXLEEhpQajExG8EDF7yOAEN9iEL9gJi/HExr0ECCxXyVljbUVZH5iKHpQIxXjQQkrzyrTRBNlAKf3B0u8NeUJx4MaJ3lH/RpKo5Yno92cEAHsB3G2treTzCF5F3RuPlNRGrLvqvITOYl4xeoNAA0H+xjiMhvm5kqyiq9sVX/aymhEqv8AE52NwiU2B1oyNBmO6L5gNr8MWuxB9MMpfuXy1GnFL13NmyKHBoIvcTJxWkQcTeC30ZSPaJ9CGllxqAxVpQ9JLXdVKvoQ0VNDplrWDnZLIp238IWf7UxjPR01/NSa2z7gi18fFKlNcP7KQR6UJKoC7RXhY2GRzM0WFk8JqI2TIVus+I69f+3UcF1bEjl2gtjIA7mMVQdi2JlObvvVuPiyOUfxHFYdSIOhlW0RUMfzK6rJNlePAm4Q0vA6VNLCWvdd/QJjflN9tl4AOgE+Q4K/3DCh4CZInuVV9QNn6JvMOy1+QLRcgoe2AxO3+NcULTGwO15WZbT3QCxF4mRCqlA6ZBZOpb9vP1UM9kyHt2/7JApLg+jO2ZXthCrgW485/SIQXowvdMPk8mQ8LbDKgUB/o4RILFdszI+K/DfluX3VFosjxCOE8kQ+ViRREU0hYUy7R+4OIOslemVTuVUe6Oq14CEcYRmmkZqDhKb/AAVFVwsdcgdy481uC2p+hRy9j7coAlSNU98C3xlw5FXWNr8wR3CsGwmYH2tBLiqK4RcZyL+UCbvzmdX7UtYFxUAPb+EWgWEiv07Mrr6dBbUQY1cLxGub6cvmbRWACTCpESqZxGMpxRG+/RRnsbYmY9cgxYQs/wBEnaScqWup1BAYNAV/tjCpOgo+kzKLWtjV8D/chcYVH7C0WvMLAvfuPBBBhPKTLAlK+2XwiI0jhITDC7epQK5AnVaVcsb5jmh7ibizVWgo+4QEhaBETietdjDYH/nx18zC7LF0dowktQVXUvNjZgyksbCNwbb0TrlxMRERzVxurRVo9hAL4VKJSpwMNsnmrNocvMsuUAsmyMt9jTUdCIHp7ZwIy+DKgWKNr51RLgNmRQeCgsbbY0JqAtWBB5BlwdkNaZ7vFioYeRQPmC2iRlVtlhK7Yq9VLNdws+uHgaJLkKbul2jKeop8UUWJ7rHyjUT2tM3ehKRuz/vf9usRXAuWqsMn6fklW+oFbPkibVgO54GWji1fKSA0HyxLt2zQRiznlY6Yq8g4FcOEt37ihPXmtuYdXJxhJKU0hSMyCBYd/hjmG/Ll6eINRDQsfUsCZzdS3HiOEHmWVCjigZ0rpUZSUP7JlDmLtHipZaqHs4cza84VceIDQAlBWN2MLUu6gOpTYPWI9co+D4g4XQYIGbWAtYOOnlRDQ9cjSu2KbtN6QhW8MAi3eDcbENKWV5aGVxbbbkUdpDQli4Oq/cEby6B8gj+qanT6LthgM4Ff7hfCTYywLdjL8peqQ0IK6bJlOQqCekmF34K+WOg5c+5St0lMG+JmhvXxlt+yI1LBkkaMbYYdrLcY8LH3AfExwEEjvvQZehgSMVQqA6Yo3jBUxFFElLvEq/p2QhqKB0OmzJHOvg6BgYlba8euCcSIJaxWr8MDGNWyO2DIU0afgIy1qBawbHdt2ReaJsFOwgbSSsWXVzYP0h+FMnSynlMbH7Zn6MzfJQcGBEyHNnTGyPF/yLDDrg/EKNwoTUBQf7mVXvb5Php+ZgO9JK+T/jAQbY2aPfUdkm8C9WWQhyYmcMb343kWACpYV/u01HxgD9i8qCUnu8MSSvnEI35lZGNeILpdXi+MwA1ySjuDZ3TBBAWRkUSfmR1cbg17vqVogApe4eYKggZ3N3jOzyILEndr/GWIWg46ZF/tMTC6F3uLl3agg2q1v3gUvd0OBebZfjlUQHQwQjS8e+xjYnODY7CAKFHB/upkj0D8zeUuOh7IJYo5Xhl0KDGsG4DbHoSepYYARB5HC9xY9uJFHXrgp6hj0WD/ADFSl/IJUUQe1lc0newV2riugmNXluXullngH9xKpxxv1y0+q4YsWy+IoUSYdMR7lAWzv/8AepiViBfa+5Uw2NQeZbhnGxjUHNzbcv0QAACj/dwvu1iv2aYZVMq1X/Vsi3Wp3F3fC8ytvi4HencB5crEX2AMCR7vNzAubKFsKk1D165o+HVz64hgjevf4hNaWNvJBVjnZvgO1DwEWO2VlsFwj6kz622z8CnvodrPKSF4zzbo5nKYOAApeF7Zp4cXxA/zibtVkP0D/edM24C/1zM6eg2rDs4gtHCmGOpWWWGKSHNwGJAWMKKMc0zY0qFmnrj+INbXg/HLbza59Vg5Xislcfiu0mrIq7YgGrJfNqZR8CHE1VCFKhQNTOopwbkEfccz0cyB8NH+9kEpIUc52/HxNm3cltXg/wAo9HjK0ELyGw5esqHGRg1UR+JkkfBju46NK9s8yrjXgJ5A2fULWLnKHzFHRU0LM2iI2SXVcNHsgjjZvyOb4IS5yVP8k+4AABj/AHylMhSMMHOT3R58RnBszQf2ikoQrF9MEIQx6s1NDfklKMRdE0C1gK2ropTAs0etpEAeWw6Fy0JVE4FIeuUB1qgKD/ftBBaoOB6ZZYfi70bg5wKTvomBcgGbQRQ152p4S+mMe0IIQ0wyhxzBaG2XTe3UUc3KGX2//wABXbYQH9WyknL3L3sPwx0wEEurGIuTKoXOFLg+Us1oddD/APgis7bEjTCCm0hYQaD/AP5Z/wD/2Q==	Conserto de ferramentas elétricas em geral 	Mediante a Realização ou não do serviço, a máquina deverá ser retirada no prazo de 180 dias conforme a PL 2545/22. Contados a partir da realização ou não do serviço.	90	0000	2026-07-23 23:32:28.948+00	2026-07-27 19:39:55.851+00
\.


--
-- TOC entry 3528 (class 0 OID 24691)
-- Dependencies: 224
-- Data for Name: equipment; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.equipment (id, tenant_id, client_id, type, brand, model, serial_number, notes, created_at, updated_at, deleted_at) FROM stdin;
980fc8e7-a3ba-455e-bfd9-669d5e0b097a	c8659485-b234-4723-9681-1e71ee94ac3b	4503d407-55f8-471f-a9f9-52b2e04cf7d6	Serra Mármore	Makita	4100NH	SN-17018	\N	2026-07-23 23:40:48.176011+00	2026-07-23 23:40:48.176011+00	\N
aea36194-c9cc-4e4d-ac28-141549d1849b	c8659485-b234-4723-9681-1e71ee94ac3b	4503d407-55f8-471f-a9f9-52b2e04cf7d6	Furadeira	Bosch	GSB 13 RE	SN-23969	\N	2026-07-23 23:40:48.343753+00	2026-07-23 23:40:48.343753+00	\N
65dd1106-3ddd-4882-aab4-f2ca485c21da	c8659485-b234-4723-9681-1e71ee94ac3b	22dda795-7f60-44b8-b405-c0f9565d4eef	Parafusadeira	DeWalt	DCD796	SN-32532	\N	2026-07-23 23:40:48.503433+00	2026-07-23 23:40:48.503433+00	\N
f1329c35-d35e-4bd5-85e0-cd20d687a563	c8659485-b234-4723-9681-1e71ee94ac3b	22dda795-7f60-44b8-b405-c0f9565d4eef	Esmerilhadeira	Makita	GA4530	SN-48294	\N	2026-07-23 23:40:48.661712+00	2026-07-23 23:40:48.661712+00	\N
1dbd502c-6aa8-4715-9a89-8ce4e83eb5be	c8659485-b234-4723-9681-1e71ee94ac3b	e2b48e4a-89dc-4336-af04-a6344e15a3ba	Serra Tico-Tico	Bosch	GST 650	SN-59253	\N	2026-07-23 23:40:48.819363+00	2026-07-23 23:40:48.819363+00	\N
7a636607-6d19-4110-aa9c-7fa4bb521924	c8659485-b234-4723-9681-1e71ee94ac3b	e2b48e4a-89dc-4336-af04-a6344e15a3ba	Lixadeira	Black+Decker	QS800	SN-63844	\N	2026-07-23 23:40:48.977591+00	2026-07-23 23:40:48.977591+00	\N
3571f89b-39ed-4e4f-bd86-6922492707f6	c8659485-b234-4723-9681-1e71ee94ac3b	7fafefb7-0a24-40a2-b82b-75cc9679e71f	Serra Mármore	Makita	4100NH	SN-18203	\N	2026-07-23 23:41:42.282939+00	2026-07-23 23:41:42.282939+00	\N
cbf10a4f-b031-49e5-9fd4-1b793cf3b05d	c8659485-b234-4723-9681-1e71ee94ac3b	7fafefb7-0a24-40a2-b82b-75cc9679e71f	Furadeira	Bosch	GSB 13 RE	SN-25278	\N	2026-07-23 23:41:42.442849+00	2026-07-23 23:41:42.442849+00	\N
b3ea49d3-208a-4a27-ba1e-d64b866c468a	c8659485-b234-4723-9681-1e71ee94ac3b	a8cbd12f-36a7-45fd-b948-238e5f175c4c	Parafusadeira	DeWalt	DCD796	SN-31446	\N	2026-07-23 23:41:42.605068+00	2026-07-23 23:41:42.605068+00	\N
16379a78-19e1-491f-8f0b-591cfad270aa	c8659485-b234-4723-9681-1e71ee94ac3b	a8cbd12f-36a7-45fd-b948-238e5f175c4c	Esmerilhadeira	Makita	GA4530	SN-46502	\N	2026-07-23 23:41:42.765056+00	2026-07-23 23:41:42.765056+00	\N
0d6203d3-49ee-440e-b0ab-90a6de66ca6e	c8659485-b234-4723-9681-1e71ee94ac3b	28bd5954-4c39-41fc-89d1-5b3443c3a030	Serra Tico-Tico	Bosch	GST 650	SN-53635	\N	2026-07-23 23:41:42.924976+00	2026-07-23 23:41:42.924976+00	\N
f1539efb-cb2a-4462-9018-d331a2a464c9	c8659485-b234-4723-9681-1e71ee94ac3b	28bd5954-4c39-41fc-89d1-5b3443c3a030	Lixadeira	Black+Decker	QS800	SN-69735	\N	2026-07-23 23:41:43.079804+00	2026-07-23 23:41:43.079804+00	\N
b71fa710-bb85-4439-976f-2f4bef2bea1d	c8659485-b234-4723-9681-1e71ee94ac3b	7fafefb7-0a24-40a2-b82b-75cc9679e71f	Serra Mármore	Makita	4100NH	SN-16551	\N	2026-07-23 23:48:08.784659+00	2026-07-23 23:48:08.784659+00	\N
7bc893f7-9ca6-47c9-bd43-644165d7bc44	c8659485-b234-4723-9681-1e71ee94ac3b	7fafefb7-0a24-40a2-b82b-75cc9679e71f	Furadeira	Bosch	GSB 13 RE	SN-23869	\N	2026-07-23 23:48:08.948546+00	2026-07-23 23:48:08.948546+00	\N
cf0b791a-f141-4395-8563-ccf2c7aad200	c8659485-b234-4723-9681-1e71ee94ac3b	a8cbd12f-36a7-45fd-b948-238e5f175c4c	Parafusadeira	DeWalt	DCD796	SN-33456	\N	2026-07-23 23:48:09.108581+00	2026-07-23 23:48:09.108581+00	\N
87b8fce7-ae7f-4c3c-a0b9-85d7c094402e	c8659485-b234-4723-9681-1e71ee94ac3b	a8cbd12f-36a7-45fd-b948-238e5f175c4c	Esmerilhadeira	Makita	GA4530	SN-43603	\N	2026-07-23 23:48:09.270752+00	2026-07-23 23:48:09.270752+00	\N
373cee8c-1dc2-4010-bdf4-133f29c28953	c8659485-b234-4723-9681-1e71ee94ac3b	28bd5954-4c39-41fc-89d1-5b3443c3a030	Serra Tico-Tico	Bosch	GST 650	SN-57399	\N	2026-07-23 23:48:09.430942+00	2026-07-23 23:48:09.430942+00	\N
06dd2dc3-04f2-471c-bf0c-cad9ca81a7a4	c8659485-b234-4723-9681-1e71ee94ac3b	28bd5954-4c39-41fc-89d1-5b3443c3a030	Lixadeira	Black+Decker	QS800	SN-61141	\N	2026-07-23 23:48:09.590543+00	2026-07-23 23:48:09.590543+00	\N
2c76dcad-dfaa-4f7b-8c8e-0d0043c23700	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	491590c4-3257-4ba1-8d68-52b2f139542f	Parafusadeira	DeWalt	DCD777	ESM-3	\N	2026-07-23 23:59:30.706769+00	2026-07-23 23:59:30.706769+00	2026-07-24 16:09:04.857+00
1c66cf0e-24c6-4b42-8558-d192aa718d2e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	e348105d-1a6c-4b34-911c-ef8b74baf29a	Furadeira	Bosch	GSB 550 RE	ESM-2	\N	2026-07-23 23:59:30.552322+00	2026-07-23 23:59:30.552322+00	2026-07-24 16:09:08.51+00
b1c97b68-5084-4aec-9a40-ff5d19b168ac	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	e348105d-1a6c-4b34-911c-ef8b74baf29a	Serra Mármore	Makita	4100NH3	ESM-1	\N	2026-07-23 23:59:30.387113+00	2026-07-23 23:59:30.387113+00	2026-07-24 16:09:11.885+00
f90c8596-5b63-405f-9d59-951ebd4af451	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	5b1cc305-7edb-4b0c-b608-0d64b765e849	Serra Mármore 	Makita	4100NH3			2026-07-24 17:46:30.088097+00	2026-07-24 17:46:30.088097+00	\N
bf88898b-f512-4d48-a1e9-78daa7fde64f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	eb0c392b-6a24-4ec4-84a0-d0729c7e719b	Motocompressor	Schulz	Air Plus 8,5		Versão 1	2026-07-24 17:52:13.02503+00	2026-07-24 17:52:13.02503+00	\N
daebcb85-c3d9-4462-a966-1a47aa20e3f3	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	02c08106-b823-413c-99dc-3018afd8c70c	Serra circular 	Bosch 	GKS130			2026-07-27 14:45:28.388696+00	2026-07-27 14:45:28.388696+00	\N
0a4066df-c59e-4783-8e9d-9fd085f7b72f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	02c08106-b823-413c-99dc-3018afd8c70c	Serra Mármore 	Makita	4100NH3			2026-07-27 14:50:54.094231+00	2026-07-27 14:50:54.094231+00	\N
e582d93f-39e8-477e-9e7a-43817b7804cf	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	02c08106-b823-413c-99dc-3018afd8c70c	Serra Mármore 	Makita	4100NH3			2026-07-27 14:51:16.439502+00	2026-07-27 14:51:16.439502+00	\N
030da74c-3830-4b7f-9fc8-5676785dd808	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	43cb493c-25ec-4657-8393-f937e6576890	Lava-Jato	Karcher 	HD585		Com mangueira 	2026-07-27 14:54:32.858703+00	2026-07-27 14:54:32.858703+00	\N
c29a10bf-79e7-47a0-a10f-8487d7635985	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	72833910-7f5b-4141-8133-dda7e8ff9e12	Lixadeira 	Makita 	SA7000C			2026-07-27 15:31:41.660881+00	2026-07-27 15:31:41.660881+00	\N
7fe8cb25-6427-4201-af7f-4e1666731a47	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	72833910-7f5b-4141-8133-dda7e8ff9e12	Lixadeira 	THAF	000			2026-07-27 15:34:15.76973+00	2026-07-27 15:34:15.76973+00	\N
a54b2776-1afa-4a22-95b4-bc083be6a90b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	4235c814-b03a-42d7-b57d-4589f01f8c1d	Soprador	NSFG	41CC			2026-07-27 15:41:16.796321+00	2026-07-27 15:41:16.796321+00	\N
c62687ec-7631-4c88-b037-beb12f95a4ef	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	7ccccbf4-cd13-420c-8cea-f3d18a2bb956	roçadeira 	Toyama	TBC43X			2026-07-27 15:47:09.519894+00	2026-07-27 15:47:09.519894+00	\N
8bb9f9a7-2b38-4c6d-8dd3-7fcfdc0d9a93	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	f342957a-54f7-4d46-9409-6f3e1d503b4c	Betoneira 	Menegotti	400L			2026-07-27 15:57:15.480322+00	2026-07-27 15:57:15.480322+00	\N
989f6383-78c6-4dac-86c6-f737c0885e4a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	ac66c053-d055-497a-8dbd-28d290142c0d	Lixadeira	Rammer	RTS1			2026-07-27 17:28:28.430806+00	2026-07-27 17:28:28.430806+00	\N
63d84acd-1ac2-4d70-be48-1f7507d115da	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	00e91576-5a07-4227-91da-36560b39b2a7	Motocompressor	Schulz Air Plus	CSA 8,3			2026-07-27 21:12:00.646048+00	2026-07-27 21:12:00.646048+00	\N
d99c6c58-ef5b-48a4-8795-71497eeb42f9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	5ad6797d-488f-4e61-aaa0-ea9667f0aafd	Furadeira 	Dewalt	Dw508s			2026-07-28 12:06:33.473803+00	2026-07-28 12:06:33.473803+00	\N
05f2650f-3838-4698-98ec-dd8badb2043e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	7384934f-2bcf-4f85-83b0-dcf623c6ed22	Serra Mármore 	Makita 	4100Nh3			2026-07-28 12:22:45.147218+00	2026-07-28 12:22:45.147218+00	\N
4e0e02fd-9e57-4052-8b53-0bb76eec9376	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	ced6073a-0a5d-47a8-8e32-50a3eee914b4	Roçadeira 	Sthil	FS80			2026-07-28 12:32:13.139994+00	2026-07-28 12:32:13.139994+00	\N
7b35c70a-e85b-4e90-bf4d-3145e1329b1c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	de143cae-013d-467e-910a-3d5d564cbd25	Serra Mármore	Dewalt	DW862 110V~			2026-07-28 13:59:37.433054+00	2026-07-28 13:59:37.433054+00	\N
374f14ee-671c-4ba6-aa4b-0e34d34fa972	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	9c5e19ac-6e8f-49b0-ab49-ba71a0eca09e	serra 	makita	33			2026-07-28 14:18:02.86876+00	2026-07-28 14:18:02.86876+00	\N
66c8a777-ae14-4106-b746-16c66341c2ae	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	6314dfad-9a56-4185-b353-f10769b0c2de	furadeira	Dewalt	508			2026-07-28 14:22:33.620396+00	2026-07-28 14:22:33.620396+00	2026-07-28 14:51:25.314+00
57ab79bf-cc18-4101-a0ad-9bc28c294ab5	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	0d66cd3e-0f02-4c63-bd34-1973ca26c673	Lava Jato	Philco	00			2026-07-28 14:45:37.569104+00	2026-07-28 14:51:47.521+00	\N
a728f253-4050-4773-891c-4ae2727fcc9e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	6d750b5a-f4e2-43d6-94cf-3d2af5c748da	Esmerilhadeira 	Makita 	Sem iD			2026-07-28 15:07:09.775558+00	2026-07-28 15:07:09.775558+00	\N
776cd238-c677-4e11-a7e0-61d3480ebc56	c8659485-b234-4723-9681-1e71ee94ac3b	716204a4-7981-48e9-9126-2a9b0239bd9a	Furadeira	Bosch	GSB 550 RE	FUR001	\N	2026-07-28 15:20:30.544406+00	2026-07-28 15:20:30.544406+00	\N
2098f18d-950d-49e9-990a-3e9b15535414	c8659485-b234-4723-9681-1e71ee94ac3b	716204a4-7981-48e9-9126-2a9b0239bd9a	Esmerilhadeira	DeWalt	DWE4020	ESM002	\N	2026-07-28 15:20:30.712328+00	2026-07-28 15:20:30.712328+00	\N
33e8473e-137f-42e8-8898-f484504c1dde	c8659485-b234-4723-9681-1e71ee94ac3b	716204a4-7981-48e9-9126-2a9b0239bd9a	Serra Circular	Makita	HS7010	SER003	\N	2026-07-28 15:20:30.867559+00	2026-07-28 15:20:30.867559+00	\N
3b381e2f-2d18-45be-a6e7-775fa738405c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	ba75cd9b-9850-45a5-9432-af409ee947f4	Lava-Jato	Wap valente	110 V		Com Pistola e mangueira	2026-07-28 15:54:54.584173+00	2026-07-28 15:54:54.584173+00	\N
33869a61-ed4a-4c11-8521-551f60818d74	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	f3e9be14-3b81-430d-be5f-2ad8c119921a	Esmerilhadeira 	Dewalt 	DW4120			2026-07-28 17:38:16.014144+00	2026-07-28 17:38:16.014144+00	\N
cfd80404-90bd-4d88-911f-fcc53fab471b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	f3e9be14-3b81-430d-be5f-2ad8c119921a	Esmerilhadeira 	Makita	Ga4530			2026-07-28 17:39:50.076187+00	2026-07-28 17:39:50.076187+00	\N
58f3b994-18cb-41a4-b635-2bfb9de13be2	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	f3e9be14-3b81-430d-be5f-2ad8c119921a	Martelete 	Makita 	HR2470 	N1		2026-07-28 17:42:15.857414+00	2026-07-28 17:42:15.857414+00	\N
fa4ed6b3-3b0e-41b6-a40b-6ed578120050	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	f3e9be14-3b81-430d-be5f-2ad8c119921a	Martelete 	Makita 	HR2470 	N2		2026-07-28 17:42:28.826434+00	2026-07-28 17:42:28.826434+00	\N
b342df4a-3cc4-4c06-ab83-08cd870876b6	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	f3e9be14-3b81-430d-be5f-2ad8c119921a	Pistola à pólvora	HILT	DX36			2026-07-28 17:43:06.37422+00	2026-07-28 17:43:06.37422+00	\N
b253db30-4fde-4039-939f-1b6fcebaa35e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	f3e9be14-3b81-430d-be5f-2ad8c119921a	Martelo	Bosch	GSH 11e			2026-07-28 17:43:34.543756+00	2026-07-28 17:43:34.543756+00	\N
2b9e466b-5a6a-4490-9c7b-02a1958e57b2	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	bbb53896-df27-4535-9a0f-6c6abf577352	Lava-Jato	Karcher	K5			2026-07-28 18:04:08.457514+00	2026-07-28 18:04:08.457514+00	\N
e0d14fd4-7b30-4c95-93e3-9d4e9a0fdd4e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	3cf92c8a-0fe5-40a8-80dc-5b8a8860d9c5	Roçadeira de Carrinho	Sem Identificação	110 V			2026-07-28 18:58:00.580181+00	2026-07-28 18:58:00.580181+00	\N
310dab71-9f32-44d4-b445-56d88d1ef3c8	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	cbe54fe3-9203-4718-beb7-766185ffa927	Martelete 	Bosch 	GBH 2-24D 110v			2026-07-28 19:23:16.882992+00	2026-07-28 19:23:16.882992+00	\N
8537df66-f52e-4826-a47e-f2d7a3343b4e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	72833910-7f5b-4141-8133-dda7e8ff9e12	Politriz 	Makita 	SA7021	127v		2026-07-28 19:16:46.300777+00	2026-07-31 14:19:43.906+00	\N
d4b83c29-e64b-496b-92e2-fd1d2370897d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	e40eb094-6f78-428a-8d4a-a376dbf222e7	politriz 	makita 	sd			2026-07-28 19:04:53.227708+00	2026-07-28 19:04:53.227708+00	2026-07-31 14:19:54.924+00
11361a7e-a079-4707-bf14-abbc032faf5b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	5ce60189-4263-423d-a1e4-d166baf66a8b	Martelete 	Dewalt 	D25123			2026-07-28 19:30:12.64483+00	2026-07-28 19:30:12.64483+00	\N
a613292e-1a80-49cd-9090-a98e7bb8b684	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	5ce60189-4263-423d-a1e4-d166baf66a8b	Parafusadeira 	ZGM	Sem iD		Sem bateria e carregador 	2026-07-28 19:39:26.255906+00	2026-07-28 19:39:26.255906+00	\N
4b9c55c4-b36d-48a6-9d44-cfc59b1998c8	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	005f0c88-f77f-4e8e-b079-06881fa72685	Motosserra 	Husqvarna 	125			2026-07-28 19:53:08.558518+00	2026-07-28 19:53:08.558518+00	\N
be7e4569-aaa6-4b7e-86bd-34ad75a8e35e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2460faab-37f1-414b-b8e9-dd8988814f41	Extratora 	WAP	Carpete Cleaner Pro 30		Há um ano o cliente trocou o rolamento.	2026-07-28 21:28:25.858738+00	2026-07-28 21:28:25.858738+00	\N
877da309-3101-4c5f-b5e3-a3c1e88d0c48	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2460faab-37f1-414b-b8e9-dd8988814f41	Lixadeira 	Dewalt 	DW411	127v		2026-07-28 21:32:49.191515+00	2026-07-28 21:32:49.191515+00	\N
fc1ba4bd-4aef-4fa2-a4d6-924104b19d8d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2460faab-37f1-414b-b8e9-dd8988814f41	Serra Mármore 	Makita 	4100NS	127v		2026-07-28 21:33:19.725846+00	2026-07-28 21:33:19.725846+00	\N
2f57a156-0576-4456-b1ce-fe74c9c0b951	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	33cbc579-810b-4435-9288-40fbd66a12ca	Martelete 	Bosch 	GBH 2-24D 220v			2026-07-29 12:29:04.086135+00	2026-07-29 12:29:04.086135+00	\N
618bf32a-97d2-4263-8c6c-d54369b66137	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	8b2a2b71-c47b-45ba-a8ce-1cbbc2b633f7	Serra de bancada 	Black in deker	Sem iD			2026-07-29 14:16:42.02865+00	2026-07-29 14:16:42.02865+00	\N
96f15645-e70f-462f-82f9-ec7abadae1e5	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	8b2a2b71-c47b-45ba-a8ce-1cbbc2b633f7	Serra de bancada 	Black in deker	BDTS1800 Tipo 2 110v		Com lamina, sem paralelo	2026-07-29 14:29:43.369165+00	2026-07-29 14:29:43.369165+00	\N
6b5570e2-0b1c-40e1-b3e4-5d178c3274a5	c8659485-b234-4723-9681-1e71ee94ac3b	3b58b228-0e27-4954-9d00-27e58035562f	Furadeira	Bosch	GSB 13 RE	TEST-OLD-1785341753363-1	\N	2026-07-29 16:15:53.489579+00	2026-07-29 16:15:53.489579+00	\N
eac013b0-7059-4af1-b5c6-3bad35d954fa	c8659485-b234-4723-9681-1e71ee94ac3b	3b58b228-0e27-4954-9d00-27e58035562f	Serra Mármore	Makita	4100NH	TEST-OLD-1785341753705-2	\N	2026-07-29 16:15:53.831787+00	2026-07-29 16:15:53.831787+00	\N
a3dab0f4-e016-4dc9-8651-d5d629786285	c8659485-b234-4723-9681-1e71ee94ac3b	3b58b228-0e27-4954-9d00-27e58035562f	Esmerilhadeira	DeWalt	DWE4020	TEST-ABANDONED-1785341754029	\N	2026-07-29 16:15:54.155751+00	2026-07-29 16:15:54.155751+00	\N
9204e5e9-91de-4564-816a-bd0699b508d6	c8659485-b234-4723-9681-1e71ee94ac3b	3b58b228-0e27-4954-9d00-27e58035562f	Parafusadeira	Black+Decker	LD120	TEST-ABANDONED-1785341754348-2	\N	2026-07-29 16:15:54.473739+00	2026-07-29 16:15:54.473739+00	\N
b88831aa-0635-4d2e-b9b9-148baef6aa36	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	32c9c508-f81d-46d5-b96a-b9d4e7143728	Martelete 	Bosch 	PBH 160			2026-07-29 17:50:55.506748+00	2026-07-29 17:50:55.506748+00	\N
cf66fa44-3aeb-4194-8b11-f3d145c31c4f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	c0984895-5dfa-4663-9816-469fabb70000	Lixadeira 	Kaqi	Sem iD			2026-07-29 20:11:48.492759+00	2026-07-29 20:11:48.492759+00	\N
c21c05d9-664d-4f55-978d-13bdd2b6a56a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	c0984895-5dfa-4663-9816-469fabb70000	Lava-Jato	Karcher 	K3.30		Quando desliga na pistola o motor continua fazendo barulho.	2026-07-29 20:20:25.359083+00	2026-07-29 20:20:25.359083+00	\N
0d9d7be7-c3ca-4d66-b1f0-9532807a345c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	daea5356-7032-4c55-88ae-1a6e55a8609c	Furadeira 	Makita 	Sem iD			2026-07-29 20:22:13.403025+00	2026-07-29 20:22:13.403025+00	\N
89fe6fd6-1cfe-4c85-8682-b2ed14ee0345	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	c7ae6402-2cb9-4a7e-baa5-4f8efb54262f	Traçador 	Stanley	Sem iD			2026-07-29 20:27:20.597613+00	2026-07-29 20:27:20.597613+00	\N
35ea8557-f5f1-47ec-a648-da91ab1cedf1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	daea5356-7032-4c55-88ae-1a6e55a8609c	Furadeira 	Makita 	HP1640 110v			2026-07-29 20:35:55.724977+00	2026-07-29 20:35:55.724977+00	\N
c602c8b2-4791-45b1-a72b-d31be3cdeb94	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2d019df4-3df6-4ef8-86ba-891dcb5e9ce2	Lixadeira 	Desoon	DSOS300 110v			2026-07-29 20:37:57.527696+00	2026-07-29 20:37:57.527696+00	\N
1420fd83-2554-4ec1-b69d-181a9df898c1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	fa625623-4d8e-4401-866a-2d2050a7765c	Soprador 	Carbon	FAK260S			2026-07-30 12:08:43.61612+00	2026-07-30 12:08:43.61612+00	\N
e089613c-e373-48af-8fd1-1ebd3ddf4170	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	8c12838f-9ad9-4c47-9e04-0fd8f5076994	Soprador 	Carbon	FAK260S			2026-07-30 12:12:28.289202+00	2026-07-30 12:12:28.289202+00	\N
d445c718-9333-410d-8dae-aee1c5e80272	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	d1d9d7c0-a55a-4474-b829-8e37461d9fe5	Guincho de coluna 	Sem ID	Sem iD			2026-07-30 12:46:21.61731+00	2026-07-30 12:46:21.61731+00	\N
2db690b1-a051-40ef-ba93-050f32768b6a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	d1d9d7c0-a55a-4474-b829-8e37461d9fe5	Guincho de coluna 	Guincho	Sem iD			2026-07-30 12:50:12.687588+00	2026-07-30 12:50:12.687588+00	\N
eeffe976-6760-478b-bd3a-a3ecd76061ed	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	fcbcb142-6e9f-4961-9350-b121fb78738b	Serra Mármore 	Makita 	4100NH3 127v			2026-07-30 14:53:04.439767+00	2026-07-30 14:53:04.439767+00	\N
b7e57d1f-ea49-4f07-be61-2a8704643cd2	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	fcbcb142-6e9f-4961-9350-b121fb78738b	Serra Mármore 	Black e Dacker 	BD115 127v			2026-07-30 15:06:42.517389+00	2026-07-30 15:06:42.517389+00	\N
94bdb0fb-dc87-4591-b4e5-07f322aa1319	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	5a6976ee-6988-4a2d-9783-abef84c22375	Lixadeira 	Dewalt	DWE 6411 127V			2026-07-30 15:19:36.931511+00	2026-07-30 15:19:36.931511+00	\N
09e1bbad-56c8-47d2-a376-cabee91512b3	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	5a6976ee-6988-4a2d-9783-abef84c22375	Esmerilhadeira 	Dewalt	DW4120 	127v		2026-07-30 15:22:58.392714+00	2026-07-30 15:22:58.392714+00	\N
cdcbf203-d9b8-42ea-85e5-1036a3510a08	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	5a6976ee-6988-4a2d-9783-abef84c22375	Furadeira 	Makita 	HP1640 	220v		2026-07-30 15:23:35.744558+00	2026-07-30 15:23:35.744558+00	\N
57286ec7-140a-41a8-817d-6caeea5c58d6	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	ad48afdb-0fbd-419d-94dd-50efadb169d4	Cortadora de Grama 	Trapp	LS30P			2026-07-30 15:35:47.711811+00	2026-07-30 15:35:47.711811+00	\N
3d06fef0-7c8f-42be-89e8-62d57dbb9ccd	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	ad48afdb-0fbd-419d-94dd-50efadb169d4	Motor Lava-Jato	Lavor 	Magnum			2026-07-30 15:40:31.120935+00	2026-07-30 15:40:31.120935+00	\N
73b25273-08f4-4d1f-9e5e-46884eff131d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	0fb9604a-9ed4-456a-b014-745c0f0e34d5	Esmerilhadeira 	Bosch	00			2026-07-30 15:53:15.274896+00	2026-07-30 15:53:15.274896+00	\N
79694a12-054e-4c95-ad60-ff85fea17cc5	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	0fb9604a-9ed4-456a-b014-745c0f0e34d5	Serra Circular 	Dewalt	DWE560 	127v		2026-07-30 15:59:10.820664+00	2026-07-30 15:59:10.820664+00	\N
eb48cbd3-38a0-48e0-8ef4-eeceb4e1f5a7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	0fb9604a-9ed4-456a-b014-745c0f0e34d5	Plaina	Makita 	N1900B 	220v		2026-07-30 15:59:52.770766+00	2026-07-30 15:59:52.770766+00	\N
c2012e80-d3d1-4739-a0be-d1b0dbeb2b30	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	bdcafd51-6adb-4361-a45c-9e76f63f947c	Soprador 	Sthil 	BGE71			2026-07-30 20:29:11.358281+00	2026-07-30 20:29:11.358281+00	\N
4a03e180-e336-4f92-9f60-b21b3205661d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	de252bde-1b36-4120-9ec6-79f0fc854287	Serra Mármore 	Makita 	4100Nh2 127v			2026-07-31 11:42:12.304798+00	2026-07-31 11:42:12.304798+00	\N
a28a4794-bff0-428a-9fc0-b02792b99e4b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	e40eb094-6f78-428a-8d4a-a376dbf222e7	Politriz 	Makita 	SA7021	127v		2026-07-28 19:11:58.882933+00	2026-07-31 14:19:13.056+00	2026-07-31 14:20:02.24+00
0b3f5e33-f494-4ea4-9326-7d147f298be0	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	4c5c36c6-0594-445c-af0d-83e45bad0fa3	Serra Mármore 	Ecosen	110v			2026-07-31 15:48:47.823077+00	2026-07-31 15:48:47.823077+00	\N
0055b8fb-1577-4f8b-bd00-2b08fc353175	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	1028f9ae-f12a-41b1-b28d-29322a1beb76	Roçadeira 	Tramontina	300W			2026-07-31 18:03:28.652979+00	2026-07-31 18:03:28.652979+00	\N
9d8dc01b-4b63-47a3-9e9b-59a7e3d0e2cb	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	1028f9ae-f12a-41b1-b28d-29322a1beb76	Carregador de bateria 	Dewalt	DCB100		Colocar um cabo de força	2026-07-31 18:15:52.57961+00	2026-07-31 18:15:52.57961+00	\N
18b02716-92c6-483d-a5c4-37e25f56b5d8	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	51f35478-f3c3-412c-ad60-de472ab1484b	Lava Jato	Tramontina 	Master 1900			2026-08-01 13:25:18.637052+00	2026-08-01 13:25:18.637052+00	\N
775459c9-f535-4992-823b-30fb7a1b4f61	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	61eb8a2d-5ea5-468d-a2e8-e99284504c62	Politriz 	Dewalt	DWP849X Tipo 1 110v			2026-08-03 11:48:44.165311+00	2026-08-03 11:48:44.165311+00	\N
f22ec215-bda9-4140-97a7-c5180a96c9e5	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	a1c5f1de-64d6-48c2-af16-f800465124b9	Lava-Jato	Jactor	6200			2026-08-03 12:20:00.980612+00	2026-08-03 12:20:00.980612+00	\N
3ba2fe0b-6b86-4bc1-8b86-753c0ffe4175	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	a6510644-5be1-40ef-adc6-e5e99891c0dd	Furadeira 	Dewalt	Dw508s			2026-08-03 12:40:51.749645+00	2026-08-03 12:40:51.749645+00	\N
d8462256-2e7c-448f-8772-7b8922aa37b1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	b8b5da0e-05d5-4e8e-8c08-c0f265d3f42c	Traçador 	Dewalt	DWE560 			2026-08-03 14:36:02.058497+00	2026-08-03 14:36:02.058497+00	\N
058ccfd1-f736-4df6-b520-b248fc8f6600	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	ee6e8dd3-896a-413b-9b0d-20e6bd9dcd79	Martelo 	Dewalt	D25481 B2	220v		2026-08-03 14:40:36.585152+00	2026-08-03 14:40:36.585152+00	\N
c8557f12-d100-41b8-9c0e-fdb4db1bf09a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	54c9ba13-d8e9-4151-9b3c-bae9c598cdee	Lava-Jato	Bosch 	GHP180 127V			2026-08-03 15:25:29.126599+00	2026-08-03 15:25:29.126599+00	\N
121a47fc-fc01-4068-9fe7-fe479c52ef16	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	08f5f4f7-b334-42a8-88f4-7379b267d01c	Martelete 	Stanley	Sem iD			2026-08-03 15:48:41.580205+00	2026-08-03 15:48:41.580205+00	\N
0264cc41-fcef-46cd-88a6-6b82df978f05	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	08f5f4f7-b334-42a8-88f4-7379b267d01c	Martelo	Makita 	HMO870C 		Não liga	2026-08-03 16:03:21.829855+00	2026-08-03 16:03:21.829855+00	\N
d912ebe8-fb46-4fc2-a965-65a97247211b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	0aaef31d-edb4-41a4-bc12-c50977730963	Martelete 	Makita 	HR2470  220v			2026-08-03 17:29:52.663924+00	2026-08-03 17:29:52.663924+00	2026-08-03 17:30:41.772+00
ff4f72f0-1674-4680-8386-83f13ad499d2	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	0aaef31d-edb4-41a4-bc12-c50977730963	Martelete 	Makita 	HR2470 220v			2026-08-03 15:57:15.62489+00	2026-08-03 15:57:15.62489+00	2026-08-03 17:33:02.681+00
4615a96b-5ee5-4ac2-bda0-e87623b3c140	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	08f5f4f7-b334-42a8-88f4-7379b267d01c	Martelete 	Makita 	HR2470  220v			2026-08-03 17:33:30.849054+00	2026-08-03 17:33:30.849054+00	\N
f5517930-f950-4c02-967a-092bfe10629e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2d9486a9-74e9-4a70-8205-04fe791da471	Parafusadeira 	Dewalt	DCD7781		Sem bateria 	2026-08-03 18:15:38.673277+00	2026-08-03 18:15:38.673277+00	\N
16a2a95b-8097-4dcc-ac24-f667dd04fc14	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	b727602c-6f4b-4320-88cb-2a2f2257224d	Esmerilhadeira 	Tipo Dewalt	127v			2026-08-03 18:35:52.267299+00	2026-08-03 18:35:52.267299+00	\N
5cde60c5-b8cb-4aae-a23c-3d79f95cbc5d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	c36ec798-9741-47ed-9023-5bf16a351310	Parafusadeira 	HuaHuo	00		Com bateria	2026-08-03 19:28:12.077681+00	2026-08-03 19:28:12.077681+00	\N
56b4a694-ef71-4ce7-a5c1-e081dd9f4f8b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	a41d03ee-47e6-482a-a4cb-dde0a146a80f	Esmerilhadeira 	Dewalt	DWE4020	127v		2026-07-30 19:49:44.261913+00	2026-08-03 19:34:07.603+00	\N
14f644b2-11d3-46fb-b86a-daf7b1ffa6a6	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	e1b5efb0-6686-4fdf-931b-fe77ccbf90e0	Soprador 	Stanley 	STPT600	127v		2026-08-03 19:47:36.774857+00	2026-08-03 19:47:36.774857+00	\N
1d70a0cc-b731-422c-8710-a497c50913f7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2f600557-66e4-4a2e-b4eb-9186657fd5b9	Lava-Jato	Jactor	J6800 110v			2026-08-03 20:51:43.196836+00	2026-08-03 20:51:43.196836+00	\N
dea115f9-de5a-43ab-8ffd-3f49c45ef083	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	cbe54fe3-9203-4718-beb7-766185ffa927	Esmeril 	Sem ID 127v	Alavanca			2026-08-04 15:09:35.589951+00	2026-08-04 15:09:35.589951+00	\N
81ad8d89-b6a8-488c-a7b8-095dbe9a6800	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	cbe54fe3-9203-4718-beb7-766185ffa927	Esmeril 	Sem ID 127v	Interruptor			2026-08-04 15:02:10.499453+00	2026-08-04 15:10:19.595+00	\N
73efcf3a-a7e7-4f38-aff3-db4a164c782f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	4c5c36c6-0594-445c-af0d-83e45bad0fa3	Martelete 	Branco	127v			2026-08-04 15:15:01.632629+00	2026-08-04 15:15:01.632629+00	\N
c8596a07-6618-4689-9808-cd05c97a1492	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2844c1c6-fad3-42c7-81ab-1b32dd636bff	Lavadora de pressão 	Chiaperini 	LJ 14L			2026-08-04 18:07:26.946934+00	2026-08-04 18:07:26.946934+00	\N
f7407048-5647-4f47-8246-61b51e441952	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	f3e9be14-3b81-430d-be5f-2ad8c119921a	Parafusadeira 	Bosch 	GSB 1200-2-LI			2026-08-04 18:31:35.445481+00	2026-08-04 18:31:35.445481+00	\N
d9a6d5c5-6126-4c50-ab76-06ddc7862185	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	43469404-5d50-4bd6-8d99-20e7149d0625	Martelete 	HILT	TCH 900			2026-08-05 11:58:09.262589+00	2026-08-05 11:58:09.262589+00	\N
51995bde-3a0f-4f1b-828d-1bb06094b115	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	91d59fb5-467b-4c8f-8bff-c86d5228ff55	Plana	Black in deker	7698-br 110v			2026-08-05 12:22:38.297007+00	2026-08-05 12:22:38.297007+00	\N
0bb03cc8-b88e-483a-98b5-027f3b72b83e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	43469404-5d50-4bd6-8d99-20e7149d0625	Martelete 	Einhell	TC-RH 900/1	127v		2026-08-05 14:25:17.796378+00	2026-08-05 14:25:17.796378+00	\N
3d5318f5-7b66-4f9a-a65e-2847c2854a93	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	7c0d2ac4-9c4a-42fc-ad9a-589351fe76cf	Lava-Jato	WAP	Eco Fit 2200 	127v		2026-08-05 14:34:10.270373+00	2026-08-05 14:34:10.270373+00	\N
55ec651d-7359-4a0c-b8ff-556964070e73	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	5a6976ee-6988-4a2d-9783-abef84c22375	Lixadeira 	Makita 	M9200  220v	220v		2026-08-05 19:27:57.6253+00	2026-08-05 19:27:57.6253+00	\N
fc6e07b8-9a09-4996-9c93-6afa5a1313ee	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	5a6976ee-6988-4a2d-9783-abef84c22375	Lixadeira 	Dewalt	DWE6411-br Tipo 10	127v		2026-08-05 19:32:06.843492+00	2026-08-05 19:32:06.843492+00	\N
94094687-8948-4615-b12b-a84501d852f3	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	5a6976ee-6988-4a2d-9783-abef84c22375	Lixadeira 	Dewalt	DWE6411-br Tipo 10	127v		2026-08-05 19:32:57.519675+00	2026-08-05 19:32:57.519675+00	\N
2c652e3a-9c45-4169-833d-f969842f6a86	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	5a6976ee-6988-4a2d-9783-abef84c22375	Lixadeira 	Dewalt	DWE6411-br Tipo 10	127v		2026-08-05 19:33:15.687987+00	2026-08-05 19:33:15.687987+00	\N
c585906c-5a8f-433b-a54c-15c440579375	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	f7f561cf-db2d-4cac-ae5b-93464cb24478	Soprador 	Sthil	BG86			2026-08-05 20:01:16.736589+00	2026-08-05 20:01:16.736589+00	\N
1d7004b6-7780-4830-a849-3395280b0afa	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	b8b5da0e-05d5-4e8e-8c08-c0f265d3f42c	Traçador 	Dewalt	DWE 560 	220v		2026-08-05 20:51:09.764403+00	2026-08-05 20:51:09.764403+00	\N
2ea3b9f4-82fd-4811-a1f1-076dd1c1ef30	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	b8b5da0e-05d5-4e8e-8c08-c0f265d3f42c	Furadeira 	Dewalt	DWD502 tipo 4	220v		2026-08-05 20:54:42.049141+00	2026-08-05 20:54:42.049141+00	\N
e4b16552-4d9c-4b1a-bd5b-88e832a4cdf2	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	b8b5da0e-05d5-4e8e-8c08-c0f265d3f42c	Martelete 	Wesco	Sem iD			2026-08-05 21:00:42.328167+00	2026-08-05 21:00:42.328167+00	\N
ddd0dfeb-d439-484b-8cb6-4e962a0b9149	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	0c1dd29e-f9de-400e-8a38-2f892eb5ff47	Martelete 	Makita 	HR2470 	127v		2026-08-06 13:08:32.860836+00	2026-08-06 13:08:32.860836+00	\N
376cd1ed-1d84-42ff-95fe-0791d970377d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	b727602c-6f4b-4320-88cb-2a2f2257224d	Furadeira 	Makita 	Kp1210	127v		2026-08-06 18:28:04.221966+00	2026-08-06 18:28:04.221966+00	\N
6850d938-e5bd-4af2-9624-73f179a4ad34	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	6773f1ca-eca1-4b81-af32-0cd378e46029	Lava Jato 	Wap 	Lider 2200	127v		2026-08-06 18:34:09.756928+00	2026-08-06 18:34:09.756928+00	\N
f1413bec-dd88-4da0-b046-e17e509d4638	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	6d251427-82ba-49f2-9ff3-5ea16132fd31	Lava Jato 	Black e Dacker 	Pw2000	127v		2026-08-06 19:07:58.286546+00	2026-08-06 19:07:58.286546+00	\N
5f3353b3-d137-4567-adc8-88683d7b3c32	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	286cc1b2-56e9-4f30-a86a-180f5f76f679	Serra mármore 	Makita 	4100NH3	127v		2026-08-06 19:29:45.013561+00	2026-08-06 19:29:45.013561+00	\N
0810c0b7-a886-4946-9518-8bdc36f81446	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	585f5754-0cc4-48da-95eb-f5aa1c5a18d4	Roçadeira 	Sthil	Fs120			2026-08-06 19:47:40.699354+00	2026-08-06 19:47:40.699354+00	\N
e4fc453b-ce70-4fc1-9ba4-186d9202d582	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	58e98858-df83-4786-840a-9f17793767a9	Serra mármore 	Makita 	4100NH3	220v		2026-08-07 13:16:26.765994+00	2026-08-07 13:16:26.765994+00	\N
71791cd2-377a-42af-86be-3b376d125298	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	61eb8a2d-5ea5-468d-a2e8-e99284504c62	Politriz 	Dewalt	DWP849X-BR Tipo 10	127v		2026-08-07 13:34:34.84283+00	2026-08-07 13:34:34.84283+00	\N
a8d69cb2-e9fb-43a7-8af9-94d4e1a2b328	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	ad48afdb-0fbd-419d-94dd-50efadb169d4	Furadeira 	Dewalt 	DW508S	127v		2026-08-07 14:08:55.455804+00	2026-08-07 14:08:55.455804+00	\N
a4499afb-3f75-41f0-9ec3-d05650b5e2e1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2a65b2fb-d1db-46d3-a786-64fd38b7942f	Serra mármore 	Dewalt 	DW860 tipo 1	127v		2026-08-07 15:06:52.969854+00	2026-08-07 15:06:52.969854+00	\N
2fa80089-f843-437b-a279-2c9a54bb8a4c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	6339933e-c4ea-4872-aa2c-d994b9ce3584	Compressor 	Schulz	Motor triásico			2026-08-07 17:33:20.878157+00	2026-08-07 17:33:20.878157+00	\N
9556964e-dc3b-4734-b5e0-068dc8006873	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	6339933e-c4ea-4872-aa2c-d994b9ce3584	Compressor 	Schulz	Motor  Trifásico			2026-08-07 17:39:20.136522+00	2026-08-07 17:39:20.136522+00	\N
5a881071-7df4-475d-b52a-6ae65e436697	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	6abd1720-bcbc-4a30-9d39-6a3fd2122e7c	Martelete 	Einhell	TC-RH 900/1	127v		2026-08-07 17:46:11.580617+00	2026-08-07 17:46:11.580617+00	\N
4e4abec3-9523-469a-a59f-76776c9864fb	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	04b89c89-6035-43e9-aac8-04962f87d879	Extratora 	ENW	ENW	127v		2026-08-07 18:53:41.583027+00	2026-08-07 18:53:41.583027+00	\N
6b4a1843-d64f-473e-9ac8-f83844059d5c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	803f2cee-aebd-43ef-802b-fbc729089cba	Parafusadeira 	Dewalt	DCD7781	230491		2026-08-07 20:47:21.78811+00	2026-08-07 20:47:21.78811+00	\N
a0c69621-78e6-4242-8982-d17e6b5f60f6	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	0122a7ca-f7d9-46c4-8e29-0057a2c5ff77	Martelo	Dewalt	D25481	220v		2026-08-07 21:11:55.511841+00	2026-08-07 21:11:55.511841+00	\N
3eafeed1-38fd-423f-825a-24a1e4468186	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	4523c826-c75e-469c-9c1c-f8363b8d1399	Martelo	Dewalt	D25481	220v		2026-08-07 21:20:43.523971+00	2026-08-07 21:20:43.523971+00	\N
0eda729c-8866-4151-b035-e5d9bca461b8	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	4523c826-c75e-469c-9c1c-f8363b8d1399	Esmerilhadeira 	Makita 	Ga4530	127v		2026-08-07 21:26:27.036351+00	2026-08-07 21:26:27.036351+00	\N
a61ac08e-6337-413c-8ce2-afbd07151449	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	4523c826-c75e-469c-9c1c-f8363b8d1399	Lixadeira 	Makita 	9910	127v		2026-08-07 21:30:09.292459+00	2026-08-07 21:30:09.292459+00	\N
6427a22e-d5e3-4ea8-8244-dc70951dd495	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	4523c826-c75e-469c-9c1c-f8363b8d1399	Esmerilhadeira Angular	Makita 	SA7000C	127v		2026-08-07 21:35:27.848353+00	2026-08-07 21:35:27.848353+00	\N
0a6c48f4-b1d2-4447-a36f-b832e176e035	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	d7df166d-9b91-4bdb-a519-416da5749d53	Esmerilhadeira 	Stanley	Sem iD 127V			2026-08-08 13:15:44.809711+00	2026-08-08 13:15:44.809711+00	\N
4846473f-40a0-4de3-a6d7-a51e54df2e96	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	12f0a5b3-e339-4cb1-8515-765765433e0f	Motocompressor	Chiaperine 	MC7.6			2026-08-08 13:47:50.825738+00	2026-08-08 13:47:50.825738+00	\N
78ba74d5-77fb-467b-b698-51f95ce0e789	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	bc3296ab-2800-49ff-82ae-3e18868b9b78	Aspirador de Pó	WAP	GTW 20	127v		2026-08-08 14:33:47.0656+00	2026-08-08 14:33:47.0656+00	\N
305bbe90-33f7-46fb-9c0c-3218c1257ba0	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	7a400294-a24d-4af7-865c-98471e92dfef	Traçador 	Dewalt	DWE560 B2 tipo 11	220v		2026-08-10 11:49:14.948769+00	2026-08-10 11:49:14.948769+00	\N
7c2ecabc-6f5e-4890-8fa7-a0aa1e34d36d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	7a400294-a24d-4af7-865c-98471e92dfef	Martelete 	Makita 	HR2470 	127v		2026-08-10 11:56:25.280243+00	2026-08-10 11:56:25.280243+00	\N
189030c4-b419-41e5-b28c-e7a3064ae8e5	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	7a400294-a24d-4af7-865c-98471e92dfef	Martelo 	Stanley	Sem iD	220v		2026-08-10 11:58:29.620232+00	2026-08-10 11:58:29.620232+00	\N
4245e93c-13be-4ee2-a4d2-acbf5b9fcd5c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	e97a2ab0-58e1-4bec-bd79-3999dffa351d	Motocompressor	Schulz	CSA 8,2			2026-08-10 13:41:27.598878+00	2026-08-10 13:41:27.598878+00	\N
1a411b38-283d-4e74-9f0e-37d866b0b999	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	234e738c-9db5-4494-a7a6-cca5e0357ee1	Furadeira 	Bosch	Magnum 	127v		2026-08-10 18:03:35.128397+00	2026-08-10 18:03:35.128397+00	\N
d2ffafdf-834d-4519-9272-0cd6e7cd837e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	89c8d185-2089-42f1-99e2-cc516300e786	Lava Jato	Britana 	BLA2400	127v		2026-08-10 19:29:01.974329+00	2026-08-10 19:29:01.974329+00	\N
c68d9901-89e6-457f-a65b-9b4341f76af4	c8659485-b234-4723-9681-1e71ee94ac3b	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	Furadeira	Bosch	GSB 13 RE	SN1786403013523788	\N	2026-08-10 23:03:33.524+00	2026-08-10 23:03:33.524+00	\N
953d6e02-30ac-4d4f-b137-1df5dfc31360	c8659485-b234-4723-9681-1e71ee94ac3b	32179aea-8524-4cfd-a67d-51c69bd54f4b	Policorte	Dewalt	D28730	SN1786403014294924	\N	2026-08-10 23:03:34.294+00	2026-08-10 23:03:34.294+00	\N
6e43aed4-21b9-40d6-a12f-d9ae29dd4c9a	c8659485-b234-4723-9681-1e71ee94ac3b	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	Plaina	Makita	KP0800	SN1786403014901956	\N	2026-08-10 23:03:34.901+00	2026-08-10 23:03:34.901+00	\N
6ae0b552-d6c5-4217-b237-1075eb4eebd9	c8659485-b234-4723-9681-1e71ee94ac3b	736ba25f-7c54-4d0d-b03b-2dd93402521b	Tupia	Makita	RT0700C	SN1786403015504795	\N	2026-08-10 23:03:35.504+00	2026-08-10 23:03:35.504+00	\N
f7f2b2d8-4525-4ea7-888b-729b05d2e052	c8659485-b234-4723-9681-1e71ee94ac3b	42797565-96e1-4694-8895-b3fc6eb607c2	Parafusadeira	Bosch	GSR 120-LI	SN1786403016259601	\N	2026-08-10 23:03:36.259+00	2026-08-10 23:03:36.259+00	\N
6445ba31-3404-401a-971f-b552843ac4a5	c8659485-b234-4723-9681-1e71ee94ac3b	d8c8fc87-860f-45fe-8990-6fef1a273bc9	Policorte	Dewalt	D28730	SN1786403016711140	\N	2026-08-10 23:03:36.711+00	2026-08-10 23:03:36.711+00	\N
b5725a1a-f1ac-4748-8f80-7befec3ccd25	c8659485-b234-4723-9681-1e71ee94ac3b	32179aea-8524-4cfd-a67d-51c69bd54f4b	Serra Circular	Makita	5007MG	SN1786403017320432	\N	2026-08-10 23:03:37.32+00	2026-08-10 23:03:37.32+00	\N
205d8183-ac58-4a98-aa9d-1d9244f930b8	c8659485-b234-4723-9681-1e71ee94ac3b	0a80a79f-aaf2-4636-bf71-9306ff16b44d	Serra Circular	Makita	5007MG	SN1786403018088149	\N	2026-08-10 23:03:38.088+00	2026-08-10 23:03:38.088+00	\N
caccf019-94db-4eff-99fe-208115710ced	c8659485-b234-4723-9681-1e71ee94ac3b	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	Policorte	Dewalt	D28730	SN1786403018542333	\N	2026-08-10 23:03:38.542+00	2026-08-10 23:03:38.542+00	\N
40631c34-f4d6-4afb-8dd5-7922b089a66e	c8659485-b234-4723-9681-1e71ee94ac3b	736ba25f-7c54-4d0d-b03b-2dd93402521b	Plaina	Makita	KP0800	SN1786403019313480	\N	2026-08-10 23:03:39.313+00	2026-08-10 23:03:39.313+00	\N
068f897b-5ea9-4a32-83dc-8579382e62f7	c8659485-b234-4723-9681-1e71ee94ac3b	42797565-96e1-4694-8895-b3fc6eb607c2	Tupia	Makita	RT0700C	SN1786403019768334	\N	2026-08-10 23:03:39.768+00	2026-08-10 23:03:39.768+00	\N
6d45e8b4-03d7-450f-bb47-47263b46be9d	c8659485-b234-4723-9681-1e71ee94ac3b	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	Martelete	Bosch	GBH 2-24D	SN1786403020219318	\N	2026-08-10 23:03:40.219+00	2026-08-10 23:03:40.219+00	\N
e15845b4-cc3c-489e-bb69-c1af1463f985	c8659485-b234-4723-9681-1e71ee94ac3b	32179aea-8524-4cfd-a67d-51c69bd54f4b	Plaina	Makita	KP0800	SN1786403020977170	\N	2026-08-10 23:03:40.977+00	2026-08-10 23:03:40.977+00	\N
590f74fd-e51f-4916-908d-7dfac210b95a	c8659485-b234-4723-9681-1e71ee94ac3b	736ba25f-7c54-4d0d-b03b-2dd93402521b	Serra Circular	Makita	5007MG	SN178640302173514	\N	2026-08-10 23:03:41.735+00	2026-08-10 23:03:41.735+00	\N
2dca6048-f431-4306-8a0d-f435c200b059	c8659485-b234-4723-9681-1e71ee94ac3b	d8c8fc87-860f-45fe-8990-6fef1a273bc9	Policorte	Dewalt	D28730	SN1786403022512401	\N	2026-08-10 23:03:42.512+00	2026-08-10 23:03:42.512+00	\N
0b5d439a-a2b3-47f3-8b5a-5fd7e79f9828	c8659485-b234-4723-9681-1e71ee94ac3b	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	Policorte	Dewalt	D28730	SN1786403023117599	\N	2026-08-10 23:03:43.117+00	2026-08-10 23:03:43.117+00	\N
7bd8a5cb-75e9-44bf-bf0f-9d0bf7939369	c8659485-b234-4723-9681-1e71ee94ac3b	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	Tupia	Makita	RT0700C	SN1786403023719717	\N	2026-08-10 23:03:43.719+00	2026-08-10 23:03:43.719+00	\N
372d2f63-9b4a-4e5a-8980-f48bfb3424c7	c8659485-b234-4723-9681-1e71ee94ac3b	736ba25f-7c54-4d0d-b03b-2dd93402521b	Martelete	Bosch	GBH 2-24D	SN1786403024323204	\N	2026-08-10 23:03:44.323+00	2026-08-10 23:03:44.323+00	\N
3753b830-24dc-4e8b-9113-9187e2930e0e	c8659485-b234-4723-9681-1e71ee94ac3b	d8c8fc87-860f-45fe-8990-6fef1a273bc9	Serra Tico-Tico	Bosch	GST 75	SN1786403024929184	\N	2026-08-10 23:03:44.929+00	2026-08-10 23:03:44.929+00	\N
0719e452-dbf4-4ede-a0c5-ca7251498955	c8659485-b234-4723-9681-1e71ee94ac3b	42797565-96e1-4694-8895-b3fc6eb607c2	Policorte	Dewalt	D28730	SN178640302553128	\N	2026-08-10 23:03:45.531+00	2026-08-10 23:03:45.531+00	\N
cd9ae78f-f8bb-401e-9797-cfc796e1b8dc	c8659485-b234-4723-9681-1e71ee94ac3b	0a80a79f-aaf2-4636-bf71-9306ff16b44d	Serra Tico-Tico	Bosch	GST 75	SN1786403026293895	\N	2026-08-10 23:03:46.293+00	2026-08-10 23:03:46.293+00	\N
4431b825-d29a-4c70-bf4d-a0591fef545c	c8659485-b234-4723-9681-1e71ee94ac3b	32179aea-8524-4cfd-a67d-51c69bd54f4b	Policorte	Dewalt	D28730	SN1786403026896400	\N	2026-08-10 23:03:46.896+00	2026-08-10 23:03:46.896+00	\N
f90e51e7-e2df-4b92-bd8d-9ada80608f56	c8659485-b234-4723-9681-1e71ee94ac3b	f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	Martelete	Bosch	GBH 2-24D	SN1786403027503914	\N	2026-08-10 23:03:47.503+00	2026-08-10 23:03:47.503+00	\N
8e3f3f99-87a5-47c8-8b8e-3ba84aeced98	c8659485-b234-4723-9681-1e71ee94ac3b	736ba25f-7c54-4d0d-b03b-2dd93402521b	Furadeira	Bosch	GSB 13 RE	SN1786403027960239	\N	2026-08-10 23:03:47.96+00	2026-08-10 23:03:47.96+00	\N
92132e62-d235-4536-86d2-04129f25d113	c8659485-b234-4723-9681-1e71ee94ac3b	32179aea-8524-4cfd-a67d-51c69bd54f4b	Policorte	Dewalt	D28730	SN1786403028408545	\N	2026-08-10 23:03:48.408+00	2026-08-10 23:03:48.408+00	\N
c634a416-32aa-4778-b239-f4a56d33cba4	c8659485-b234-4723-9681-1e71ee94ac3b	d8c8fc87-860f-45fe-8990-6fef1a273bc9	Serra Circular	Makita	5007MG	SN1786403029008604	\N	2026-08-10 23:03:49.008+00	2026-08-10 23:03:49.008+00	\N
166b3791-a5c5-43fa-b331-fd545423c970	c8659485-b234-4723-9681-1e71ee94ac3b	f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	Tupia	Makita	RT0700C	SN178640302960772	\N	2026-08-10 23:03:49.607+00	2026-08-10 23:03:49.607+00	\N
b1a0bfb0-547a-426d-9e45-6080e7581998	c8659485-b234-4723-9681-1e71ee94ac3b	d8c8fc87-860f-45fe-8990-6fef1a273bc9	Parafusadeira	Bosch	GSR 120-LI	SN1786403030218444	\N	2026-08-10 23:03:50.218+00	2026-08-10 23:03:50.218+00	\N
8d86fb4e-573d-4e94-bf50-7c91a6aa95ab	c8659485-b234-4723-9681-1e71ee94ac3b	f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	Serra Circular	Makita	5007MG	SN1786403030668287	\N	2026-08-10 23:03:50.668+00	2026-08-10 23:03:50.668+00	\N
1b7ff083-9cb9-4a42-b157-9fd3f8b0f2be	c8659485-b234-4723-9681-1e71ee94ac3b	0a80a79f-aaf2-4636-bf71-9306ff16b44d	Lixadeira	Dewalt	DWE6411	SN1786403031454875	\N	2026-08-10 23:03:51.454+00	2026-08-10 23:03:51.454+00	\N
76be6a4b-28a5-4320-9308-a739321f876c	c8659485-b234-4723-9681-1e71ee94ac3b	42797565-96e1-4694-8895-b3fc6eb607c2	Esmerilhadeira	Dewalt	DWE4020	SN1786403032103259	\N	2026-08-10 23:03:52.103+00	2026-08-10 23:03:52.103+00	\N
2c38e979-0ed7-4b98-9532-74088bbb006c	c8659485-b234-4723-9681-1e71ee94ac3b	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	Tupia	Makita	RT0700C	SN178640303270640	\N	2026-08-10 23:03:52.706+00	2026-08-10 23:03:52.706+00	\N
9665cc01-ce61-446c-a52b-1521d9c60b5c	c8659485-b234-4723-9681-1e71ee94ac3b	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	Serra Circular	Makita	5007MG	SN178640303331517	\N	2026-08-10 23:03:53.315+00	2026-08-10 23:03:53.315+00	\N
c9343865-d171-43ad-b533-4ebb659ea615	c8659485-b234-4723-9681-1e71ee94ac3b	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	Parafusadeira	Bosch	GSR 120-LI	SN1786403033927549	\N	2026-08-10 23:03:53.927+00	2026-08-10 23:03:53.927+00	\N
e9571521-3ec4-45ac-8e02-40d00769c1e2	c8659485-b234-4723-9681-1e71ee94ac3b	736ba25f-7c54-4d0d-b03b-2dd93402521b	Martelete	Bosch	GBH 2-24D	SN1786403034540610	\N	2026-08-10 23:03:54.54+00	2026-08-10 23:03:54.54+00	\N
876dd5a3-2b34-47d9-aaa7-89cdd17bcf40	c8659485-b234-4723-9681-1e71ee94ac3b	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	Serra Circular	Makita	5007MG	SN1786403035317750	\N	2026-08-10 23:03:55.317+00	2026-08-10 23:03:55.317+00	\N
eb21952f-f046-433b-a30b-1c49047aee3d	c8659485-b234-4723-9681-1e71ee94ac3b	0a80a79f-aaf2-4636-bf71-9306ff16b44d	Tupia	Makita	RT0700C	SN1786403036082513	\N	2026-08-10 23:03:56.082+00	2026-08-10 23:03:56.082+00	\N
5a32982a-31d0-42fb-8eea-b35d1c43e41d	c8659485-b234-4723-9681-1e71ee94ac3b	32179aea-8524-4cfd-a67d-51c69bd54f4b	Plaina	Makita	KP0800	SN1786403036534989	\N	2026-08-10 23:03:56.534+00	2026-08-10 23:03:56.534+00	\N
85495e90-12c1-496b-ba28-fed7d66ab2c2	c8659485-b234-4723-9681-1e71ee94ac3b	42797565-96e1-4694-8895-b3fc6eb607c2	Plaina	Makita	KP0800	SN178640303712874	\N	2026-08-10 23:03:57.128+00	2026-08-10 23:03:57.128+00	\N
668a4476-9b23-4677-8e08-9e7af96587cf	c8659485-b234-4723-9681-1e71ee94ac3b	32179aea-8524-4cfd-a67d-51c69bd54f4b	Plaina	Makita	KP0800	SN178640303772822	\N	2026-08-10 23:03:57.728+00	2026-08-10 23:03:57.728+00	\N
006b5260-216c-4e25-be14-0ed60d31cd27	c8659485-b234-4723-9681-1e71ee94ac3b	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	Parafusadeira	Bosch	GSR 120-LI	SN178640303849610	\N	2026-08-10 23:03:58.496+00	2026-08-10 23:03:58.496+00	\N
9e589808-96e8-4974-9ea4-602f1d51f73e	c8659485-b234-4723-9681-1e71ee94ac3b	d8c8fc87-860f-45fe-8990-6fef1a273bc9	Furadeira	Bosch	GSB 13 RE	SN1786403039250871	\N	2026-08-10 23:03:59.25+00	2026-08-10 23:03:59.25+00	\N
fc0c83f7-f506-41a7-b45c-5e3738bc4118	c8659485-b234-4723-9681-1e71ee94ac3b	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	Parafusadeira	Bosch	GSR 120-LI	SN1786403039998360	\N	2026-08-10 23:03:59.998+00	2026-08-10 23:03:59.998+00	\N
54ab213d-8e1d-436f-885d-33087ebe4cd2	c8659485-b234-4723-9681-1e71ee94ac3b	d8c8fc87-860f-45fe-8990-6fef1a273bc9	Martelete	Bosch	GBH 2-24D	SN1786403040789240	\N	2026-08-10 23:04:00.789+00	2026-08-10 23:04:00.789+00	\N
eee8adcf-0f8f-4a55-909c-49a153689b79	c8659485-b234-4723-9681-1e71ee94ac3b	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	Serra Circular	Makita	5007MG	SN1786403041386707	\N	2026-08-10 23:04:01.386+00	2026-08-10 23:04:01.386+00	\N
1c529ffe-a0cc-404a-9f5a-22f9a83207ba	c8659485-b234-4723-9681-1e71ee94ac3b	f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	Lixadeira	Dewalt	DWE6411	SN1786403041988691	\N	2026-08-10 23:04:01.988+00	2026-08-10 23:04:01.988+00	\N
fa2059be-ccff-41d3-b359-91041db43659	c8659485-b234-4723-9681-1e71ee94ac3b	d8c8fc87-860f-45fe-8990-6fef1a273bc9	Parafusadeira	Bosch	GSR 120-LI	SN1786403042597680	\N	2026-08-10 23:04:02.597+00	2026-08-10 23:04:02.597+00	\N
e8ee9df9-f323-451d-b783-6a5d71188603	c8659485-b234-4723-9681-1e71ee94ac3b	f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	Martelete	Bosch	GBH 2-24D	SN1786403043370632	\N	2026-08-10 23:04:03.37+00	2026-08-10 23:04:03.37+00	\N
e7dbda74-6707-4cf6-8fd8-fb59ce0a6b84	c8659485-b234-4723-9681-1e71ee94ac3b	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	Parafusadeira	Bosch	GSR 120-LI	SN178640304383444	\N	2026-08-10 23:04:03.834+00	2026-08-10 23:04:03.834+00	\N
27ec16de-bf18-4270-a931-6386e0e15abb	c8659485-b234-4723-9681-1e71ee94ac3b	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	Parafusadeira	Bosch	GSR 120-LI	SN1786403044601846	\N	2026-08-10 23:04:04.601+00	2026-08-10 23:04:04.601+00	\N
d054b32a-2f94-4f67-a98e-80a4e7226699	c8659485-b234-4723-9681-1e71ee94ac3b	f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	Esmerilhadeira	Dewalt	DWE4020	SN1786403045211428	\N	2026-08-10 23:04:05.211+00	2026-08-10 23:04:05.211+00	\N
3c5ab9f5-8181-456a-b73b-5e7b01b95310	c8659485-b234-4723-9681-1e71ee94ac3b	736ba25f-7c54-4d0d-b03b-2dd93402521b	Esmerilhadeira	Dewalt	DWE4020	SN1786403045969343	\N	2026-08-10 23:04:05.969+00	2026-08-10 23:04:05.969+00	\N
c00d9fc7-eefe-4753-a436-e8592e5b2ca2	c8659485-b234-4723-9681-1e71ee94ac3b	32179aea-8524-4cfd-a67d-51c69bd54f4b	Lixadeira	Dewalt	DWE6411	SN178640304654968	\N	2026-08-10 23:04:06.549+00	2026-08-10 23:04:06.549+00	\N
c01b75ff-66fc-404e-9712-dca2b5b6248d	c8659485-b234-4723-9681-1e71ee94ac3b	0a80a79f-aaf2-4636-bf71-9306ff16b44d	Furadeira	Bosch	GSB 13 RE	SN1786403047298531	\N	2026-08-10 23:04:07.298+00	2026-08-10 23:04:07.298+00	\N
a8d59778-b4c5-477b-a7f1-2d027211df5f	c8659485-b234-4723-9681-1e71ee94ac3b	736ba25f-7c54-4d0d-b03b-2dd93402521b	Policorte	Dewalt	D28730	SN1786403047900604	\N	2026-08-10 23:04:07.9+00	2026-08-10 23:04:07.9+00	\N
cc125347-3437-4101-83a8-86cd1236bed0	c8659485-b234-4723-9681-1e71ee94ac3b	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	Plaina	Makita	KP0800	SN1786403048353447	\N	2026-08-10 23:04:08.353+00	2026-08-10 23:04:08.353+00	\N
469d3df9-5754-46e8-b699-d9a42d0b3c36	c8659485-b234-4723-9681-1e71ee94ac3b	0a80a79f-aaf2-4636-bf71-9306ff16b44d	Serra Tico-Tico	Bosch	GST 75	SN178640304911443	\N	2026-08-10 23:04:09.114+00	2026-08-10 23:04:09.114+00	\N
fe218a7b-db85-4130-8c44-3cb12f4ac9ae	c8659485-b234-4723-9681-1e71ee94ac3b	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	Policorte	Dewalt	D28730	SN1786403049891603	\N	2026-08-10 23:04:09.891+00	2026-08-10 23:04:09.891+00	\N
b556210b-fa4e-486a-b088-6baa2253bbee	c8659485-b234-4723-9681-1e71ee94ac3b	d8c8fc87-860f-45fe-8990-6fef1a273bc9	Tupia	Makita	RT0700C	SN1786403050364141	\N	2026-08-10 23:04:10.364+00	2026-08-10 23:04:10.364+00	\N
c8794136-0da0-4df4-b8ab-be6556ff3950	c8659485-b234-4723-9681-1e71ee94ac3b	736ba25f-7c54-4d0d-b03b-2dd93402521b	Serra Tico-Tico	Bosch	GST 75	SN1786403050815232	\N	2026-08-10 23:04:10.815+00	2026-08-10 23:04:10.815+00	\N
55ceb396-a02f-4455-8616-050afb1091f5	c8659485-b234-4723-9681-1e71ee94ac3b	f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	Tupia	Makita	RT0700C	SN1786403051265741	\N	2026-08-10 23:04:11.265+00	2026-08-10 23:04:11.265+00	\N
7ae95b51-6dfe-4163-bbe2-9adfa5708508	c8659485-b234-4723-9681-1e71ee94ac3b	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	Furadeira	Bosch	GSB 13 RE	SN1786403051869178	\N	2026-08-10 23:04:11.869+00	2026-08-10 23:04:11.869+00	\N
37295de0-1cbb-4304-8bb6-1a0667532d34	c8659485-b234-4723-9681-1e71ee94ac3b	32179aea-8524-4cfd-a67d-51c69bd54f4b	Serra Circular	Makita	5007MG	SN1786403052328498	\N	2026-08-10 23:04:12.328+00	2026-08-10 23:04:12.328+00	\N
b747512a-8edd-4611-aa29-8178f534d915	c8659485-b234-4723-9681-1e71ee94ac3b	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	Serra Circular	Makita	5007MG	SN1786403052802454	\N	2026-08-10 23:04:12.802+00	2026-08-10 23:04:12.802+00	\N
1f89b449-c637-4266-97f9-14535b9e0b0e	c8659485-b234-4723-9681-1e71ee94ac3b	42797565-96e1-4694-8895-b3fc6eb607c2	Policorte	Dewalt	D28730	SN178640305326110	\N	2026-08-10 23:04:13.261+00	2026-08-10 23:04:13.261+00	\N
c9681972-68ef-40b1-b3ad-e1b17ef8a7ce	c8659485-b234-4723-9681-1e71ee94ac3b	42797565-96e1-4694-8895-b3fc6eb607c2	Esmerilhadeira	Dewalt	DWE4020	SN1786403053718197	\N	2026-08-10 23:04:13.718+00	2026-08-10 23:04:13.718+00	\N
acb305b1-0ab9-4362-a8b4-d9dc378ee6ba	c8659485-b234-4723-9681-1e71ee94ac3b	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	Tupia	Makita	RT0700C	SN178640305418234	\N	2026-08-10 23:04:14.182+00	2026-08-10 23:04:14.182+00	\N
6897f548-763b-4e6f-9b93-c85204e1821e	c8659485-b234-4723-9681-1e71ee94ac3b	736ba25f-7c54-4d0d-b03b-2dd93402521b	Martelete	Bosch	GBH 2-24D	SN1786403054939929	\N	2026-08-10 23:04:14.939+00	2026-08-10 23:04:14.939+00	\N
144d34be-23d7-4959-bdf4-04ac46892853	c8659485-b234-4723-9681-1e71ee94ac3b	f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	Esmerilhadeira	Dewalt	DWE4020	SN17864030557103	\N	2026-08-10 23:04:15.71+00	2026-08-10 23:04:15.71+00	\N
45378a63-8317-441c-a6ee-59285f8aec3b	c8659485-b234-4723-9681-1e71ee94ac3b	32179aea-8524-4cfd-a67d-51c69bd54f4b	Policorte	Dewalt	D28730	SN17864030564838	\N	2026-08-10 23:04:16.483+00	2026-08-10 23:04:16.483+00	\N
f211289c-615d-42f8-b18f-74ce116f5c9d	c8659485-b234-4723-9681-1e71ee94ac3b	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	Esmerilhadeira	Dewalt	DWE4020	SN1786403057089541	\N	2026-08-10 23:04:17.089+00	2026-08-10 23:04:17.089+00	\N
ef906827-d600-4604-af32-2dca0c967fd4	c8659485-b234-4723-9681-1e71ee94ac3b	32179aea-8524-4cfd-a67d-51c69bd54f4b	Policorte	Dewalt	D28730	SN1786403057859778	\N	2026-08-10 23:04:17.859+00	2026-08-10 23:04:17.859+00	\N
67faa35e-a736-4897-ba39-70b3aa7079d6	c8659485-b234-4723-9681-1e71ee94ac3b	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	Tupia	Makita	RT0700C	SN178640305831513	\N	2026-08-10 23:04:18.316+00	2026-08-10 23:04:18.316+00	\N
fd037b12-89b2-4f3f-84c2-f62b2dfd2b69	c8659485-b234-4723-9681-1e71ee94ac3b	0a80a79f-aaf2-4636-bf71-9306ff16b44d	Furadeira	Bosch	GSB 13 RE	SN1786403058771519	\N	2026-08-10 23:04:18.771+00	2026-08-10 23:04:18.771+00	\N
8584da1e-349d-4ff3-a040-c38ede7de70d	c8659485-b234-4723-9681-1e71ee94ac3b	42797565-96e1-4694-8895-b3fc6eb607c2	Lixadeira	Dewalt	DWE6411	SN1786403059529225	\N	2026-08-10 23:04:19.529+00	2026-08-10 23:04:19.529+00	\N
391b7bd2-f168-4f3b-9d76-d9812769be88	c8659485-b234-4723-9681-1e71ee94ac3b	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	Martelete	Bosch	GBH 2-24D	SN1786403060319517	\N	2026-08-10 23:04:20.319+00	2026-08-10 23:04:20.319+00	\N
1fa409f1-9127-4794-8d48-90d032394c2c	c8659485-b234-4723-9681-1e71ee94ac3b	0a80a79f-aaf2-4636-bf71-9306ff16b44d	Plaina	Makita	KP0800	SN1786403061078707	\N	2026-08-10 23:04:21.078+00	2026-08-10 23:04:21.078+00	\N
b6230951-64ed-4993-bde8-9e378940f690	c8659485-b234-4723-9681-1e71ee94ac3b	0a80a79f-aaf2-4636-bf71-9306ff16b44d	Policorte	Dewalt	D28730	SN1786403061680393	\N	2026-08-10 23:04:21.68+00	2026-08-10 23:04:21.68+00	\N
795d3c37-a397-462c-9a20-754fd82190f9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	741641ea-2cc7-4213-9975-c6584bf9da43	Martelete 	Makita 	HR2470 	127v		2026-08-11 13:04:25.827044+00	2026-08-11 13:04:25.827044+00	\N
2e7ca550-fda0-42c5-9f25-2b3792a0b264	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	58e98858-df83-4786-840a-9f17793767a9	Serra Mármore 	Dewalt	DW862 110V~			2026-08-11 13:11:57.767352+00	2026-08-11 13:11:57.767352+00	\N
4f9a268d-25f5-431e-a965-b97ea79a24c3	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	58e98858-df83-4786-840a-9f17793767a9	Serra Mármore 	Stanley	SP125-BR	127v		2026-08-11 13:15:17.084753+00	2026-08-11 13:15:17.084753+00	\N
6f7c64f5-e0d4-4024-9cee-6237e482280d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	58e98858-df83-4786-840a-9f17793767a9	Lixadeira 	Stanley	SB90	127v		2026-08-11 13:18:36.771132+00	2026-08-11 13:18:36.771132+00	\N
6b3b7e2c-8437-455a-b07d-6b3a264679e9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	98559b9a-797f-4c70-9b80-4f1a67ce4557	Motosserra 	Nakkan	80cc			2026-08-11 13:59:55.419197+00	2026-08-11 13:59:55.419197+00	\N
76bd8480-6a27-4929-91da-cbce34da3546	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	de4177f6-8c0d-4c23-a44f-a3d39f372235	Misturador de massa	Cortag	HM-120 127v			2026-08-11 17:32:06.794304+00	2026-08-11 17:39:43.383+00	\N
625b5215-d858-40a7-a3db-4e660d910b30	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	b727602c-6f4b-4320-88cb-2a2f2257224d	Furadeira 	Black e dacker 	7945	127v		2026-08-11 18:19:18.755979+00	2026-08-11 18:19:18.755979+00	\N
d0567483-f610-4707-835b-aa4338298a84	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	04b89c89-6035-43e9-aac8-04962f87d879	Eletroserra	Makita	UC3020A	127v		2026-08-11 21:09:54.745007+00	2026-08-11 21:09:54.745007+00	\N
164f5678-3c07-4a64-87eb-9eabf3d9c9d5	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2d019df4-3df6-4ef8-86ba-891dcb5e9ce2	lava-jato	Jactor 	6800	110v		2026-08-12 12:22:02.244752+00	2026-08-12 12:22:02.244752+00	\N
381ed16a-2718-4b1e-8992-1735870d2652	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	cdfc8003-9858-48dd-8092-5f757783a973	Cabeçote do compressor 	Pressure	ATG2			2026-08-12 12:42:49.55963+00	2026-08-12 12:42:49.55963+00	\N
4d8f7aa5-1dff-4650-bac8-d4c898281d72	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	28b4f382-aa95-4d51-a6b6-73326c8c21f9	Guincho de coluna 	Moto Mil	H-A 105	110v		2026-08-12 14:26:19.731711+00	2026-08-12 14:26:19.731711+00	\N
ee57412e-f2e8-4e56-9edd-59a590d376e4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	0c1dd29e-f9de-400e-8a38-2f892eb5ff47	Martelete 	Stanley 	SHR263-BR tipo 1	110v		2026-08-12 15:21:07.617259+00	2026-08-12 15:21:07.617259+00	\N
4b5113ac-9816-4e6f-a4a6-c3dd440d3179	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	69f8f47a-c4bf-4f67-a288-0ec0eb5441e8	Motocompressor 	Schulz  	Pratic air csi 8,5	110v		2026-08-12 21:07:30.679936+00	2026-08-12 21:07:30.679936+00	\N
d57379e8-921c-4d6c-aa84-ab2e618b44cd	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	de4177f6-8c0d-4c23-a44f-a3d39f372235	Roçadeira 	Sthil	Fs55			2026-08-13 11:37:58.66951+00	2026-08-13 11:37:58.66951+00	\N
eaacf0fa-bdb2-4753-8b2d-2f4c8c518170	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2a65b2fb-d1db-46d3-a786-64fd38b7942f	Lava-Jato	WAP	Ousada plus 2200	127v		2026-08-13 12:14:24.963794+00	2026-08-13 12:14:24.963794+00	\N
fe8249af-95c8-4331-b5f5-b650fad5a878	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	53f00aca-04ae-4f15-b319-10bb674f8516	Martelete	Hanabi	220v			2026-08-13 12:31:44.361148+00	2026-08-13 12:31:44.361148+00	\N
19f0a961-b3d6-4f86-b319-4611cd739e14	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	7a880a10-d8e2-4046-ae5b-0f28652edf53	Furadeira 	Bosch	CSB550	127v		2026-08-13 14:14:08.922799+00	2026-08-13 14:14:08.922799+00	\N
f9b2e58e-faef-44e7-b9ff-e10bd2d28e7a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	43cb493c-25ec-4657-8393-f937e6576890	Aspirador de Pó	Karcher	NT200 220v			2026-08-13 17:25:13.460566+00	2026-08-13 17:25:13.460566+00	\N
8f1538ab-2d30-4739-b073-a444de71cc1d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	72833910-7f5b-4141-8133-dda7e8ff9e12	Politriz 	Dewalt	DWP849x	127v		2026-08-13 19:53:56.336597+00	2026-08-13 19:53:56.336597+00	\N
1d9c1b36-d5c6-44a8-adc9-04ea9f000d1e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	f3e9be14-3b81-430d-be5f-2ad8c119921a	Lava-Jato	Karcher	K3.30	127v		2026-08-13 20:14:44.566865+00	2026-08-13 20:14:44.566865+00	\N
1281beef-7947-4e34-8e97-548675644fd8	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	4f5ce24d-43f4-4205-97ef-5be2fd76cb81	Roçadeira 	Trapp	127v			2026-08-13 20:36:03.073645+00	2026-08-13 20:36:03.073645+00	\N
6cdc2bab-1bb5-4185-b32c-e328797ee46f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	4f5ce24d-43f4-4205-97ef-5be2fd76cb81	Roçadeira 	Tamontina	127v			2026-08-13 20:52:20.073006+00	2026-08-13 20:52:20.073006+00	\N
cf4e3f9c-3d84-4d9c-80db-1e81c403dea1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	f9c8a6ad-8969-475d-9b01-602745488b29	Lava Jato	Karcher	K2.500	127v	Completo	2026-08-14 14:47:19.099257+00	2026-08-14 14:47:19.099257+00	\N
9ef46de6-1514-4cc3-9ceb-95eae1d594f7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	8f5fbd44-307d-47cd-b4b4-60200753035d	Lava Jato	Karcher	K3.98	127v		2026-08-14 19:22:06.494801+00	2026-08-14 19:22:06.494801+00	\N
24ca1ad5-024e-4594-97d6-f54bc92572e8	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	838eb4e3-bc0c-4826-b08c-136b0f53cc86	Roçadeira 	Husqvarna	226RJ			2026-08-17 11:46:19.772903+00	2026-08-17 11:46:19.772903+00	\N
2dd9e6e0-ab85-44bf-921a-3d1139ed6150	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	8ad3424b-b360-4264-a21b-41ccf11861b9	Esmerilhadeira 	Makita	Ga4530	127v		2026-08-17 12:21:01.036417+00	2026-08-17 12:21:01.036417+00	\N
f09f3ff1-f024-4816-96dc-1c9aaa758a34	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	8ad3424b-b360-4264-a21b-41ccf11861b9	Furadeira 	Dewalt	DWD502 	127v		2026-08-17 12:23:20.598363+00	2026-08-17 12:23:20.598363+00	\N
d552ca59-be5a-4c61-a3d7-c07f808cca20	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2d5e2fba-c3ce-4745-8d58-a62f465abb93	Serra Mármore 	Makita	4100NH	127v		2026-08-17 19:48:57.023689+00	2026-08-17 19:48:57.023689+00	\N
a3bc60f1-4a95-4b8d-b65a-e584a13677d6	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	ced6073a-0a5d-47a8-8e32-50a3eee914b4	Esmerilhadeira 	Dewalt	DWE4020	127v		2026-08-17 21:09:45.016794+00	2026-08-17 21:09:45.016794+00	\N
b6a57071-133d-4341-8103-65d53efad068	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	ced6073a-0a5d-47a8-8e32-50a3eee914b4	Lixadeira 	Stanley	SB90	127v		2026-08-17 21:12:00.411028+00	2026-08-17 21:12:00.411028+00	\N
71d64be6-36cc-497e-b132-f3e9b324a18a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	ced6073a-0a5d-47a8-8e32-50a3eee914b4	Lixadeira 	Stanley	SB90	127v		2026-08-17 21:13:08.668251+00	2026-08-17 21:13:08.668251+00	\N
a7ab237f-b630-421e-89a3-07b52d43fc68	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	f31790ae-24b5-4a6e-a898-c9b66eded923	Maretelete	Paralelo SID	Sem iD	127v		2026-08-17 21:20:18.611396+00	2026-08-17 21:20:18.611396+00	\N
7d391e82-3279-4772-b16e-f33aa69c3d34	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	f31790ae-24b5-4a6e-a898-c9b66eded923	Martelete 	Paralelo SID	Sem iD	127v		2026-08-17 21:21:39.243737+00	2026-08-17 21:21:39.243737+00	\N
9d6ed18f-6e40-pg_dump: processing data for table "public.financial_entries"
pg_dump: dumping contents of table "public.financial_entries"
4d2b-a3bc-0991750173ca	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	48dd2e2f-01e6-47bf-8178-7ababf413267	Martelete 	Makita 	HR2470 	127v		2026-08-18 11:46:30.30709+00	2026-08-18 11:46:30.30709+00	\N
197fd8c8-06ea-4b76-9d6d-c33565b3463d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	d8c32459-3650-4257-81a5-4275c1951d6c	Furadeira 	Bosch 	Magnun	110		2026-08-18 13:24:38.794516+00	2026-08-18 13:24:38.794516+00	\N
1751c57d-f861-4eae-9f29-05dc2521ea1d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	0a5fa56a-053d-40fe-ac6d-858567de03e3	Serra Mármore 	Makita 	4100NH3	127v		2026-08-18 14:07:10.493971+00	2026-08-18 14:07:10.493971+00	\N
b00a0402-5b27-4638-ae42-2e9c19ea42aa	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	951aad4b-8f2c-47fe-ab6b-2f3cb9f53a9e	Parafusadeira 	Dewalt	DCD7781			2026-08-18 14:44:28.302343+00	2026-08-18 14:44:28.302343+00	\N
0523bd2d-d691-4f00-8fe2-45ee59203431	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	f4c86b23-1d2d-4118-a5c7-f61338b007d7	Esmerilhadeira 	Bosch 	GWS 770	127v		2026-08-18 14:56:05.822069+00	2026-08-18 14:56:05.822069+00	\N
0e5cc803-69bb-40cd-870c-c7480d5e728f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	9c4f572a-e599-45e0-a3f2-f0c9645cdb1e	Lava Jato	Karcher	K3.30	127v		2026-08-18 15:12:26.390893+00	2026-08-18 15:12:26.390893+00	\N
0643aabb-e0e4-45a4-8df6-d58bd31d387e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	9c4f572a-e599-45e0-a3f2-f0c9645cdb1e	Lava Jato 	Karcher	K3.30	220v		2026-08-18 15:13:04.590326+00	2026-08-18 15:13:04.590326+00	\N
5933ff9a-38b4-4e6f-a023-3a17f17bc4a4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	4a95a4a4-174b-4a0e-8ff0-28695fb7a812	Cabeçote	Chiaperini 	40 AP3V			2026-08-18 15:59:16.732307+00	2026-08-18 15:59:16.732307+00	\N
9d8efae7-eeae-4d33-a83b-e29a02e55d24	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	49d5bbeb-578c-4e9d-9669-0fe59af3d6b9	Ventosa 	Auxom 	18650	21v		2026-08-18 18:19:48.958208+00	2026-08-18 18:19:48.958208+00	\N
c1330de8-ad20-46de-8573-b48493defac7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	9644ebe1-3fca-4c7f-b856-ea67ec6318fd	Lixadeira 	Stanley	STGS7221	127v		2026-08-18 18:41:41.208218+00	2026-08-18 18:41:41.208218+00	\N
97ca4cf6-695f-439c-a3ea-459969f668a6	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	b10a2175-61de-4a7a-9fd9-31de3bda7ec4	Esmerilhadeira 	Black in deker	G720	127v		2026-08-18 18:50:01.132189+00	2026-08-18 18:50:01.132189+00	\N
dafc1acf-fd8e-497e-971b-0afb42407674	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	9644ebe1-3fca-4c7f-b856-ea67ec6318fd	Plaina	Stanley	STPP7502 TIPO1	127v		2026-08-18 19:04:26.718516+00	2026-08-18 19:04:26.718516+00	\N
05e59c11-22c7-4c82-b9a8-cd6db94ae58b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	9644ebe1-3fca-4c7f-b856-ea67ec6318fd	Serra de meia esquadria	Dewalt	Sem iD			2026-08-18 19:06:40.714546+00	2026-08-18 19:06:40.714546+00	\N
629c9167-5cde-4995-829f-dac99e654999	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	3af3efa2-c68a-429f-b636-baf65551923a	Martelete 	Dewalt	D25133	127v		2026-08-18 19:44:44.226698+00	2026-08-18 19:44:44.226698+00	\N
8783bcc3-dd6f-496d-b116-d4f4e6694dfd	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	25d739a9-fd5e-41db-b01e-52f673619302	Plaina 	Makita 	N1900B 220v			2026-08-18 19:55:32.575413+00	2026-08-18 19:55:32.575413+00	\N
b1eb8ca7-7ed8-4718-a9ce-f70bbf2b39a4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	7fa572dc-5575-4da8-9556-6b278a421005	Soprador 	Sthil	BG 86			2026-08-18 20:36:57.222847+00	2026-08-18 20:36:57.222847+00	\N
\.


--
-- TOC entry 3533 (class 0 OID 24795)
-- Dependencies: 229
-- Data for Name: financial_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_entries (id, tenant_id, type, description, amount, due_date, paid_date, status, service_order_id, created_at, updated_at) FROM stdin;
f39901e8-9160-485c-b243-f1e8927e2dc6	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0066-B - Devalcir De Jesus	50.00	2026-08-07	\N	pendente	584454f2-922d-4336-94ab-fc26540f41cd	2026-08-07 17:58:19.404633+00	2026-08-07 17:58:19.404633+00
39a5f2fd-7768-46f8-914f-0945ad080615	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0057 - Luis Carlos Evangelista 	240.00	2026-08-10	\N	pendente	7e6f618c-867c-4113-9ab5-a5dbbbeab3a3	2026-08-10 16:05:01.556723+00	2026-08-10 16:05:01.556723+00
f1400cdb-9d77-4eec-8d05-05a6170b4345	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0075 - Samuel Loredo da Silva Júnior	290.00	2026-08-10	\N	pendente	9ca5c21f-b07e-4411-b50b-b53d2f9f034b	2026-08-10 17:41:38.011269+00	2026-08-10 17:41:38.011269+00
6e90b730-0f5b-4284-8319-477499d12373	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0085 - Renato Pacheco	510.00	2026-08-10	\N	pendente	ea7fcdf0-e497-432f-99de-8ca7148cdc14	2026-08-10 19:04:18.716628+00	2026-08-10 19:04:18.716628+00
177b20d1-c572-4c09-a760-c344d954fe51	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0002 - José Oliveira	148.00	2026-07-24	\N	pendente	c7186ef6-34d8-499b-add3-b305f498eac6	2026-07-24 13:43:02.171238+00	2026-07-24 13:43:02.171238+00
3b6390ab-a4a5-4f31-8cbb-eee2997c2cd8	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0001 - José Oliveira	162.00	2026-07-24	\N	pendente	8371ae12-4971-4b81-9129-6943cec3572a	2026-07-24 13:43:07.602097+00	2026-07-24 13:43:07.602097+00
10a4b7e3-aa4d-418f-8074-ac95a3ea7e3f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0007 - Celmo Santos 	100.00	2026-07-27	\N	pendente	d67bada3-0998-4f0c-a0c7-39a97bb4d8c9	2026-07-27 14:49:31.32429+00	2026-07-27 14:49:31.32429+00
e593fa76-b2fe-482e-8e70-82b3dd9787c7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0009 - Bruno Garagem 21	239.99	2026-07-27	\N	pendente	c6f2c468-9920-4840-9879-f4537c438cf4	2026-07-27 14:56:17.344799+00	2026-07-27 14:56:17.344799+00
06df6517-e535-4ce4-bfae-b7c5d6903338	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0012 - welington charles	290.00	2026-07-27	\N	pendente	9f9aeb41-0fbf-47aa-988b-e5f0b09d6a49	2026-07-27 15:45:09.996625+00	2026-07-27 15:45:09.996625+00
6ec4ee34-f1a5-49c1-835b-90560df25be6	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0020 - Marcos de Paula	70.00	2026-07-28	\N	pendente	9fc9d663-9042-4862-94db-a99daa2e78ae	2026-07-28 14:02:45.20726+00	2026-07-28 14:02:45.20726+00
44e0a846-2b2e-435b-8a8c-06f3dc21173a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0033 - Alan Soares 	50.00	2026-07-29	\N	pendente	60d9bc5a-3e31-4238-ae2f-4222aa3b7586	2026-07-29 18:04:00.394496+00	2026-07-29 18:04:00.394496+00
8e298abd-4de7-4bd8-818f-7b240f58bcf9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0019 - Marcos Felc Pint 	170.00	2026-07-30	\N	pendente	7f1d4ab1-e8c1-45f0-8be2-e65f40bae359	2026-07-30 20:32:06.538711+00	2026-07-30 20:32:06.538711+00
d810b50d-96f3-491c-bbc2-166f6192f218	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0044-B - Adir Martins Ramos 	70.00	2026-07-31	\N	pendente	dd49e6f9-5515-4a7f-86ba-cd8e8e9804d8	2026-07-31 13:46:14.542827+00	2026-07-31 13:46:14.542827+00
165d91dc-76c5-4ac5-aa6b-98ad6dc4f723	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0044-A - Adir Martins Ramos 	80.00	2026-07-31	\N	pendente	f4a435a2-f9de-40cd-acb9-fad17aff30d3	2026-07-31 13:46:19.744773+00	2026-07-31 13:46:19.744773+00
51a5930d-f017-445f-bf77-6920eb7811d2	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0010 - Luiz Carlos 	670.00	2026-07-31	\N	pendente	56e73ee6-79ee-41af-9827-66a21ad7159e	2026-07-31 14:21:03.534673+00	2026-07-31 14:21:03.534673+00
0313b559-112e-4601-8f3d-5d9104af5549	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0006 - Ricardo Vieira 	190.00	2026-07-31	\N	pendente	b8c8ea7d-ca4e-4f71-8fc5-67bbe8f30602	2026-07-31 15:02:00.225681+00	2026-07-31 15:02:00.225681+00
2d7d85ee-3e8a-432b-961d-66035e780b87	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0016 - Tiago Boerher Sales 	250.00	2026-07-31	\N	pendente	dc1c7d37-c534-4e56-a32b-2bc1c8eb1fde	2026-07-31 17:57:50.133414+00	2026-07-31 17:57:50.133414+00
308236de-5f40-4991-b494-e58a73c964f8	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0030 - Luiz Carlos 	140.00	2026-07-31	\N	pendente	56d7a980-f2e3-4618-b3b8-a0af7d9e5471	2026-07-31 18:23:44.002576+00	2026-07-31 18:23:44.002576+00
33456fd5-2d08-446e-b6c6-c4a5f10cb17f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0038-A - Reginaldo Freire	60.00	2026-08-01	\N	pendente	4af873ce-fc15-4d8d-a431-2ccb5fd26982	2026-08-01 13:39:18.943557+00	2026-08-01 13:39:18.943557+00
5453c924-a3a3-444d-8e11-5075f4cf05bb	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0032-A - Paulo Cesar Fortunado 	90.00	2026-08-03	\N	pendente	86e497a7-0905-4029-a63f-0712be31cc06	2026-08-03 18:53:28.764558+00	2026-08-03 18:53:28.764558+00
34b7424e-acce-44b1-b50e-75de77fd10c9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0014 - Pilar Seis (Paulo Ricardo)	700.00	2026-08-03	\N	pendente	c0f24c43-eaaa-4dfe-89ca-9e6342cbca2a	2026-08-03 18:53:38.222765+00	2026-08-03 18:53:38.222765+00
4f9e0ee1-4c62-484f-8d44-fe7bf391d6bd	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0046-A - Davi Lopes Ferreira / Thais 	610.00	2026-08-03	\N	pendente	e5eb61a5-e138-4eef-8eee-d8972098dcad	2026-08-03 18:56:44.152823+00	2026-08-03 18:56:44.152823+00
397f254c-477b-49ca-be80-4f1ac812fb59	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0040 - Alex Araujo 	40.00	2026-08-03	\N	pendente	dfdca527-6846-485b-b655-52db054d2093	2026-08-03 19:51:29.900771+00	2026-08-03 19:51:29.900771+00
d535d2a0-823f-4a62-9651-818f1a668368	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0041 - Atila 	50.00	2026-08-03	\N	pendente	c30a82a2-d2f3-44ad-b26c-d9477f9cc220	2026-08-03 19:55:19.311322+00	2026-08-03 19:55:19.311322+00
27d54750-44d5-4eb1-99ca-e3ee3a19da2b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0018 - Manoel José 	60.00	2026-08-03	\N	pendente	b8142b98-af47-4633-94bf-6acd7313ab62	2026-08-03 20:13:32.540496+00	2026-08-03 20:13:32.540496+00
72a4e7e2-4dbd-46b0-86f2-ab838ae0c912	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0045-A - Vanusa Limeira Rezende	200.00	2026-08-03	\N	pendente	166fc1b9-8818-4454-8986-fdbc9a579b6f	2026-08-03 20:25:54.904751+00	2026-08-03 20:25:54.904751+00
715343dc-9761-4530-8891-8c16829a4047	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0045-B - Vanusa Limeira Rezende	140.00	2026-08-03	\N	pendente	fc4e36c4-e5a3-4419-94ed-42418cb00f50	2026-08-03 20:25:59.094753+00	2026-08-03 20:25:59.094753+00
3bcda211-d8ad-45d6-abc3-afee95a86fc7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0045-C - Vanusa Limeira Rezende	300.00	2026-08-03	\N	pendente	c0d37832-e76d-4d20-a80e-ffb091f7ee0a	2026-08-03 20:26:05.034623+00	2026-08-03 20:26:05.034623+00
08c83431-1fa6-4d2c-959d-a23370ee1cc9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0065 - Victor Brasil	740.00	2026-08-03	\N	pendente	196bae00-2942-47f3-a7cf-ba0fe6e6a435	2026-08-03 20:56:44.025659+00	2026-08-03 20:56:44.025659+00
5e28261f-92e1-4c00-8783-64b99986f430	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0048 - MJJ Serralheria 	220.00	2026-08-06	\N	pendente	f231baa9-0e66-4f8e-adc9-5a01e5650f41	2026-08-06 14:52:22.24684+00	2026-08-06 14:52:22.24684+00
91674773-4a41-4fe8-8648-f03314d2c394	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0066-A - Devalcir De Jesus	60.00	2026-08-10	\N	pendente	4319ed74-dcb3-46b0-a59b-31e0a0ed0546	2026-08-10 19:04:39.257792+00	2026-08-10 19:04:39.257792+00
17cc9dbc-98de-4293-9ecf-db2c46fc228c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0081-C - Marcos Felc Pint 	50.00	2026-08-11	\N	pendente	0373a2d8-403f-410d-bd8f-141f80c718bb	2026-08-11 13:40:24.614158+00	2026-08-11 13:40:24.614158+00
9156b281-3493-4ed4-9f18-6bf96fefb149	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0081-A - Marcos Felc Pint 	50.00	2026-08-11	\N	pendente	79b831c3-35f3-4dac-90fc-d007178e7cb9	2026-08-11 13:48:04.237588+00	2026-08-11 13:48:04.237588+00
20550074-db4f-44dd-af52-167f2b7249db	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0081-B - Marcos Felc Pint 	50.00	2026-08-11	\N	pendente	750714d0-23c8-44e8-8fd2-bb16fe2c53c6	2026-08-11 13:48:14.765958+00	2026-08-11 13:48:14.765958+00
da3a4840-390a-480d-8c93-baa5a7a587e4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0081-D - Marcos Felc Pint 	20.00	2026-08-11	\N	pendente	a86d9f4f-a662-4256-969b-cdfcebf0041f	2026-08-11 13:48:19.429087+00	2026-08-11 13:48:19.429087+00
a7408486-1677-4928-90b8-a4272c14650d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0081-E - Marcos Felc Pint 	20.00	2026-08-11	\N	pendente	60648952-a439-4bb0-a1fe-75948d96f593	2026-08-11 13:50:44.636717+00	2026-08-11 13:50:44.636717+00
35109ba2-1c25-4b1d-95ee-8ba9c65e0bce	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0081-F - Marcos pg_dump: processing data for table "public.impersonate_logs"
pg_dump: dumping contents of table "public.impersonate_logs"
Felc Pint 	60.00	2026-08-11	\N	pendente	cfc3b3df-ee8d-4a3b-b9f4-e87eb058d340	2026-08-11 13:50:53.184075+00	2026-08-11 13:50:53.184075+00
5052e329-c6ff-4ede-b4a5-4d59c159f7e4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0081-H - Marcos Felc Pint 	20.00	2026-08-11	\N	pendente	c3615677-9763-4abd-96b2-d8d6e0b28502	2026-08-11 13:51:17.961412+00	2026-08-11 13:51:17.961412+00
708b8882-f0ec-4ab3-a613-80c5347f1ec1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0081-K - Marcos Felc Pint 	60.00	2026-08-11	\N	pendente	04e0d501-3f0c-4e28-a3a7-f09332ee837b	2026-08-11 13:51:42.801325+00	2026-08-11 13:51:42.801325+00
4ed5d7dd-7805-46ba-871b-342dda24e220	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0079 - André da Rocha Gardona	30.00	2026-08-11	\N	pendente	21029924-8440-46d5-a475-9a3f3d2da8f2	2026-08-11 14:05:44.724847+00	2026-08-11 14:05:44.724847+00
27669de2-e0d3-4950-a890-18bcfe335560	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0059-C - Marquinho MM Instalações 	360.00	2026-08-11	\N	pendente	ef5df1a9-90f1-4989-9ec4-ecb9cc5be9e0	2026-08-11 14:31:31.563756+00	2026-08-11 14:31:31.563756+00
2383c986-db5a-41f3-8ab3-1f3506ae4f9b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0103 - Rony Moacyr Tayt Sohn	70.00	2026-08-12	\N	pendente	78d83607-0309-4a2f-8897-e924aaccd53e	2026-08-12 19:49:56.16111+00	2026-08-12 19:49:56.16111+00
38ea1c4c-0ea0-4dad-aa05-867296e88296	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0084 - Diego Paqui	50.00	2026-08-12	\N	pendente	6e6de9d2-ec95-460d-9477-c03bf7e9ece1	2026-08-12 19:51:16.518771+00	2026-08-12 19:51:16.518771+00
74871181-f168-45e6-913a-e18b8b096cf3	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0098 - João Alberto 	20.00	2026-08-13	\N	pendente	065f60b8-c41e-4556-ac02-d77cfe9b4625	2026-08-13 18:59:47.514095+00	2026-08-13 18:59:47.514095+00
f2fd02e1-36b0-482a-9269-5bdd7098b717	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0074 - Adonias Nacimento 	290.00	2026-08-13	\N	pendente	187d64d9-8882-42d2-b287-fb949167105e	2026-08-13 21:23:24.883655+00	2026-08-13 21:23:24.883655+00
a09d6bb4-9448-4110-9580-7b9adecfa7e5	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0081-G - Marcos Felc Pint 	110.00	2026-08-14	\N	pendente	9bc0dd11-bd8f-4390-9db8-ec942bf548a1	2026-08-14 17:46:07.554458+00	2026-08-14 17:46:07.554458+00
2186c43e-1240-4dce-8bf8-e9fee79aa581	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0081-J - Marcos Felc Pint 	70.00	2026-08-14	\N	pendente	f80a47c8-95b6-448b-b302-a27c0ad0542f	2026-08-14 17:46:14.990322+00	2026-08-14 17:46:14.990322+00
3c0c39e7-898c-44d1-a47f-34ef3e689e71	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0108 - Maciel Costa 	30.00	2026-08-14	\N	pendente	6f415b16-4276-4bf1-811c-7f955f7d8406	2026-08-14 19:55:05.512735+00	2026-08-14 19:55:05.512735+00
72ff0088-7fd6-4afa-b4e4-e3902ba35c53	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0072 - Pedro Garrido 	260.00	2026-08-15	\N	pendente	f6b14792-18a5-4052-b505-e11dd498525f	2026-08-15 13:26:25.869058+00	2026-08-15 13:26:25.869058+00
cdbf1f87-d2c3-4469-922f-41ca6a8e34a1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0125 - JSW Anderson 	30.00	2026-08-18	\N	pendente	42fccade-1e8b-4890-8174-ec28b172098c	2026-08-18 14:59:51.763178+00	2026-08-18 14:59:51.763178+00
25868fcb-f9a6-4079-bf47-e231efd025ee	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0111 - Luiz Carlos 	100.00	2026-08-18	\N	pendente	72d2fddc-13ff-463a-b870-a0e03ab66ec7	2026-08-18 15:20:10.973458+00	2026-08-18 15:20:10.973458+00
5be2f02e-f18c-41f5-85cb-bb8b8b04122e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	receita	OS #0097 - Manoel Olegarío Neto	200.00	2026-08-18	\N	pendente	e87b7620-bd83-445b-acac-34a21fe4e49f	2026-08-18 18:21:31.568566+00	2026-08-18 18:21:31.568566+00
\.


--
-- TOC entry 3535 (class 0 OID 57358)
-- Dependencies: 231
-- Data for Name: impersonate_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.impersonate_logs (id, admin_id, tenant_id, started_at, ended_at, ip_address, actions_summary) FROM stdin;
4d7f9bd7-d68e-43fc-ae7a-b406d5938bff	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-07-29 00:24:12.125+00	\N	170.233.51.17	
cd1e03ac-3984-40f3-97d8-3b68011b8274	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-07-29 15:28:34.854+00	\N	170.233.51.17	
c65ed443-28bf-4f7c-8f4c-b196b84afa71	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-07-29 16:45:57.275+00	\N	170.233.51.17	
5ba7ca60-3a7f-4c12-b52e-806f79635c95	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-07-30 13:17:59.281+00	\N	170.233.51.17	
406c9c04-7cff-4a01-8c73-c5910575ba8f	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-07-30 13:18:09.963+00	\N	170.233.51.17	
2a6381e0-297d-4f7f-9242-abb64bb7fe26	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2026-08-01 19:43:22.773+00	\N	189.113.67.26	
2edc3084-d20d-4ada-b2d2-1e5ce16be4f6	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-01 19:43:50.567+00	\N	189.113.67.26	
9d97444f-6b5f-4105-9e16-3bf16f41e32e	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-01 23:53:47.96+00	\N	189.113.67.26	
f2e08267-73ff-4ce4-aa77-c796307eaf6f	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-03 19:29:33.442+00	\N	189.113.67.26	
58bb6353-2836-4844-b9fe-a2b4859946a4	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2026-08-03 19:39:55.529+00	\N	189.113.67.26	
220df2e3-8172-4ca6-8c41-fa3ef660e79b	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-03 19:40:17.071+00	\N	189.113.67.26	
bb0eea01-2492-4571-a2d2-64f09ad40df8	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-10 20:14:43.103+00	\N	189.113.68.225	
558b2d34-c8f0-4a1a-8e8d-89fe86ecaf0b	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-10 20:52:38.176+00	\N	189.113.68.225	
11cc9647-cb80-4303-b068-b33444e11722	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-10 20:53:25.764+00	\N	189.113.68.225	
29f3d031-d87e-4596-a348-e49931e9076f	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-10 20:59:16.486+00	\N	189.113.68.225	
499b9ea5-dfd6-4633-b516-23fb44a8fe06	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-10 21:18:52.888+00	\N	189.113.68.225	
9052adc7-701f-4ba7-bee0-476cc9db7d80	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2026-08-10 21:19:31.372+00	\N	189.113.68.225	
c297eeb3-eef9-4730-994c-ba8c818ac19a	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-10 22:08:49.899+00	\N	189.113.68.225	
3d5759a7-236f-47b5-aabf-98b82d16eb26	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2026-08-10 22:11:06.423+00	\N	189.113.68.225	
03bb8a34-00fe-4216-a1a1-5aa149d5bd6e	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2026-08-10 22:12:21.5+00	\N	189.113.68.225	
2b6705eb-b85c-4dbe-8295-9b2890f9296d	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2026-08-10 22:12:52.305+00	\N	189.113.68.225	
fcf1fa06-127c-44d3-bae1-19141d05119b	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-10 22:17:05.612+00	\N	189.113.68.225	
ceea4dac-35c4-430a-8cc4-4c6ad8c8fea7	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2026-08-10 22:17:31.739+00	\N	189.113.68.225	
d1a44940-f05d-4c17-8946-3aa71ba91789	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-10 22:20:48.433+00	\N	189.113.68.225	
2af25600-f12b-419f-9c65-0aa7889baf0c	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-10 22:48:55.599+00	\N	200.192.19.146	
0f62fb8d-b6e1-471d-9f26-306009b0ac4b	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2026-08-10 23:10:14.096+00	\N	189.113.68.225	
ff5c49c5-bb5b-4b00-88b5-c67553f2d249	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-10 23:10:33.425+00	\N	189.113.6pg_dump: processing data for table "public.knex_migrations"
pg_dump: dumping contents of table "public.knex_migrations"
pg_dump: processing data for table "public.knex_migrations_lock"
pg_dump: dumping contents of table "public.knex_migrations_lock"
pg_dump: processing data for table "public.pin_attempts"
pg_dump: dumping contents of table "public.pin_attempts"
pg_dump: processing data for table "public.service_order_items"
pg_dump: dumping contents of table "public.service_order_items"
8.225	
47c65e15-ff25-46ec-87a7-2aee8bd95b3e	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-11 00:48:55.375+00	\N	189.113.68.225	
4be30e6a-88bd-45bc-962a-fd89b4457f79	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-11 01:15:57.863+00	\N	189.113.68.225	
0b25df04-e705-449c-8eec-cf7dfbb14440	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-11 02:46:27.376+00	\N	189.113.68.225	
dbf29109-70ee-4063-9a8e-1dc4103c3e69	1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	c8659485-b234-4723-9681-1e71ee94ac3b	2026-08-11 16:29:42.184+00	\N	189.113.68.225	
\.


--
-- TOC entry 3521 (class 0 OID 24577)
-- Dependencies: 217
-- Data for Name: knex_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations (id, name, batch, migration_time) FROM stdin;
1	20260722_001_initial_saas_schema.js	1	2026-07-23 16:31:44.354+00
2	20260727_001_make_document_optional.js	2	2026-07-27 13:52:27.397+00
3	20260728_001_add_lote_to_service_orders.js	3	2026-07-28 15:19:34.386+00
4	20260728_002_fix_order_number_unique.js	4	2026-07-28 15:22:56.974+00
5	20260728_003_security_improvements.js	5	2026-07-29 00:20:25.27+00
\.


--
-- TOC entry 3523 (class 0 OID 24584)
-- Dependencies: 219
-- Data for Name: knex_migrations_lock; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.knex_migrations_lock (index, is_locked) FROM stdin;
1	0
\.


--
-- TOC entry 3534 (class 0 OID 57344)
-- Dependencies: 230
-- Data for Name: pin_attempts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.pin_attempts (id, tenant_id, ip_address, attempted_at, success) FROM stdin;
14b2b127-d8f5-4b02-bc6b-071b9b4426d9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	170.82.90.162	2026-07-31 14:19:54.021+00	t
2ec20ef7-fc7c-481c-8276-b55eb8db2810	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	170.82.90.162	2026-07-31 14:20:01.585+00	t
fec95fd8-97f4-48ce-83c2-85c4fc36e224	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	170.82.90.162	2026-08-03 16:07:09.712+00	t
e090508d-8fcc-4690-ae5e-bd52286cdb04	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	170.82.90.162	2026-08-03 17:30:30.617+00	f
11755a30-a31d-4ff6-8bcf-47e373009adf	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	170.82.90.162	2026-08-03 17:30:41.023+00	t
c9e96fc0-2edd-47af-af34-127e0d373dd0	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	170.82.90.162	2026-08-03 17:33:02.029+00	t
934b2acc-b600-4f40-9be2-a76fde43099f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	170.82.90.38	2026-08-11 13:50:23.218+00	t
\.


--
-- TOC entry 3530 (class 0 OID 24748)
-- Dependencies: 226
-- Data for Name: service_order_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_order_items (id, service_order_id, quantity, description, unit_price) FROM stdin;
b83bfbe7-e16b-4c56-9d3e-7a12bbc759c9	3b0675d2-4894-46d3-ab98-f312937fa556	1.00	Mão de obra	80.00
c8458527-b907-4e13-91f4-dc09ea8d6fa0	3b0675d2-4894-46d3-ab98-f312937fa556	1.00	Peça de reposição	107.00
8e5807fb-c875-4743-967b-d0eee0122486	64717cae-fce7-492e-b675-f30205202ef1	1.00	Mão de obra	80.00
94346824-f36a-4387-806a-cf15fd83d3dd	64717cae-fce7-492e-b675-f30205202ef1	1.00	Peça de reposição	74.00
eb10d488-299c-4897-a874-2918b7ae1b35	ba6865d7-ec54-4bed-9239-d7ed8b06880b	1.00	Mão de obra	80.00
a79adb04-c8b1-4fdd-b463-ccbe8cd92f4a	ba6865d7-ec54-4bed-9239-d7ed8b06880b	1.00	Peça de reposição	101.00
4370b639-3085-4224-8913-cde8e6c07317	7bb62260-5f7c-4dff-98f2-363c0564caf9	1.00	Mão de obra	80.00
0d2d094d-7747-470b-b5a8-780cc2765bfe	7bb62260-5f7c-4dff-98f2-363c0564caf9	1.00	Peça de reposição	74.00
0d82c72d-8b8b-427e-8789-c2d3986560c1	9b481aa8-0ccf-437f-8968-fcdeb6aab3dc	1.00	Mão de obra	80.00
f579c1a1-414e-4095-ba09-5a015cd040ca	9b481aa8-0ccf-437f-8968-fcdeb6aab3dc	1.00	Peça de reposição	83.00
a054b6c8-715e-485f-815d-9871d5e75a12	5d0cab4a-d9db-489c-bdfc-d6f2d8f1f2e6	1.00	Mão de obra	80.00
427f64b0-a0ad-4911-940a-550283a0f852	5d0cab4a-d9db-489c-bdfc-d6f2d8f1f2e6	1.00	Peça de reposição	149.00
cb7a195d-0333-42e1-a65b-7514093a98d5	2f763d83-95c3-492a-993e-b43bce8b69aa	1.00	Mão de obra	80.00
9d4aae73-68e0-459f-905f-e0a6bd111fbd	2f763d83-95c3-492a-993e-b43bce8b69aa	1.00	Peça de reposição	82.00
a4717358-3c2e-40c3-b9e9-d19411cedf54	6c1ad83f-b31f-4ac3-bec9-fa3f4a719610	1.00	Mão de obra	80.00
d6523445-2773-4863-8016-22751cbfd998	6c1ad83f-b31f-4ac3-bec9-fa3f4a719610	1.00	Peça de reposição	103.00
594fc633-5658-4ee6-a384-930b2ccdf0db	91874eda-692b-4eaa-a111-cc0e3ea5b1b5	1.00	Mão de obra	80.00
d898a6bc-89b5-493c-969a-41ed1878fa56	91874eda-692b-4eaa-a111-cc0e3ea5b1b5	1.00	Peça de reposição	102.00
f027e5bc-8b44-4257-829c-7393eac1a18b	6238c6ad-c5d7-4448-8b68-38e8120fb10c	1.00	Mão de obra	80.00
51a8af52-a5c6-486b-939c-0474d3502da0	6238c6ad-c5d7-4448-8b68-38e8120fb10c	1.00	Peça de reposição	118.00
d2516149-2d2b-4f48-9071-bb653bb5cdea	60c0f67e-dd23-4289-af2e-58d6140c6d59	1.00	Mão de obra	80.00
2f09c7d9-90d5-404f-8d6c-c9f6cefc1adf	60c0f67e-dd23-4289-af2e-58d6140c6d59	1.00	Peça de reposição	105.00
ced9b703-49bb-40c4-92d7-8ff02474cd9c	3a054487-f443-4413-9903-2b826fd1b02d	1.00	Mão de obra	80.00
e7afc20d-3803-4214-a624-11bafb025826	3a054487-f443-4413-9903-2b826fd1b02d	1.00	Peça de reposição	123.00
52c38967-9ba4-4113-a8fe-23cff74e82e2	8371ae12-4971-4b81-9129-6943cec3572a	1.00	Mão de obra	70.00
1fb3d52c-7fe9-4938-8f45-9cac6fe0bce4	8371ae12-4971-4b81-9129-6943cec3572a	1.00	Peça	92.00
f4e66f97-49b3-4464-a351-d86da057fd49	c7186ef6-34d8-499b-add3-b305f498eac6	1.00	Mão de obra	70.00
970c0ed2-9e60-4de4-b0d8-fbf3a6ffe53c	c7186ef6-34d8-499b-add3-b305f498eac6	1.00	Peça	78.00
ed3f61a4-555e-4fa9-9a94-753212a04ef4	6b655868-07db-4bda-8325-3c84d2c7b9f7	1.00	Mão de obra	70.00
83d80820-5a53-4946-ac20-0b3362dc5ef2	6b655868-07db-4bda-8325-3c84d2c7b9f7	1.00	Peça	63.00
8f3a8228-761f-48f4-9ab3-62bb458fcddb	04f3b564-f2f3-42ea-9073-73cc8c828b74	1.00	Jogo de anéis 	50.00
4a8fb2e4-b957-472c-b086-ef863eba6510	04f3b564-f2f3-42ea-9073-73cc8c828b74	1.00	Jogo de Juntas 	30.00
c6720eba-7c08-4d96-bc64-a22ef385f15b	04f3b564-f2f3-42ea-9073-73cc8c828b74	1.00	Limpeza no prato de válvulas	0.00
7e3c6daa-6046-4c3c-bb2d-9e650e2d0d17	04f3b564-f2f3-42ea-9073-73cc8c828b74	1.00	Elemento filtrante 	30.00
fb57ceeb-7975-4187-bbfe-11b9231c952a	04f3b564-f2f3-42ea-9073-73cc8c828b74	1.00	Óleo 	20.00
66e16fa1-c7a9-4cc8-b55e-73f7420b1ead	04f3b564-f2f3-42ea-9073-73cc8c828b74	1.00	M.O	60.00
d30de170-ef62-45b7-884f-261c067f01e7	c2f35eef-18b4-482b-9260-352dc134f6d4	1.00	M.O 	30.00
a92b6f25-2659-45b7-97d9-8e8456c8daf5	ae1288f8-90a5-4e00-9d5c-c7c1fb2e1b72	1.00	Caixa de engrenagem 	230.00
3a135dda-e85d-4241-b371-bd0369fd6e1c	ae1288f8-90a5-4e00-9d5c-c7c1fb2e1b72	1.00	Mandril Dewalt	120.00
33a44b84-b134-4b36-ad4d-4028f34185f9	e2ad4476-01e2-46bb-a639-eec9097daee3	1.00	Carvão 	20.00
24692790-db8d-4bcf-bda9-b0615a1fd8ec	e2ad4476-01e2-46bb-a639-eec9097daee3	1.00	M.O 	30.00
797c5e1c-0c26-4b88-bcde-f4f0888d7fb3	5d38dec3-1de7-4873-8922-062e220c5261	1.00	Rotor 	180.00
d4db043f-2d93-4ce5-8d33-2fe08c5ffbc5	5d38dec3-1de7-4873-8922-062e220c5261	1.00	Engrenagem 	60.00
6d8679ee-9def-45b7-b260-bfe2eb7eaa20	5d38dec3-1de7-4873-8922-062e220c5261	1.00	Lubrificação 	30.00
af91f30d-acc4-4eb6-942e-934cf1685d82	5d38dec3-1de7-4873-8922-062e220c5261	1.00	Botão seletor 	30.00
4c7fa61c-b8b7-4099-9cbf-76a7a26d6e4f	5d38dec3-1de7-4873-8922-062e220c5261	1.00	Chapa de Fixação 	30.00
2326f0f6-6c10-4e67-8c43-836b9298315a	5d38dec3-1de7-4873-8922-062e220c5261	1.00	Mão de obra 	50.00
e357939f-cb40-4d73-aa6b-fdfec3f11021	045a9548-96af-4f26-bdda-34649163adc8	1.00	Carvão 	40.00
e5f44de4-9866-4877-b200-7fa030e122d2	ae1288f8-90a5-4e00-9d5c-c7c1fb2e1b72	1.00	Mão de obra	50.00
559326e5-d203-4525-9b8d-4acc42d95655	6883491c-bac7-43b1-9751-30bcc23ca241	1.00	Capacitor de partida 	100.00
f15786cb-9b68-404d-946e-0984dff755b5	6883491c-bac7-43b1-9751-30bcc23ca241	1.00	Mão de obra 	50.00
0850ef62-e778-4f2d-8079-9345c39e5095	fae91efb-ea64-47fe-88cb-5f7424751d78	1.00	Rotor	150.00
ce98ce06-97ec-4c79-ba73-6d2286b3d89e	fae91efb-ea64-47fe-88cb-5f7424751d78	1.00	Estator	120.00
8db8df62-a36a-408a-bb84-a88f9efe96d0	fae91efb-ea64-47fe-88cb-5f7424751d78	1.00	Lubrificação	40.00
7d775835-cff7-4c2c-a07b-84af79c3ed6c	fae91efb-ea64-47fe-88cb-5f7424751d78	1.00	Mão de obra 	50.00
0e65ff81-d684-4de1-a824-333693c2314f	d67bada3-0998-4f0c-a0c7-39a97bb4d8c9	1.00	Rolamento 608	20.00
f4d4f966-f0ff-4e30-bb2e-904e2971ceed	d67bada3-0998-4f0c-a0c7-39a97bb4d8c9	1.00	Rolamento 6001	30.00
1e7f68aa-8226-467b-af9b-ed9de7ac1349	d67bada3-0998-4f0c-a0c7-39a97bb4d8c9	1.00	M.O 	50.00
268860b2-e582-4d3a-add0-36d66d6fafe9	86e497a7-0905-4029-a63f-0712be31cc06	1.00	Lubrificação	50.00
599edf88-30b9-4744-af28-4781aac87713	86e497a7-0905-4029-a63f-0712be31cc06	1.00	O`Ring do pistão	20.00
40688ca9-cc52-4859-946d-c045dee62058	86e497a7-0905-4029-a63f-0712be31cc06	1.00	Rolamento 609	20.00
b384f381-29b8-4bd8-851d-04baee3de4c5	4285f73a-4ec2-4144-97d7-0067c4e773b7	1.00	Rolamento 608	20.00
61ce93b1-0bf7-4d2a-b5c8-e1472a034168	4285f73a-4ec2-4144-97d7-0067c4e773b7	1.00	Rolamento 6001	30.00
b652c33b-507c-4ffb-a1da-2cfe785e9d7a	4285f73a-4ec2-4144-97d7-0067c4e773b7	1.00	M.O 	50.00
532a2ea0-886c-49ae-9851-8acc962dd395	56d7a980-f2e3-4618-b3b8-a0af7d9e5471	1.00	Gatilho	80.00
ffd9aed8-7fde-49e9-a102-aae0ca0e148f	0b57a76a-cddf-4f02-8dd1-df693bd98923	1.00	Cabo elétrico 	30.00
146acec4-b038-4a8a-bab2-1f5883da5f96	6dc86da8-1a64-40e9-94a8-9c60d63d8bdf	1.00	Rolamento 6201	30.00
3bfff1ab-b7f9-438a-a87d-2352a62f6f80	6dc86da8-1a64-40e9-94a8-9c60d63d8bdf	1.00	M.O 	40.00
038d4d50-fd3d-4a15-8bfa-94cf4100e039	c0f24c43-eaaa-4dfe-89ca-9e6342cbca2a	1.00	Chave de comando	600.00
7e9aafdf-3892-43b6-a159-a0815c8b54d7	c0f24c43-eaaa-4dfe-89ca-9e6342cbca2a	1.00	Mão de obra	100.00
027120aa-166c-4a78-8e0b-6a17e35b944a	c6f2c468-9920-4840-9879-f4537c438cf4	1.00	Válvula By Pass	160.00
0ddb9a17-274a-4eeb-8c86-8b7a96572412	c6f2c468-9920-4840-9879-f4537c438cf4	1.00	M.O 	80.00
06f06cdd-4efc-451b-a2ee-0b0a52769898	9f9aeb41-0fbf-47aa-988b-e5f0b09d6a49	1.00	Cilindro e Pistão	190.00
b239d035-bcc7-4300-81a9-9d73101caf7c	9f9aeb41-0fbf-47aa-988b-e5f0b09d6a49	1.00	Junta do Cilindro	20.00
eb286492-42a2-4977-bb2c-845cea3f24a3	9f9aeb41-0fbf-47aa-988b-e5f0b09d6a49	1.00	Mão de obra	80.00
bb339cea-1b00-419f-bb02-5ebcdfd93260	b8142b98-af47-4633-94bf-6acd7313ab62	1.00	Carvão 	20.00
14f481bc-0489-4a0f-aac2-73565a757260	b8142b98-af47-4633-94bf-6acd7313ab62	1.00	Tampa do porta carvão 	10.00
0866a307-1e6d-4719-a274-8ba35c35567e	b8142b98-af47-4633-94bf-6acd7313ab62	1.00	Mão de Obra 	30.00
3b3a5288-b988-40ed-aefd-d2b0a7333c27	9fc9d663-9042-4862-94db-a99daa2e78ae	1.00	Rolamento 608	20.00
1996f3b1-7143-4c00-a28a-94e5e472213f	9fc9d663-9042-4862-94db-a99daa2e78ae	1.00	Jogo de carvão	20.00
0eb4c37a-3d20-499f-9dcf-6db28872d9fa	9fc9d663-9042-4862-94db-a99daa2e78ae	1.00	Calço na bobina/ mão de obra	30.00
15959b5a-ad6e-4bc9-8dbc-a404df9d3c2c	214246a0-327c-4fa9-87a6-2d4b7afe8041	1.00	Tubeira	120.00
4a28875f-539a-460b-9be1-8e60a8a1fddc	214246a0-327c-4fa9-87a6-2d4b7afe8041	1.00	Mão de obra	20.00
676a60dc-ba72-4f9e-97b7-5582b5a6bb53	0c5b183c-833d-44e3-bd30-e61edc6c4057	1.00	Mão de obra	80.00
4203ddaf-2711-4a8b-ae50-e5deca33c34f	0c5b183c-833d-44e3-bd30-e61edc6c4057	1.00	Troca de disco	45.00
654552c7-1840-4217-8fe8-51960c3898c8	0904f0de-cf2e-439c-acbd-1f236df974f4	1.00	Mão de obra 	30.00
c93628a5-f883-4499-b622-9b2a6a3da0eb	12b874e9-003f-4927-a632-77857adf0e7e	1.00	Rotor 	130.00
d2cf025b-26d4-46e9-812a-e766a3de1b4d	12b874e9-003f-4927-a632-77857adf0e7e	1.00	Estator 	120.00
7650f033-4f72-47eb-a627-0e648b084063	12b874e9-003f-4927-a632-77857adf0e7e	1.00	Carvão	20.00
da8db751-1b07-4b86-b8d8-3ba05b87ea7b	12b874e9-003f-4927-a632-77857adf0e7e	1.00	Mão de Obra 	50.00
242aedfa-e751-49dc-9c99-0263e541a770	56d7a980-f2e3-4618-b3b8-a0af7d9e5471	1.00	Carvão	20.00
1792340a-d2ea-4f3b-8c89-a05c8b4ac8b5	a2bd17cc-c1b3-4df8-9495-9f1200497b72	1.00	Rotor 	0.00
5603c2b7-c978-4cfe-8b0b-4f99c4673912	754d18cf-53ac-47ee-9b10-36a840a48860	1.00	Rotor 	280.00
a4bb5225-9264-4ee7-8cf5-cfc6193013e1	754d18cf-53ac-47ee-9b10-36a840a48860	1.00	Estator	180.00
dd0bd757-a38d-4fe0-8aa5-30d32c68a2f9	1b76cc63-aced-4b7c-a847-b0e7e88b8b77	1.00	Rolamento 629	20.00
24ae105b-a189-445f-b4d6-271d405373ad	1b76cc63-aced-4b7c-a847-b0e7e88b8b77	1.00	Carvão 	20.00
e6b7ffd6-554f-44cb-937b-eb2b9014dccf	1b76cc63-aced-4b7c-a847-b0e7e88b8b77	1.00	Cabo elétrico 	20.00
5dbd150a-b1cf-4897-a79f-83462f3d2740	1b76cc63-aced-4b7c-a847-b0e7e88b8b77	1.00	Mão de obra	50.00
6dc10d40-a4d0-408f-84e0-0a188e2dd221	045a9548-96af-4f26-bdda-34649163adc8	1.00	Almofada 	40.00
ce211880-c8eb-40f4-9a82-a674164b1228	045a9548-96af-4f26-bdda-34649163adc8	1.00	Rolamento 6000	30.00
5dd18d15-d9d5-4c19-b875-4342bccba8f3	045a9548-96af-4f26-bdda-34649163adc8	1.00	Mão de Obra 	30.00
5305c61a-1d4b-49c1-adcb-8966d5573c0d	a2bd17cc-c1b3-4df8-9495-9f1200497b72	1.00	Carvão	0.00
82d006cf-184f-4738-8ef1-7edaf7ee3e28	56d7a980-f2e3-4618-b3b8-a0af7d9e5471	1.00	Mão de Obra	40.00
7139f62d-d118-4c76-8456-df30b68619f0	7cd9933d-759f-49b7-8bd6-c1f10a7ee4a9	1.00	Rotor	310.00
02e3ad10-569a-4bb4-b146-f8d8ae8d7de2	735ac9d2-c8d7-452d-8b70-3a75fc33b7a6	1.00	Montagem	60.00
5491438a-be7e-4669-882c-9587f26bcba0	7cd9933d-759f-49b7-8bd6-c1f10a7ee4a9	1.00	Estator	220.00
96e8b138-ee9a-4f81-8a18-4953190962c9	7cd9933d-759f-49b7-8bd6-c1f10a7ee4a9	1.00	Porta carvão	60.00
f28f6493-1104-447a-931c-1cad0503f3d9	7cd9933d-759f-49b7-8bd6-c1f10a7ee4a9	1.00	Jogo de carvão	50.00
7ef13df6-6eca-4ac2-bf95-58fa1b6f8369	7cd9933d-759f-49b7-8bd6-c1f10a7ee4a9	1.00	Mão de obra	60.00
c16ca7d4-8d60-4cab-a1a6-9940eb8aadd5	8e5d4e91-bdc6-4ba6-ba6d-910203762ed4	1.00	Botão trava do gatilho	20.00
a7e3d6c6-32f6-4e13-b2e9-0b82c3b3374f	8e5d4e91-bdc6-4ba6-ba6d-910203762ed4	1.00	Mão de obra	20.00
9285c554-a191-410f-9fb1-33b1b02bb687	115a5776-a43c-47f3-af74-7cdb61e912d3	1.00	Mão de obra 	60.00
205e2d1f-f405-48ea-b956-ed49598ca802	1d62baa9-3ced-4b01-8536-4c623eb56e8f	1.00	Lubrificação 	80.00
404ccdf1-cb9c-4af5-95bb-9efeb599b83a	1d62baa9-3ced-4b01-8536-4c623eb56e8f	1.00	Tomada pino macho	20.00
cd947078-d97e-4bc3-891e-733867270a4c	754d18cf-53ac-47ee-9b10-36a840a48860	1.00	Mão de obra	60.00
bbc95680-5a40-41c9-b303-23b6aacaaf64	60d9bc5a-3e31-4238-ae2f-4222aa3b7586	1.00	Mão de obra 	50.00
5922eda2-063d-4ff5-9824-dfc8f51ad160	003053ea-db62-4e80-9fb8-5a6f68434533	1.00	Rotor 	0.00
2d8cb52e-b9ea-4f0e-9eaa-deeec04cd039	003053ea-db62-4e80-9fb8-5a6f68434533	1.00	Engrangem	0.00
61ed8ecd-b2fe-484b-87d2-740f3177322f	003053ea-db62-4e80-9fb8-5a6f68434533	1.00	Carcaça	0.00
091759da-aba8-4672-bf84-d5d104bfaa9f	42bef4a9-042d-43ae-b2d0-e88d33152ce1	1.00	Válvula Bypass	50.00
9091ab72-e5db-4bfb-8cb5-04415ef3fb73	42bef4a9-042d-43ae-b2d0-e88d33152ce1	1.00	Mão de Obra	50.00
81170dea-f5c3-41e4-8909-6eb89bef5908	7f1d4ab1-e8c1-45f0-8be2-e65f40bae359	1.00	Jogo de anéis 	70.00
f6e04938-a527-4138-a094-9fa9e580057e	7f1d4ab1-e8c1-45f0-8be2-e65f40bae359	1.00	Descarbonização 	80.00
5915800a-27b5-49af-a44e-6ed5d503976f	7f1d4ab1-e8c1-45f0-8be2-e65f40bae359	1.00	Junta do cilindro	20.00
814f07f2-6321-4cb5-ba0e-aac71172aa56	275a3f90-d716-425f-8d8d-e3886b8c4a15	1.00	Gatilho	40.00
cbc35d3e-c187-4621-894e-fbf8a2f15f8a	34c06735-d64a-44f4-98d6-0cea04823b96	1.00	Rebobinagem da bobina 	300.00
f9d44ef8-ae94-4b4f-8245-98cec8a4758e	34c06735-d64a-44f4-98d6-0cea04823b96	1.00	Rolamento 608	20.00
4d73d83c-c6f0-4116-b505-ca0de89df5bb	34c06735-d64a-44f4-98d6-0cea04823b96	1.00	Rolamento 6000	20.00
1768e85d-f981-4a78-910e-3709693280a5	34c06735-d64a-44f4-98d6-0cea04823b96	1.00	Rolamento 6002	30.00
a36ee3ac-aed7-4133-a4dc-469db5bcea9b	34c06735-d64a-44f4-98d6-0cea04823b96	1.00	Mão de obra	60.00
95f2e573-554f-4ea2-aae3-a69a57482e51	3f1d2bc3-c377-4a8d-ad9e-e543339b4744	1.00	Conj. pés de apoio 	100.00
4d327f6d-3aff-4c5d-945a-43d6f4045d5b	99d0271a-0c46-4b39-9dc5-9727f7b0a610	1.00	Rebubinação do Motor 	1800.00
20a40967-28f8-42af-bcc2-650605ee0429	3f1d2bc3-c377-4a8d-ad9e-e543339b4744	1.00	Base completa 	100.00
da255dda-dc99-4c3c-9704-4c8056c8af71	3f1d2bc3-c377-4a8d-ad9e-e543339b4744	1.00	Almofada da lixa	40.00
01638fbd-e6d9-41a7-b8c7-0c8ae66baebe	3f1d2bc3-c377-4a8d-ad9e-e543339b4744	1.00	Mão de obra 	40.00
3da94247-caf4-45ec-8b94-fb7044127eec	51a9ca1a-a2b1-47b0-9074-d41cb3699700	1.00	Mão de obra	56.00
11d3d6db-7df6-4a88-8329-0fffbd0fdf31	51a9ca1a-a2b1-47b0-9074-d41cb3699700	1.00	Reparo no estator	118.00
118143ba-2f6e-43ca-a42f-eba630b58945	51a9ca1a-a2b1-47b0-9074-d41cb3699700	1.00	Troca de interruptor	50.00
b9ae705c-b8ad-4372-aa47-8eb124463c9f	9fe59675-13c8-4715-a375-ee2a3474c197	1.00	Troca de interruptor	46.00
44cfaf63-c691-48f8-ae94-52c8f9801801	9fe59675-13c8-4715-a375-ee2a3474c197	1.00	Mão de obra	113.00
33ab167e-06d9-45c8-ae1d-03c76ea41d93	29a209cc-9105-4667-9ff6-1471676e55f5	1.00	Mão de obra	59.00
37613b5b-505c-4be1-a6f6-7551f8a24c12	29a209cc-9105-4667-9ff6-1471676e55f5	1.00	Troca de carvão	38.00
32f9b939-31a1-4203-8f11-ed16ff84e5e4	9ddfa3c1-f53a-4ef6-8c54-3f52cbd4ff54	1.00	Troca de rolamento	74.00
29c75430-976d-4779-a5f3-cfb13259aebb	9ddfa3c1-f53a-4ef6-8c54-3f52cbd4ff54	1.00	Troca de engrenagem	111.00
c6bf073a-974c-483e-a910-efcd4ed1ae17	9ddfa3c1-f53a-4ef6-8c54-3f52cbd4ff54	1.00	Troca de interruptor	65.00
94dfa10b-d54d-4e82-a757-0316cddc0760	b4a1c8f8-0b87-40ef-b56b-e913863fae10	1.00	Troca de interruptor	38.00
19b0e723-8698-4bfa-82f0-893aa223f6f3	810f9355-9a30-4341-9be2-dea58d620b1e	1.00	Troca de interruptor	58.00
c8c8125b-75d1-4cbc-b8b8-09ee5955975a	810f9355-9a30-4341-9be2-dea58d620b1e	1.00	Limpeza interna	27.00
c21d5a06-b32b-4641-9b7a-b08be5f54acd	88c6f402-b63c-4633-8132-df90e7300e98	1.00	Mão de obra	116.00
891e75a2-16b9-4097-bd35-a6c9bc1ea25c	88c6f402-b63c-4633-8132-df90e7300e98	1.00	Limpeza interna	36.00
9262b9b1-d220-4d1f-a89d-23aabccb2796	275a3f90-d716-425f-8d8d-e3886b8c4a15	1.00	Mão de obra	20.00
2b609a17-d678-473b-88b3-b022e206b5cf	f231baa9-0e66-4f8e-adc9-5a01e5650f41	1.00	Rotor 	150.00
1e412d21-23a2-4247-8a4a-b0b2f9ef969e	f231baa9-0e66-4f8e-adc9-5a01e5650f41	1.00	Carvão	20.00
41cc798f-19f8-4f56-b2b3-4987bf17bdac	f231baa9-0e66-4f8e-adc9-5a01e5650f41	1.00	Mão de obra	50.00
292e124f-6c26-46a9-8af6-7497a4b2a2dd	10eccb8d-6905-481c-8c03-45954a230b54	1.00	Filtro de ar	30.00
802ebcce-5075-4055-9c73-43eaa18fc333	10eccb8d-6905-481c-8c03-45954a230b54	1.00	Suspiro do óleo 	50.00
05fe5766-6824-45a8-9dab-6e7eed290b34	e5eb61a5-e138-4eef-8eee-d8972098dcad	1.00	Rebobinagem do motor 	500.00
a561fd87-aba4-477a-894e-c723162c5009	e5eb61a5-e138-4eef-8eee-d8972098dcad	1.00	Capacitor de partida	50.00
525c32fa-c2e3-4085-aa6b-ad968dfd0144	e5eb61a5-e138-4eef-8eee-d8972098dcad	1.00	Mão de obra 	60.00
17986cbd-433c-4bd8-81e2-152a95c68735	10eccb8d-6905-481c-8c03-45954a230b54	1.00	Óleo 	20.00
d74404a4-618a-4632-9b77-5d732c1598f9	10eccb8d-6905-481c-8c03-45954a230b54	1.00	Engate rápido	40.00
d0f3f0f9-37ce-4fa2-ac04-887c477cd619	10eccb8d-6905-481c-8c03-45954a230b54	1.00	Mão de obra 	50.00
9c388353-6041-4ee4-bdd1-15ae5e642e17	b8c8ea7d-ca4e-4f71-8fc5-67bbe8f30602	1.00	Jogo de anéis 	50.00
261e94db-4ffa-4631-b895-c96bb7f0c39d	b8c8ea7d-ca4e-4f71-8fc5-67bbe8f30602	1.00	Jogo de Juntas 	30.00
df5ecb7f-ec9f-418b-b40a-fb0770b934ba	b8c8ea7d-ca4e-4f71-8fc5-67bbe8f30602	1.00	Limpeza no prato de válvulas	0.00
eabb82f9-19d5-4f51-92b5-7674d23b4526	b8c8ea7d-ca4e-4f71-8fc5-67bbe8f30602	1.00	Elemento filtrante 	30.00
d9ef3850-9667-4b6e-a463-2d9e4d5f8874	b8c8ea7d-ca4e-4f71-8fc5-67bbe8f30602	1.00	Óleo 	20.00
36355a5c-a7d1-46eb-99f7-eb402ea161b0	b8c8ea7d-ca4e-4f71-8fc5-67bbe8f30602	1.00	M.O	60.00
a1f7ff68-b016-4acd-acf3-b9d85af05b29	56e73ee6-79ee-41af-9827-66a21ad7159e	1.00	Controlador de Velocidade 	450.00
0c85b4ca-2e0f-4fe9-98ea-852bfbcce27d	56e73ee6-79ee-41af-9827-66a21ad7159e	1.00	Gatilho 	170.00
4ed30277-1e13-4e02-8084-6f4a6bcb1a6b	56e73ee6-79ee-41af-9827-66a21ad7159e	1.00	M.O 	50.00
abf58fa0-7fff-42ca-9550-3bb3aac95f63	1a8c3fc7-5cfd-4d0f-8965-df6471a63397	1.00	Kit reparo comp.	0.00
b10d59b6-f393-4bcb-8ea1-84d9b4c14b00	3b9e2d96-44a4-4ac6-95cb-e727da2cdbd7	1.00	Rotor 	0.00
a0dc77bc-63bb-41b8-805e-0cc06e3c75e8	3b9e2d96-44a4-4ac6-95cb-e727da2cdbd7	1.00	Carvão	0.00
226bf560-71ac-4d95-b4d4-ddd8645da5a6	3b9e2d96-44a4-4ac6-95cb-e727da2cdbd7	1.00	Porta carvão	0.00
908f2896-31cc-49b0-8bac-bb0d6ed560cc	93660902-0806-436c-8969-af11a5c173df	1.00	Rotor 	420.00
0d804c72-75b2-462a-aee1-904d203c55fc	93660902-0806-436c-8969-af11a5c173df	1.00	Carvão	40.00
9d80abc9-e465-42b0-8ef4-80006aff9640	93660902-0806-436c-8969-af11a5c173df	1.00	Mão de obra 	70.00
a80d30ff-509c-4658-b177-f6f5c8dc2f2b	fbbcf1e8-b14b-45d0-87e5-e822e021ee35	1.00	Porta carvão 	60.00
1a32c9c5-c78e-46c5-857d-25f841d3ac37	fbbcf1e8-b14b-45d0-87e5-e822e021ee35	1.00	Mão de obra	50.00
8e5e33e4-9d84-47ab-80eb-9d4a6af168af	4af873ce-fc15-4d8d-a431-2ccb5fd26982	1.00	Carvão 	20.00
2726bcb5-40c5-43fa-9dba-b6a5920763db	4af873ce-fc15-4d8d-a431-2ccb5fd26982	1.00	Fio partido	0.00
6eae1fae-528e-4883-bd5f-07713492b83e	4af873ce-fc15-4d8d-a431-2ccb5fd26982	1.00	Mão de obra	40.00
3ca7f2fc-713b-469f-b490-532fbbc55daf	123e91d2-e036-4a74-80eb-03037134ded8	1.00	Tomada 10a	20.00
9c5d944f-8504-4264-bd42-e95d89653e8f	123e91d2-e036-4a74-80eb-03037134ded8	1.00	Tampa do porta carvão	10.00
5270bb5e-df05-4dc9-9c24-0cd3b2f3e58b	196bae00-2942-47f3-a7cf-ba0fe6e6a435	1.00	Rebobinamento do motor 	500.00
5a370aeb-1e10-40f7-9b30-0ca40678381b	196bae00-2942-47f3-a7cf-ba0fe6e6a435	1.00	Kit reparo completo 	180.00
af1c6669-ae2e-4f25-94ff-071be740f8b0	196bae00-2942-47f3-a7cf-ba0fe6e6a435	1.00	Mão de obra 	60.00
a1a4a21d-284e-4b51-87f2-39c983d84c8c	123e91d2-e036-4a74-80eb-03037134ded8	1.00	Jogo de carvão	20.00
72bc9349-2b55-4feb-aa8a-a25af970d74f	123e91d2-e036-4a74-80eb-03037134ded8	1.00	Rotor	370.00
16cfa628-48ce-443c-94e7-2577b9813bd6	123e91d2-e036-4a74-80eb-03037134ded8	1.00	Tampa da correia (carcaça)	100.00
d8002def-45dd-4a27-a46b-fb415bbef932	567dcee6-143f-48d9-bfae-660625d76d0c	1.00	Rotor	500.00
5a668316-a27e-4bfe-9154-11fe70f76cc3	567dcee6-143f-48d9-bfae-660625d76d0c	1.00	Mão de obra	50.00
2ecf8509-4fe7-463d-88d4-bfaf1bc37ff1	a49da342-6461-406e-bc1b-2ba38afbd9b1	1.00	Mola do porta carvão	20.00
110b174e-7b6d-447f-a9ca-956d391f030f	a49da342-6461-406e-bc1b-2ba38afbd9b1	1.00	Mão de obra	30.00
f595a462-91e2-49cc-aa78-f232f593344b	b92f8c34-09d1-4098-9e39-63db4edea838	1.00	Base completa 	100.00
2b2c479d-4d1f-412d-bf28-daa7939375cc	b92f8c34-09d1-4098-9e39-63db4edea838	1.00	Almofada da lixa	40.00
eba62e43-7554-40aa-b6aa-2d4cec52d9dd	b92f8c34-09d1-4098-9e39-63db4edea838	1.00	Rolamento 6001	30.00
4742fb84-4555-44ed-b26c-3254b596e63a	7c1b027d-0871-449c-bda5-4d7aeb538afc	1.00	Rotor 	310.00
0ac3e8c9-9663-4c20-943c-6c66dcc37548	7c1b027d-0871-449c-bda5-4d7aeb538afc	1.00	Estator	250.00
ebed6db4-095e-4418-9a99-76e5c0e6fe55	7c1b027d-0871-449c-bda5-4d7aeb538afc	1.00	Mão de obra	60.00
5983417e-5554-4ef2-9545-855ac3162238	07264ab0-4bde-4dc0-a31b-5b6aa854add6	1.00	Rotor	0.00
8aca297a-761b-4000-9951-f5e0bf1f5ef7	07264ab0-4bde-4dc0-a31b-5b6aa854add6	1.00	Estator 	0.00
cebe69ba-780f-40ab-a2d4-94786dde4f77	07264ab0-4bde-4dc0-a31b-5b6aa854add6	1.00	Mão de obra 	0.00
797ec44d-7550-45e6-830b-49633126cf58	05c63926-f7ce-4bba-a743-138cd6f01a66	1.00	Estator	0.00
b4197b76-50e1-4de5-a9d2-269de05645a6	05c63926-f7ce-4bba-a743-138cd6f01a66	1.00	Tomada 10A	0.00
6d6e1b37-f4ba-44d2-a259-5627ced20cc8	05c63926-f7ce-4bba-a743-138cd6f01a66	1.00	Chaveta da engrenagem	0.00
ef7b6025-b531-45a1-b21f-45ee0d4bd4ef	05c63926-f7ce-4bba-a743-138cd6f01a66	1.00	Mão de obra 	0.00
e93b921e-f7c1-450c-81cc-0919ec735e20	c916d3eb-57d3-4428-b673-9f29116661a2	1.00	Rotor	0.00
3147e7a5-ecbd-4583-a2b8-b8d09b823381	c916d3eb-57d3-4428-b673-9f29116661a2	1.00	Estator	0.00
95053a03-e2be-431f-916a-72ae3106b234	c916d3eb-57d3-4428-b673-9f29116661a2	1.00	Mão de obra	0.00
8baefa85-d67f-41a9-ab2f-e1f88a1ff912	b92f8c34-09d1-4098-9e39-63db4edea838	1.00	Mão de obra	40.00
e99705a9-7ae2-4e8f-8215-9cbe2677b856	4132b3d0-f242-4523-a898-0d420536dd1a	1.00	Base completa	100.00
aafa7b20-e984-4028-a1ff-1a3c5facacc6	dd49e6f9-5515-4a7f-86ba-cd8e8e9804d8	1.00	Porta Carvão 	20.00
7013a5f6-ff26-464b-92e1-d22810782c46	dd49e6f9-5515-4a7f-86ba-cd8e8e9804d8	1.00	Carvão	20.00
d29b4428-44b8-4bf6-93c9-54af157e616f	dd49e6f9-5515-4a7f-86ba-cd8e8e9804d8	1.00	Mão de Obra	30.00
310c270c-5fe3-4406-9820-addd149fb9f8	f4a435a2-f9de-40cd-acb9-fad17aff30d3	1.00	Interruptor	50.00
c3ccb62f-9496-45e7-b897-43626f54d7d7	f4a435a2-f9de-40cd-acb9-fad17aff30d3	1.00	Mão de Obra 	30.00
14e6ad98-e2e8-4cbb-87e6-f790d8493196	b6fe696a-d45a-415d-91c7-21e9e6b9c90d	1.00	Fio partido 	30.00
7e54fbd0-ed1a-4b56-ab76-7f83c27d882d	b6fe696a-d45a-415d-91c7-21e9e6b9c90d	1.00	Lubrificação	40.00
0c627a33-db16-4661-9824-6e87cb5a38d1	4132b3d0-f242-4523-a898-0d420536dd1a	1.00	Almofada	40.00
7ea8914e-23df-4f58-9a02-a47605b55125	4132b3d0-f242-4523-a898-0d420536dd1a	1.00	Conj. pés de apoio	100.00
66f76c0c-76a7-41f7-b2f6-b0b7325093da	2c12cbbd-9f06-437f-84fe-d8d06142d55e	1.00	Placa de aperto 	30.00
d767c05f-71e0-4633-991e-b482e77b5dd2	2c12cbbd-9f06-437f-84fe-d8d06142d55e	1.00	Cilindro 	40.00
00412b04-ee19-4b56-9cf5-14535a0f2d1d	2c12cbbd-9f06-437f-84fe-d8d06142d55e	1.00	Pistão	30.00
ac3c1c66-46db-4852-a5a8-137293611021	2c12cbbd-9f06-437f-84fe-d8d06142d55e	1.00	Oring 	20.00
7f0f6383-4d07-4713-9986-37c334fe4eab	2c12cbbd-9f06-437f-84fe-d8d06142d55e	1.00	Cabo elétrico	20.00
5b65980c-e604-4f68-989d-4ecd2cb3b9f6	2c12cbbd-9f06-437f-84fe-d8d06142d55e	1.00	Carvão 	20.00
05d08d66-0dbf-4fa5-97a4-097c09af10a0	2c12cbbd-9f06-437f-84fe-d8d06142d55e	1.00	Mão de obra 	50.00
674658aa-1367-4fe7-9c86-f5fd972ef642	2c12cbbd-9f06-437f-84fe-d8d06142d55e	1.00	lubrificação 	30.00
9f6898d1-2bde-443a-a0ed-66f8dfe5b2db	c8beb81c-7a94-47dd-a3ec-5674e7c806cc	1.00	Came 	50.00
9c7e5661-9600-4ade-8467-b7b662bc0896	c8beb81c-7a94-47dd-a3ec-5674e7c806cc	1.00	Mancal 	60.00
5e4036a1-a48e-4cc1-a378-e371878cc51a	c8beb81c-7a94-47dd-a3ec-5674e7c806cc	1.00	Tomada 	20.00
0cd031b8-28eb-4770-9450-f394bbc68af3	c8beb81c-7a94-47dd-a3ec-5674e7c806cc	1.00	Oring	20.00
dbb223f4-037d-4975-9bb9-a9c0b5b444ef	c8beb81c-7a94-47dd-a3ec-5674e7c806cc	1.00	Lubrificação	30.00
499667f3-9cd7-40e8-93e8-91390137954e	c8beb81c-7a94-47dd-a3ec-5674e7c806cc	1.00	Mão de obra 	50.00
32f623ab-f73a-4dca-8aa1-53ec32b24ad8	dfdca527-6846-485b-b655-52db054d2093	1.00	Calço no Estator 	40.00
ced72fff-bb8c-4422-80d7-18dea39bb095	4132b3d0-f242-4523-a898-0d420536dd1a	1.00	Rolamento 6001	30.00
8e984db4-96a8-4d40-bd28-25f400c9a230	986cf19d-319e-448d-b463-2888d589ba79	1.00	Mandril	60.00
29c752bd-72df-42ee-8473-b1d25fc0915b	986cf19d-319e-448d-b463-2888d589ba79	1.00	Mão de obra	40.00
88515b3d-2287-4f64-a10a-8103ecbfc0a4	852a3fec-392b-40f1-950f-9762ad8b0519	1.00	Capacitor de partida 	60.00
a0cac203-1a57-47ef-93aa-7f356691477c	852a3fec-392b-40f1-950f-9762ad8b0519	1.00	Jogo de rodas 	100.00
8572ef8d-77d5-4597-abb4-6232181ae4fb	852a3fec-392b-40f1-950f-9762ad8b0519	1.00	Mão de obra	50.00
c811ae23-f37d-450d-bc09-83585d442990	166fc1b9-8818-4454-8986-fdbc9a579b6f	1.00	Base Completa 	100.00
7f6d4da7-f977-472e-ab11-292473934e1d	166fc1b9-8818-4454-8986-fdbc9a579b6f	1.00	Almofada 	40.00
bdf6e0be-f8e4-4133-95b0-f76038c57108	166fc1b9-8818-4454-8986-fdbc9a579b6f	1.00	Tomada Pino macho 	20.00
671feca9-7b4f-436d-a5c0-769718cafe6b	166fc1b9-8818-4454-8986-fdbc9a579b6f	1.00	Mão de obra 	40.00
3c6d1e04-f932-4b29-8e52-44d1094a6909	fc4e36c4-e5a3-4419-94ed-42418cb00f50	1.00	Engrenagem 	50.00
a1aa4d25-2333-49dd-938c-1102863e4591	fc4e36c4-e5a3-4419-94ed-42418cb00f50	1.00	Pinhão 	40.00
228b57f4-1af8-4d80-89ca-b5a029590ccb	fc4e36c4-e5a3-4419-94ed-42418cb00f50	1.00	Mão de obra 	50.00
4144d89e-8cb6-4274-b934-93a9ed69f6a4	c0d37832-e76d-4d20-a80e-ffb091f7ee0a	1.00	Engrenagem 	40.00
c30fb2fa-537c-4f2b-b3d5-4e5bc6d870e0	c0d37832-e76d-4d20-a80e-ffb091f7ee0a	1.00	Mancal 	50.00
e9910f2b-f16a-4a4b-864c-8dd0a32afe6f	c0d37832-e76d-4d20-a80e-ffb091f7ee0a	1.00	Rotor 	130.00
42a69a3a-7ed8-449e-88ae-795bdef301c9	c0d37832-e76d-4d20-a80e-ffb091f7ee0a	1.00	Atuador 	30.00
98f111a1-3bfd-44e5-9861-7ac5ab1a0ff8	c0d37832-e76d-4d20-a80e-ffb091f7ee0a	1.00	Mão de obra 	50.00
8e5d80f6-ee59-468b-93ad-628ef248b14f	c30a82a2-d2f3-44ad-b26c-d9477f9cc220	1.00	Gatilho	20.00
13fb6b32-336f-4da1-b1cc-3ef7f00869ff	c30a82a2-d2f3-44ad-b26c-d9477f9cc220	1.00	Mão de obra 	30.00
900b58f5-7ab9-4bd4-9d1d-beef96e0a3df	be90a785-79cc-4b33-9cfb-4361135210ff	1.00	Gatilho	50.00
bf313601-5b27-40b0-9455-dcefc92a1f6e	be90a785-79cc-4b33-9cfb-4361135210ff	1.00	Mão de obra	30.00
4c8b284c-b20f-4cb8-b3ee-610a599a2caa	74b0d23c-6bb1-4128-81b7-523156afa3d4	1.00	Rolamento 6001	30.00
58fdddf3-0fbb-4381-9435-0f615eec8e67	74b0d23c-6bb1-4128-81b7-523156afa3d4	1.00	Mão de obra 	40.00
9b9d8106-8a90-486c-a3aa-ed17998ef980	f6a2eb03-639d-46b7-a693-f5135f39358e	1.00	Fio partido 	30.00
0305e39a-24b2-4aef-bc9b-0b0e7e776ec9	065f60b8-c41e-4556-ac02-d77cfe9b4625	1.00	Parafuso de regulagem	20.00
6becd451-1cef-4faa-8dd8-6a67a7d4dadb	e1d9cc39-b2f6-485c-9836-bfe9ee152b5a	1.00	Rotor 	200.00
f5771611-48aa-4e47-bede-edf508b5853d	e1d9cc39-b2f6-485c-9836-bfe9ee152b5a	1.00	Engrenagem	80.00
848e2b35-6416-492c-acea-29f5af063683	e1d9cc39-b2f6-485c-9836-bfe9ee152b5a	1.00	Mão de obra	50.00
3dc8874d-9df7-47cc-bb58-4d8103894925	f6b14792-18a5-4052-b505-e11dd498525f	1.00	Válvula Bypass	100.00
c84213f0-cf9c-48f3-9e40-92dec8e5c3c1	f6b14792-18a5-4052-b505-e11dd498525f	1.00	Kit reparo 	100.00
d40d38c9-0074-4831-8896-143873e923d8	f6b14792-18a5-4052-b505-e11dd498525f	1.00	Mão de obra 	60.00
fa40201a-e391-4702-96bb-d12be26cf066	b652668b-7e69-4dce-b2c6-d30dc395c0fc	1.00	Válvula Bypass	100.00
b64e2f54-8921-43a1-a751-ad07846ac9c1	4197462f-2376-4048-b3bc-82bcb4c8007b	1.00	Rotor 	290.00
d2160896-799b-4fef-b389-e140cb081c5e	4197462f-2376-4048-b3bc-82bcb4c8007b	1.00	Estator	190.00
63754928-333f-4a2d-a859-ac27efe746a3	4197462f-2376-4048-b3bc-82bcb4c8007b	1.00	Jogo de carvão	20.00
1765cba0-25bc-4969-b928-73a116f5e89c	4197462f-2376-4048-b3bc-82bcb4c8007b	1.00	Mão de obra	60.00
f3f23f33-dc0a-4bb9-bb86-b6d945371ef9	b652668b-7e69-4dce-b2c6-d30dc395c0fc	1.00	Kit Reparo 	180.00
1b6c1e48-bde4-4b08-b073-d1b0f9aef783	b652668b-7e69-4dce-b2c6-d30dc395c0fc	1.00	Mão de obra	80.00
e076ad96-6073-40e3-be6e-ad7d8be8a2a4	f9993808-c293-448c-be0a-8b1404a2a985	1.00	2 Cilindros 	340.00
34030597-ef14-4cae-a6d1-f88f3b6498e6	ab664a09-417e-4bd9-9bd3-468663633246	1.00	Gatilho	0.00
6d311f4d-92a6-4865-8887-4254f0e008da	ab664a09-417e-4bd9-9bd3-468663633246	1.00	Placa eletrônica	0.00
4a507f79-9d0a-4f77-a48e-023728b58dfb	5c0e6ed7-0f9c-4629-8009-48e0cfdca70f	1.00	Kit reparo comp.	230.00
fcf2ee8e-d6ed-44c9-803c-aff22a5ff33d	5c0e6ed7-0f9c-4629-8009-48e0cfdca70f	1.00	Reparo do bico 	60.00
aed50c1d-ea68-41d3-bbeb-7e73c4c3aeab	5c0e6ed7-0f9c-4629-8009-48e0cfdca70f	1.00	Mão de obra 	60.00
0d20ae06-7726-4faa-a829-20a45a4fc7a4	f9993808-c293-448c-be0a-8b1404a2a985	1.00	2 Jogos de aneis 	140.00
1b101e08-f84a-4a0e-a302-d008ed7e75dd	44ea71b3-cad4-4878-9441-f18abfde1c2e	1.00	Retentor de óleo 	30.00
f9bab4f3-d783-4d5b-94de-18bfc60371ed	44ea71b3-cad4-4878-9441-f18abfde1c2e	1.00	Válvulas pressão e sucção	60.00
2758884a-7ff4-4005-ad81-e192c46349bf	44ea71b3-cad4-4878-9441-f18abfde1c2e	1.00	Esguicho regulador	60.00
0acb685e-0ea8-4e69-8ccf-98beb7dc8ce0	44ea71b3-cad4-4878-9441-f18abfde1c2e	1.00	Gaxetas de vedação	50.00
73b22a10-8d34-4a55-9116-c21dca1b5c35	44ea71b3-cad4-4878-9441-f18abfde1c2e	1.00	Óleo 	30.00
d8bc7d32-7bf0-405d-94b8-ebfecb58260a	44ea71b3-cad4-4878-9441-f18abfde1c2e	1.00	Mão de Obra	80.00
e046ce2e-a8ce-4a2f-933a-93abaf2933ad	f9993808-c293-448c-be0a-8b1404a2a985	1.00	Jogo de junta 	100.00
de4e75e6-eafc-4419-a0a4-9b5688e1857b	f9993808-c293-448c-be0a-8b1404a2a985	1.00	Reparo do prato de valvúlas 	150.00
0eecbfd8-01c8-490f-93d9-56c019690aaa	f9993808-c293-448c-be0a-8b1404a2a985	1.00	Óleo	60.00
2d338584-5238-4acd-b034-c4b40bb7dd4f	f9993808-c293-448c-be0a-8b1404a2a985	1.00	Mão de obra	100.00
96a0a8b1-fe3b-4802-a294-cbdb76afcab1	dc1c7d37-c534-4e56-a32b-2bc1c8eb1fde	1.00	Cotovelo 	30.00
a865109f-9305-4782-97a2-e74e3dff2edd	dc1c7d37-c534-4e56-a32b-2bc1c8eb1fde	1.00	Anilha da serpentina 	10.00
fc6302e1-de32-4d29-a5fe-b59fd5d5d96e	dc1c7d37-c534-4e56-a32b-2bc1c8eb1fde	1.00	Óleo 	20.00
3b7dd8ce-0f2f-4e08-be17-55a22f7a27ef	dc1c7d37-c534-4e56-a32b-2bc1c8eb1fde	1.00	Vareta Marcador de óleo 	60.00
227118a3-e82e-4c3d-8817-3e55675a4774	dc1c7d37-c534-4e56-a32b-2bc1c8eb1fde	1.00	Mão de Obra 	50.00
66df9a69-6306-4ab8-ae1b-778883e0fddb	dc1c7d37-c534-4e56-a32b-2bc1c8eb1fde	1.00	Jogo de Rodinhas 	80.00
0001ae9c-1a40-4ed4-bf5f-9d4bd02da56a	8c346433-e17f-4b18-9db1-0970c1ad297e	1.00	Mão de obra	30.00
355e616f-bfba-40ae-a667-a6b76191af42	ea7fcdf0-e497-432f-99de-8ca7148cdc14	1.00	Chave Eletromagnética	360.00
6dd5f7f4-100b-4fd6-bf95-be0d8f6fd328	ea7fcdf0-e497-432f-99de-8ca7148cdc14	1.00	Mão de obra	150.00
92ac1083-9649-4785-9b76-8fe6229eaabc	dbd9dc06-f8cf-46de-b788-87e343fc06f4	1.00	O`Ring do pistão	20.00
087759e5-9428-4436-a511-42cb8457660a	dbd9dc06-f8cf-46de-b788-87e343fc06f4	1.00	O`Ring da biela	20.00
7929aa76-c227-486c-a0ec-e140659773da	dbd9dc06-f8cf-46de-b788-87e343fc06f4	1.00	Lubrificação	100.00
5de1b48f-bda0-4256-851f-605362b1c2a1	dbd9dc06-f8cf-46de-b788-87e343fc06f4	1.00	Botão seletor	50.00
6be8f683-3909-475d-97cb-172e9ab94226	dbd9dc06-f8cf-46de-b788-87e343fc06f4	1.00	Exentrico	30.00
d0af3caa-af57-4449-9602-ac40c31c97d6	dbd9dc06-f8cf-46de-b788-87e343fc06f4	1.00	Mão de obra	100.00
46d32771-4336-47fc-b065-9460d42605b6	ef5df1a9-90f1-4989-9ec4-ecb9cc5be9e0	1.00	Rotor 	150.00
81109055-77da-420d-95d9-191ee41d48cf	ef5df1a9-90f1-4989-9ec4-ecb9cc5be9e0	1.00	Estator 	120.00
8373f8fd-5c74-4e6a-9bef-ed7510ec6aa7	ef5df1a9-90f1-4989-9ec4-ecb9cc5be9e0	1.00	Lubrificação	40.00
9b202aa1-93ab-4c52-9cfa-4139695dd406	ef5df1a9-90f1-4989-9ec4-ecb9cc5be9e0	1.00	Mão de Obra 	50.00
92978f89-b518-4ec5-a5e6-3c3e08ed57a8	6aa1e6dd-5d8b-41db-b304-021f5704f42d	1.00	Mão de obra	20.00
b5551600-1228-4e7f-9dc4-72f200c01b63	1a6c2039-a147-4f35-bf97-43c41d34c125	1.00	Mão de Obra	40.00
3a25f441-ce02-4f5d-aaff-aba309dbcaba	856dbff9-be5b-4198-b72f-aae3c4bbd50f	1.00	Capacitor	180.00
193fc916-3fbb-4b40-969c-24fb032430b3	856dbff9-be5b-4198-b72f-aae3c4bbd50f	1.00	Mão de obra	50.00
baa1c26e-8642-40bb-be04-04de73c2b96d	11df6e23-8e9e-401f-9333-9500d98395b0	1.00	Gatilho	120.00
f1e6747e-75b9-4921-a89c-01d69d6264a1	11df6e23-8e9e-401f-9333-9500d98395b0	1.00	Mão de obra 	30.00
37f9e09b-2403-4150-b3ac-de3c6107d1ce	7e6f618c-867c-4113-9ab5-a5dbbbeab3a3	1.00	Biela e Pistão	160.00
be0d8fdf-0ab5-4961-ba4e-b9ebcf5c5e18	7e6f618c-867c-4113-9ab5-a5dbbbeab3a3	1.00	Mão de obra + Lubificação	80.00
91aa6fe8-c5d4-44dc-bc76-0c70c5402427	5aec6958-f2ca-4741-b9af-b62a7b30ff22	1.00	Rotor	190.00
1f6da7e2-a469-4e42-9fdd-c145d0173733	5aec6958-f2ca-4741-b9af-b62a7b30ff22	1.00	Mão de obra	50.00
a4cd1303-bdc2-4180-b440-14dc45ba93ac	4132b3d0-f242-4523-a898-0d420536dd1a	1.00	Mão de obra	40.00
81e73530-b456-49bb-8d83-b7949da94494	88c6f402-b63c-4633-8132-df90e7300e98	1.00	Revisão completa	168.00
c6aa1a8b-e71c-4da6-926a-9585ff248933	da4f1af4-1db2-4f06-8c73-9aaf955f0c0b	1.00	Limpeza interna	39.00
f68d3931-8ea6-491b-899e-bdf8ac3e1d98	fad3ef69-763f-4f53-b397-f9aad766444e	1.00	Limpeza interna	28.00
1dd0d8c0-ef63-4da1-8b81-76a8fb1009cc	fad3ef69-763f-4f53-b397-f9aad766444e	1.00	Troca de engrenagem	121.00
b295df69-ab39-4be5-a737-9e0c9283d974	fad3ef69-763f-4f53-b397-f9aad766444e	1.00	Troca de carvão	37.00
74a22385-10fa-4b28-b77b-4af32e8b7462	d096696c-7fed-48ce-8551-ddd3e00492f1	1.00	Revisão completa	151.00
047729f5-86ca-49e7-9f8d-f8dddbdfed2e	0d9bbd5a-00e9-4c85-921d-8f15b7656446	1.00	Troca de interruptor	46.00
5d97e9de-e046-4cbc-90eb-44b8bbcb6502	b82bf7db-c761-4e5f-b5b1-f59220b28de6	1.00	Revisão completa	215.00
a3cc9122-d652-48d1-91e6-c2d5ae700ef8	b82bf7db-c761-4e5f-b5b1-f59220b28de6	1.00	Troca de carvão	39.00
193c2390-135c-4e6a-ba67-bb156dcd1167	b82bf7db-c761-4e5f-b5b1-f59220b28de6	1.00	Troca de rolamento	44.00
212a6c5d-139b-4e19-b031-6a738291a8d4	de499168-c315-4356-a758-0731795aabc2	1.00	Troca de engrenagem	100.00
c4eced1a-004c-4d6e-b09b-10876127220c	de499168-c315-4356-a758-0731795aabc2	1.00	Mão de obra	110.00
6aa33e7b-07b5-43e2-8e09-ca452610efd5	de499168-c315-4356-a758-0731795aabc2	1.00	Revisão completa	243.00
e19442e8-8fae-4d7a-97a9-46ebaabbd8ef	1a3da2df-e597-46e9-a065-387c132ece30	1.00	Troca de carvão	32.00
7b359e4d-73eb-43c0-995f-04c038416a01	1a3da2df-e597-46e9-a065-387c132ece30	1.00	Limpeza interna	38.00
2b2aeb70-f671-4fde-9873-35dda9bc7c89	1a3da2df-e597-46e9-a065-387c132ece30	1.00	Troca de interruptor	35.00
5dfb4356-966d-4e30-ba35-0dd1fc135a2f	943fe26d-2539-4187-997a-6e463589a93b	1.00	Mão de obra	55.00
f6223202-822c-4976-8c49-05b2bfb0b4a4	943fe26d-2539-4187-997a-6e463589a93b	1.00	Troca de carvão	22.00
0356dea5-35db-4d55-a2d4-41da722bf930	42454d56-dbde-4590-b10c-525d58e1509f	1.00	Troca de carvão	35.00
6071bb58-ab48-499f-b649-a67c249ab320	42454d56-dbde-4590-b10c-525d58e1509f	1.00	Mão de obra	92.00
30ccf1c4-a368-4d22-a582-8bfba1fb96d8	bee121ca-1615-4258-9bf1-e0493ce7dfe6	1.00	Troca de interruptor	61.00
4edafdbc-844e-42e4-8926-b60cb1a647dd	bee121ca-1615-4258-9bf1-e0493ce7dfe6	1.00	Troca de rolamento	61.00
58f67916-e042-429e-a5bf-8d791c79e021	89fe2f06-a083-4ecc-9ac1-0aeb6bf2d8a9	1.00	Mão de obra	68.00
6b567b7f-7d89-4925-bd71-d0154e09c0e6	89fe2f06-a083-4ecc-9ac1-0aeb6bf2d8a9	1.00	Revisão completa	243.00
32e5500a-34f1-49ba-a7ab-b2185ba229a7	a95f2d60-48a5-488d-bf8d-2af4bf946a57	1.00	Troca de interruptor	58.00
439d4d91-0244-4aa6-8703-c20c328f53cd	a95f2d60-48a5-488d-bf8d-2af4bf946a57	1.00	Troca de carvão	25.00
6b73be36-c6ec-45df-93fa-21cf6f934bec	f50d5253-b308-49f1-9beb-12d833787cbc	1.00	Troca de rolamento	79.00
276874e8-5142-41d7-b604-cf14460e8085	f50d5253-b308-49f1-9beb-12d833787cbc	1.00	Reparo no estator	123.00
6e113636-7ffc-434e-a8e8-c3945758bd5e	f50d5253-b308-49f1-9beb-12d833787cbc	1.00	Revisão completa	175.00
fdefa13f-edfc-43f6-922e-892f7ca5e4e6	4e0e9597-227f-4767-b00f-e4f8fd44c4d4	1.00	Reparo no estator	143.00
342a2e18-375c-4c29-abf1-1f38791310c6	4e0e9597-227f-4767-b00f-e4f8fd44c4d4	1.00	Limpeza interna	44.00
fab96aba-adff-4441-baf6-5d896fcc696a	1b983341-a023-4eee-b592-3424994625ab	1.00	Troca de carvão	34.00
70f8ac35-1a99-4208-9423-432087c671d4	1b983341-a023-4eee-b592-3424994625ab	1.00	Limpeza interna	44.00
e4fa5f53-c5ac-4b55-81e8-f878ab99b06d	dc30bf50-4e58-46ca-923d-18e8f14e8c79	1.00	Troca de engrenagem	140.00
506fdb23-1263-4eb6-82ce-9f7b93637bba	95be6da7-1510-4901-86a0-cb728d0ed946	1.00	Troca de rolamento	64.00
647e64d6-5577-4fa2-808b-a720b450484e	95a10675-96ca-46cf-b9ad-0f47101ec6c6	1.00	Troca de carvão	24.00
29c5b487-d327-4b83-bff9-7098eea9d26f	95a10675-96ca-46cf-b9ad-0f47101ec6c6	1.00	Reparo no estator	129.00
26000001-0061-4797-841b-b33a7e79aead	ea47a878-b9f8-44c9-97a6-a38381409a77	1.00	Mão de obra	55.00
0efc8d48-8958-4286-9dd7-481fcac120e5	ea47a878-b9f8-44c9-97a6-a38381409a77	1.00	Revisão completa	239.00
e3ec3fa6-79d2-450d-8d91-4024bb09959a	1c020be7-5a7e-43a5-9627-f0dd90bdcc98	1.00	Troca de carvão	23.00
8a9a9c54-65fc-4af0-b198-69191ada0646	1c020be7-5a7e-43a5-9627-f0dd90bdcc98	1.00	Revisão completa	198.00
f5180f4e-d4f2-4777-b94f-fe4601204588	756cf93f-4b6c-4d04-8ef3-01235ccafe72	1.00	Troca de interruptor	31.00
15744acc-efbf-43ce-afd4-748a288ed938	50b92f0d-cfce-4c8f-a12b-26bda9d446fe	1.00	Limpeza interna	34.00
a4486954-eea5-4b3f-912d-a4c78cc11a24	50b92f0d-cfce-4c8f-a12b-26bda9d446fe	1.00	Revisão completa	242.00
3f1784f0-5d7d-4fe4-94b2-27c65b7ee9a8	50b92f0d-cfce-4c8f-a12b-26bda9d446fe	1.00	Reparo no estator	191.00
9eda2290-d88e-4c0b-8200-05d76016b580	49dba099-05dd-4c7a-9a82-2d0d941e73ee	1.00	Mão de obra	78.00
183f7d3a-8df1-4e79-9e21-e06d586d65d0	49dba099-05dd-4c7a-9a82-2d0d941e73ee	1.00	Reparo no estator	176.00
edc94885-b661-4eaa-bd55-ae540707c2cb	8904ed70-8843-48e5-81cb-d5d1bd504cc1	1.00	Revisão completa	121.00
179018b7-0966-4ba3-85cd-a9ebc61670ac	8904ed70-8843-48e5-81cb-d5d1bd504cc1	1.00	Troca de carvão	37.00
36ba052d-11d7-4619-b600-123c5de8baf0	f7895c42-8898-45fa-babe-96f0586119e5	1.00	Limpeza interna	25.00
1efc66eb-b702-4a03-966d-348d21184b09	f7895c42-8898-45fa-babe-96f0586119e5	1.00	Mão de obra	76.00
a409361d-19e3-483d-81be-4f03ee239ca6	29d9cf64-f9b6-4cd2-b384-75cb9e7be7c1	1.00	Troca de carvão	20.00
be20a6e8-eca2-4e51-9f10-e7780a11a780	29d9cf64-f9b6-4cd2-b384-75cb9e7be7c1	1.00	Troca de interruptor	37.00
d3185b21-ffe1-4ed4-9e50-0c27553c104d	3fe6b966-5518-4221-a9b7-0cd45a7d327e	1.00	Troca de interruptor	69.00
ea533311-cfc4-44a1-8594-94d36a1c98fa	3fe6b966-5518-4221-a9b7-0cd45a7d327e	1.00	Troca de rolamento	59.00
0bac0e3d-7a4b-4cdb-8e54-d0d5cd7503f5	b2e09e97-08e8-4c58-9dfe-f2747a778949	1.00	Limpeza interna	27.00
9afa1b3a-3226-4099-81f6-2108a19e0cba	b2e09e97-08e8-4c58-9dfe-f2747a778949	1.00	Troca de carvão	42.00
05b0b170-2ac4-4d9b-9cf7-84efe1432623	b2e09e97-08e8-4c58-9dfe-f2747a778949	1.00	Troca de engrenagem	122.00
a7d97aa5-4900-442f-8db8-ed922217ab30	23629eeb-6ad8-4c60-832e-66527adafa81	1.00	Troca de engrenagem	82.00
9ef23776-bf60-49b7-8a95-71df53f7e705	23629eeb-6ad8-4c60-832e-66527adafa81	1.00	Limpeza interna	37.00
c59d2b48-d9af-43fc-83c9-d7905f6d2241	23629eeb-6ad8-4c60-832e-66527adafa81	1.00	Troca de carvão	23.00
0802b330-888c-4bfa-af53-38c3a4cd4f6b	6279de65-6f15-4729-9ff1-03cffb2b3a00	1.00	Troca de engrenagem	112.00
f56f131b-74a5-48fd-b1a0-bbc8299f0fb9	b0af6776-722d-465e-ac4b-13f585e0a90d	1.00	Revisão completa	111.00
cb02df3e-8e63-4f29-9ab3-d4997691f64b	b0af6776-722d-465e-ac4b-13f585e0a90d	1.00	Troca de carvão	31.00
806919de-6caa-4389-b589-232e8cfcfb9c	74a971b7-3148-4dcd-9688-408d9e306a87	1.00	Revisão completa	105.00
9acb3d99-f2cb-4572-99a3-b3bb95a4dfcc	74a971b7-3148-4dcd-9688-408d9e306a87	1.00	Troca de rolamento	66.00
fb7f826d-63e1-4b58-9c9c-38b4404255c6	cbfcdc02-113f-4d3b-b479-3468036a1b38	1.00	Mão de obra	54.00
177e34fd-baeb-4fff-bf6b-05a3567e021e	cbfcdc02-113f-4d3b-b479-3468036a1b38	1.00	Troca de rolamento	41.00
ac99a1b8-0568-4b79-be50-975948812eb8	cbfcdc02-113f-4d3b-b479-3468036a1b38	1.00	Troca de engrenagem	149.00
89ad22a6-ffda-4d27-b0bb-4128bc65a7b9	77fd8063-6848-4557-8db8-b48bcdf7a41c	1.00	Troca de carvão	22.00
dbd75eb1-7cc3-49ec-8104-414adb08bc86	77fd8063-6848-4557-8db8-b48bcdf7a41c	1.00	Revisão completa	144.00
7973d808-37fc-4271-922f-82bfc4f7805b	77fd8063-6848-4557-8db8-b48bcdf7a41c	1.00	Troca de rolamento	78.00
58010fcb-4630-49d4-a3a7-a3469abc2639	7f7bc86a-42a7-4d71-b3f8-e52c3fd6ce9b	1.00	Mão de obra	75.00
567fa23d-9575-47a0-ac70-e86bb273c240	7f7bc86a-42a7-4d71-b3f8-e52c3fd6ce9b	1.00	Revisão completa	234.00
d7ae7a08-a50d-4807-9c18-06ce0722884f	7f7bc86a-42a7-4d71-b3f8-e52c3fd6ce9b	1.00	Troca de engrenagem	67.00
1f81e24f-2c45-4039-a6ad-80926cb85727	a7e9d51d-647b-4b64-a678-2e5d2ed4df1e	1.00	Mão de obra	116.00
77d9c55a-5171-4418-b111-8ce6ce2b6c04	a7e9d51d-647b-4b64-a678-2e5d2ed4df1e	1.00	Troca de engrenagem	130.00
49f64f9b-46a4-4048-8023-fc050f06f27a	a7e9d51d-647b-4b64-a678-2e5d2ed4df1e	1.00	Troca de rolamento	44.00
76ac8350-cd9e-4607-bd35-348804465804	bd8001eb-c8cf-4d63-8035-d25f299fa558	1.00	Troca de engrenagem	95.00
02ec30f2-0daa-460b-95de-54d5a98bbaa2	bd8001eb-c8cf-4d63-8035-d25f299fa558	1.00	Troca de interruptor	38.00
db662644-1be3-45d5-a8bf-99ff8a4d8e9d	360d5fe6-4861-47d7-a99e-61f8fff0bd8d	1.00	Mão de obra	57.00
a0e21409-66f1-4236-8164-64316fa0b221	360d5fe6-4861-47d7-a99e-61f8fff0bd8d	1.00	Troca de engrenagem	75.00
eee6cf28-3617-476b-b7b0-5df5f5fedd28	3d2abc1e-792d-4d09-a9c7-1a95a3b837d5	1.00	Troca de engrenagem	119.00
15fc3877-aea4-4414-8051-1ccce72e9e05	3d2abc1e-792d-4d09-a9c7-1a95a3b837d5	1.00	Mão de obra	68.00
9041303d-105e-4e1d-9834-80817245338a	888445a4-79fe-499a-8ffe-65eed2291bae	1.00	Revisão completa	221.00
a8f4bf91-0f47-47ab-b007-2acd07f1578d	888445a4-79fe-499a-8ffe-65eed2291bae	1.00	Troca de interruptor	52.00
c61840f0-aa82-4ff9-a384-1dc2e71a0376	888445a4-79fe-499a-8ffe-65eed2291bae	1.00	Reparo no estator	177.00
402daadc-c914-4972-8a30-bf3d4d7688b8	fddb8612-f0fe-406e-87ef-7bbc4fa6304b	1.00	Revisão completa	188.00
6260647a-d3de-41f2-ab8d-e5502b8f42fe	b11216ac-edbb-443a-88b3-474e085861a3	1.00	Revisão completa	233.00
a2367a3a-b70a-4f53-ac68-44199b505785	b11216ac-edbb-443a-88b3-474e085861a3	1.00	Troca de carvão	23.00
5409fa26-ab99-45ef-b7f4-79b5abcbf04d	b11216ac-edbb-443a-88b3-474e085861a3	1.00	Troca de interruptor	41.00
68d70c3b-7835-4d69-8f92-29a8702355c1	f7b8e3bd-ac9f-4025-8816-f7a6db6af099	1.00	Revisão completa	150.00
c7f9ae22-2207-4fce-aeb2-b2b960698164	f7b8e3bd-ac9f-4025-8816-f7a6db6af099	1.00	Troca de engrenagem	111.00
06b79db6-d1f4-4847-b1b1-cd929acc4f83	e0d0d8a8-5833-4b1e-acae-10f6edf112bb	1.00	Mão de obra	89.00
331aae60-7af4-47b7-8e3c-22e88d922839	e0d0d8a8-5833-4b1e-acae-10f6edf112bb	1.00	Revisão completa	130.00
ce4d39fa-7409-4151-b3e4-c8ffd14db844	e0d0d8a8-5833-4b1e-acae-10f6edf112bb	1.00	Troca de interruptor	63.00
4d53ffc9-afe3-46bc-ad04-24d0f43e3f11	87ea9a8b-c7b2-4ed3-a4d4-8598a3c39761	1.00	Troca de interruptor	55.00
31251b82-c74b-45ff-ad11-ec35701e2417	03e11d3f-6b5d-4bd1-b82a-4eca2ebdc3e9	1.00	Revisão completa	141.00
2c643598-b58d-482b-993b-9d120059c9c1	03e11d3f-6b5d-4bd1-b82a-4eca2ebdc3e9	1.00	Troca de interruptor	63.00
fd3bebbb-8749-4108-9d44-414ea584e254	03e11d3f-6b5d-4bd1-b82a-4eca2ebdc3e9	1.00	Troca de rolamento	43.00
094c7ee7-a710-46cc-baab-873973d87e59	cba35c22-d33b-4367-abe9-6e4b763fe646	1.00	Revisão completa	149.00
dbb369c1-0bd9-465a-90bf-af921501f2f2	cba35c22-d33b-4367-abe9-6e4b763fe646	1.00	Mão de obra	62.00
69e0744d-46c6-4a41-a24d-e250064cc2f2	11dd60b9-6272-4242-8eff-cddf50bfbec2	1.00	Revisão completa	139.00
36a6c5c6-532b-494d-9d33-ad1f8ffa280a	54f22d1d-5bc4-4444-9bd2-c2f0c2baffbf	1.00	Troca de rolamento	52.00
d592e00b-c5e9-4935-82ea-2247c7338a4e	54f22d1d-5bc4-4444-9bd2-c2f0c2baffbf	1.00	Reparo no estator	94.00
127b5605-dee2-412b-b957-01ef2b5eb7ed	54f22d1d-5bc4-4444-9bd2-c2f0c2baffbf	1.00	Revisão completa	162.00
0cba662e-5b4b-494f-a014-f57d27f78c8e	d57f788e-d5e0-44e5-976e-14beec9470b3	1.00	Troca de interruptor	32.00
94991f9d-d05f-480e-81dd-5d7000464773	d57f788e-d5e0-44e5-976e-14beec9470b3	1.00	Revisão completa	158.00
66d12ab2-3737-4bdc-aac3-eeb495c2e301	d57f788e-d5e0-44e5-976e-14beec9470b3	1.00	Troca de engrenagem	116.00
e7c45836-b5b0-4101-903b-b8d6f3c83ebd	c791892f-b4ab-4fd0-857f-154c0bd24544	1.00	Troca de carvão	33.00
ed9e7173-1d41-4a8e-9bbb-b8b0349a9f9c	acfe2d4f-2a1f-473d-9ffc-29d95321bd0f	1.00	Mão de obra	50.00
6f3166c3-7df8-4a9d-a883-2e6b6a2e690c	796c58be-e51c-452d-856a-2e7998fdde21	1.00	Troca de interruptor	67.00
21fc77b5-4610-4378-a89c-612ddd34e6ad	d0839179-929e-4ea0-a45f-9495b10ae3d0	1.00	Troca de carvão	44.00
512258c6-7543-448f-8c16-f7a634c6487b	d0839179-929e-4ea0-a45f-9495b10ae3d0	1.00	Troca de interruptor	30.00
ddd57bb9-8fd3-4a8c-80ae-de9d19d8eecb	11c627d8-314c-4d2c-909d-fa38770bf1f0	1.00	Mão de obra	108.00
5a42c34b-08ff-4861-9935-b6b519e4d9de	136c57d8-a5d6-4afe-a9da-9bf8edd1f255	1.00	Revisão completa	215.00
c163b870-0819-4d2e-98be-3c21b153a693	6eb2e31f-59f4-4df8-8ced-6fa1625044d0	1.00	Troca de rolamento	60.00
a0b6d466-909c-41ec-aee6-b75f015b77c8	9bae228a-8e38-4cda-b5e4-924c00dd27bc	1.00	Mão de obra	86.00
e546ae59-5546-4d4c-87e5-ab455d69808b	4373d95f-491b-4076-9d7b-5efd64b3f358	1.00	Mão de obra	61.00
ab8ee16d-0eef-4c4a-9a03-92688009a4d7	8c2549b4-a4b1-4271-b31e-4f17663bbe86	1.00	Troca de rolamento	56.00
5116ec45-3e3e-453d-94f2-0c69fcb0ae06	8c2549b4-a4b1-4271-b31e-4f17663bbe86	1.00	Limpeza interna	27.00
ce3f56fe-abe7-403e-a9e1-0df86bc32c3e	8c2549b4-a4b1-4271-b31e-4f17663bbe86	1.00	Troca de engrenagem	124.00
7ffd4aa8-aad9-4d61-bed3-804f0faf22eb	0c11123e-0597-46a4-84b4-9e1eb488614a	1.00	Limpeza interna	28.00
a86ffb1e-069e-4f3f-885e-b90ee2ca653e	0c11123e-0597-46a4-84b4-9e1eb488614a	1.00	Troca de interruptor	56.00
4e773dea-1ce3-441b-b744-bcf7b6e60faa	0c11123e-0597-46a4-84b4-9e1eb488614a	1.00	Mão de obra	101.00
d1897e6b-4da3-4e3e-ba60-ccbcc306c67a	6760b44e-e2f9-4ed2-b48b-25ffed0f7c43	1.00	Troca de carvão	27.00
20a5ce66-59b2-4620-89bd-58dd532bcc5a	6760b44e-e2f9-4ed2-b48b-25ffed0f7c43	1.00	Troca de engrenagem	126.00
2290009e-2da7-450f-94c2-8039f441ce21	6760b44e-e2f9-4ed2-b48b-25ffed0f7c43	1.00	Troca de interruptor	60.00
6043d14a-80fb-4c5b-a934-dd9878119d58	efb73759-c46c-4f40-8820-ef69d7c813bc	1.00	Reparo no estator	107.00
6b719954-ae14-4321-af3a-12639a768323	efb73759-c46c-4f40-8820-ef69d7c813bc	1.00	Mão de obra	71.00
d2e35ab3-c2bd-4d02-a3bf-7931f25f7556	f4b4aeee-f53a-4520-9d04-c7b5e71eb57d	1.00	Troca de rolamento	46.00
71923c62-da3a-4e40-bdca-a3f45c0b52cf	f4b4aeee-f53a-4520-9d04-c7b5e71eb57d	1.00	Troca de interruptor	31.00
8085eef9-a0d3-4ea8-8f6a-7a21438e1ea0	f4b4aeee-f53a-4520-9d04-c7b5e71eb57d	1.00	Troca de carvão	33.00
3b00cfbc-49c8-487c-99cc-4c1b25c92e7e	de60bd51-74b9-47dd-96f9-06d75846686f	1.00	Limpeza interna	47.00
dd18bae1-f3aa-4bb0-952f-b3fbb0cedaf9	b0c19aba-da24-4b8e-8426-0e8965902761	1.00	Troca de interruptor	32.00
cf63f0ce-8ccb-40d3-bf4d-f5009d411380	d5e4372b-33a2-4a6c-9bd4-0ea2ab6f94f6	1.00	Reparo no estator	95.00
b1d41c9f-4b53-44a4-bba0-57721ee82fce	d5e4372b-33a2-4a6c-9bd4-0ea2ab6f94f6	1.00	Revisão completa	150.00
01c14553-3690-4bb7-a1c5-b10f8d59296a	d5e4372b-33a2-4a6c-9bd4-0ea2ab6f94f6	1.00	Troca de rolamento	55.00
94b55356-17ff-47fe-9516-af1d7ec23a51	76aaacea-06bd-4d3e-bf7e-796be405c72f	1.00	Troca de carvão	36.00
4aa68625-4896-480b-acdc-59696441589c	76aaacea-06bd-4d3e-bf7e-796be405c72f	1.00	Troca de interruptor	31.00
0b7aff50-d4d2-409e-9518-cd7cf636b244	76aaacea-06bd-4d3e-bf7e-796be405c72f	1.00	Revisão completa	221.00
252ff73e-5add-4dfe-ba17-000dbf8487eb	7c46fc3e-37c6-49b1-9d90-38642ed41336	1.00	Mão de obra	105.00
48e359a6-b5dc-42fb-b0d5-bb8cdc84b612	7c46fc3e-37c6-49b1-9d90-38642ed41336	1.00	Troca de interruptor	60.00
27c85188-a59f-4fa3-aa76-3602a1afe71c	7c46fc3e-37c6-49b1-9d90-38642ed41336	1.00	Troca de carvão	39.00
416e05ed-38c6-4020-ada3-b2d7621dab71	e1479a44-dc74-449f-b379-b31e55cc5b59	1.00	Limpeza interna	41.00
f59de2e2-8450-4337-bc99-49715adc054d	e1479a44-dc74-449f-b379-b31e55cc5b59	1.00	Troca de engrenagem	135.00
10fe34de-99b0-4621-a0b7-589445c4d805	02ff73d4-a8e3-4bd1-95ac-259164f5c3ed	1.00	Troca de interruptor	33.00
5a8bdd41-4633-4aa2-91e9-ce9d604b34aa	02ff73d4-a8e3-4bd1-95ac-259164f5c3ed	1.00	Revisão completa	178.00
91a4406f-409d-44a4-a2e5-542ddbb6ea65	b8cf3869-7d3e-4a50-b9ca-36d981633c1a	1.00	Rolamento axial 	230.00
e53faa21-0980-42cf-acd2-5d0d35eda6c7	b8cf3869-7d3e-4a50-b9ca-36d981633c1a	1.00	Kit Mola do pistão	180.00
7f29481e-f1a6-47a3-b17d-1584bc8b7b28	b8cf3869-7d3e-4a50-b9ca-36d981633c1a	1.00	Óleo	20.00
3cebae1f-9143-45c8-8425-e01491e3e048	b8cf3869-7d3e-4a50-b9ca-36d981633c1a	1.00	Cabeçote	250.00
081a6c15-fad9-4de3-901b-d737b1630835	b8cf3869-7d3e-4a50-b9ca-36d981633c1a	1.00	Carcaça do óleo	210.00
932a5776-c0cd-4f77-9a85-c02e78c0f8f4	b8cf3869-7d3e-4a50-b9ca-36d981633c1a	1.00	Mão de obra	60.00
72fcefcc-4a88-457f-a258-fdefb6f15d92	79b831c3-35f3-4dac-90fc-d007178e7cb9	1.00	Jogo de carvão 	20.00
b5832b76-f75e-438a-ab66-7395f0fdb99e	79b831c3-35f3-4dac-90fc-d007178e7cb9	1.00	Mão de obra 	30.00
f0ee4b8a-955a-406c-8023-f4da769b266f	750714d0-23c8-44e8-8fd2-bb16fe2c53c6	1.00	Jogo de carvão	20.00
17148588-4d4a-4c6d-a3a4-3d27694f3750	750714d0-23c8-44e8-8fd2-bb16fe2c53c6	1.00	Mão de obra 	30.00
d3d38832-ceb9-4418-ab16-180e2ab64759	0373a2d8-403f-410d-bd8f-141f80c718bb	1.00	Jogo de carvão	20.00
4940b31b-3ff5-4c0d-b1cb-e661cd36d3d8	0373a2d8-403f-410d-bd8f-141f80c718bb	1.00	Mão de obra	30.00
2de0740a-0e52-412b-9345-ebc5574f5da3	a86d9f4f-a662-4256-969b-cdfcebf0041f	1.00	Limpeza	20.00
05931e2e-b0bf-450e-8c12-93593f07b3e9	60648952-a439-4bb0-a1fe-75948d96f593	1.00	Limpeza	20.00
16289324-ef1a-484f-b9d5-be99aed99cf2	60648952-a439-4bb0-a1fe-75948d96f593	1.00	Correia/ Usei a correia da máquina que já estava aqui	0.00
8ddbd030-d63a-4858-ba81-89f3eaff5857	cfc3b3df-ee8d-4a3b-b9f4-e87eb058d340	1.00	Rolamento 608	20.00
9dda6206-6475-4b9d-bb90-ba85dcabdb9d	cfc3b3df-ee8d-4a3b-b9f4-e87eb058d340	1.00	Rolamento 627	20.00
56028259-0a92-4a2d-a8cc-2e08b4005280	cfc3b3df-ee8d-4a3b-b9f4-e87eb058d340	1.00	Limpeza	20.00
a985ca73-bf7a-441f-86ba-ec973a22b272	9bc0dd11-bd8f-4390-9db8-ec942bf548a1	1.00	Correia 	50.00
2d3e7305-e870-4e00-bb89-e3e0e8018461	9bc0dd11-bd8f-4390-9db8-ec942bf548a1	1.00	Rolamento 608	20.00
b24391f8-f22e-473d-beb8-904fc09c2ca7	9bc0dd11-bd8f-4390-9db8-ec942bf548a1	1.00	Rolamento 627	20.00
4c9ebf6e-63b2-465f-a17f-f2f2d3a2f347	9bc0dd11-bd8f-4390-9db8-ec942bf548a1	1.00	Limpeza	20.00
94bd57e5-05ed-4afd-88b8-cf897f1a1473	c3615677-9763-4abd-96b2-d8d6e0b28502	1.00	Limpeza	20.00
4de541ed-47be-4cc9-9f7f-f4427f012190	f80a47c8-95b6-448b-b302-a27c0ad0542f	1.00	Correia 	50.00
c3dc45d9-540b-4a6f-a210-c8977861b395	f80a47c8-95b6-448b-b302-a27c0ad0542f	1.00	Limpeza	20.00
ffef7411-be98-4689-93bf-311bbe0b94f0	04e0d501-3f0c-4e28-a3a7-f09332ee837b	1.00	Rolamento 608	20.00
c79a5d6a-3e6f-42bf-90be-fb7f9e763d38	04e0d501-3f0c-4e28-a3a7-f09332ee837b	1.00	Rolamento 627	20.00
45f2c6af-9c3d-4904-9f4d-b7db8e2b4cb8	04e0d501-3f0c-4e28-a3a7-f09332ee837b	1.00	Limpeza	20.00
381dd06a-8798-492c-8e5f-bb9328964008	71b5358f-04fd-4990-92aa-0fe587c1af54	1.00	Retrátil de partida 	60.00
1f409db1-7a14-4ed5-9eea-31901d7b5136	71b5358f-04fd-4990-92aa-0fe587c1af54	1.00	Mão de obra	20.00
74998cf1-f157-405d-9ff8-2c6022f19120	71b5358f-04fd-4990-92aa-0fe587c1af54	1.00	Limpeza do carburador 	60.00
9f6108fe-32f6-41c8-8d8c-9f8b393f37ae	42fc3ba0-b108-4344-b813-47a27344719a	1.00	Motor 	260.00
33847236-fa5e-4028-b63a-218d39788bd7	42fc3ba0-b108-4344-b813-47a27344719a	1.00	Mão de obra	50.00
974f340d-ecf3-48cc-8b5e-694db69f6256	04255932-1458-471b-95f2-b331ebd1ff44	1.00	Rebobinagem do motor	500.00
810057e3-95f5-44f7-af14-188b0560651e	04255932-1458-471b-95f2-b331ebd1ff44	1.00	Anéis de segmento 	60.00
d3a56ffd-e5ca-4454-ab4d-e23ac0bd4949	04255932-1458-471b-95f2-b331ebd1ff44	1.00	Tampão de óleo	60.00
cdb728db-24ff-4313-9c60-000cc52bd72d	04255932-1458-471b-95f2-b331ebd1ff44	1.00	Jogo de Juntas	40.00
4e944d33-fcd9-4507-9495-38ebf490a5f3	04255932-1458-471b-95f2-b331ebd1ff44	1.00	Filtro de Ar	30.00
ff17ebf2-56da-4420-b58c-efe8214476b5	04255932-1458-471b-95f2-b331ebd1ff44	1.00	Óleo	20.00
987754e7-ee54-4b04-b29a-02033d6eb328	3fc68377-9ce2-487d-80a6-9da4e5a59cb1	1.00	Rolamento 608	20.00
f173fc2e-04e2-4949-8447-63a56855f334	9ca5c21f-b07e-4411-b50b-b53d2f9f034b	1.00	Rolamento 608	20.00
93cc055c-b83b-429c-9135-749204614721	9ca5c21f-b07e-4411-b50b-b53d2f9f034b	1.00	Caixa do Rolamento	100.00
8483da83-fa7c-4a32-95ad-7ed381053bb3	9ca5c21f-b07e-4411-b50b-b53d2f9f034b	1.00	Mancal	60.00
4a3bf0ad-abf3-42ba-8038-909f920204f3	9ca5c21f-b07e-4411-b50b-b53d2f9f034b	1.00	Came	50.00
584dc519-daa6-4598-af20-c9bc667613f7	9ca5c21f-b07e-4411-b50b-b53d2f9f034b	1.00	Mão de obra	60.00
5735c87d-fedf-41e7-b827-868ec73588c8	9d465184-61d5-4a04-92e6-740108075bd1	1.00	Engrenagem 	50.00
749596d4-26eb-4d93-820a-62be4f49c113	9d465184-61d5-4a04-92e6-740108075bd1	1.00	Pinhão	40.00
1b486e54-6c87-4671-9176-6aa6311e70a4	9d465184-61d5-4a04-92e6-740108075bd1	1.00	Mão de obra	40.00
9deedb38-393f-4325-b5a9-18c3298aeec3	3fc68377-9ce2-487d-80a6-9da4e5a59cb1	1.00	Jogo de carvão	20.00
c2e855e9-43b3-4173-993f-7660cd109554	3fc68377-9ce2-487d-80a6-9da4e5a59cb1	1.00	Mão de obra	50.00
3a596eb6-19f3-4b23-a1e6-7dfe19ad3fa0	187d64d9-8882-42d2-b287-fb949167105e	1.00	Carburador 	250.00
3b5d76fc-dc44-40fc-81cb-d307dc525454	187d64d9-8882-42d2-b287-fb949167105e	1.00	Mão de obra	40.00
a7900096-3fa7-41a2-b521-1445f9ad6090	4319ed74-dcb3-46b0-a59b-31e0a0ed0546	1.00	Interruptor	30.00
902568d9-e007-4d6d-b114-0c04fccce8ea	4319ed74-dcb3-46b0-a59b-31e0a0ed0546	1.00	Mão de Obra	30.00
9a100079-8e14-4613-8d91-e70b35ef1547	584454f2-922d-4336-94ab-fc26540f41cd	1.00	Cabo elétrico	20.00
4e11ab74-92d0-46b9-9ef6-4280b8c6d415	584454f2-922d-4336-94ab-fc26540f41cd	1.00	Mão de obra	30.00
cd28d2b1-4073-4afd-8fe7-c9b49bc16f77	7da58dac-4c49-4c53-9414-24cb58801f37	1.00	Rotor 	160.00
0d47f19f-e4ae-4997-950f-561c01f8953e	7da58dac-4c49-4c53-9414-24cb58801f37	1.00	Estator	120.00
6dcd7177-a4f5-4190-98d2-74f740866c3e	7da58dac-4c49-4c53-9414-24cb58801f37	1.00	Carvão	20.00
b2301585-6247-4802-bdf4-e7292cafba87	7da58dac-4c49-4c53-9414-24cb58801f37	1.00	Mão de Obra	50.00
90ea6174-b9d1-4875-a4a0-ccb78fc005c1	b34d4433-cf80-4c46-84f5-8bc7a058d891	1.00	Kit Reparo 	100.00
106674bb-fc67-460b-9976-0a4641a76cb7	b34d4433-cf80-4c46-84f5-8bc7a058d891	1.00	Mão de Obra	80.00
3444ffb0-8ea6-4ce0-aa00-f71faa71d1b5	999f14c9-d4c3-4785-a450-20b199d345fa	1.00	Mão de obra	30.00
adff2b66-338f-49ae-880b-d4d22da8e687	04255932-1458-471b-95f2-b331ebd1ff44	1.00	Capacitor	120.00
4e69ff5c-b98d-4367-871e-158a780b4680	04255932-1458-471b-95f2-b331ebd1ff44	1.00	Mão de obra	80.00
667e819b-4eaf-4a61-b2f0-ab2bb3a2c906	8cc1f341-9f2e-4e13-b072-ab3d5b674bdd	1.00	Gatilho	120.00
d99a6a07-9083-404c-9c90-f4bac329455a	8cc1f341-9f2e-4e13-b072-ab3d5b674bdd	1.00	Mão de Obra	40.00
a5887e5b-f94a-4bbe-b5d6-89adba55b45d	c6859274-de57-44af-80fc-1ab582603c4b	1.00	Rotor 	0.00
124bea85-3482-40c3-b45f-25103cc2e172	c6859274-de57-44af-80fc-1ab582603c4b	1.00	Carcaça 	0.00
197b8c20-ac34-4518-8197-397361ab568c	6f415b16-4276-4bf1-811c-7f955f7d8406	1.00	Mão de obra	30.00
d9eaef5f-9afa-4644-a31c-ddcbe9937cc4	404527aa-eaed-4889-8f77-da11e7c37818	1.00	Rotor 	130.00
12e55c6b-b4d9-4790-b036-45102b85f88d	404527aa-eaed-4889-8f77-da11e7c37818	1.00	Mancal	50.00
38f1caf0-42a2-438c-b921-36c82d986bdc	404527aa-eaed-4889-8f77-da11e7c37818	1.00	Engrenagem	40.00
318943fe-880e-4435-9b48-39912640ce37	404527aa-eaed-4889-8f77-da11e7c37818	1.00	Mão de obra	50.00
fb7ae4e9-e43c-4442-9cbc-d90cab89269c	42fccade-1e8b-4890-8174-ec28b172098c	1.00	Fio/ mão de obra 	30.00
c57d5ac6-1441-47b2-9d07-21d9ae56e3a6	72d2fddc-13ff-463a-b870-a0e03ab66ec7	1.00	Rolamento 6001	30.00
22663ceb-b65a-4ca4-9e75-286078ee3426	72d2fddc-13ff-463a-b870-a0e03ab66ec7	1.00	Ventoinha	20.00
fe6d860b-7596-4d0c-b280-f5e11bbd2cba	21029924-8440-46d5-a475-9a3f3d2da8f2	1.00	Fio em curto/ Mão de obra 	30.00
3ca91b61-fd9e-45ea-8419-45403083b930	61beb573-7765-402a-bfb6-bbf811badf63	1.00	Gatilho 	160.00
400c38b7-c46f-428c-b5d9-4bcf198d24c9	61beb573-7765-402a-bfb6-bbf811badf63	1.00	Comutador	50.00
47c1f43e-54b6-4a94-bae1-3b6c325fdbd3	61beb573-7765-402a-bfb6-bbf811badf63	1.00	Jogo de carvão	60.00
3d7118c3-fa39-4b24-a637-59a123edd98e	61beb573-7765-402a-bfb6-bbf811badf63	1.00	Mão de obra	60.00
e30d9ff9-081c-4e04-8dc0-41721d3da870	72d2fddc-13ff-463a-b870-a0e03ab66ec7	1.00	Mão de obra	50.00
61799474-f026-4a56-9825-01b922a195c1	84a28741-ae5b-49b0-ad98-dea98d166fb0	1.00	Rotor 	0.00
4b944d8e-0631-4517-b4d2-705cdb9df69c	84a28741-ae5b-49b0-ad98-dea98d166fb0	1.00	Porta carvão	0.00
42dd6a11-4965-4e48-bf54-643060de9350	84a28741-ae5b-49b0-ad98-dea98d166fb0	1.00	Carvão	0.00
6c03ac87-b9b6-4511-addf-b59355905569	a3372542-05ce-4ef4-8baa-5d9516427d44	1.00	Fio partido/ mão de obra	30.00
001b266a-7855-4c62-b119-a3135f4b94bf	6e6de9d2-ec95-460d-9477-c03bf7e9ece1	1.00	Cabo de força 	20.00
d72e1fa2-f728-4332-8b1c-8d4c5711c11c	6e6de9d2-ec95-460d-9477-c03bf7e9ece1	1.00	Mão de obra 	30.00
37652a85-3984-4a92-8f40-2e40605c5777	78d83607-0309-4a2f-8897-e924aaccd53e	1.00	Micro Switch	20.00
6be635ce-8891-437d-b80e-afa2850024fc	78d83607-0309-4a2f-8897-e924aaccd53e	1.00	Mão de obra	50.00
c38bc4da-ea28-41c0-bdae-de0a6ac76900	4e304a73-f1c4-40f7-8b50-112340ae8601	1.00	Válvula Bypass 	90.00
ae3c4fe5-3ab9-43dc-b02a-a1004cb655eb	4e304a73-f1c4-40f7-8b50-112340ae8601	1.00	Mão de obra 	60.00
97e7c373-f9af-44da-ad4b-21d50614254b	a0bd07fa-4493-47da-9f79-fbb19088ac5f	1.00	Motor	240.00
a31f5ca7-fa5f-4a11-9f41-3da396542ebf	a0bd07fa-4493-47da-9f79-fbb19088ac5f	1.00	Mão de obra	50.00
3bd28e3e-b062-4487-aa23-b6a54b396d42	e87b7620-bd83-445b-acac-34a21fe4e49f	1.00	Mancal	60.00
6a75e8a5-b33f-4dd8-9fc2-497851425717	e87b7620-bd83-445b-acac-34a21fe4e49f	1.00	Came	50.00
5689250d-84b0-401a-99d9-d051fa54de00	e87b7620-bd83-445b-acac-34a21fe4e49f	1.00	Lubrificação	40.00
442d3d43-5934-4586-9190-199582dbd9b5	e87b7620-bd83-445b-acac-34a21fe4e49f	1.00	Mão de obra	50.00
a409240e-cbc2-426d-acdc-eb1c75d6ab70	13cbb363-2744-403b-ac69-566d0d4c92f2	2.00	JOGO DE ANÉIS 4.3/4" 	80.00
4f19d78b-f3fc-4abb-a32e-1a64332453ae	13cbb363-2744-403b-ac69-566d0d4c92f2	1.00	JOGO DE JUNTAS	100.00
b2817a0b-6ccb-493e-bd35-97945540a73d	13cbb363-2744-403b-ac69-566d0d4c92f2	2.00	CILINDROS 4.3/4"	240.00
de42278d-f2d0-4238-8cbb-b63cb6754e24	13cbb363-2744-403b-ac69-566d0d4c92f2	2.00	FILTRO DE AR 1"	50.00
61a392c8-3777-4bee-aee3-64dff8149844	13cbb363-2744-403b-ac69-566d0d4c92f2	2.00	CONJ PISTÃO 4.3/4"	160.00
95c79daa-004b-42cb-892a-c5e455e4e0ca	13cbb363-2744-403b-ac69-566d0d4c92f2	1.00	JOGO DE ANÉIS 3.1/4" 	70.00
c1ce6f37-080b-4d5c-b8f6-c2d4a7571ab2	13cbb363-2744-403b-ac69-566d0d4c92f2	1.00	VÁLVULA PURGADORA (DRENO)	40.00
2fe002a1-2c55-4d08-8fbe-63636c9f850b	13cbb363-2744-403b-ac69-566d0d4c92f2	1.00	KIT MOLA VÁLVULA	100.00
5ae53448-74b8-4c57-8c80-21dacf51aaff	13cbb363-2744-403b-ac69-566d0d4c92f2	1.00	VISOR DE NÍVEL DE ÓLEO	30.00
3afb3b12-e88b-47ce-b940-9b5ef86b2ea7	13cbb363-2744-403b-ac69-566d0d4c92f2	1.00	MANÔMETRO 	40.00
afcb3a4a-e1e9-415e-8704-ecf01833ad98	13cbb363-2744-403b-ac69-566d0d4c92f2	1.00	ÓLEO 	100.00
e12b710b-e993-40d6-8fe8-2a6e0ef65301	13cbb363-2744-403b-ac69-566d0d4c92f2	1.00	MÃO DE OBRA 	260.00
7188659e-1d4a-4ab2-9ba3-139bf44607da	3d177bee-a4df-4ff8-aba5-d37fbbf507ab	1.00	Tampa da roda dentada	70.00
643eedd8-407c-4cc7-9e8a-7ce2613205de	3d177bee-a4df-4ff8-aba5-d37fbbf507ab	1.00	Tampa cobertura 	10.00
c4e6cfb5-f2bd-40d7-a2eb-904e9b9f2176	3d177bee-a4df-4ff8-aba5-d37fbbf507ab	1.00	Engrenagem cónica 	20.00
46218db2-03fc-41e4-b67a-fd0ba114a296	3d177bee-a4df-4ff8-aba5-d37fbbf507ab	1.00	Engrenagem cónica de dentes retos 	20.00
62d8dbc9-54f3-4729-8090-0945e67e0b24	3d177bee-a4df-4ff8-aba5-d37fbbf5pg_dump: processing data for table "public.service_orders"
pg_dump: dumping contents of table "public.service_orders"
07ab	1.00	Parafuso de ajuste 	10.00
f84c15b1-4102-47a0-9797-a2a5c4313059	3d177bee-a4df-4ff8-aba5-d37fbbf507ab	1.00	Pino de ajuste	10.00
c6761ae0-5e2c-438d-af1a-07d1dcb543f1	3d177bee-a4df-4ff8-aba5-d37fbbf507ab	1.00	Sabre	190.00
bcc35639-7bf1-4379-b8b4-caa4c0967da7	3d177bee-a4df-4ff8-aba5-d37fbbf507ab	1.00	Mão de obra	80.00
21af0eba-4ef0-4152-9a02-1d22372000a1	4e2d84c1-27bc-4b95-9197-e8470af2fdd4	1.00	Carburador 	270.00
2782c98f-8825-4ece-bf66-7f1e13d3e930	4e2d84c1-27bc-4b95-9197-e8470af2fdd4	1.00	Descarbonização do cilindro e pistão	80.00
80da05e6-3cbe-4903-a11b-65ed69bfd09a	4e2d84c1-27bc-4b95-9197-e8470af2fdd4	1.00	Limpeza e Mão de obra 	60.00
\.


--
-- TOC entry 3529 (class 0 OID 24713)
-- Dependencies: 225
-- Data for Name: service_orders; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.service_orders (id, tenant_id, order_number, client_id, equipment_id, technician_id, status, reported_defect, diagnosis, notes, payment_method, warranty_days, entry_date, completion_date, created_at, updated_at, deleted_at, lote_numero, lote_sufixo) FROM stdin;
c0f24c43-eaaa-4dfe-89ca-9e6342cbca2a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	14	f342957a-54f7-4d46-9409-6f3e1d503b4c	8bb9f9a7-2b38-4c6d-8dd3-7fcfdc0d9a93	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Não liga	\N	\N	\N	90	2026-07-23	\N	2026-07-27 15:58:42.501911+00	2026-08-03 18:53:37.996+00	\N	\N	\N
11df6e23-8e9e-401f-9333-9500d98395b0	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	17	a6510644-5be1-40ef-adc6-e5e99891c0dd	3ba2fe0b-6b86-4bc1-8b86-753c0ffe4175	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Não liga 	Tirou o carvão 	Sinal para o serviço: R$80,00/ Pagou o sinal 03/08 (Pagou o restante e levou dia 10/08)	PIX	90	2026-07-28	\N	2026-07-28 12:07:01.844919+00	2026-08-10 13:51:56.144+00	\N	\N	\N
babe140f-a4f8-45e1-a9e6-50d8fe94624c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	13	7ccccbf4-cd13-420c-8cea-f3d18a2bb956	c62687ec-7631-4c88-b037-beb12f95a4ef	6da88878-0303-4aac-941c-24b9622d20b8	aberta	\N	\N	\N	\N	90	2026-07-27	\N	2026-07-27 15:47:54.339275+00	2026-07-27 15:47:54.339275+00	2026-07-27 15:49:14.502+00	\N	\N
9fc9d663-9042-4862-94db-a99daa2e78ae	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	20	de143cae-013d-467e-910a-3d5d564cbd25	7b35c70a-e85b-4e90-bf4d-3145e1329b1c	6da88878-0303-4aac-941c-24b9622d20b8	entregue	Está comendo muito o carvão.	A maquina está arrastando 	\N	Cartão Crédito	90	2026-07-27	2026-07-27	2026-07-28 14:02:31.430467+00	2026-07-28 14:07:48.916+00	\N	\N	\N
c6f2c468-9920-4840-9879-f4537c438cf4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	9	43cb493c-25ec-4657-8393-f937e6576890	030da74c-3830-4b7f-9fc8-5676785dd808	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Sem pressão 	\N	\N	PIX	90	2026-07-27	2026-07-27	2026-07-27 14:56:09.783945+00	2026-07-27 20:05:59.618+00	\N	\N	\N
9f9aeb41-0fbf-47aa-988b-e5f0b09d6a49	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	12	4235c814-b03a-42d7-b57d-4589f01f8c1d	a54b2776-1afa-4a22-95b4-bc083be6a90b	6da88878-0303-4aac-941c-24b9622d20b8	entregue	Não Liga/Parou trabalhando	\N	Foi avisado ao cliente que o carburador está em OBS!, o mesmo falou que tem outro carburador de reserva!	PIX	90	2026-07-27	2026-07-27	2026-07-27 15:44:48.077978+00	2026-07-27 20:08:41.489+00	\N	\N	\N
f44de641-582e-4180-8676-1aa37dad3e56	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	21	9c5e19ac-6e8f-49b0-ab49-ba71a0eca09e	374f14ee-671c-4ba6-aa4b-0e34d34fa972	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aberta	\N	\N	\N	\N	90	2026-07-28	\N	2026-07-28 14:18:20.046133+00	2026-07-28 14:18:20.046133+00	2026-07-28 14:19:25.562+00	\N	\N
214246a0-327c-4fa9-87a6-2d4b7afe8041	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	23	0d66cd3e-0f02-4c63-bd34-1973ca26c673	57ab79bf-cc18-4101-a0ad-9bc28c294ab5	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Sem Pressão 	\N	\N	Dinheiro	90	2026-07-20	2026-07-28	2026-07-28 14:49:23.010455+00	2026-07-28 14:52:49.17+00	\N	\N	\N
694a7ac3-297f-4e7d-8ac7-1a1283a55529	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	22	6314dfad-9a56-4185-b353-f10769b0c2de	66c8a777-ae14-4106-b746-16c66341c2ae	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aberta	\N	\N	\N	\N	90	2026-07-28	\N	2026-07-28 14:23:06.318907+00	2026-07-28 14:23:06.318907+00	2026-07-28 14:24:45.632+00	\N	\N
936fd06f-e42c-457f-b215-097a0679aabe	c8659485-b234-4723-9681-1e71ee94ac3b	13	716204a4-7981-48e9-9126-2a9b0239bd9a	776cd238-c677-4e11-a7e0-61d3480ebc56	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	aberta	Não liga, possível problema no motor	\N	\N	\N	90	2026-07-28	\N	2026-07-28 15:20:31.188871+00	2026-07-28 15:20:31.188871+00	\N	13	A
7fc93d69-526f-47fb-8ca7-1d99abe48161	c8659485-b234-4723-9681-1e71ee94ac3b	14	716204a4-7981-48e9-9126-2a9b0239bd9a	776cd238-c677-4e11-a7e0-61d3480ebc56	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	aberta	Não liga, possível problema no motor	\N	\N	\N	90	2026-07-28	\N	2026-07-28 15:23:56.783077+00	2026-07-28 15:23:56.783077+00	\N	14	A
bb7bc476-22de-4520-96a4-96c76462339a	c8659485-b234-4723-9681-1e71ee94ac3b	14	716204a4-7981-48e9-9126-2a9b0239bd9a	2098f18d-950d-49e9-990a-3e9b15535414	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	aprovada	Fazendo barulho estranho ao girar	\N	\N	\N	90	2026-07-28	\N	2026-07-28 15:23:56.968706+00	2026-07-28 15:23:56.968706+00	\N	14	B
0c5b183c-833d-44e3-bd30-e61edc6c4057	c8659485-b234-4723-9681-1e71ee94ac3b	14	716204a4-7981-48e9-9126-2a9b0239bd9a	33e8473e-137f-42e8-8898-f484504c1dde	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	concluida	Disco travando durante o uso	\N	\N	\N	90	2026-07-28	\N	2026-07-28 15:23:57.128701+00	2026-07-28 15:23:57.128701+00	\N	14	C
3b0675d2-4894-46d3-ab98-f312937fa556	c8659485-b234-4723-9681-1e71ee94ac3b	1	4503d407-55f8-471f-a9f9-52b2e04cf7d6	980fc8e7-a3ba-455e-bfd9-669d5e0b097a	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	aberta	Não liga	\N	\N	PIX	90	2026-07-03	\N	2026-07-23 23:40:49.143693+00	2026-07-23 23:40:49.143693+00	\N	\N	\N
64717cae-fce7-492e-b675-f30205202ef1	c8659485-b234-4723-9681-1e71ee94ac3b	2	4503d407-55f8-471f-a9f9-52b2e04cf7d6	aea36194-c9cc-4e4d-ac28-141549d1849b	e5012518-7b2d-4424-b07c-227c8116915f	aprovada	Barulho no motor	\N	\N	PIX	90	2026-07-01	\N	2026-07-23 23:40:49.47964+00	2026-07-23 23:40:49.47964+00	\N	\N	\N
ba6865d7-ec54-4bed-9239-d7ed8b06880b	c8659485-b234-4723-9681-1e71ee94ac3b	3	22dda795-7f60-44b8-b405-c0f9565d4eef	65dd1106-3ddd-4882-aab4-f2ca485c21da	50f51495-7dac-4549-8cc7-e7283714054e	aguardando_peca	Disco travando	\N	\N	PIX	90	2026-07-14	\N	2026-07-23 23:40:49.797702+00	2026-07-23 23:40:49.797702+00	\N	\N	\N
6dc86da8-1a64-40e9-94a8-9c60d63d8bdf	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	11	72833910-7f5b-4141-8133-dda7e8ff9e12	7fe8cb25-6427-4201-af7f-4e1666731a47	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Fazendo Barulho 	\N	Duplicada da OS #0010	A combinar	90	2026-07-21	\N	2026-07-27 15:33:47.670245+00	2026-07-28 20:36:59.92+00	\N	\N	\N
7bb62260-5f7c-4dff-98f2-363c0564caf9	c8659485-b234-4723-9681-1e71ee94ac3b	4	22dda795-7f60-44b8-b405-c0f9565d4eef	f1329c35-d35e-4bd5-85e0-cd20d687a563	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	concluida	Esquentando muito	\N	\N	PIX	90	2026-07-02	2026-07-02	2026-07-23 23:40:50.115685+00	2026-07-23 23:40:50.115685+00	\N	\N	\N
9b481aa8-0ccf-437f-8968-fcdeb6aab3dc	c8659485-b234-4723-9681-1e71ee94ac3b	5	e2b48e4a-89dc-4336-af04-a6344e15a3ba	1dbd502c-6aa8-4715-9a89-8ce4e83eb5be	e5012518-7b2d-4424-b07c-227c8116915f	entregue	Faísca nas escovas	\N	\N	PIX	90	2026-07-14	2026-07-14	2026-07-23 23:40:50.427454+00	2026-07-23 23:40:50.427454+00	\N	\N	\N
5d0cab4a-d9db-489c-bdfc-d6f2d8f1f2e6	c8659485-b234-4723-9681-1e71ee94ac3b	6	e2b48e4a-89dc-4336-af04-a6344e15a3ba	7a636607-6d19-4110-aa9c-7fa4bb521924	50f51495-7dac-4549-8cc7-e7283714054e	aberta	Vibração anormal	\N	\N	PIX	90	2026-07-03	\N	2026-07-23 23:40:50.743688+00	2026-07-23 23:40:50.743688+00	\N	\N	\N
e2ad4476-01e2-46bb-a639-eec9097daee3	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	24	6d750b5a-f4e2-43d6-94cf-3d2af5c748da	a728f253-4050-4773-891c-4ae2727fcc9e	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Não liga 	\N	\N	PIX	90	2026-07-22	2026-07-29	2026-07-28 15:09:15.039776+00	2026-07-29 12:20:18.682+00	\N	\N	\N
2f763d83-95c3-492a-993e-b43bce8b69aa	c8659485-b234-4723-9681-1e71ee94ac3b	7	7fafefb7-0a24-40a2-b82b-75cc9679e71f	b71fa710-bb85-4439-976f-2f4bef2bea1d	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	aberta	Não liga	\N	\N	PIX	90	2026-07-01	\N	2026-07-23 23:48:09.926327+00	2026-07-23 23:48:09.926327+00	\N	\N	\N
6c1ad83f-b31f-4ac3-bec9-fa3f4a719610	c8659485-b234-4723-9681-1e71ee94ac3b	8	7fafefb7-0a24-40a2-b82b-75cc9679e71f	7bc893f7-9ca6-47c9-bd43-644165d7bc44	e5012518-7b2d-4424-b07c-227c8116915f	aprovada	Barulho no motor	\N	\N	PIX	90	2026-07-06	\N	2026-07-23 23:48:10.246632+00	2026-07-23 23:48:10.246632+00	\N	\N	\N
91874eda-692b-4eaa-a111-cc0e3ea5b1b5	c8659485-b234-4723-9681-1e71ee94ac3b	9	a8cbd12f-36a7-45fd-b948-238e5f175c4c	cf0b791a-f141-4395-8563-ccf2c7aad200	50f51495-7dac-4549-8cc7-e7283714054e	aguardando_peca	Disco travando	\N	\N	PIX	90	2026-07-08	\N	2026-07-23 23:48:10.566682+00	2026-07-23 23:48:10.566682+00	\N	\N	\N
6238c6ad-c5d7-4448-8b68-38e8120fb10c	c8659485-b234-4723-9681-1e71ee94ac3b	10	a8cbd12f-36a7-45fd-b948-238e5f175c4c	87b8fce7-ae7f-4c3c-a0b9-85d7c094402e	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	concluida	Esquentando muito	\N	\N	PIX	90	2026-07-13	2026-07-13	2026-07-23 23:48:10.879678+00	2026-07-23 23:48:10.879678+00	\N	\N	\N
60c0f67e-dd23-4289-af2e-58d6140c6d59	c8659485-b234-4723-9681-1e71ee94ac3b	11	28bd5954-4c39-41fc-89d1-5b3443c3a030	373cee8c-1dc2-4010-bdf4-133f29c28953	e5012518-7b2d-4424-b07c-227c8116915f	entregue	Faísca nas escovas	\N	\N	PIX	90	2026-07-18	2026-07-18	2026-07-23 23:48:11.194788+00	2026-07-23 23:48:11.194788+00	\N	\N	\N
3a054487-f443-4413-9903-2b826fd1b02d	c8659485-b234-4723-9681-1e71ee94ac3b	12	28bd5954-4c39-41fc-89d1-5b3443c3a030	06dd2dc3-04f2-471c-bf0c-cad9ca81a7a4	50f51495-7dac-4549-8cc7-e7283714054e	aberta	Vibração anormal	\N	\N	PIX	90	2026-07-04	\N	2026-07-23 23:48:11.519477+00	2026-07-23 23:48:11.519477+00	\N	\N	\N
6b655868-07db-4bda-8325-3c84d2c7b9f7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	3	491590c4-3257-4ba1-8d68-52b2f139542f	2c76dcad-dfaa-4f7b-8c8e-0d0043c23700	2257be26-1899-4625-aa5b-9ef0bfad2821	concluida	Faísca excessiva	\N	\N	PIX	90	2026-07-17	2026-07-17	2026-07-23 23:59:31.688002+00	2026-07-23 23:59:31.688002+00	2026-07-24 00:24:16.631+00	\N	\N
b8c8ea7d-ca4e-4f71-8fc5-67bbe8f30602	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	6	eb0c392b-6a24-4ec4-84a0-d0729c7e719b	bf88898b-f512-4d48-a1e9-78daa7fde64f	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Vazando óleo/Não enche 	Sinal para o serviço: 100,00\nOK 24/07\nPagou restante 30/07	Os interna 2299	PIX	90	2026-07-24	2026-07-31	2026-07-24 18:24:31.028489+00	2026-07-31 15:57:45.404+00	\N	\N	\N
dc1c7d37-c534-4e56-a32b-2bc1c8eb1fde	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	16	00e91576-5a07-4227-91da-36560b39b2a7	63d84acd-1ac2-4d70-be48-1f7507d115da	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Cotovelo Quebrado \nTrocar o Óleo 	\N	Sinal Para realização do Serviço: 130,00\nSinal Ok: 28/07 Resta R$120,00\nRestante Ok: 04/08	\N	90	2026-07-25	2026-07-31	2026-07-27 21:14:52.115645+00	2026-08-07 14:58:39.785+00	\N	\N	\N
56e73ee6-79ee-41af-9827-66a21ad7159e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	10	72833910-7f5b-4141-8133-dda7e8ff9e12	c29a10bf-79e7-47a0-a10f-8487d7635985	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Não liga 	\N	Pagou Sinal: R$470,00 Dia 24/07 \nFalta: R$200,00\nPagou restante 31/07	PIX	90	2026-07-21	2026-07-31	2026-07-27 15:33:29.907458+00	2026-07-31 18:29:51.153+00	\N	\N	\N
c7186ef6-34d8-499b-add3-b305f498eac6	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	2	e348105d-1a6c-4b34-911c-ef8b74baf29a	1c66cf0e-24c6-4b42-8558-d192aa718d2e	0a2b60f8-f270-4752-a8ca-9faffd6448fb	entregue	Motor fraco	\N	\N	PIX	90	2026-07-13	\N	2026-07-23 23:59:31.372297+00	2026-07-24 13:43:01.943+00	2026-07-24 16:08:46.497+00	\N	\N
8371ae12-4971-4b81-9129-6943cec3572a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	1	e348105d-1a6c-4b34-911c-ef8b74baf29a	b1c97b68-5084-4aec-9a40-ff5d19b168ac	2257be26-1899-4625-aa5b-9ef0bfad2821	entregue	Não liga	\N	\N	PIX	90	2026-07-20	\N	2026-07-23 23:59:31.044315+00	2026-07-24 13:43:07.381+00	2026-07-24 16:08:50.046+00	\N	\N
b8142b98-af47-4633-94bf-6acd7313ab62	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	18	7384934f-2bcf-4f85-83b0-dcf623c6ed22	05f2650f-3838-4698-98ec-dd8badb2043e	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Não liga 	\N	\N	\N	90	2026-07-24	\N	2026-07-28 12:23:54.146336+00	2026-08-03 20:13:32.307+00	\N	\N	\N
c2f35eef-18b4-482b-9260-352dc134f6d4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	4	5b1cc305-7edb-4b0c-b608-0d64b765e849	f90c8596-5b63-405f-9d59-951ebd4af451	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Não liga 	Fio partido	OS interna 2303	A combinar	90	2026-07-23	\N	2026-07-24 17:47:18.993044+00	2026-07-24 18:45:37.38+00	\N	\N	\N
04f3b564-f2f3-42ea-9073-73cc8c828b74	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	5	eb0c392b-6a24-4ec4-84a0-d0729c7e719b	bf88898b-f512-4d48-a1e9-78daa7fde64f	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aberta	Vazando óleo/Não enche 	\N	Sinal para realização do serviço: 100,00	A combinar	90	2026-07-23	\N	2026-07-24 18:07:55.467562+00	2026-07-24 18:07:55.467562+00	2026-07-24 18:56:38.529+00	\N	\N
d67bada3-0998-4f0c-a0c7-39a97bb4d8c9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	7	02c08106-b823-413c-99dc-3018afd8c70c	daebcb85-c3d9-4462-a966-1a47aa20e3f3	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Máquina travada	\N	\N	\N	90	2026-07-27	\N	2026-07-27 14:48:03.539466+00	2026-07-27 14:49:31.06+00	\N	\N	\N
4285f73a-4ec2-4144-97d7-0067c4e773b7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	8	02c08106-b823-413c-99dc-3018afd8c70c	e582d93f-39e8-477e-9e7a-43817b7804cf	db2355b2-9927-449b-97fb-7b95ccb5edb2	aberta	Máquina travada	\N	Duplicada da OS #0007	\N	90	2026-07-27	\N	2026-07-27 14:50:09.942496+00	2026-07-27 14:51:21.892+00	2026-07-27 14:51:43.477+00	\N	\N
675de873-a2e8-47b0-a590-4e24b9ec7ccd	c8659485-b234-4723-9681-1e71ee94ac3b	15	4503d407-55f8-471f-a9f9-52b2e04cf7d6	aea36194-c9cc-4e4d-ac28-141549d1849b	732a158a-1474-4300-b6ff-679d19073fb4	aberta	\N	\N	\N	\N	90	2026-07-28	\N	2026-07-28 15:59:30.357093+00	2026-07-28 15:59:42.165+00	\N	15	A
a4273e8d-9717-437e-85fd-31af9c1d4a78	c8659485-b234-4723-9681-1e71ee94ac3b	15	4503d407-55f8-471f-a9f9-52b2e04cf7d6	980fc8e7-a3ba-455e-bfd9-669d5e0b097a	732a158a-1474-4300-b6ff-679d19073fb4	aberta	\N	\N	\N	\N	90	2026-07-28	\N	2026-07-28 15:59:42.436781+00	2026-07-28 15:59:42.436781+00	\N	15	B
0baf5e3f-f39b-4ec7-9d05-7b1b73e22180	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	26	f3e9be14-3b81-430d-be5f-2ad8c119921a	cfd80404-90bd-4d88-911f-fcc53fab471b	db2355b2-9927-449b-97fb-7b95ccb5edb2	aberta	\N	\N	\N	\N	90	2026-07-28	\N	2026-07-28 17:43:55.437018+00	2026-07-28 17:43:55.437018+00	2026-07-28 17:45:31.116+00	26	C
0904f0de-cf2e-439c-acbd-1f236df974f4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	26	f3e9be14-3b81-430d-be5f-2ad8c119921a	33869a61-ed4a-4c11-8521-551f60818d74	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Não liga 	Carvão travado por sujeira 	\N	PIX	90	2026-07-15	2026-07-21	2026-07-28 17:38:40.673662+00	2026-07-28 17:47:54.111+00	\N	26	A
12b874e9-003f-4927-a632-77857adf0e7e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	26	f3e9be14-3b81-430d-be5f-2ad8c119921a	cfd80404-90bd-4d88-911f-fcc53fab471b	db2355b2-9927-449b-97fb-7b95ccb5edb2	cancelada	Não liga 	\N	O cliente não quis fazer e descartou a máquina.	\N	90	2026-07-15	2026-07-21	2026-07-28 17:40:51.416389+00	2026-07-28 17:49:59.697+00	\N	26	B
003053ea-db62-4e80-9fb8-5a6f68434533	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	37	32c9c508-f81d-46d5-b96a-b9d4e7143728	b88831aa-0635-4d2e-b9b9-148baef6aa36	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	cancelada	Fazer revisão 	Máquina obsoleta (A fábrica não fornece mais peças para reposição)	Descartou 29/07	\N	90	2026-07-29	\N	2026-07-29 17:52:12.519587+00	2026-07-29 18:08:26.552+00	\N	\N	\N
4af873ce-fc15-4d8d-a431-2ccb5fd26982	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	38	c0984895-5dfa-4663-9816-469fabb70000	cf66fa44-3aeb-4194-8b11-f3d145c31c4f	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Trocar o carvão e fazer uma revisão.	Fez o pagamento no Pix, levou 01/08 	\N	PIX	90	2026-07-29	2026-08-01	2026-07-29 20:12:23.985809+00	2026-08-01 15:10:14.621+00	\N	38	A
c8083522-492b-4491-b26b-d4ebdbd184dc	c8659485-b234-4723-9681-1e71ee94ac3b	16	3b58b228-0e27-4954-9d00-27e58035562f	6b5570e2-0b1c-40e1-b3e4-5d178c3274a5	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	aberta	Não liga - OS DE TESTE (45 dias)	\N	\N	PIX	90	2026-06-14	\N	2026-07-29 16:15:53.661877+00	2026-07-29 16:15:53.661877+00	\N	\N	\N
42bef4a9-042d-43ae-b2d0-e88d33152ce1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	25	ba75cd9b-9850-45a5-9432-af409ee947f4	3b381e2f-2d18-45be-a6e7-775fa738405c	6da88878-0303-4aac-941c-24b9622d20b8	entregue	Está vazando.	Os antiga N°2307	\N	Dinheiro	90	2026-07-24	\N	2026-07-28 15:57:46.22612+00	2026-07-28 20:27:18.473+00	\N	\N	\N
2c12cbbd-9f06-437f-84fe-d8d06142d55e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	26	f3e9be14-3b81-430d-be5f-2ad8c119921a	58f3b994-18cb-41a4-b635-2bfb9de13be2	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Não bate 	\N	Sinal para realização do serviço pago dia 21/07 (120,00)\nPago total 04/08	PIX	90	2026-07-15	2026-07-28	2026-07-28 17:44:08.650827+00	2026-08-04 18:15:04.762+00	\N	26	D
dfdca527-6846-485b-b655-52db054d2093	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	40	c7ae6402-2cb9-4a7e-baa5-4f8efb54262f	89fe6fd6-1cfe-4c85-8682-b2ed14ee0345	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	concluida	Fechou curto 	\N	Pagou levou 04/08	\N	90	2026-07-29	2026-08-03	2026-07-29 20:28:11.14327+00	2026-08-04 18:19:55.518+00	\N	\N	\N
115a5776-a43c-47f3-af74-7cdb61e912d3	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	26	f3e9be14-3b81-430d-be5f-2ad8c119921a	b342df4a-3cc4-4c06-ab83-08cd870876b6	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Não Atira 	Equipamento sujo por acúmulo de pólvora	\N	PIX	90	2026-07-15	2026-07-21	2026-07-28 17:44:37.292078+00	2026-07-28 18:15:01.944+00	\N	26	F
1d62baa9-3ced-4b01-8536-4c623eb56e8f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	26	f3e9be14-3b81-430d-be5f-2ad8c119921a	b253db30-4fde-4039-939f-1b6fcebaa35e	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Não bate 	\N	\N	PIX	90	2026-07-15	2026-07-21	2026-07-28 17:44:46.398244+00	2026-07-28 18:16:09.271+00	\N	26	G
6883491c-bac7-43b1-9751-30bcc23ca241	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	27	bbb53896-df27-4535-9a0f-6c6abf577352	2b9e466b-5a6a-4490-9c7b-02a1958e57b2	6da88878-0303-4aac-941c-24b9622d20b8	entregue	Não liga 	\N	Com Pistola completa e engate rápido \nPagou Total 03/07 Levou 	\N	90	2026-07-28	\N	2026-07-28 18:04:19.310132+00	2026-08-03 15:02:22.907+00	\N	\N	\N
b6d8a52f-97ae-439e-b375-f28bf9cebffa	c8659485-b234-4723-9681-1e71ee94ac3b	17	3b58b228-0e27-4954-9d00-27e58035562f	eac013b0-7059-4af1-b5c6-3bad35d954fa	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	aprovada	Disco travando - OS DE TESTE (60 dias)	\N	\N	Cartão	90	2026-05-30	\N	2026-07-29 16:15:53.991739+00	2026-07-29 16:15:53.991739+00	\N	\N	\N
648644fe-8b54-4fd6-a1ba-e3b727bf862e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	29	e40eb094-6f78-428a-8d4a-a376dbf222e7	a28a4794-bff0-428a-9fc0-b02792b99e4b	6da88878-0303-4aac-941c-24b9622d20b8	aberta	Gatilho	\N	\N	\N	90	2026-07-28	\N	2026-07-28 19:05:09.479278+00	2026-07-28 19:12:19.665+00	2026-07-28 19:14:37.974+00	\N	\N
852a3fec-392b-40f1-950f-9762ad8b0519	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	28	3cf92c8a-0fe5-40a8-80dc-5b8a8860d9c5	e0d14fd4-7b30-4c95-93e3-9d4e9a0fdd4e	6da88878-0303-4aac-941c-24b9622d20b8	entregue	Não está ligando, trocar as rodas.(Os.2312)	\N	Sinal: 100,00/ Pagamento do sinal realizado no dia 28/07 \nPg Restante 05/08	\N	90	2026-07-25	\N	2026-07-28 19:00:37.711275+00	2026-08-05 19:57:13.583+00	\N	\N	\N
71b5358f-04fd-4990-92aa-0fe587c1af54	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	42	8c12838f-9ad9-4c47-9e04-0fd8f5076994	e089613c-e373-48af-8fd1-1ebd3ddf4170	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Retratíl não está funcionando	Suporte interno quebrado.	PG 80,00 03/08\nResta 60,00 Pg 11/08	\N	90	2026-07-30	\N	2026-07-30 12:09:36.615071+00	2026-08-11 14:52:08.425+00	\N	\N	\N
9f0d4997-9926-4a92-a26f-7ab0efee3182	c8659485-b234-4723-9681-1e71ee94ac3b	18	3b58b228-0e27-4954-9d00-27e58035562f	a3dab0f4-e016-4dc9-8651-d5d629786285	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	concluida	Vibração anormal - EQUIPAMENTO ABANDONADO (200 dias)	\N	\N	Dinheiro	90	2026-01-10	2026-01-20	2026-07-29 16:15:54.313622+00	2026-07-29 16:15:54.313622+00	\N	\N	\N
7fe02cf3-d203-4bc3-8a94-6d6cccab5c27	c8659485-b234-4723-9681-1e71ee94ac3b	19	3b58b228-0e27-4954-9d00-27e58035562f	9204e5e9-91de-4564-816a-bd0699b508d6	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	aguardando_peca	Bateria não carrega - EQUIPAMENTO ABANDONADO (185 dias)	\N	\N	PIX	90	2026-01-25	\N	2026-07-29 16:15:54.631709+00	2026-07-29 16:15:54.631709+00	\N	\N	\N
5d38dec3-1de7-4873-8922-062e220c5261	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	35	33cbc579-810b-4435-9288-40fbd66a12ca	2f57a156-0576-4456-b1ce-fe74c9c0b951	db2355b2-9927-449b-97fb-7b95ccb5edb2	aprovada	Não bate 	\N	Sinal para realização do serviço (250,00)\nChave Pix: 21968161250\nFelipe Queiroz Rebello \nFAvor enviar o comprovante para seguir com o serviço.	PIX	90	2026-07-25	\N	2026-07-29 12:32:47.762647+00	2026-08-03 20:14:27.725+00	\N	\N	\N
1b76cc63-aced-4b7c-a847-b0e7e88b8b77	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	34	2460faab-37f1-414b-b8e9-dd8988814f41	fc1ba4bd-4aef-4fa2-a4d6-924104b19d8d	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aprovada	Não Liga 	\N	\N	\N	90	2026-07-28	\N	2026-07-28 21:35:00.318745+00	2026-08-03 20:10:51.697+00	\N	34	C
56d7a980-f2e3-4618-b3b8-a0af7d9e5471	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	30	72833910-7f5b-4141-8133-dda7e8ff9e12	8537df66-f52e-4826-a47e-f2d7a3343b4e	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Gatilho	Sinal para Realização do serviço: R$80,00\nPagamento total: 31/07 ok\nLevou 13/08	\N	\N	90	2026-07-28	2026-08-06	2026-07-28 19:17:14.170076+00	2026-08-13 19:51:49.494+00	\N	\N	\N
60d9bc5a-3e31-4238-ae2f-4222aa3b7586	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	33	005f0c88-f77f-4e8e-b079-06881fa72685	4b9c55c4-b36d-48a6-9d44-cfc59b1998c8	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Não lubrifica \nNão aperta a corrente 	O óleo utilizado estava muito grosso e entupiu as vias da bomba de óleo, impedindo a lubrificação. \nO parafuso que foi adaptado pelo cliente estava muito curto, por isso a corrente não estava sendo apertada.	Pago dia 29/07	A combinar	90	2026-07-24	2026-07-29	2026-07-28 19:55:57.50871+00	2026-07-29 18:05:34.524+00	\N	\N	\N
045a9548-96af-4f26-bdda-34649163adc8	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	34	2460faab-37f1-414b-b8e9-dd8988814f41	877da309-3101-4c5f-b5e3-a3c1e88d0c48	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aprovada	Não liga 	\N	\N	\N	90	2026-07-25	\N	2026-07-28 21:33:38.603294+00	2026-08-03 20:10:44.543+00	\N	34	B
c8beb81c-7a94-47dd-a3ec-5674e7c806cc	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	26	f3e9be14-3b81-430d-be5f-2ad8c119921a	fa4ed6b3-3b0e-41b6-a40b-6ed578120050	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Não bate 	\N	Sinal para a realização do serviço pago dia 21/07 (110,00)\nPago restante 04/08	PIX	90	2026-07-15	2026-07-28	2026-07-28 17:44:23.458748+00	2026-08-07 14:59:03.009+00	\N	26	E
e4359f4f-dc56-4a31-b1c5-79e16cb154f9	c8659485-b234-4723-9681-1e71ee94ac3b	20	716204a4-7981-48e9-9126-2a9b0239bd9a	33e8473e-137f-42e8-8898-f484504c1dde	e5012518-7b2d-4424-b07c-227c8116915f	aprovada	\N	\N	\N	\N	90	2026-01-26	\N	2026-07-29 20:16:06.726661+00	2026-08-03 19:31:48.828+00	\N	\N	\N
d893d274-b55d-4aae-b5a6-568ec61b1b18	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	38	c0984895-5dfa-4663-9816-469fabb70000	c21c05d9-664d-4f55-978d-13bdd2b6a56a	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	concluida	Quando desliga a pistola o motor continua fazendo barulho.	Chave do Bypass	\N	\N	90	2026-07-29	\N	2026-07-29 20:32:58.382279+00	2026-08-07 14:57:44.975+00	\N	38	B
c30a82a2-d2f3-44ad-b26c-d9477f9cc220	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	41	2d019df4-3df6-4ef8-86ba-891dcb5e9ce2	c602c8b2-4791-45b1-a72b-d31be3cdeb94	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	O gatilho está duro 	Pago 04/05	\N	\N	90	2026-07-29	2026-08-03	2026-07-29 20:38:50.906042+00	2026-08-05 20:21:42.258+00	\N	\N	\N
93660902-0806-436c-8969-af11a5c173df	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	36	8b2a2b71-c47b-45ba-a8ce-1cbbc2b633f7	96f15645-e70f-462f-82f9-ec7abadae1e5	6da88878-0303-4aac-941c-24b9622d20b8	cancelada	Desarma quando vai cortar	Rotor em curto 	Sinal para o Serviço: R$400,00 / O cliente não fez o serviço levou dia 01/08	\N	90	2026-07-29	\N	2026-07-29 14:17:04.750158+00	2026-08-01 13:47:54.696+00	\N	\N	\N
986cf19d-319e-448d-b463-2888d589ba79	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	32	5ce60189-4263-423d-a1e4-d166baf66a8b	a613292e-1a80-49cd-9090-a98e7bb8b684	6da88878-0303-4aac-941c-24b9622d20b8	entregue	O mandril não está abrindo	\N	Pagou, levou 04/08	\N	90	2026-07-28	\N	2026-07-28 19:39:46.346159+00	2026-08-04 20:11:00.121+00	\N	32	B
b6fe696a-d45a-415d-91c7-21e9e6b9c90d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	31	cbe54fe3-9203-4718-beb7-766185ffa927	310dab71-9f32-44d4-b445-56d88d1ef3c8	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Está com mal contato, fazer uma lubrificação. (Os.2317)	\N	Pagou Total 04/08	\N	90	2026-07-29	\N	2026-07-28 19:24:57.755437+00	2026-08-04 15:05:58.966+00	\N	\N	\N
404527aa-eaed-4889-8f77-da11e7c37818	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	39	daea5356-7032-4c55-88ae-1a6e55a8609c	35ea8557-f5f1-47ec-a648-da91ab1cedf1	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aguardando_peca	Mandril bambo.	\N	Sinal R$180,00\nPagamento total Ok 17/08	\N	90	2026-07-29	\N	2026-07-29 20:23:00.207547+00	2026-08-18 14:30:22.819+00	\N	\N	\N
1ac83055-6eac-43e1-b22f-c2823a9008cf	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	46	ad48afdb-0fbd-419d-94dd-50efadb169d4	3d06fef0-7c8f-42be-89e8-62d57dbb9ccd	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	\N	Sem defeito 	\N	\N	90	2026-07-30	\N	2026-07-30 15:40:52.283156+00	2026-08-03 18:56:50.794+00	\N	46	B
0eb35729-ff37-4e5e-8ae7-ee1080cf5a25	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	52	1028f9ae-f12a-41b1-b28d-29322a1beb76	0055b8fb-1577-4f8b-bd00-2b08fc353175	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Trocar o carretel. 	Carretel mal encaixado.	\N	\N	90	2026-07-31	2026-07-31	2026-07-31 18:03:56.416473+00	2026-08-03 18:06:04.033+00	\N	52	A
c0d37832-e76d-4d20-a80e-ffb091f7ee0a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	45	5a6976ee-6988-4a2d-9783-abef84c22375	cdcbf203-d9b8-42ea-85e5-1036a3510a08	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	\N	\N	Sinal para a realização do serviço: R$180,00\nPago dia 29/07\nPg restante 05/08	\N	90	2026-07-10	2026-08-03	2026-07-30 15:25:34.224987+00	2026-08-05 20:19:35.495+00	\N	45	C
275a3f90-d716-425f-8d8d-e3886b8c4a15	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	64	e1b5efb0-6686-4fdf-931b-fe77ccbf90e0	14f644b2-11d3-46fb-b86a-daf7b1ffa6a6	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Não liga	Gatilho queimado	sinal 30,00 ok 11/08 Pagou o restante 17/08! Levou!	\N	90	2026-08-03	\N	2026-08-03 19:47:45.997609+00	2026-08-17 13:46:50.185+00	\N	\N	\N
4cf5776f-8346-4ad5-9e85-0938a5625dec	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	59	08f5f4f7-b334-42a8-88f4-7379b267d01c	121a47fc-fc01-4068-9fe7-fe479c52ef16	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Está centelhando 	Não foi encontrado defeito	\N	\N	90	2026-08-03	\N	2026-08-03 15:49:31.959119+00	2026-08-08 12:20:53.774+00	\N	59	A
7c1b027d-0871-449c-bda5-4d7aeb538afc	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	47	0fb9604a-9ed4-456a-b014-745c0f0e34d5	79694a12-054e-4c95-ad60-ff85fea17cc5	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aprovada	Não liga/Falhando	Sinal: 440,00	\N	\N	90	2026-07-30	\N	2026-07-30 16:00:07.804477+00	2026-08-04 12:05:05.151+00	\N	47	B
07264ab0-4bde-4dc0-a31b-5b6aa854add6	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	47	0fb9604a-9ed4-456a-b014-745c0f0e34d5	eb48cbd3-38a0-48e0-8ef4-eeceb4e1f5a7	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aprovada	Fagulhando	A maquina está fora de linha, Não tem mais peças para reposição	\N	\N	90	2026-07-30	\N	2026-07-30 16:00:55.076027+00	2026-08-04 12:04:44.425+00	\N	47	C
f4a435a2-f9de-40cd-acb9-fad17aff30d3	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	44	fcbcb142-6e9f-4961-9350-b121fb78738b	eeffe976-6760-478b-bd3a-a3ecd76061ed	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Não liga 	\N	Pagou total 04/08	\N	90	2026-07-30	2026-07-31	2026-07-30 14:53:37.384119+00	2026-08-04 14:06:41.132+00	\N	44	A
b8cf3869-7d3e-4a50-b9ca-36d981633c1a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	53	51f35478-f3c3-412c-ad60-de472ab1484b	18b02716-92c6-483d-a5c4-37e25f56b5d8	6da88878-0303-4aac-941c-24b9622d20b8	cancelada	Sem pressão.	A falta de óleo danificou várias peças do lava-jato. Sinal para o serviço:650,00	Não fez o serviço, levou a máquina dia 11/08	\N	90	2026-08-01	\N	2026-08-01 13:25:48.109831+00	2026-08-11 12:56:40.163+00	\N	\N	\N
34c06735-d64a-44f4-98d6-0cea04823b96	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	15	ac66c053-d055-497a-8dbd-28d290142c0d	989f6383-78c6-4dac-86c6-f737c0885e4a	6da88878-0303-4aac-941c-24b9622d20b8	aguardando_peca	Está com cheiro de queimado, colocar parafuso original.	A bobina da lixadeira entrou em curto, e foi constatado que os rolamentos estão travados 	\N	\N	90	2026-07-27	\N	2026-07-27 17:31:41.313351+00	2026-07-31 15:02:26.448+00	\N	\N	\N
a2bd17cc-c1b3-4df8-9495-9f1200497b72	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	62	b727602c-6f4b-4320-88cb-2a2f2257224d	16a2a95b-8097-4dcc-ac24-f667dd04fc14	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Saiu fumaça e não liga mais.	Rotor entrou em curto	\N	\N	90	2026-08-03	\N	2026-08-03 18:36:17.655848+00	2026-08-06 18:53:59.627+00	\N	\N	\N
d7b70769-6b01-45b6-b69b-f3c4fb536a45	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	54	61eb8a2d-5ea5-468d-a2e8-e99284504c62	775459c9-f535-4992-823b-30fb7a1b4f61	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	A máquina está esquentando muito.	\N	Estava com o comutador arrastando na carcaça. \nFalei com o cliente que era calço na bobina e não cobrei nada.	\N	90	2026-08-04	\N	2026-08-03 11:48:59.385932+00	2026-08-07 13:22:44.386+00	\N	\N	\N
11fb8cba-ce01-439d-8a43-ca1a596c2956	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	58	54c9ba13-d8e9-4151-9b3c-bae9c598cdee	c8557f12-d100-41b8-9c0e-fdb4db1bf09a	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Fazendo um barulho/ parece estar trabalhando forçado.	Não foi encontrado defeito no lava-jato.	\N	\N	90	2026-08-03	\N	2026-08-03 15:25:53.611951+00	2026-08-05 18:42:41.538+00	\N	\N	\N
2a761672-5467-41d2-8e58-f25c49612940	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	34	2460faab-37f1-414b-b8e9-dd8988814f41	be7e4569-aaa6-4b7e-86bd-34ad75a8e35e	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aprovada	Fazendo barulho e cheiro de queimado.\nTrocou um rolamento no dia 28/07/2025	A base do motor está completamente enferrujado, juntamente com os rolamentos.\nNão tem como fazer o reparo, somente trocando o motor completo.	\N	\N	90	2026-07-25	\N	2026-07-28 21:31:59.544368+00	2026-08-03 20:10:38.53+00	\N	34	A
fae91efb-ea64-47fe-88cb-5f7424751d78	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	60	0aaef31d-edb4-41a4-bc12-c50977730963	ff4f72f0-1674-4680-8386-83f13ad499d2	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aberta	Cheiro de queimado.	Valor do Sinal: 220,00	\N	\N	90	2026-08-03	\N	2026-08-03 16:00:44.77581+00	2026-08-03 16:00:44.77581+00	2026-08-03 16:07:10.483+00	\N	\N
7e6f618c-867c-4113-9ab5-a5dbbbeab3a3	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	57	ee6e8dd3-896a-413b-9b0d-20e6bd9dcd79	058ccfd1-f736-4df6-b520-b248fc8f6600	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Não bate 	\N	Sinal: 140,00 Ok 06/08 Pagamento restante ok! 10/08	\N	90	2026-08-03	2026-08-10	2026-08-03 14:40:51.799574+00	2026-08-10 18:53:43.983+00	\N	\N	\N
0b57a76a-cddf-4f02-8dd1-df693bd98923	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	52	1028f9ae-f12a-41b1-b28d-29322a1beb76	9d8dc01b-4b63-47a3-9e9b-59a7e3d0e2cb	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	\N	Pago e retirada 03/08	\N	\N	90	2026-07-31	2026-07-31	2026-07-31 18:16:14.822031+00	2026-08-03 18:05:36.608+00	\N	52	B
ae1288f8-90a5-4e00-9d5c-c7c1fb2e1b72	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	61	2d9486a9-74e9-4a70-8205-04fe791da471	f5517930-f950-4c02-967a-092bfe10629e	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aprovada	Mandril não funciona/Sem bateria	\N	Sinal para realização do serviço: 280,00	\N	90	2026-08-03	\N	2026-08-03 18:16:34.82494+00	2026-08-06 14:24:16.226+00	\N	\N	\N
86e497a7-0905-4029-a63f-0712be31cc06	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	32	5ce60189-4263-423d-a1e4-d166baf66a8b	11361a7e-a079-4707-bf14-abbc032faf5b	6da88878-0303-4aac-941c-24b9622d20b8	entregue	Não está martelando	A caixa de compressão está quebrada e por conta disso a maquina está fazendo um barulho de engrenagem. Não tem como trocar essa peça pois a máquina está fora de linha. 	Pagou levou 03/08	\N	90	2026-07-28	\N	2026-07-28 19:30:38.403381+00	2026-08-03 18:53:28.482+00	\N	32	A
e5eb61a5-e138-4eef-8eee-d8972098dcad	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	46	ad48afdb-0fbd-419d-94dd-50efadb169d4	57286ec7-140a-41a8-817d-6caeea5c58d6	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Quando coloca na grama fica fraca.	Motor em curto	Sinal para Realização do serviço: R$300,00	\N	90	2026-07-30	\N	2026-07-30 15:39:43.063887+00	2026-08-03 18:56:43.881+00	\N	46	A
754d18cf-53ac-47ee-9b10-36a840a48860	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	59	08f5f4f7-b334-42a8-88f4-7379b267d01c	0264cc41-fcef-46cd-88a6-6b82df978f05	6da88878-0303-4aac-941c-24b9622d20b8	aprovada	Não liga	Valor do Sinal: 430,00	Os antiga 2196	\N	90	2026-08-03	\N	2026-08-03 16:04:44.046593+00	2026-08-03 20:09:28.192+00	\N	59	B
fc4e36c4-e5a3-4419-94ed-42418cb00f50	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	45	5a6976ee-6988-4a2d-9783-abef84c22375	09e1bbad-56c8-47d2-a376-cabee91512b3	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	\N	\N	Sinal para a realização do serviço: R$80,00\nPago no dia 29/07\nPg restante 05/08	\N	90	2026-07-10	2026-08-05	2026-07-30 15:23:56.288628+00	2026-08-05 20:19:01.776+00	\N	45	B
99d0271a-0c46-4b39-9dc5-9727f7b0a610	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	43	d1d9d7c0-a55a-4474-b829-8e37461d9fe5	2db690b1-a051-40ef-ba93-050f32768b6a	6da88878-0303-4aac-941c-24b9622d20b8	aprovada	O Guincho não funciona 	\N	\N	\N	90	2026-07-30	\N	2026-07-30 12:49:38.235809+00	2026-08-03 20:10:31.339+00	\N	\N	\N
196bae00-2942-47f3-a7cf-ba0fe6e6a435	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	65	2f600557-66e4-4a2e-b4eb-9186657fd5b9	1d70a0cc-b731-422c-8710-a497c50913f7	6da88878-0303-4aac-941c-24b9622d20b8	concluida	Motor queimado e está vazando água.	Sinal: 240,00/ Pagamento do sinal realizado no dia 30/07	\N	PIX	90	2026-07-17	2026-08-03	2026-08-03 20:56:30.503745+00	2026-08-03 20:56:43.777+00	\N	\N	\N
05c63926-f7ce-4bba-a743-138cd6f01a66	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	47	0fb9604a-9ed4-456a-b014-745c0f0e34d5	73b25273-08f4-4d1f-9e5e-46884eff131d	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aprovada	Caixa de engrenagem 	A máquina está fora de linha, Não tem mais peças de reposição! 	\N	\N	90	2026-07-30	\N	2026-07-30 15:58:06.647124+00	2026-08-04 12:05:29.367+00	\N	47	A
438a1e46-320b-4245-a066-4747d15e68bd	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	49	bdcafd51-6adb-4361-a45c-9e76f63f947c	c2012e80-d3d1-4739-a0be-d1b0dbeb2b30	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Mal contato	Trava de segurança mal encaixada.	Avisado 04/08	\N	90	2026-07-30	2026-08-05	2026-07-30 20:29:25.091458+00	2026-08-05 20:34:52.664+00	\N	\N	\N
166fc1b9-8818-4454-8986-fdbc9a579b6f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	45	5a6976ee-6988-4a2d-9783-abef84c22375	94bdb0fb-dc87-4591-b4e5-07f322aa1319	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	\N	\N	Sinal para realização do Serviço: R$120,00\nPago dia 29/07\nPG resante 05/08	\N	90	2026-07-10	2026-08-03	2026-07-30 15:21:50.544585+00	2026-08-05 20:17:47.693+00	\N	45	A
dd49e6f9-5515-4a7f-86ba-cd8e8e9804d8	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	44	fcbcb142-6e9f-4961-9350-b121fb78738b	b7e57d1f-ea49-4f07-be61-2a8704643cd2	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Falhando ver carvão 	\N	Pagou Total 04/08	\N	90	2026-07-30	\N	2026-07-30 15:06:57.144321+00	2026-08-04 14:06:20.519+00	\N	44	B
74b0d23c-6bb1-4128-81b7-523156afa3d4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	56	b8b5da0e-05d5-4e8e-8c08-c0f265d3f42c	d8462256-2e7c-448f-8772-7b8922aa37b1	6da88878-0303-4aac-941c-24b9622d20b8	aprovada	Disco bambo.	O rolamento da caixa de engrenagem estava quebrado. 	\N	\N	90	2026-08-03	\N	2026-08-03 14:37:06.104131+00	2026-08-05 21:07:04.167+00	\N	56	A
ab664a09-417e-4bd9-9bd3-468663633246	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	63	c36ec798-9741-47ed-9023-5bf16a351310	5cde60c5-b8cb-4aae-a23c-3d79f95cbc5d	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Não liga/Com bateria.	\N	Sem peça de reposição	\N	90	2026-08-03	\N	2026-08-03 19:28:37.314837+00	2026-08-07 17:51:16.305+00	\N	\N	\N
be90a785-79cc-4b33-9cfb-4361135210ff	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	50	de252bde-1b36-4120-9ec6-79f0fc854287	4a03e180-e336-4f92-9f60-b21b3205661d	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Ver Rotor 	\N	Pagamento total dia 04/08	\N	90	2026-07-31	\N	2026-07-31 11:42:41.458977+00	2026-08-12 15:27:24.304+00	\N	\N	\N
ef5df1a9-90f1-4989-9ec4-ecb9cc5be9e0	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	59	08f5f4f7-b334-42a8-88f4-7379b267d01c	4615a96b-5ee5-4ac2-bda0-e87623b3c140	6da88878-0303-4aac-941c-24b9622d20b8	concluida	Está com cheiro de queimado.	\N	Pagamento total 08/08	\N	90	2026-08-03	2026-08-11	2026-08-03 17:33:51.265883+00	2026-08-11 14:31:31.245+00	\N	59	C
584454f2-922d-4336-94ab-fc26540f41cd	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	66	cbe54fe3-9203-4718-beb7-766185ffa927	dea115f9-de5a-43ab-8ffd-3f49c45ef083	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Não liga	\N	Pagamento 07/08\nLevou 12/08	\N	90	2026-08-04	2026-08-12	2026-08-04 15:10:42.027771+00	2026-08-12 17:41:25.326+00	\N	66	B
c916d3eb-57d3-4428-b673-9f29116661a2	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	51	4c5c36c6-0594-445c-af0d-83e45bad0fa3	0b3f5e33-f494-4ea4-9326-7d147f298be0	6da88878-0303-4aac-941c-24b9622d20b8	cancelada	Fagulhando e parou	Rotor e Estator entraram em curto.	\N	\N	90	2026-07-31	\N	2026-07-31 15:49:03.050468+00	2026-08-04 15:19:30.791+00	\N	\N	\N
7b1112e1-8938-41b0-b254-7efca3a5d633	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	67	4c5c36c6-0594-445c-af0d-83e45bad0fa3	73efcf3a-a7e7-4f38-aff3-db4a164c782f	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aberta	Não liga	Solda na placa de contato.	\N	\N	90	2026-08-04	\N	2026-08-04 15:15:13.282295+00	2026-08-05 13:13:27.609+00	\N	\N	\N
7f1d4ab1-e8c1-45f0-8be2-e65f40bae359	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	19	ced6073a-0a5d-47a8-8e32-50a3eee914b4	4e0e02fd-9e57-4052-8b53-0bb76eec9376	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Corda do retrátil travada 	Motor travado devido a carbonização e umidade no cilindro. 	Sinal para a realização do serviço: R$70,00	\N	90	2026-07-28	2026-07-30	2026-07-28 12:32:39.853055+00	2026-08-05 14:25:37.542+00	\N	\N	\N
f231baa9-0e66-4f8e-adc9-5a01e5650f41	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	48	a41d03ee-47e6-482a-a4cb-dde0a146a80f	56b4a694-ef71-4ce7-a5c1-e081dd9f4f8b	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Fagulhando 	Rotor em curto.	Sinal: R$150,00 Ok 03/07\nresta 70,00 ok 06/07	\N	90	2026-07-30	2026-08-06	2026-07-30 19:50:15.123926+00	2026-08-17 15:16:17.454+00	\N	\N	\N
5c0e6ed7-0f9c-4629-8009-48e0cfdca70f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	55	a1c5f1de-64d6-48c2-af16-f800465124b9	f22ec215-bda9-4140-97a7-c5180a96c9e5	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	A máquina está vazando agua, soltar a mangueira.	Sinal: 220,00	Levou e disse que retornaria para concluir o serviço. 06/08	\N	90	2026-08-03	\N	2026-08-03 12:20:12.78781+00	2026-08-06 18:55:21.585+00	\N	\N	\N
3df2b634-150f-465b-af4b-8355c6692106	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	78	6d251427-82ba-49f2-9ff3-5ea16132fd31	f1413bec-dd88-4da0-b046-e17e509d4638	db2355b2-9927-449b-97fb-7b95ccb5edb2	aberta	Sem pressão e vazando agua 	\N	\N	\N	90	2026-08-06	\N	2026-08-06 19:08:20.147487+00	2026-08-06 19:08:20.147487+00	\N	\N	\N
187d64d9-8882-42d2-b287-fb949167105e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	74	f7f561cf-db2d-4cac-ae5b-93464cb24478	c585906c-5a8f-433b-a54c-15c440579375	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Oscilando velocidade 	\N	Sinal 200,00\nPg restante levou 14/08	\N	90	2026-08-05	2026-08-13	2026-08-05 20:05:00.081311+00	2026-08-14 20:11:42.295+00	\N	\N	\N
f6a2eb03-639d-46b7-a693-f5135f39358e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	56	b8b5da0e-05d5-4e8e-8c08-c0f265d3f42c	1d7004b6-7780-4830-a849-3395280b0afa	6da88878-0303-4aac-941c-24b9622d20b8	aprovada	\N	O cabo de força estava partido.	\N	\N	90	2026-08-05	\N	2026-08-05 20:51:33.874261+00	2026-08-05 21:07:57.576+00	\N	56	B
e1d9cc39-b2f6-485c-9836-bfe9ee152b5a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	56	b8b5da0e-05d5-4e8e-8c08-c0f265d3f42c	2ea3b9f4-82fd-4811-a1f1-076dd1c1ef30	6da88878-0303-4aac-941c-24b9622d20b8	aprovada	O mandril está bambo.	Sinal: 190,00	\N	\N	90	2026-08-05	\N	2026-08-05 20:55:10.780683+00	2026-08-05 21:10:44.496+00	\N	56	C
44ea71b3-cad4-4878-9441-f18abfde1c2e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	68	2844c1c6-fad3-42c7-81ab-1b32dd636bff	c8596a07-6618-4689-9808-cd05c97a1492	db2355b2-9927-449b-97fb-7b95ccb5edb2	aprovada	Sem pressão	\N	Sinal 180,00	\N	90	2026-08-04	\N	2026-08-04 18:07:46.185762+00	2026-08-06 19:23:35.757+00	\N	\N	\N
4197462f-2376-4048-b3bc-82bcb4c8007b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	56	b8b5da0e-05d5-4e8e-8c08-c0f265d3f42c	e4b16552-4d9c-4b1a-bd5b-88e832a4cdf2	6da88878-0303-4aac-941c-24b9622d20b8	aprovada	Parou.	Entrou em curto	Sinal R$360,00	\N	90	2026-08-05	\N	2026-08-05 21:01:14.773206+00	2026-08-06 14:04:04.861+00	\N	56	D
8cc1f341-9f2e-4e13-b072-ab3d5b674bdd	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	83	ad48afdb-0fbd-419d-94dd-50efadb169d4	a8d69cb2-e9fb-43a7-8af9-94d4e1a2b328	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Mal contato/Não liga	\N	Sinal 100,00 Ok 11/08\nResta 60,00 Ok 17/08	\N	90	2026-08-07	\N	2026-08-07 14:09:12.384361+00	2026-08-17 21:06:01.899+00	\N	\N	\N
735ac9d2-c8d7-452d-8b70-3a75fc33b7a6	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	80	585f5754-0cc4-48da-95eb-f5aa1c5a18d4	0810c0b7-a886-4946-9518-8bdc36f81446	6da88878-0303-4aac-941c-24b9622d20b8	concluida	Pega e morre	A bobina está dando pouca centelha. 	O cliente comprou a bobina no Serginho e trouxe para fazer a montagem! Antiga os.2233	\N	90	2026-08-06	\N	2026-08-06 19:50:29.052021+00	2026-08-06 19:51:14.939+00	\N	\N	\N
8c346433-e17f-4b18-9db1-0970c1ad297e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	69	f3e9be14-3b81-430d-be5f-2ad8c119921a	f7407048-5647-4f47-8246-61b51e441952	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	concluida	O mandril não está rodando.	Caixa de engrenagem solta 	\N	\N	90	2026-08-04	\N	2026-08-04 18:32:39.539525+00	2026-08-07 15:31:34.607+00	\N	\N	\N
4319ed74-dcb3-46b0-a59b-31e0a0ed0546	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	66	cbe54fe3-9203-4718-beb7-766185ffa927	81ad8d89-b6a8-488c-a7b8-095dbe9a6800	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Mal contato no interruptor 	Interruptor em curto.	Pagamento total 07/08 \nLevou 12/08	\N	90	2026-08-04	2026-08-12	2026-08-04 15:03:21.782822+00	2026-08-12 17:41:01.784+00	\N	66	A
7da58dac-4c49-4c53-9414-24cb58801f37	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	71	91d59fb5-467b-4c8f-8bff-c86d5228ff55	51995bde-3a0f-4f1b-828d-1bb06094b115	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	cancelada	Perdeu a força e está saindo fumaça 	\N	Sinal 250,00\nNão fez Levou 12/08	\N	90	2026-08-05	\N	2026-08-05 12:23:13.048116+00	2026-08-12 17:49:03.516+00	\N	\N	\N
a49da342-6461-406e-bc1b-2ba38afbd9b1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	70	6abd1720-bcbc-4a30-9d39-6a3fd2122e7c	5a881071-7df4-475d-b52a-6ae65e436697	6da88878-0303-4aac-941c-24b9622d20b8	entregue	Parou	Martelete na maleta 	Pagamento do serviço 10/08	\N	90	2026-08-05	\N	2026-08-05 11:58:27.408286+00	2026-08-10 19:18:07.719+00	\N	\N	\N
5aec6958-f2ca-4741-b9af-b62a7b30ff22	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	73	5a6976ee-6988-4a2d-9783-abef84c22375	55ec651d-7359-4a0c-b8ff-556964070e73	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aprovada	\N	\N	Sinal 170,00	\N	90	2026-08-05	\N	2026-08-05 19:28:59.642895+00	2026-08-10 20:51:11.579+00	\N	73	A
d6203891-0b9f-40e1-86dc-0f8db172de97	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	87	803f2cee-aebd-43ef-802b-fbc729089cba	6b4a1843-d64f-473e-9ac8-f83844059d5c	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aprovada	Caiu acido na máquina 	\N	\N	\N	90	2026-08-07	\N	2026-08-07 20:48:18.926249+00	2026-08-08 12:56:19.581+00	\N	\N	\N
1a6c2039-a147-4f35-bf97-43c41d34c125	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	88	803f2cee-aebd-43ef-802b-fbc729089cba	6b4a1843-d64f-473e-9ac8-f83844059d5c	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Caiu ácido na máquina (com bateria)	\N	Pagamento 08/08	\N	90	2026-08-07	\N	2026-08-07 20:48:27.781788+00	2026-08-08 18:49:28.163+00	\N	\N	\N
123e91d2-e036-4a74-80eb-03037134ded8	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	89	4523c826-c75e-469c-9c1c-f8363b8d1399	a61ac08e-6337-413c-8ce2-afbd07151449	6da88878-0303-4aac-941c-24b9622d20b8	aguardando_peca	A máquina está faltando peça 	\N	Pagamento total 07/08	\N	90	2026-08-07	\N	2026-08-07 21:30:26.678683+00	2026-08-07 21:38:03.222+00	\N	89	C
567dcee6-143f-48d9-bfae-660625d76d0c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	89	4523c826-c75e-469c-9c1c-f8363b8d1399	6427a22e-d5e3-4ea8-8244-dc70951dd495	6da88878-0303-4aac-941c-24b9622d20b8	aguardando_peca	\N	\N	Pagamento total 07/08	\N	90	2026-08-07	\N	2026-08-07 21:35:45.481664+00	2026-08-07 21:38:41.693+00	\N	89	D
dbd9dc06-f8cf-46de-b788-87e343fc06f4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	89	4523c826-c75e-469c-9c1c-f8363b8d1399	3eafeed1-38fd-423f-825a-24a1e4468186	6da88878-0303-4aac-941c-24b9622d20b8	aguardando_peca	A máquina está fraca.	\N	Pagou o total 07/08	\N	90	2026-08-07	\N	2026-08-07 21:24:56.717884+00	2026-08-07 21:37:00.695+00	\N	89	A
ea7fcdf0-e497-432f-99de-8ca7148cdc14	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	85	6339933e-c4ea-4872-aa2c-d994b9ce3584	9556964e-dc3b-4734-b5e0-068dc8006873	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Não liga	Sinal para a realização do serviço: R$300,00/ Pagamento do sinal 05/08	Os. modelo antigo 2307	\N	90	2026-08-07	\N	2026-08-07 17:37:48.899892+00	2026-08-10 19:04:18.465+00	\N	\N	\N
6aa1e6dd-5d8b-41db-b304-021f5704f42d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	76	b727602c-6f4b-4320-88cb-2a2f2257224d	376cd1ed-1d84-42ff-95fe-0791d970377d	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aprovada	Travando e com a placa do martelete solta.	\N	Colocamos a chapa do martelete que estava solta.	\N	90	2026-08-06	\N	2026-08-06 18:28:34.506253+00	2026-08-08 13:30:45.91+00	\N	\N	\N
3f1d2bc3-c377-4a8d-ad9e-e543339b4744	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	73	5a6976ee-6988-4a2d-9783-abef84c22375	2c652e3a-9c45-4169-833d-f969842f6a86	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aprovada	\N	\N	Sinal 200,00	\N	90	2026-08-05	\N	2026-08-05 19:33:42.448054+00	2026-08-10 20:53:24.275+00	\N	73	B
b92f8c34-09d1-4098-9e39-63db4edea838	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	73	5a6976ee-6988-4a2d-9783-abef84c22375	94094687-8948-4615-b12b-a84501d852f3	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aprovada	\N	\N	Sinal 40,00	\N	90	2026-08-05	\N	2026-08-05 19:33:52.617509+00	2026-08-10 20:55:26.859+00	\N	73	C
4132b3d0-f242-4523-a898-0d420536dd1a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	73	5a6976ee-6988-4a2d-9783-abef84c22375	fc6e07b8-9a09-4996-9c93-6afa5a1313ee	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aprovada	\N	\N	Sinal 200,00	\N	90	2026-08-05	\N	2026-08-05 19:34:11.423682+00	2026-08-10 20:57:31.501+00	\N	73	D
79b831c3-35f3-4dac-90fc-d007178e7cb9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	81	58e98858-df83-4786-840a-9f17793767a9	e4fc453b-ce70-4fc1-9ba4-186d9202d582	6da88878-0303-4aac-941c-24b9622d20b8	concluida	fazer revisão 	\N	\N	\N	90	2026-08-07	2026-08-11	2026-08-07 13:19:15.639787+00	2026-08-11 13:48:03.942+00	\N	81	A
21029924-8440-46d5-a475-9a3f3d2da8f2	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	79	286cc1b2-56e9-4f30-a86a-180f5f76f679	5f3353b3-d137-4567-adc8-88683d7b3c32	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Fechou curto no cabo.	\N	Pagamento dia 12/08	\N	90	2026-08-06	2026-08-11	2026-08-06 19:30:08.5646+00	2026-08-12 20:17:39.514+00	\N	\N	\N
f6b14792-18a5-4052-b505-e11dd498525f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	72	7c0d2ac4-9c4a-42fc-ad9a-589351fe76cf	3d5318f5-7b66-4f9a-a65e-2847c2854a93	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	A máquina fica fraca quando aciona o gatilho. 	\N	Sinal 150,00 Pagamento do sinal 07/08	\N	90	2026-08-05	2026-08-15	2026-08-05 14:35:14.530917+00	2026-08-15 14:51:18.487+00	\N	\N	\N
b34d4433-cf80-4c46-84f5-8bc7a058d891	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	77	6773f1ca-eca1-4b81-af32-0cd378e46029	6850d938-e5bd-4af2-9624-73f179a4ad34	db2355b2-9927-449b-97fb-7b95ccb5edb2	aprovada	Vazando água\nCom pistola s/ Bico	\N	Sinal 90,00	\N	90	2026-08-06	\N	2026-08-06 18:34:51.164061+00	2026-08-12 17:50:28.92+00	\N	\N	\N
6e6de9d2-ec95-460d-9477-c03bf7e9ece1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	84	2a65b2fb-d1db-46d3-a786-64fd38b7942f	a4499afb-3f75-41f0-9ec3-d05650b5e2e1	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Não liga, pode ser o carvão.	\N	Pagou levou 13/08	\N	90	2026-08-07	2026-08-12	2026-08-07 15:07:19.020643+00	2026-08-13 12:16:55.98+00	\N	\N	\N
61beb573-7765-402a-bfb6-bbf811badf63	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	82	61eb8a2d-5ea5-468d-a2e8-e99284504c62	71791cd2-377a-42af-86be-3b376d125298	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aberta	A máquina está falhando, fica oscilando a velocidade. 	Sinal: 180,00	\N	\N	90	2026-08-07	\N	2026-08-07 13:36:36.570138+00	2026-08-12 20:26:25.162+00	\N	\N	\N
8e5d4e91-bdc6-4ba6-ba6d-910203762ed4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	89	4523c826-c75e-469c-9c1c-f8363b8d1399	0eda729c-8866-4151-b035-e5d9bca461b8	6da88878-0303-4aac-941c-24b9622d20b8	aguardando_peca	O botão não trava.	\N	Pagamento total 07/08	\N	90	2026-08-07	\N	2026-08-07 21:27:03.454614+00	2026-08-07 21:37:34.358+00	\N	89	B
bee121ca-1615-4258-9bf1-e0493ce7dfe6	c8659485-b234-4723-9681-1e71ee94ac3b	37	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	7bd8a5cb-75e9-44bf-bf0f-9d0bf7939369	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-04-23	2026-04-26	2026-04-23 03:00:00+00	2026-04-26 03:00:00+00	\N	\N	\N
fbbcf1e8-b14b-45d0-87e5-e822e021ee35	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	93	7a400294-a24d-4af7-865c-98471e92dfef	7c2ecabc-6f5e-4890-8fa7-a0aa1e34d36d	6da88878-0303-4aac-941c-24b9622d20b8	aprovada	Só funciona para um lado.	\N	SINAL: 50,00	\N	90	2026-08-10	\N	2026-08-10 11:56:52.065083+00	2026-08-14 12:59:25.989+00	\N	93	B
856dbff9-be5b-4198-b72f-aae3c4bbd50f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	91	12f0a5b3-e339-4cb1-8515-765765433e0f	4846473f-40a0-4de3-a6d7-a51e54df2e96	6da88878-0303-4aac-941c-24b9622d20b8	aprovada	O capacitor estourou, só colocar o compressor pra funcionar.	Sinal 140,00	\N	\N	90	2026-08-08	\N	2026-08-08 13:47:59.913438+00	2026-08-10 12:50:06.717+00	\N	\N	\N
7cd9933d-759f-49b7-8bd6-c1f10a7ee4a9	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	93	7a400294-a24d-4af7-865c-98471e92dfef	305bbe90-33f7-46fb-9c0c-3218c1257ba0	6da88878-0303-4aac-941c-24b9622d20b8	aprovada	Parou de funcionar.	\N	SINAL: 540,00	\N	90	2026-08-10	\N	2026-08-10 11:50:03.383917+00	2026-08-14 12:58:47.854+00	\N	93	A
9ca5c21f-b07e-4411-b50b-b53d2f9f034b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	75	0c1dd29e-f9de-400e-8a38-2f892eb5ff47	ddd0dfeb-d439-484b-8cb6-4e962a0b9149	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	A máquina está fazendo barulho de engrenagem.	\N	Sinal para a realização do serviço: 160,00 / Pagamento do sinal 06/08 ok!\nResta 130,00 / Pagamento do restante 12/08 (levou)	\N	90	2026-07-21	2026-08-10	2026-08-06 13:12:57.039139+00	2026-08-12 15:48:53.572+00	\N	\N	\N
51a9ca1a-a2b1-47b0-9074-d41cb3699700	c8659485-b234-4723-9681-1e71ee94ac3b	21	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	c68d9901-89e6-457f-a65b-9b4341f76af4	735e3c04-3492-4cd8-ae5d-9905053551f3	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-03-02	2026-03-06	2026-03-02 03:00:00+00	2026-03-06 03:00:00+00	\N	\N	\N
9fe59675-13c8-4715-a375-ee2a3474c197	c8659485-b234-4723-9681-1e71ee94ac3b	22	32179aea-8524-4cfd-a67d-51c69bd54f4b	953d6e02-30ac-4d4f-b137-1df5dfc31360	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-03-24	2026-03-26	2026-03-24 03:00:00+00	2026-03-26 03:00:00+00	\N	\N	\N
29a209cc-9105-4667-9ff6-1471676e55f5	c8659485-b234-4723-9681-1e71ee94ac3b	23	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	6e43aed4-21b9-40d6-a12f-d9ae29dd4c9a	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-03-23	2026-03-28	2026-03-23 03:00:00+00	2026-03-28 03:00:00+00	\N	\N	\N
9ddfa3c1-f53a-4ef6-8c54-3f52cbd4ff54	c8659485-b234-4723-9681-1e71ee94ac3b	24	736ba25f-7c54-4d0d-b03b-2dd93402521b	6ae0b552-d6c5-4217-b237-1075eb4eebd9	e5012518-7b2d-4424-b07c-227c8116915f	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-03-06	2026-03-08	2026-03-06 03:00:00+00	2026-03-08 03:00:00+00	\N	\N	\N
b4a1c8f8-0b87-40ef-b56b-e913863fae10	c8659485-b234-4723-9681-1e71ee94ac3b	25	42797565-96e1-4694-8895-b3fc6eb607c2	f7f2b2d8-4525-4ea7-888b-729b05d2e052	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-03-06	2026-03-07	2026-03-06 03:00:00+00	2026-03-07 03:00:00+00	\N	\N	\N
810f9355-9a30-4341-9be2-dea58d620b1e	c8659485-b234-4723-9681-1e71ee94ac3b	26	d8c8fc87-860f-45fe-8990-6fef1a273bc9	6445ba31-3404-401a-971f-b552843ac4a5	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-03-23	2026-03-26	2026-03-23 03:00:00+00	2026-03-26 03:00:00+00	\N	\N	\N
88c6f402-b63c-4633-8132-df90e7300e98	c8659485-b234-4723-9681-1e71ee94ac3b	27	32179aea-8524-4cfd-a67d-51c69bd54f4b	b5725a1a-f1ac-4748-8f80-7befec3ccd25	735e3c04-3492-4cd8-ae5d-9905053551f3	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-03-26	2026-03-30	2026-03-26 03:00:00+00	2026-03-30 03:00:00+00	\N	\N	\N
da4f1af4-1db2-4f06-8c73-9aaf955f0c0b	c8659485-b234-4723-9681-1e71ee94ac3b	28	0a80a79f-aaf2-4636-bf71-9306ff16b44d	205d8183-ac58-4a98-aa9d-1d9244f930b8	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-03-07	2026-03-12	2026-03-07 03:00:00+00	2026-03-12 03:00:00+00	\N	\N	\N
fad3ef69-763f-4f53-b397-f9aad766444e	c8659485-b234-4723-9681-1e71ee94ac3b	29	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	caccf019-94db-4eff-99fe-208115710ced	e5012518-7b2d-4424-b07c-227c8116915f	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-03-07	2026-03-11	2026-03-07 03:00:00+00	2026-03-11 03:00:00+00	\N	\N	\N
d096696c-7fed-48ce-8551-ddd3e00492f1	c8659485-b234-4723-9681-1e71ee94ac3b	30	736ba25f-7c54-4d0d-b03b-2dd93402521b	40631c34-f4d6-4afb-8dd5-7922b089a66e	735e3c04-3492-4cd8-ae5d-9905053551f3	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-04-24	2026-04-25	2026-04-24 03:00:00+00	2026-04-25 03:00:00+00	\N	\N	\N
0d9bbd5a-00e9-4c85-921d-8f15b7656446	c8659485-b234-4723-9681-1e71ee94ac3b	31	42797565-96e1-4694-8895-b3fc6eb607c2	068f897b-5ea9-4a32-83dc-8579382e62f7	735e3c04-3492-4cd8-ae5d-9905053551f3	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-04-02	2026-04-03	2026-04-02 03:00:00+00	2026-04-03 03:00:00+00	\N	\N	\N
b82bf7db-c761-4e5f-b5b1-f59220b28de6	c8659485-b234-4723-9681-1e71ee94ac3b	32	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	6d45e8b4-03d7-450f-bb47-47263b46be9d	e5012518-7b2d-4424-b07c-227c8116915f	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-04-06	2026-04-07	2026-04-06 03:00:00+00	2026-04-07 03:00:00+00	\N	\N	\N
de499168-c315-4356-a758-0731795aabc2	c8659485-b234-4723-9681-1e71ee94ac3b	33	32179aea-8524-4cfd-a67d-51c69bd54f4b	e15845b4-cc3c-489e-bb69-c1af1463f985	735e3c04-3492-4cd8-ae5d-9905053551f3	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-04-09	2026-04-11	2026-04-09 03:00:00+00	2026-04-11 03:00:00+00	\N	\N	\N
1a3da2df-e597-46e9-a065-387c132ece30	c8659485-b234-4723-9681-1e71ee94ac3b	34	736ba25f-7c54-4d0d-b03b-2dd93402521b	590f74fd-e51f-4916-908d-7dfac210b95a	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-04-14	2026-04-16	2026-04-14 03:00:00+00	2026-04-16 03:00:00+00	\N	\N	\N
943fe26d-2539-4187-997a-6e463589a93b	c8659485-b234-4723-9681-1e71ee94ac3b	35	d8c8fc87-860f-45fe-8990-6fef1a273bc9	2dca6048-f431-4306-8a0d-f435c200b059	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-04-13	2026-04-18	2026-04-13 03:00:00+00	2026-04-18 03:00:00+00	\N	\N	\N
42454d56-dbde-4590-b10c-525d58e1509f	c8659485-b234-4723-9681-1e71ee94ac3b	36	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	0b5d439a-a2b3-47f3-8b5a-5fd7e79f9828	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-04-16	2026-04-21	2026-04-16 03:00:00+00	2026-04-21 03:00:00+00	\N	\N	\N
89fe2f06-a083-4ecc-9ac1-0aeb6bf2d8a9	c8659485-b234-4723-9681-1e71ee94ac3b	38	736ba25f-7c54-4d0d-b03b-2dd93402521b	372d2f63-9b4a-4e5a-8980-f48bfb3424c7	e5012518-7b2d-4424-b07c-227c8116915f	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-04-03	2026-04-06	2026-04-03 03:00:00+00	2026-04-06 03:00:00+00	\N	\N	\N
a95f2d60-48a5-488d-bf8d-2af4bf946a57	c8659485-b234-4723-9681-1e71ee94ac3b	39	d8c8fc87-860f-45fe-8990-6fef1a273bc9	3753b830-24dc-4e8b-9113-9187e2930e0e	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-04-23	2026-04-24	2026-04-23 03:00:00+00	2026-04-24 03:00:00+00	\N	\N	\N
f50d5253-b308-49f1-9beb-12d833787cbc	c8659485-b234-4723-9681-1e71ee94ac3b	40	42797565-96e1-4694-8895-b3fc6eb607c2	0719e452-dbf4-4ede-a0c5-ca7251498955	735e3c04-3492-4cd8-ae5d-9905053551f3	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-05-11	2026-05-16	2026-05-11 03:00:00+00	2026-05-16 03:00:00+00	\N	\N	\N
4e0e9597-227f-4767-b00f-e4f8fd44c4d4	c8659485-b234-4723-9681-1e71ee94ac3b	41	0a80a79f-aaf2-4636-bf71-9306ff16b44d	cd9ae78f-f8bb-401e-9797-cfc796e1b8dc	e5012518-7b2d-4424-b07c-227c8116915f	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-05-12	2026-05-14	2026-05-12 03:00:00+00	2026-05-14 03:00:00+00	\N	\N	\N
1b983341-a023-4eee-b592-3424994625ab	c8659485-b234-4723-9681-1e71ee94ac3b	42	32179aea-8524-4cfd-a67d-51c69bd54f4b	4431b825-d29a-4c70-bf4d-a0591fef545c	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-05-02	2026-05-06	2026-05-02 03:00:00+00	2026-05-06 03:00:00+00	\N	\N	\N
9d465184-61d5-4a04-92e6-740108075bd1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	90	d7df166d-9b91-4bdb-a519-416da5749d53	0a6c48f4-b1d2-4447-a36f-b832e176e035	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aprovada	Faz Barulho e perdeu os parafusos 	\N	Sinal 70,00	\N	90	2026-08-08	\N	2026-08-08 13:16:10.798723+00	2026-08-12 16:03:15.157+00	\N	\N	\N
84a28741-ae5b-49b0-ad98-dea98d166fb0	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	95	234e738c-9db5-4494-a7a6-cca5e0357ee1	1a411b38-283d-4e74-9f0e-37d866b0b999	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aprovada	Cheiro de Queimado 	A máquina está fora de linha, Não tem peças para reposição	\N	\N	90	2026-08-10	\N	2026-08-10 18:03:49.486843+00	2026-08-12 20:48:13.418+00	\N	\N	\N
1a8c3fc7-5cfd-4d0f-8965-df6471a63397	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	96	89c8d185-2089-42f1-99e2-cc516300e786	d2ffafdf-834d-4519-9272-0cd6e7cd837e	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Não está saindo água, pouca pressão 	\N	Não tem peça. Levou 13/08	\N	90	2026-08-10	\N	2026-08-10 19:29:49.543929+00	2026-08-13 19:58:34.821+00	\N	\N	\N
3fc68377-9ce2-487d-80a6-9da4e5a59cb1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	93	7a400294-a24d-4af7-865c-98471e92dfef	189030c4-b419-41e5-b28c-e7a3064ae8e5	6da88878-0303-4aac-941c-24b9622d20b8	aprovada	Fazendo barulho	\N	\N	\N	90	2026-08-10	\N	2026-08-10 11:59:18.353018+00	2026-08-14 12:59:06.855+00	\N	93	C
dc30bf50-4e58-46ca-923d-18e8f14e8c79	c8659485-b234-4723-9681-1e71ee94ac3b	43	f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	f90e51e7-e2df-4b92-bd8d-9ada80608f56	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-05-15	2026-05-16	2026-05-15 03:00:00+00	2026-05-16 03:00:00+00	\N	\N	\N
95be6da7-1510-4901-86a0-cb728d0ed946	c8659485-b234-4723-9681-1e71ee94ac3b	44	736ba25f-7c54-4d0d-b03b-2dd93402521b	8e3f3f99-87a5-47c8-8b8e-3ba84aeced98	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-05-04	2026-05-07	2026-05-04 03:00:00+00	2026-05-07 03:00:00+00	\N	\N	\N
95a10675-96ca-46cf-b9ad-0f47101ec6c6	c8659485-b234-4723-9681-1e71ee94ac3b	45	32179aea-8524-4cfd-a67d-51c69bd54f4b	92132e62-d235-4536-86d2-04129f25d113	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-05-24	2026-05-26	2026-05-24 03:00:00+00	2026-05-26 03:00:00+00	\N	\N	\N
ea47a878-b9f8-44c9-97a6-a38381409a77	c8659485-b234-4723-9681-1e71ee94ac3b	46	d8c8fc87-860f-45fe-8990-6fef1a273bc9	c634a416-32aa-4778-b239-f4a56d33cba4	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-05-06	2026-05-10	2026-05-06 03:00:00+00	2026-05-10 03:00:00+00	\N	\N	\N
1c020be7-5a7e-43a5-9627-f0dd90bdcc98	c8659485-b234-4723-9681-1e71ee94ac3b	47	f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	166b3791-a5c5-43fa-b331-fd545423c970	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-05-13	2026-05-17	2026-05-13 03:00:00+00	2026-05-17 03:00:00+00	\N	\N	\N
756cf93f-4b6c-4d04-8ef3-01235ccafe72	c8659485-b234-4723-9681-1e71ee94ac3b	48	d8c8fc87-860f-45fe-8990-6fef1a273bc9	b1a0bfb0-547a-426d-9e45-6080e7581998	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-05-05	2026-05-10	2026-05-05 03:00:00+00	2026-05-10 03:00:00+00	\N	\N	\N
50b92f0d-cfce-4c8f-a12b-26bda9d446fe	c8659485-b234-4723-9681-1e71ee94ac3b	49	f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	8d86fb4e-573d-4e94-bf50-7c91a6aa95ab	e5012518-7b2d-4424-b07c-227c8116915f	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-05-01	2026-05-06	2026-05-01 03:00:00+00	2026-05-06 03:00:00+00	\N	\N	\N
49dba099-05dd-4c7a-9a82-2d0d941e73ee	c8659485-b234-4723-9681-1e71ee94ac3b	50	0a80a79f-aaf2-4636-bf71-9306ff16b44d	1b7ff083-9cb9-4a42-b157-9fd3f8b0f2be	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-05-05	2026-05-07	2026-05-05 03:00:00+00	2026-05-07 03:00:00+00	\N	\N	\N
8904ed70-8843-48e5-81cb-d5d1bd504cc1	c8659485-b234-4723-9681-1e71ee94ac3b	51	42797565-96e1-4694-8895-b3fc6eb607c2	76be6a4b-28a5-4320-9308-a739321f876c	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-05-01	2026-05-02	2026-05-01 03:00:00+00	2026-05-02 03:00:00+00	\N	\N	\N
f7895c42-8898-45fa-babe-96f0586119e5	c8659485-b234-4723-9681-1e71ee94ac3b	52	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	2c38e979-0ed7-4b98-9532-74088bbb006c	e5012518-7b2d-4424-b07c-227c8116915f	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-06-01	2026-06-04	2026-06-01 03:00:00+00	2026-06-04 03:00:00+00	\N	\N	\N
29d9cf64-f9b6-4cd2-b384-75cb9e7be7c1	c8659485-b234-4723-9681-1e71ee94ac3b	53	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	9665cc01-ce61-446c-a52b-1521d9c60b5c	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-06-16	2026-06-19	2026-06-16 03:00:00+00	2026-06-19 03:00:00+00	\N	\N	\N
3fe6b966-5518-4221-a9b7-0cd45a7d327e	c8659485-b234-4723-9681-1e71ee94ac3b	54	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	c9343865-d171-43ad-b533-4ebb659ea615	e5012518-7b2d-4424-b07c-227c8116915f	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-06-22	2026-06-25	2026-06-22 03:00:00+00	2026-06-25 03:00:00+00	\N	\N	\N
b2e09e97-08e8-4c58-9dfe-f2747a778949	c8659485-b234-4723-9681-1e71ee94ac3b	55	736ba25f-7c54-4d0d-b03b-2dd93402521b	e9571521-3ec4-45ac-8e02-40d00769c1e2	e5012518-7b2d-4424-b07c-227c8116915f	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-06-21	2026-06-23	2026-06-21 03:00:00+00	2026-06-23 03:00:00+00	\N	\N	\N
23629eeb-6ad8-4c60-832e-66527adafa81	c8659485-b234-4723-9681-1e71ee94ac3b	56	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	876dd5a3-2b34-47d9-aaa7-89cdd17bcf40	735e3c04-3492-4cd8-ae5d-9905053551f3	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-06-23	2026-06-26	2026-06-23 03:00:00+00	2026-06-26 03:00:00+00	\N	\N	\N
6279de65-6f15-4729-9ff1-03cffb2b3a00	c8659485-b234-4723-9681-1e71ee94ac3b	57	0a80a79f-aaf2-4636-bf71-9306ff16b44d	eb21952f-f046-433b-a30b-1c49047aee3d	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-06-23	2026-06-25	2026-06-23 03:00:00+00	2026-06-25 03:00:00+00	\N	\N	\N
b0af6776-722d-465e-ac4b-13f585e0a90d	c8659485-b234-4723-9681-1e71ee94ac3b	58	32179aea-8524-4cfd-a67d-51c69bd54f4b	5a32982a-31d0-42fb-8eea-b35d1c43e41d	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-06-07	2026-06-10	2026-06-07 03:00:00+00	2026-06-10 03:00:00+00	\N	\N	\N
74a971b7-3148-4dcd-9688-408d9e306a87	c8659485-b234-4723-9681-1e71ee94ac3b	59	42797565-96e1-4694-8895-b3fc6eb607c2	85495e90-12c1-496b-ba28-fed7d66ab2c2	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-06-13	2026-06-18	2026-06-13 03:00:00+00	2026-06-18 03:00:00+00	\N	\N	\N
cbfcdc02-113f-4d3b-b479-3468036a1b38	c8659485-b234-4723-9681-1e71ee94ac3b	60	32179aea-8524-4cfd-a67d-51c69bd54f4b	668a4476-9b23-4677-8e08-9e7af96587cf	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-06-09	2026-06-14	2026-06-09 03:00:00+00	2026-06-14 03:00:00+00	\N	\N	\N
77fd8063-6848-4557-8db8-b48bcdf7a41c	c8659485-b234-4723-9681-1e71ee94ac3b	61	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	006b5260-216c-4e25-be14-0ed60d31cd27	735e3c04-3492-4cd8-ae5d-9905053551f3	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-06-24	2026-06-27	2026-06-24 03:00:00+00	2026-06-27 03:00:00+00	\N	\N	\N
7f7bc86a-42a7-4d71-b3f8-e52c3fd6ce9b	c8659485-b234-4723-9681-1e71ee94ac3b	62	d8c8fc87-860f-45fe-8990-6fef1a273bc9	9e589808-96e8-4974-9ea4-602f1d51f73e	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-06-22	2026-06-24	2026-06-22 03:00:00+00	2026-06-24 03:00:00+00	\N	\N	\N
a7e9d51d-647b-4b64-a678-2e5d2ed4df1e	c8659485-b234-4723-9681-1e71ee94ac3b	63	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	fc0c83f7-f506-41a7-b45c-5e3738bc4118	735e3c04-3492-4cd8-ae5d-9905053551f3	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-06-01	2026-06-03	2026-06-01 03:00:00+00	2026-06-03 03:00:00+00	\N	\N	\N
bd8001eb-c8cf-4d63-8035-d25f299fa558	c8659485-b234-4723-9681-1e71ee94ac3b	64	d8c8fc87-860f-45fe-8990-6fef1a273bc9	54ab213d-8e1d-436f-885d-33087ebe4cd2	e5012518-7b2d-4424-b07c-227c8116915f	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-06-24	2026-06-26	2026-06-24 03:00:00+00	2026-06-26 03:00:00+00	\N	\N	\N
360d5fe6-4861-47d7-a99e-61f8fff0bd8d	c8659485-b234-4723-9681-1e71ee94ac3b	65	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	eee8adcf-0f8f-4a55-909c-49a153689b79	735e3c04-3492-4cd8-ae5d-9905053551f3	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-06-13	2026-06-18	2026-06-13 03:00:00+00	2026-06-18 03:00:00+00	\N	\N	\N
3d2abc1e-792d-4d09-a9c7-1a95a3b837d5	c8659485-b234-4723-9681-1e71ee94ac3b	66	f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	1c529ffe-a0cc-404a-9f5a-22f9a83207ba	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-06-19	2026-06-24	2026-06-19 03:00:00+00	2026-06-24 03:00:00+00	\N	\N	\N
888445a4-79fe-499a-8ffe-65eed2291bae	c8659485-b234-4723-9681-1e71ee94ac3b	67	d8c8fc87-860f-45fe-8990-6fef1a273bc9	fa2059be-ccff-41d3-b359-91041db43659	e5012518-7b2d-4424-b07c-227c8116915f	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-07-04	2026-07-07	2026-07-04 03:00:00+00	2026-07-07 03:00:00+00	\N	\N	\N
fddb8612-f0fe-406e-87ef-7bbc4fa6304b	c8659485-b234-4723-9681-1e71ee94ac3b	68	f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	e8ee9df9-f323-451d-b783-6a5d71188603	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-07-01	2026-07-04	2026-07-01 03:00:00+00	2026-07-04 03:00:00+00	\N	\N	\N
b11216ac-edbb-443a-88b3-474e085861a3	c8659485-b234-4723-9681-1e71ee94ac3b	69	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	e7dbda74-6707-4cf6-8fd8-fb59ce0a6b84	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-07-22	2026-07-26	2026-07-22 03:00:00+00	2026-07-26 03:00:00+00	\N	\N	\N
f7b8e3bd-ac9f-4025-8816-f7a6db6af099	c8659485-b234-4723-9681-1e71ee94ac3b	70	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	27ec16de-bf18-4270-a931-6386e0e15abb	735e3c04-3492-4cd8-ae5d-9905053551f3	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-07-13	2026-07-18	2026-07-13 03:00:00+00	2026-07-18 03:00:00+00	\N	\N	\N
e0d0d8a8-5833-4b1e-acae-10f6edf112bb	c8659485-b234-4723-9681-1e71ee94ac3b	71	f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	d054b32a-2f94-4f67-a98e-80a4e7226699	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-07-12	2026-07-13	2026-07-12 03:00:00+00	2026-07-13 03:00:00+00	\N	\N	\N
87ea9a8b-c7b2-4ed3-a4d4-8598a3c39761	c8659485-b234-4723-9681-1e71ee94ac3b	72	736ba25f-7c54-4d0d-b03b-2dd93402521b	3c5ab9f5-8181-456a-b73b-5e7b01b95310	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-07-23	2026-07-27	2026-07-23 03:00:00+00	2026-07-27 03:00:00+00	\N	\N	\N
03e11d3f-6b5d-4bd1-b82a-4eca2ebdc3e9	c8659485-b234-4723-9681-1e71ee94ac3b	73	32179aea-8524-4cfd-a67d-51c69bd54f4b	c00d9fc7-eefe-4753-a436-e8592e5b2ca2	e5012518-7b2d-4424-b07c-227c8116915f	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-07-06	2026-07-10	2026-07-06 03:00:00+00	2026-07-10 03:00:00+00	\N	\N	\N
cba35c22-d33b-4367-abe9-6e4b763fe646	c8659485-b234-4723-9681-1e71ee94ac3b	74	0a80a79f-aaf2-4636-bf71-9306ff16b44d	c01b75ff-66fc-404e-9712-dca2b5b6248d	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-07-16	2026-07-17	2026-07-16 03:00:00+00	2026-07-17 03:00:00+00	\N	\N	\N
11dd60b9-6272-4242-8eff-cddf50bfbec2	c8659485-b234-4723-9681-1e71ee94ac3b	75	736ba25f-7c54-4d0d-b03b-2dd93402521b	a8d59778-b4c5-477b-a7f1-2d027211df5f	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-07-01	2026-07-02	2026-07-01 03:00:00+00	2026-07-02 03:00:00+00	\N	\N	\N
54f22d1d-5bc4-4444-9bd2-c2f0c2baffbf	c8659485-b234-4723-9681-1e71ee94ac3b	76	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	cc125347-3437-4101-83a8-86cd1236bed0	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-07-10	2026-07-13	2026-07-10 03:00:00+00	2026-07-13 03:00:00+00	\N	\N	\N
d57f788e-d5e0-44e5-976e-14beec9470b3	c8659485-b234-4723-9681-1e71ee94ac3b	77	0a80a79f-aaf2-4636-bf71-9306ff16b44d	469d3df9-5754-46e8-b699-d9a42d0b3c36	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-07-02	2026-07-06	2026-07-02 03:00:00+00	2026-07-06 03:00:00+00	\N	\N	\N
c791892f-b4ab-4fd0-857f-154c0bd24544	c8659485-b234-4723-9681-1e71ee94ac3b	78	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	fe218a7b-db85-4130-8c44-3cb12f4ac9ae	e5012518-7b2d-4424-b07c-227c8116915f	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-07-17	2026-07-20	2026-07-17 03:00:00+00	2026-07-20 03:00:00+00	\N	\N	\N
acfe2d4f-2a1f-473d-9ffc-29d95321bd0f	c8659485-b234-4723-9681-1e71ee94ac3b	79	d8c8fc87-860f-45fe-8990-6fef1a273bc9	b556210b-fa4e-486a-b088-6baa2253bbee	e5012518-7b2d-4424-b07c-227c8116915f	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-07-11	2026-07-14	2026-07-11 03:00:00+00	2026-07-14 03:00:00+00	\N	\N	\N
796c58be-e51c-452d-856a-2e7998fdde21	c8659485-b234-4723-9681-1e71ee94ac3b	80	736ba25f-7c54-4d0d-b03b-2dd93402521b	c8794136-0da0-4df4-b8ab-be6556ff3950	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-07-06	2026-07-08	2026-07-06 03:00:00+00	2026-07-08 03:00:00+00	\N	\N	\N
d0839179-929e-4ea0-a45f-9495b10ae3d0	c8659485-b234-4723-9681-1e71ee94ac3b	81	f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	55ceb396-a02f-4455-8616-050afb1091f5	e5012518-7b2d-4424-b07c-227c8116915f	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-07-20	2026-07-23	2026-07-20 03:00:00+00	2026-07-23 03:00:00+00	\N	\N	\N
11c627d8-314c-4d2c-909d-fa38770bf1f0	c8659485-b234-4723-9681-1e71ee94ac3b	82	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	7ae95b51-6dfe-4163-bbe2-9adfa5708508	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-07-26	2026-07-31	2026-07-26 03:00:00+00	2026-07-31 03:00:00+00	\N	\N	\N
136c57d8-a5d6-4afe-a9da-9bf8edd1f255	c8659485-b234-4723-9681-1e71ee94ac3b	83	32179aea-8524-4cfd-a67d-51c69bd54f4b	37295de0-1cbb-4304-8bb6-1a0667532d34	e5012518-7b2d-4424-b07c-227c8116915f	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-07-06	2026-07-07	2026-07-06 03:00:00+00	2026-07-07 03:00:00+00	\N	\N	\N
6eb2e31f-59f4-4df8-8ced-6fa1625044d0	c8659485-b234-4723-9681-1e71ee94ac3b	84	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	b747512a-8edd-4611-aa29-8178f534d915	e5012518-7b2d-4424-b07c-227c8116915f	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-08-19	2026-08-22	2026-08-19 03:00:00+00	2026-08-22 03:00:00+00	\N	\N	\N
9bae228a-8e38-4cda-b5e4-924c00dd27bc	c8659485-b234-4723-9681-1e71ee94ac3b	85	42797565-96e1-4694-8895-b3fc6eb607c2	1f89b449-c637-4266-97f9-14535b9e0b0e	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-08-25	2026-08-26	2026-08-25 03:00:00+00	2026-08-26 03:00:00+00	\N	\N	\N
4373d95f-491b-4076-9d7b-5efd64b3f358	c8659485-b234-4723-9681-1e71ee94ac3b	86	42797565-96e1-4694-8895-b3fc6eb607c2	c9681972-68ef-40b1-b3ad-e1b17ef8a7ce	e5012518-7b2d-4424-b07c-227c8116915f	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-08-15	2026-08-18	2026-08-15 03:00:00+00	2026-08-18 03:00:00+00	\N	\N	\N
8c2549b4-a4b1-4271-b31e-4f17663bbe86	c8659485-b234-4723-9681-1e71ee94ac3b	87	6f355cc8-ca21-4536-bdde-f9bc7bd2c5de	acb305b1-0ab9-4362-a8b4-d9dc378ee6ba	e5012518-7b2d-4424-b07c-227c8116915f	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-08-06	2026-08-08	2026-08-06 03:00:00+00	2026-08-08 03:00:00+00	\N	\N	\N
0c11123e-0597-46a4-84b4-9e1eb488614a	c8659485-b234-4723-9681-1e71ee94ac3b	88	736ba25f-7c54-4d0d-b03b-2dd93402521b	6897f548-763b-4e6f-9b93-c85204e1821e	735e3c04-3492-4cd8-ae5d-9905053551f3	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-08-10	2026-08-11	2026-08-10 03:00:00+00	2026-08-11 03:00:00+00	\N	\N	\N
6760b44e-e2f9-4ed2-b48b-25ffed0f7c43	c8659485-b234-4723-9681-1e71ee94ac3b	89	f015dc1b-3f95-43fc-8c16-b0d02eb1ebbf	144d34be-23d7-4959-bdf4-04ac46892853	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Débito	90	2026-08-10	2026-08-12	2026-08-10 03:00:00+00	2026-08-12 03:00:00+00	\N	\N	\N
efb73759-c46c-4f40-8820-ef69d7c813bc	c8659485-b234-4723-9681-1e71ee94ac3b	90	32179aea-8524-4cfd-a67d-51c69bd54f4b	45378a63-8317-441c-a6ee-59285f8aec3b	a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-08-21	2026-08-25	2026-08-21 03:00:00+00	2026-08-25 03:00:00+00	\N	\N	\N
f4b4aeee-f53a-4520-9d04-c7b5e71eb57d	c8659485-b234-4723-9681-1e71ee94ac3b	91	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	f211289c-615d-42f8-b18f-74ce116f5c9d	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-08-01	2026-08-04	2026-08-01 03:00:00+00	2026-08-04 03:00:00+00	\N	\N	\N
de60bd51-74b9-47dd-96f9-06d75846686f	c8659485-b234-4723-9681-1e71ee94ac3b	92	32179aea-8524-4cfd-a67d-51c69bd54f4b	ef906827-d600-4604-af32-2dca0c967fd4	735e3c04-3492-4cd8-ae5d-9905053551f3	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-08-07	2026-08-08	2026-08-07 03:00:00+00	2026-08-08 03:00:00+00	\N	\N	\N
b0c19aba-da24-4b8e-8426-0e8965902761	c8659485-b234-4723-9681-1e71ee94ac3b	93	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	67faa35e-a736-4897-ba39-70b3aa7079d6	c4c1038d-666f-4ad9-8db6-54e2fe4197ba	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-08-18	2026-08-21	2026-08-18 03:00:00+00	2026-08-21 03:00:00+00	\N	\N	\N
d5e4372b-33a2-4a6c-9bd4-0ea2ab6f94f6	c8659485-b234-4723-9681-1e71ee94ac3b	94	0a80a79f-aaf2-4636-bf71-9306ff16b44d	fd037b12-89b2-4f3f-84c2-f62b2dfd2b69	e5012518-7b2d-4424-b07c-227c8116915f	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Cartão Crédito	90	2026-08-02	2026-08-07	2026-08-02 03:00:00+00	2026-08-07 03:00:00+00	\N	\N	\N
76aaacea-06bd-4d3e-bf7e-796be405c72f	c8659485-b234-4723-9681-1e71ee94ac3b	95	42797565-96e1-4694-8895-b3fc6eb607c2	8584da1e-349d-4ff3-a040-c38ede7de70d	735e3c04-3492-4cd8-ae5d-9905053551f3	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-08-14	2026-08-19	2026-08-14 03:00:00+00	2026-08-19 03:00:00+00	\N	\N	\N
7c46fc3e-37c6-49b1-9d90-38642ed41336	c8659485-b234-4723-9681-1e71ee94ac3b	96	3ae60d4b-e3ee-4b45-a15b-c3081e3c6f9d	391b7bd2-f168-4f3b-9d76-d9812769be88	e5012518-7b2d-4424-b07c-227c8116915f	concluida	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-08-07	2026-08-08	2026-08-07 03:00:00+00	2026-08-08 03:00:00+00	\N	\N	\N
e1479a44-dc74-449f-b379-b31e55cc5b59	c8659485-b234-4723-9681-1e71ee94ac3b	97	0a80a79f-aaf2-4636-bf71-9306ff16b44d	1fa409f1-9127-4794-8d48-90d032394c2c	e5012518-7b2d-4424-b07c-227c8116915f	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	PIX	90	2026-08-20	2026-08-22	2026-08-20 03:00:00+00	2026-08-22 03:00:00+00	\N	\N	\N
02ff73d4-a8e3-4bd1-95ac-259164f5c3ed	c8659485-b234-4723-9681-1e71ee94ac3b	98	0a80a79f-aaf2-4636-bf71-9306ff16b44d	b6230951-64ed-4993-bde8-9e378940f690	e5012518-7b2d-4424-b07c-227c8116915f	entregue	Equipamento apresentando problema de funcionamento	Verificado e reparado com sucesso	\N	Dinheiro	90	2026-08-23	2026-08-24	2026-08-23 03:00:00+00	2026-08-24 03:00:00+00	\N	\N	\N
60648952-a439-4bb0-a1fe-75948d96f593	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	81	58e98858-df83-4786-840a-9f17793767a9	6f7c64f5-e0d4-4024-9cee-6237e482280d	6da88878-0303-4aac-941c-24b9622d20b8	concluida	\N	\N	\N	\N	90	2026-08-11	2026-08-11	2026-08-11 13:19:56.03517+00	2026-08-11 13:50:44.311+00	\N	81	E
0373a2d8-403f-410d-bd8f-141f80c718bb	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	81	58e98858-df83-4786-840a-9f17793767a9	4f9a268d-25f5-431e-a965-b97ea79a24c3	6da88878-0303-4aac-941c-24b9622d20b8	concluida	\N	\N	\N	\N	90	2026-08-11	2026-08-11	2026-08-11 13:15:40.316011+00	2026-08-11 13:40:24.257+00	\N	81	C
a86d9f4f-a662-4256-969b-cdfcebf0041f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	81	58e98858-df83-4786-840a-9f17793767a9	6f7c64f5-e0d4-4024-9cee-6237e482280d	6da88878-0303-4aac-941c-24b9622d20b8	concluida	\N	\N	\N	\N	90	2026-08-11	2026-08-11	2026-08-11 13:19:08.098401+00	2026-08-11 13:48:19.132+00	\N	81	D
cfc3b3df-ee8d-4a3b-b9f4-e87eb058d340	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	81	58e98858-df83-4786-840a-9f17793767a9	6f7c64f5-e0d4-4024-9cee-6237e482280d	6da88878-0303-4aac-941c-24b9622d20b8	concluida	Fazendo barulho	\N	\N	\N	90	2026-08-11	2026-08-11	2026-08-11 13:21:59.657103+00	2026-08-11 13:50:52.858+00	\N	81	F
e87b7620-bd83-445b-acac-34a21fe4e49f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	97	741641ea-2cc7-4213-9975-c6584bf9da43	795d3c37-a397-462c-9a20-754fd82190f9	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	concluida	Não faz o martelete 	\N	Sinal 100,00 ok 13/08	\N	90	2026-08-11	2026-08-18	2026-08-11 13:04:42.765236+00	2026-08-18 18:21:31.315+00	\N	\N	\N
c3615677-9763-4abd-96b2-d8d6e0b28502	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	81	58e98858-df83-4786-840a-9f17793767a9	6f7c64f5-e0d4-4024-9cee-6237e482280d	6da88878-0303-4aac-941c-24b9622d20b8	concluida	\N	\N	\N	\N	90	2026-08-11	2026-08-11	2026-08-11 13:27:24.301886+00	2026-08-11 13:51:17.499+00	\N	81	H
7f9710e3-5404-488d-906a-6a912b3815dd	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	81	58e98858-df83-4786-840a-9f17793767a9	6f7c64f5-e0d4-4024-9cee-6237e482280d	6da88878-0303-4aac-941c-24b9622d20b8	concluida	\N	Não precisou fazer a Limpeza.	\N	\N	90	2026-08-11	2026-08-11	2026-08-11 13:30:17.708066+00	2026-08-11 13:51:25.811+00	\N	81	I
9bc0dd11-bd8f-4390-9db8-ec942bf548a1	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	81	58e98858-df83-4786-840a-9f17793767a9	6f7c64f5-e0d4-4024-9cee-6237e482280d	6da88878-0303-4aac-941c-24b9622d20b8	concluida	Não lixa 	Sinal: 50,00	\N	\N	90	2026-08-11	2026-08-14	2026-08-11 13:23:46.663789+00	2026-08-14 17:46:07.247+00	\N	81	G
750714d0-23c8-44e8-8fd2-bb16fe2c53c6	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	81	58e98858-df83-4786-840a-9f17793767a9	2e7ca550-fda0-42c5-9f25-2b3792a0b264	6da88878-0303-4aac-941c-24b9622d20b8	concluida	Fazer uma revisão 	\N	\N	\N	90	2026-08-11	2026-08-11	2026-08-11 13:12:18.703255+00	2026-08-11 13:48:14.469+00	\N	81	B
dcff534b-0c32-4464-b55d-fdfba5d9a6e4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	86	04b89c89-6035-43e9-aac8-04962f87d879	4e4abec3-9523-469a-a59f-76776c9864fb	6da88878-0303-4aac-941c-24b9622d20b8	cancelada	Saiu Fumaça 	O motor entrou em curto. Não tem peça para reposição.	Não fez/Levou 13/08	\N	90	2026-08-07	\N	2026-08-07 18:54:06.800789+00	2026-08-13 18:33:07.402+00	\N	86	A
4e24e848-369c-47eb-b6da-4f27c4fdf90b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	81	58e98858-df83-4786-840a-9f17793767a9	6f7c64f5-e0d4-4024-9cee-6237e482280d	6da88878-0303-4aac-941c-24b9622d20b8	aberta	Não precisou Fazer a limpeza	\N	\N	\N	90	2026-08-11	\N	2026-08-11 13:48:44.358936+00	2026-08-11 13:49:43.634+00	2026-08-11 13:50:28.721+00	81	M
04e0d501-3f0c-4e28-a3a7-f09332ee837b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	81	58e98858-df83-4786-840a-9f17793767a9	6f7c64f5-e0d4-4024-9cee-6237e482280d	6da88878-0303-4aac-941c-24b9622d20b8	concluida	Fazendo barulho	\N	\N	\N	90	2026-08-11	2026-08-11	2026-08-11 13:33:14.293565+00	2026-08-11 13:51:42.476+00	\N	81	K
9cd3224c-ee86-4840-902b-3bbf485ee9d7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	81	58e98858-df83-4786-840a-9f17793767a9	6f7c64f5-e0d4-4024-9cee-6237e482280d	6da88878-0303-4aac-941c-24b9622d20b8	concluida	\N	Não precisou fazer a limpeza!	\N	\N	90	2026-08-11	2026-08-11	2026-08-11 13:35:57.145275+00	2026-08-11 13:51:48.865+00	\N	81	L
f9993808-c293-448c-be0a-8b1404a2a985	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	102	cdfc8003-9858-48dd-8092-5f757783a973	381ed16a-2718-4b1e-8992-1735870d2652	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	\N	\N	Sinal:600,00 Pagamento sinal dia 03/08 Pagamento do restante e retirada 17/08 ok!	\N	90	2026-08-12	\N	2026-08-12 12:53:29.592368+00	2026-08-17 15:17:14.926+00	\N	\N	\N
42fc3ba0-b108-4344-b813-47a27344719a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	92	bc3296ab-2800-49ff-82ae-3e18868b9b78	78ba74d5-77fb-467b-b698-51f95ce0e789	6da88878-0303-4aac-941c-24b9622d20b8	aprovada	Está fraco	O motor entrou em curto. sinal: 200,00	\N	\N	90	2026-08-08	\N	2026-08-08 14:34:18.911136+00	2026-08-12 13:51:12.22+00	\N	\N	\N
ef8ce2a7-dcaf-47af-a21f-3fd9e48b77f4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	112	f3e9be14-3b81-430d-be5f-2ad8c119921a	1d9c1b36-d5c6-44a8-adc9-04ea9f000d1e	db2355b2-9927-449b-97fb-7b95ccb5edb2	aberta	Sem pressão/Vazando água/As vezes não funciona/Ver a carcaça	\N	Sem Pistola 	\N	90	2026-08-13	\N	2026-08-13 20:15:22.156986+00	2026-08-13 20:17:38.105+00	\N	\N	\N
4e304a73-f1c4-40f7-8b50-112340ae8601	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	107	2a65b2fb-d1db-46d3-a786-64fd38b7942f	eaacf0fa-bdb2-4753-8b2d-2f4c8c518170	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aguardando_peca	Fazer uma revisão/estava parada (Com pistola completa)	\N	Sinal: 50,00 ok 18/08	\N	90	2026-08-13	\N	2026-08-13 12:14:43.344233+00	2026-08-18 15:29:06.802+00	\N	\N	\N
3b9e2d96-44a4-4ac6-95cb-e727da2cdbd7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	100	b727602c-6f4b-4320-88cb-2a2f2257224d	625b5215-d858-40a7-a3db-4e660d910b30	db2355b2-9927-449b-97fb-7b95ccb5edb2	aprovada	Não liga/sem carvão	\N	\N	\N	90	2026-08-11	\N	2026-08-11 18:19:53.873263+00	2026-08-13 20:27:30.108+00	\N	\N	\N
6f415b16-4276-4bf1-811c-7f955f7d8406	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	108	53f00aca-04ae-4f15-b319-10bb674f8516	fe8249af-95c8-4331-b5f5-b650fad5a878	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Mal contato	Fio partido.	Pagou Levou 18/08	\N	90	2026-08-13	2026-08-14	2026-08-13 12:31:59.19161+00	2026-08-18 13:29:15.373+00	\N	\N	\N
78278f62-5fe8-4d38-958a-dd718a4d6f7a	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	113	4f5ce24d-43f4-4205-97ef-5be2fd76cb81	1281beef-7947-4e34-8e97-548675644fd8	db2355b2-9927-449b-97fb-7b95ccb5edb2	aberta	Trabalhando fraco	\N	\N	\N	90	2026-08-13	\N	2026-08-13 20:36:41.062823+00	2026-08-13 20:52:36.691+00	\N	113	A
a3372542-05ce-4ef4-8baa-5d9516427d44	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	99	de4177f6-8c0d-4c23-a44f-a3d39f372235	76bd8480-6a27-4929-91da-cbce34da3546	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Não liga/Carvão novo	\N	Pagou e levou 13/08	\N	90	2026-08-11	\N	2026-08-11 17:32:35.81479+00	2026-08-13 11:45:45.051+00	\N	\N	\N
2f023775-f950-4ffc-9926-aa3f8ca51f0d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	116	838eb4e3-bc0c-4826-b08c-136b0f53cc86	24ca1ad5-024e-4594-97d6-f54bc92572e8	db2355b2-9927-449b-97fb-7b95ccb5edb2	aberta	Liga mas o carrretel parece girar pesado/Fazer limpeza geral.	\N	\N	\N	90	2026-08-17	\N	2026-08-17 11:46:54.045875+00	2026-08-17 11:46:54.045875+00	\N	\N	\N
78d83607-0309-4a2f-8897-e924aaccd53e	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	103	28b4f382-aa95-4d51-a6b6-73326c8c21f9	4d8f7aa5-1dff-4650-bac8-d4c898281d72	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	entregue	Não está subindo. Sem cabo de aço!	\N	Pagou levou 13/08	\N	90	2026-08-12	2026-08-12	2026-08-12 14:26:42.630191+00	2026-08-13 12:46:17.635+00	\N	\N	\N
55b2403f-d145-4650-a32f-b3f03a0bff12	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	113	4f5ce24d-43f4-4205-97ef-5be2fd76cb81	6cdc2bab-1bb5-4185-b32c-e328797ee46f	db2355b2-9927-449b-97fb-7b95ccb5edb2	aberta	Não liga	\N	\N	\N	90	2026-08-13	\N	2026-08-13 20:52:37.022367+00	2026-08-13 20:52:55.667+00	\N	113	B
10eccb8d-6905-481c-8c03-45954a230b54	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	94	e97a2ab0-58e1-4bec-bd79-3999dffa351d	4245e93c-13be-4ee2-a4d2-acbf5b9fcd5c	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	concluida	Não está ligando, trocar o filtro e o tampão de óleo. Fazer revisão e colocar um engate rápido.	\N	Sinal 100,00 Ok 14/08\nRestante Ok 17/08	\N	90	2026-08-10	\N	2026-08-10 13:41:46.376851+00	2026-08-17 17:31:18.892+00	\N	\N	\N
a2aa6419-dcd6-4ccc-9058-384f98c6e0bb	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	117	8ad3424b-b360-4264-a21b-41ccf11861b9	2dd9e6e0-ab85-44bf-921a-3d1139ed6150	db2355b2-9927-449b-97fb-7b95ccb5edb2	aberta	Mal contato no cabo.	\N	\N	\N	90	2026-08-17	\N	2026-08-17 12:22:32.466721+00	2026-08-17 12:23:33.427+00	\N	117	A
3d177bee-a4df-4ff8-aba5-d37fbbf507ab	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	86	04b89c89-6035-43e9-aac8-04962f87d879	d0567483-f610-4707-835b-aa4338298a84	6da88878-0303-4aac-941c-24b9622d20b8	aguardando_peca	Não gira	As peças foram danificadas por falta de lubrificação da corrente. (óleo) 	Sinal: 250,00 OK 13/08	\N	90	2026-08-11	\N	2026-08-11 21:10:24.458643+00	2026-08-13 19:31:52.252+00	\N	86	B
999f14c9-d4c3-4785-a450-20b199d345fa	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	104	0c1dd29e-f9de-400e-8a38-2f892eb5ff47	ee57412e-f2e8-4e56-9edd-59a590d376e4	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	concluida	Está saindo muita graxa 	Limpeza no excesso de graxa	\N	\N	90	2026-08-12	\N	2026-08-12 15:21:38.672825+00	2026-08-14 20:27:20.38+00	\N	\N	\N
d61a62f9-ca3b-4860-aad7-1837bd9e5a70	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	119	ced6073a-0a5d-47a8-8e32-50a3eee914b4	a3bc60f1-4a95-4b8d-b65a-e584a13677d6	6da88878-0303-4aac-941c-24b9622d20b8	aberta	Está centelhando 	\N	\N	\N	90	2026-08-17	\N	2026-08-17 21:10:41.854327+00	2026-08-17 21:12:31.573+00	\N	119	A
a919783d-bfef-403e-8cdb-0aea92c6febe	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	114	f9c8a6ad-8969-475d-9b01-602745488b29	cf4e3f9c-3d84-4d9c-80db-1e81c403dea1	db2355b2-9927-449b-97fb-7b95ccb5edb2	aberta	Sem pressão/Completo	\N	\N	\N	90	2026-08-14	\N	2026-08-14 14:47:38.552692+00	2026-08-14 14:47:38.552692+00	\N	\N	\N
f80a47c8-95b6-448b-b302-a27c0ad0542f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	81	58e98858-df83-4786-840a-9f17793767a9	6f7c64f5-e0d4-4024-9cee-6237e482280d	6da88878-0303-4aac-941c-24b9622d20b8	concluida	Não está rodando	Sinal: 40,00	\N	\N	90	2026-08-11	2026-08-14	2026-08-11 13:31:25.980346+00	2026-08-14 17:46:14.694+00	\N	81	J
065f60b8-c41e-4556-ac02-d77cfe9b4625	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	98	98559b9a-797f-4c70-9b80-4f1a67ce4557	6b3b7e2c-8437-455a-b07d-6b3a264679e9	db2355b2-9927-449b-97fb-7b95ccb5edb2	entregue	Está soltando a lamina 	\N	Pagamento dia 14/08	\N	90	2026-08-11	2026-08-13	2026-08-11 14:00:21.643065+00	2026-08-14 18:25:09.523+00	\N	\N	\N
aefe1c9a-4f14-4380-b81f-da882c448354	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	115	8f5fbd44-307d-47cd-b4b4-60200753035d	9ef46de6-1514-4cc3-9ceb-95eae1d594f7	db2355b2-9927-449b-97fb-7b95ccb5edb2	aberta	Ligado direto/sem pressão. Completo 	\N	\N	\N	90	2026-08-14	\N	2026-08-14 19:22:55.569005+00	2026-08-14 19:22:55.569005+00	\N	\N	\N
04255932-1458-471b-95f2-b331ebd1ff44	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	105	69f8f47a-c4bf-4f67-a288-0ec0eb5441e8	4b5113ac-9816-4e6f-a4a6-c3dd440d3179	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aberta	Não liga e está vazando óleo	\N	Sinal 560,00	\N	90	2026-08-12	\N	2026-08-12 21:08:07.731075+00	2026-08-14 20:50:03.134+00	\N	\N	\N
4e2d84c1-27bc-4b95-9197-e8470af2fdd4	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	106	de4177f6-8c0d-4c23-a44f-a3d39f372235	d57379e8-921c-4d6c-aa84-ab2e618b44cd	6da88878-0303-4aac-941c-24b9622d20b8	aguardando_peca	Fazer uma revisão geral	\N	Sinal: 190,00 Ok 18/08	\N	90	2026-08-13	\N	2026-08-13 11:38:11.818022+00	2026-08-18 22:03:00.675+00	\N	\N	\N
4d210cc3-4225-48ce-a499-c6dcaca0ab24	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	118	2d5e2fba-c3ce-4745-8d58-a62f465abb93	d552ca59-be5a-4c61-a3d7-c07f808cca20	db2355b2-9927-449b-97fb-7b95ccb5edb2	aberta	Fagulhando.	\N	\N	\N	90	2026-08-17	\N	2026-08-17 19:49:16.480612+00	2026-08-17 19:49:16.480612+00	\N	\N	\N
1182bbfd-85c2-4771-b8e9-7c5ee8417601	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	117	8ad3424b-b360-4264-a21b-41ccf11861b9	f09f3ff1-f024-4816-96dc-1c9aaa758a34	db2355b2-9927-449b-97fb-7b95ccb5edb2	aberta	\N	\N	\N	\N	90	2026-08-17	\N	2026-08-17 12:23:33.702782+00	2026-08-17 12:23:33.702782+00	\N	117	B
b652668b-7e69-4dce-b2c6-d30dc395c0fc	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	101	2d019df4-3df6-4ef8-86ba-891dcb5e9ce2	164f5678-3c07-4a64-87eb-9eabf3d9c9d5	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aguardando_peca	Não tem pressão	\N	Sinal 220,00 Sinal ok 17/08\nResta 140,00	\N	90	2026-08-12	\N	2026-08-12 12:22:38.268939+00	2026-08-17 12:29:38.166+00	\N	\N	\N
6855828a-d573-4b9f-bfcb-3c06d9c45c47	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	119	ced6073a-0a5d-47a8-8e32-50a3eee914b4	b6a57071-133d-4341-8103-65d53efad068	6da88878-0303-4aac-941c-24b9622d20b8	aberta	Não liga	\N	\N	\N	90	2026-08-17	\N	2026-08-17 21:12:31.850692+00	2026-08-17 21:12:31.850692+00	\N	119	B
cf85d3fe-71cb-4e0d-9c4b-6ea76b8bf956	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	119	ced6073a-0a5d-47a8-8e32-50a3eee914b4	71d64be6-36cc-497e-b132-f3e9b324a18a	6da88878-0303-4aac-941c-24b9622d20b8	aberta	\N	\N	\N	\N	90	2026-08-17	\N	2026-08-17 21:13:24.2693+00	2026-08-17 21:13:24.2693+00	\N	119	C
41fff77c-cc7c-436c-9544-f86b253e6487	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	119	ced6073a-0a5d-47a8-8e32-50a3eee914b4	b6a57071-133d-4341-8103-65d53efad068	6da88878-0303-4aac-941c-24b9622d20b8	aberta	\N	\N	\N	\N	90	2026-08-17	\N	2026-08-17 21:13:36.984092+00	2026-08-17 21:13:36.984092+00	\N	119	D
cea80560-e234-4e31-9522-67ad40304416	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	120	f31790ae-24b5-4a6e-a898-c9b66eded923	7d391e82-3279-4772-b16e-f33aa69c3d34	6da88878-0303-4aac-941c-24b9622d20b8	aberta	Não liga 	\N	\N	\N	90	2026-08-17	\N	2026-08-17 21:20:38.371124+00	2026-08-17 21:21:42.391+00	\N	\N	\N
a2463f4b-007d-46c1-926d-a7ed6be9e194	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	121	48dd2e2f-01e6-47bf-8178-7ababf413267	9d6ed18f-6e40-4d2b-a3bc-0991750173ca	6da88878-0303-4aac-941c-24b9622d20b8	aberta	A máquina está fraca.	\N	\N	\N	90	2026-08-18	\N	2026-08-18 11:47:18.455526+00	2026-08-18 11:47:18.455526+00	\N	\N	\N
72d2fddc-13ff-463a-b870-a0e03ab66ec7	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	111	72833910-7f5b-4141-8133-dda7e8ff9e12	8f1538ab-2d30-4739-b073-a444de71cc1d	db2355b2-9927-449b-97fb-7b95ccb5edb2	concluida	Fazendo barulho de engrenagem	\N	\N	\N	90	2026-08-13	2026-08-18	2026-08-13 19:54:20.469906+00	2026-08-18 15:20:10.723+00	\N	\N	\N
a0bd07fa-4493-47da-9f79-fbb19088ac5f	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	110	43cb493c-25ec-4657-8393-f937e6576890	f9b2e58e-faef-44e7-b9ff-e10bd2d28e7a	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aprovada	Não liga 	\N	Sinal 200,00	\N	90	2026-08-13	\N	2026-08-13 17:25:26.377571+00	2026-08-18 15:41:29.088+00	\N	\N	\N
c6859274-de57-44af-80fc-1ab582603c4b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	109	7a880a10-d8e2-4046-ae5b-0f28652edf53	19f0a961-b3d6-4f86-b319-4611cd739e14	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	cancelada	Parece estar travada	O rotor entrou em curto e derreteu a carcaça. A máquina está fora de linha, não tem mais peças para reposição.	Levou dia 18/08 Zé Paulo irmão de Claudinho que veio buscar. 	\N	90	2026-08-13	\N	2026-08-13 14:14:30.994087+00	2026-08-18 12:19:21.301+00	\N	\N	\N
2a678c54-c23e-41a5-87bb-7bb6ebe7ffe3	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	122	d8c32459-3650-4257-81a5-4275c1951d6c	197fd8c8-06ea-4b76-9d6d-c33565b3463d	6da88878-0303-4aac-941c-24b9622d20b8	aberta	Soltou um fio	\N	\N	\N	90	2026-08-18	\N	2026-08-18 13:25:01.850619+00	2026-08-18 13:25:01.850619+00	\N	\N	\N
d2aeabf9-0583-456d-a509-d8a8b6db1fbb	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	123	0a5fa56a-053d-40fe-ac6d-858567de03e3	1751c57d-f861-4eae-9f29-05dc2521ea1d	6da88878-0303-4aac-941c-24b9622d20b8	aberta	Está com mal contato e ficou fraca. 	\N	\N	\N	90	2026-08-18	\N	2026-08-18 14:07:36.748096+00	2026-08-18 14:07:36.748096+00	\N	\N	\N
c2c3e7f1-49f1-4047-a2f1-72417f6a286c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	124	951aad4b-8f2c-47fe-ab6b-2f3cb9f53a9e	b00a0402-5b27-4638-ae42-2e9c19ea42aa	db2355b2-9927-449b-97fb-7b95ccb5edb2	aberta	Caio e desmontou caixa de engrenagem/sem bateria	\N	\N	\N	90	2026-08-18	\N	2026-08-18 14:44:31.213214+00	2026-08-18 14:44:31.213214+00	\N	\N	\N
42fccade-1e8b-4890-8174-ec28b172098c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	125	f4c86b23-1d2d-4118-a5c7-f61338b007d7	0523bd2d-d691-4f00-8fe2-45ee59203431	6da88878-0303-4aac-941c-24b9622d20b8	concluida	Não liga, pode ser carvão	O fio da bobina arrebentou. 	\N	\N	90	2026-08-18	2026-08-18	2026-08-18 14:57:33.944112+00	2026-08-18 14:59:51.534+00	\N	\N	\N
645fa357-dc55-42a0-8pg_dump: processing data for table "public.technicians"
pg_dump: dumping contents of table "public.technicians"
be7-e6dd88e244a0	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	126	9c4f572a-e599-45e0-a3f2-f0c9645cdb1e	0643aabb-e0e4-45a4-8df6-d58bd31d387e	6da88878-0303-4aac-941c-24b9622d20b8	aberta	Parou de funcionar, sem mangueira 	\N	\N	\N	90	2026-08-18	\N	2026-08-18 15:13:19.292992+00	2026-08-18 15:14:35.189+00	\N	\N	\N
e1791790-027a-4466-bc85-673666849324	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	128	49d5bbeb-578c-4e9d-9669-0fe59af3d6b9	9d8efae7-eeae-4d33-a83b-e29a02e55d24	6da88878-0303-4aac-941c-24b9622d20b8	aberta	Não está ligando.{Na mala, 2 baterias e um carregador}	\N	\N	\N	90	2026-08-18	\N	2026-08-18 18:20:36.626746+00	2026-08-18 18:23:46.456+00	\N	\N	\N
be327a9f-7099-48f4-87b5-40c26225d044	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	130	b10a2175-61de-4a7a-9fd9-31de3bda7ec4	97ca4cf6-695f-439c-a3ea-459969f668a6	6da88878-0303-4aac-941c-24b9622d20b8	aberta	Fazendo barulho e soltando o disco. 	\N	\N	\N	90	2026-08-18	\N	2026-08-18 18:50:38.346638+00	2026-08-18 18:50:38.346638+00	\N	\N	\N
81d165c5-97c6-4f8f-ad40-81e41dd12665	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	129	9644ebe1-3fca-4c7f-b856-ea67ec6318fd	c1330de8-ad20-46de-8573-b48493defac7	6da88878-0303-4aac-941c-24b9622d20b8	aberta	\N	\N	\N	\N	90	2026-08-18	\N	2026-08-18 18:42:14.822241+00	2026-08-18 19:04:41.862+00	\N	129	A
d722087e-e034-47e1-9486-282061484350	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	129	9644ebe1-3fca-4c7f-b856-ea67ec6318fd	dafc1acf-fd8e-497e-971b-0afb42407674	6da88878-0303-4aac-941c-24b9622d20b8	aberta	\N	\N	\N	\N	90	2026-08-18	\N	2026-08-18 19:04:42.178249+00	2026-08-18 19:04:42.178249+00	\N	129	B
0ba02f13-1194-4a9d-b3ba-c1bc9f0be06b	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	129	9644ebe1-3fca-4c7f-b856-ea67ec6318fd	05e59c11-22c7-4c82-b9a8-cd6db94ae58b	6da88878-0303-4aac-941c-24b9622d20b8	aberta	\N	\N	\N	\N	90	2026-08-18	\N	2026-08-18 19:07:01.49527+00	2026-08-18 19:07:01.49527+00	\N	129	C
13cbb363-2744-403b-ac69-566d0d4c92f2	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	127	4a95a4a4-174b-4a0e-8ff0-28695fb7a812	5933ff9a-38b4-4e6f-a023-3a17f17bc4a4	ba921ec9-0acf-40f2-8917-c1dd88d46c5c	aguardando_peca	\N	\N	Sinal 1100,00 ok 18/08	\N	90	2026-08-18	\N	2026-08-18 17:48:59.681831+00	2026-08-18 19:40:38.244+00	\N	\N	\N
fa4811d6-0ff1-47c2-8d6e-0fde53736900	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	131	3af3efa2-c68a-429f-b636-baf65551923a	629c9167-5cde-4995-829f-dac99e654999	db2355b2-9927-449b-97fb-7b95ccb5edb2	aberta	Não liga	\N	\N	\N	90	2026-08-18	\N	2026-08-18 19:45:03.543148+00	2026-08-18 19:45:03.543148+00	\N	\N	\N
566934c6-c00f-4e2a-956c-73c6ad1b70e6	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	132	25d739a9-fd5e-41db-b01e-52f673619302	8783bcc3-dd6f-496d-b116-d4f4e6694dfd	db2355b2-9927-449b-97fb-7b95ccb5edb2	aberta	Trocar o cabo e fazer uma limpeza 	\N	O cliente estava usando ela em 110v	\N	90	2026-08-18	\N	2026-08-18 19:55:59.857305+00	2026-08-18 19:55:59.857305+00	\N	\N	\N
387799cb-d999-48f2-9ba3-13738521bf7d	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	133	7fa572dc-5575-4da8-9556-6b278a421005	b1eb8ca7-7ed8-4718-a9ce-f70bbf2b39a4	6da88878-0303-4aac-941c-24b9622d20b8	aberta	Fazer uma limpeza no carburador e no tanque de gasolina 	\N	\N	\N	90	2026-08-18	\N	2026-08-18 20:38:01.929677+00	2026-08-18 20:38:01.929677+00	\N	\N	\N
\.


--
-- TOC entry 3527 (class 0 OID 24677)
-- Dependencies: 223
-- Data for Name: technicians; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.technicians (id, tenant_id, name, phone, specialty, active, created_at, updated_at, deleted_at) FROM stdin;
a5f385cf-e784-4a1b-8f12-4d9aa4e9dc8e	c8659485-b234-4723-9681-1e71ee94ac3b	Fernando	21999996666	Ferramentas elétricas em geral	t	2026-07-23 23:40:47.205615+00	2026-07-23 23:40:47.205615+00	\N
e5012518-7b2d-4424-b07c-227c8116915f	c8659485-b234-4723-9681-1e71ee94ac3b	Igor	21988885555	Serra mármore e furadeiras	t	2026-07-23 23:40:47.375491+00	2026-07-23 23:40:47.375491+00	\N
50f51495-7dac-4549-8cc7-e7283714054e	c8659485-b234-4723-9681-1e71ee94ac3b	Felipe	21977774444	Parafusadeiras e esmerilhadeiras	t	2026-07-23 23:40:47.5353+00	2026-07-23 23:40:47.5353+00	\N
5ad58663-8f31-416e-8e57-1a970952c6aa	c8659485-b234-4723-9681-1e71ee94ac3b	Fernando	2199pg_dump: processing data for table "public.tenants"
pg_dump: dumping contents of table "public.tenants"
pg_dump: processing data for table "public.users"
pg_dump: dumping contents of table "public.users"
9996666	Ferramentas elétricas em geral	t	2026-07-23 23:40:57.798528+00	2026-07-23 23:40:57.798528+00	\N
f5f297ac-326b-4a6a-9043-5438eebb3d0c	c8659485-b234-4723-9681-1e71ee94ac3b	Igor	21988885555	Serra mármore e furadeiras	t	2026-07-23 23:40:57.96053+00	2026-07-23 23:40:57.96053+00	\N
7245eed4-f1f1-4471-adb1-57bb5cd20903	c8659485-b234-4723-9681-1e71ee94ac3b	Felipe	21977774444	Parafusadeiras e esmerilhadeiras	t	2026-07-23 23:40:58.122455+00	2026-07-23 23:40:58.122455+00	\N
b02de207-7771-40bd-99b5-b951ff5126d5	c8659485-b234-4723-9681-1e71ee94ac3b	Fernando	21999996666	Ferramentas elétricas em geral	t	2026-07-23 23:41:41.329343+00	2026-07-23 23:41:41.329343+00	\N
22362f19-ce6d-458b-8db1-3a027b911533	c8659485-b234-4723-9681-1e71ee94ac3b	Igor	21988885555	Serra mármore e furadeiras	t	2026-07-23 23:41:41.488164+00	2026-07-23 23:41:41.488164+00	\N
1543382d-df2c-48cc-9354-5a1eb36f43dc	c8659485-b234-4723-9681-1e71ee94ac3b	Fernando	21999996666	Ferramentas elétricas em geral	t	2026-07-23 23:43:38.950836+00	2026-07-23 23:43:38.950836+00	\N
92acc99e-a09b-41ab-ada2-eaaba7110e04	c8659485-b234-4723-9681-1e71ee94ac3b	Igor	21988885555	Serra mármore e furadeiras	t	2026-07-23 23:43:39.114875+00	2026-07-23 23:43:39.114875+00	\N
732a158a-1474-4300-b6ff-679d19073fb4	c8659485-b234-4723-9681-1e71ee94ac3b	Felipe	21977774444	Parafusadeiras e esmerilhadeiras	t	2026-07-23 23:43:39.326834+00	2026-07-23 23:43:39.326834+00	\N
a4661e6f-1a20-4f0a-89af-78101f967f15	c8659485-b234-4723-9681-1e71ee94ac3b	Felipe	21977774444	Parafusadeiras e esmerilhadeiras	t	2026-07-23 23:41:41.649069+00	2026-07-23 23:41:41.649069+00	2026-07-24 00:27:09.997+00
db2355b2-9927-449b-97fb-7b95ccb5edb2	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Felipe Queiroz Rebello	21968161250		t	2026-07-24 13:40:55.229999+00	2026-07-24 13:40:55.229999+00	\N
6da88878-0303-4aac-941c-24b9622d20b8	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Igor Queiroz Rebello	21975473524		t	2026-07-24 13:41:21.212651+00	2026-07-24 13:41:21.212651+00	\N
ba921ec9-0acf-40f2-8917-c1dd88d46c5c	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Luiz Fernando da Silva Rebello	21968198904		t	2026-07-24 13:42:30.561141+00	2026-07-24 13:42:30.561141+00	\N
0a2b60f8-f270-4752-a8ca-9faffd6448fb	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Junior	21988001122	Furadeiras e parafusadeiras	t	2026-07-23 23:59:29.588099+00	2026-07-23 23:59:29.588099+00	2026-07-24 16:08:25.235+00
2257be26-1899-4625-aa5b-9ef0bfad2821	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Marcos	21975473524	Serra mármore	t	2026-07-23 23:59:29.264777+00	2026-07-23 23:59:29.264777+00	2026-07-24 16:08:29.678+00
c4c1038d-666f-4ad9-8db6-54e2fe4197ba	c8659485-b234-4723-9681-1e71ee94ac3b	Carlos	(21) 92624-3451	Ferramentas elétricas	t	2026-08-10 23:03:32.777+00	2026-08-10 23:03:32.779+00	\N
735e3c04-3492-4cd8-ae5d-9905053551f3	c8659485-b234-4723-9681-1e71ee94ac3b	Marcos	(21) 98906-2311	Ferramentas elétricas	t	2026-08-10 23:03:33.098+00	2026-08-10 23:03:33.098+00	\N
\.


--
-- TOC entry 3524 (class 0 OID 24627)
-- Dependencies: 220
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenants (id, name, slug, active, modules, created_at, updated_at) FROM stdin;
c8659485-b234-4723-9681-1e71ee94ac3b	Empresa Master	master	t	["os", "financeiro", "faturamento"]	2026-07-23 18:01:31.047369+00	2026-08-10 20:59:12.264+00
cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Eletrotécnica São Miguel	esm	t	["os", "faturamento"]	2026-07-23 23:28:16.863334+00	2026-08-10 22:12:48.522+00
\.


--
-- TOC entry 3525 (class 0 OID 24641)
-- Dependencies: 221
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, tenant_id, name, email, password_hash, role, active, last_login, created_at, updated_at) FROM stdin;
1782bbc3-ea85-41e1-ada4-81ec2a0d70c1	\N	Super Admin	admin@oslaboris.com	$2b$10$ClpFbXKfh5rrKbg4dqE9pur4POtPtlpnHg4nYCwXNzp3xTnbPhKHq	super_admin	t	2026-08-11 01:15:37.514+00	2026-07-23 16:46:53.668218+00	2026-07-23 16:46:53.668218+00
b1874604-7b06-4507-aa91-636baad193d6	cd2d295a-4f88-4c73-8eb7-e6adc240e9d1	Admin Eletrotécnica São Miguel	esm@oslaboris.com	$2b$10$Cpg_dump: executing SEQUENCE SET knex_migrations_id_seq
pg_dump: executing SEQUENCE SET knex_migrations_lock_index_seq
pg_dump: creating CONSTRAINT "public.audit_logs audit_logs_pkey"
pg_dump: creating CONSTRAINT "public.clients clients_pkey"
pg_dump: creating CONSTRAINT "public.company_settings company_settings_pkey"
pg_dump: creating CONSTRAINT "public.company_settings company_settings_tenant_id_unique"
pg_dump: creating CONSTRAINT "public.equipment equipment_pkey"
pg_dump: creating CONSTRAINT "public.financial_entries financial_entries_pkey"
pg_dump: creating CONSTRAINT "public.impersonate_logs impersonate_logs_pkey"
pg_dump: creating CONSTRAINT "public.knex_migrations_lock knex_migrations_lock_pkey"
pg_dump: creating CONSTRAINT "public.knex_migrations knex_migrations_pkey"
pg_dump: creating CONSTRAINT "public.pin_attempts pin_attempts_pkey"
pg_dump: creating CONSTRAINT "public.service_order_items service_order_items_pkey"
pg_dump: creating CONSTRAINT "public.service_orders service_orders_pkey"
pg_dump: creating CONSTRAINT "public.technicians technicians_pkey"
pg_dump: creating CONSTRAINT "public.tenants tenants_pkey"
pg_dump: creating CONSTRAINT "public.tenants tenants_slug_unique"
pg_dump: creating CONSTRAINT "public.users users_email_unique"
Ne4qdtqk8jh3AVP9uI4r.W0MVPc2uqqthXcYjV9Wuo3Gp1tBAX/W	tenant_user	t	2026-08-17 17:54:07.227+00	2026-07-23 18:01:31.364096+00	2026-07-24 00:13:32.158+00
\.


--
-- TOC entry 3544 (class 0 OID 0)
-- Dependencies: 216
-- Name: knex_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_id_seq', 5, true);


--
-- TOC entry 3545 (class 0 OID 0)
-- Dependencies: 218
-- Name: knex_migrations_lock_index_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.knex_migrations_lock_index_seq', 1, true);


--
-- TOC entry 3348 (class 2606 OID 24789)
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3328 (class 2606 OID 24669)
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- TOC entry 3344 (class 2606 OID 24773)
-- Name: company_settings company_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_settings
    ADD CONSTRAINT company_settings_pkey PRIMARY KEY (id);


--
-- TOC entry 3346 (class 2606 OID 24775)
-- Name: company_settings company_settings_tenant_id_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_settings
    ADD CONSTRAINT company_settings_tenant_id_unique UNIQUE (tenant_id);


--
-- TOC entry 3334 (class 2606 OID 24700)
-- Name: equipment equipment_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_pkey PRIMARY KEY (id);


--
-- TOC entry 3350 (class 2606 OID 24805)
-- Name: financial_entries financial_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_entries
    ADD CONSTRAINT financial_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 3357 (class 2606 OID 57366)
-- Name: impersonate_logs impersonate_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.impersonate_logs
    ADD CONSTRAINT impersonate_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3318 (class 2606 OID 24589)
-- Name: knex_migrations_lock knex_migrations_lock_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations_lock
    ADD CONSTRAINT knex_migrations_lock_pkey PRIMARY KEY (index);


--
-- TOC entry 3316 (class 2606 OID 24582)
-- Name: knex_migrations knex_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.knex_migrations
    ADD CONSTRAINT knex_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3353 (class 2606 OID 57351)
-- Name: pin_attempts pin_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_attempts
    ADD CONSTRAINT pin_attempts_pkey PRIMARY KEY (id);


--
-- TOC entry 3342 (class 2606 OID 24757)
-- Name: service_order_items service_order_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_order_items
    ADD CONSTRAINT service_order_items_pkey PRIMARY KEY (id);


--
-- TOC entry 3339 (class 2606 OID 24724)
-- Name: service_orders service_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_pkey PRIMARY KEY (id);


--
-- TOC entry 3331 (class 2606 OID 24685)
-- Name: technicians technicians_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technicians
    ADD CONSTRAINT technicians_pkey PRIMARY KEY (id);


--
-- TOC entry 3320 (class 2606 OID 24638)
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- TOC entry 3322 (class 2606 OID 24640)
-- Name: tenants tenants_slug_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_unique UNIQUE (slug);


--
-- TOC pg_dump: creating CONSTRAINT "public.users users_pkey"
pg_dump: creating INDEX "public.clients_tenant_document_unique"
pg_dump: creating INDEX "public.equipment_client_id_index"
pg_dump: creating INDEX "public.equipment_tenant_id_index"
pg_dump: creating INDEX "public.financial_entries_tenant_id_index"
pg_dump: creating INDEX "public.idx_service_orders_lote"
pg_dump: creating INDEX "public.idx_service_orders_unique_number"
pg_dump: creating INDEX "public.impersonate_logs_admin_id_index"
pg_dump: creating INDEX "public.impersonate_logs_started_at_index"
pg_dump: creating INDEX "public.impersonate_logs_tenant_id_index"
pg_dump: creating INDEX "public.pin_attempts_tenant_id_ip_address_attempted_at_index"
pg_dump: creating INDEX "public.service_orders_tenant_id_index"
pg_dump: creating FK CONSTRAINT "public.audit_logs audit_logs_tenant_id_foreign"
pg_dump: creating FK CONSTRAINT "public.clients clients_tenant_id_foreign"
pg_dump: creating FK CONSTRAINT "public.company_settings company_settings_tenant_id_foreign"
pg_dump: creating FK CONSTRAINT "public.equipment equipment_client_id_foreign"
entry 3324 (class 2606 OID 24659)
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- TOC entry 3326 (class 2606 OID 24652)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3329 (class 1259 OID 32768)
-- Name: clients_tenant_document_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX clients_tenant_document_unique ON public.clients USING btree (tenant_id, document) WHERE ((document IS NOT NULL) AND ((document)::text <> ''::text));


--
-- TOC entry 3332 (class 1259 OID 24711)
-- Name: equipment_client_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX equipment_client_id_index ON public.equipment USING btree (client_id);


--
-- TOC entry 3335 (class 1259 OID 24712)
-- Name: equipment_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX equipment_tenant_id_index ON public.equipment USING btree (tenant_id);


--
-- TOC entry 3351 (class 1259 OID 24816)
-- Name: financial_entries_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX financial_entries_tenant_id_index ON public.financial_entries USING btree (tenant_id);


--
-- TOC entry 3336 (class 1259 OID 49152)
-- Name: idx_service_orders_lote; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_service_orders_lote ON public.service_orders USING btree (tenant_id, lote_numero);


--
-- TOC entry 3337 (class 1259 OID 49153)
-- Name: idx_service_orders_unique_number; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_service_orders_unique_number ON public.service_orders USING btree (tenant_id, order_number, COALESCE(lote_sufixo, ''::character varying)) WHERE (deleted_at IS NULL);


--
-- TOC entry 3355 (class 1259 OID 57377)
-- Name: impersonate_logs_admin_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX impersonate_logs_admin_id_index ON public.impersonate_logs USING btree (admin_id);


--
-- TOC entry 3358 (class 1259 OID 57379)
-- Name: impersonate_logs_started_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX impersonate_logs_started_at_index ON public.impersonate_logs USING btree (started_at);


--
-- TOC entry 3359 (class 1259 OID 57378)
-- Name: impersonate_logs_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX impersonate_logs_tenant_id_index ON public.impersonate_logs USING btree (tenant_id);


--
-- TOC entry 3354 (class 1259 OID 57357)
-- Name: pin_attempts_tenant_id_ip_address_attempted_at_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX pin_attempts_tenant_id_ip_address_attempted_at_index ON public.pin_attempts USING btree (tenant_id, ip_address, attempted_at);


--
-- TOC entry 3340 (class 1259 OID 24747)
-- Name: service_orders_tenant_id_index; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX service_orders_tenant_id_index ON public.service_orders USING btree (tenant_id);


--
-- TOC entry 3371 (class 2606 OID 24790)
-- Name: audit_logs audit_logs_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- TOC entry 3361 (class 2606 OID 24670)
-- Name: clients clients_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- TOC entry 3370 (class 2606 OID 24776)
-- Name: company_settings company_settings_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.company_settings
    ADD CONSTRAINT company_settings_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- TOC entry 3363 (class 2606 OID 24706)
-- Name: equipment equipment_client_id_foreign; Type: FK CONSpg_dump: creating FK CONSTRAINT "public.equipment equipment_tenant_id_foreign"
pg_dump: creating FK CONSTRAINT "public.financial_entries financial_entries_service_order_id_foreign"
pg_dump: creating FK CONSTRAINT "public.financial_entries financial_entries_tenant_id_foreign"
pg_dump: creating FK CONSTRAINT "public.impersonate_logs impersonate_logs_admin_id_foreign"
pg_dump: creating FK CONSTRAINT "public.impersonate_logs impersonate_logs_tenant_id_foreign"
pg_dump: creating FK CONSTRAINT "public.pin_attempts pin_attempts_tenant_id_foreign"
pg_dump: creating FK CONSTRAINT "public.service_order_items service_order_items_service_order_id_foreign"
pg_dump: creating FK CONSTRAINT "public.service_orders service_orders_client_id_foreign"
pg_dump: creating FK CONSTRAINT "public.service_orders service_orders_equipment_id_foreign"
pg_dump: creating FK CONSTRAINT "public.service_orders service_orders_technician_id_foreign"
pg_dump: creating FK CONSTRAINT "public.service_orders service_orders_tenant_id_foreign"
pg_dump: creating FK CONSTRAINT "public.technicians technicians_tenant_id_foreign"
pg_dump: creating FK CONSTRAINT "public.users users_tenant_id_foreign"
TRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- TOC entry 3364 (class 2606 OID 24701)
-- Name: equipment equipment_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.equipment
    ADD CONSTRAINT equipment_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- TOC entry 3372 (class 2606 OID 24811)
-- Name: financial_entries financial_entries_service_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_entries
    ADD CONSTRAINT financial_entries_service_order_id_foreign FOREIGN KEY (service_order_id) REFERENCES public.service_orders(id);


--
-- TOC entry 3373 (class 2606 OID 24806)
-- Name: financial_entries financial_entries_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_entries
    ADD CONSTRAINT financial_entries_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- TOC entry 3375 (class 2606 OID 57367)
-- Name: impersonate_logs impersonate_logs_admin_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.impersonate_logs
    ADD CONSTRAINT impersonate_logs_admin_id_foreign FOREIGN KEY (admin_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- TOC entry 3376 (class 2606 OID 57372)
-- Name: impersonate_logs impersonate_logs_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.impersonate_logs
    ADD CONSTRAINT impersonate_logs_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- TOC entry 3374 (class 2606 OID 57352)
-- Name: pin_attempts pin_attempts_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.pin_attempts
    ADD CONSTRAINT pin_attempts_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- TOC entry 3369 (class 2606 OID 24758)
-- Name: service_order_items service_order_items_service_order_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_order_items
    ADD CONSTRAINT service_order_items_service_order_id_foreign FOREIGN KEY (service_order_id) REFERENCES public.service_orders(id) ON DELETE CASCADE;


--
-- TOC entry 3365 (class 2606 OID 24730)
-- Name: service_orders service_orders_client_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_client_id_foreign FOREIGN KEY (client_id) REFERENCES public.clients(id);


--
-- TOC entry 3366 (class 2606 OID 24735)
-- Name: service_orders service_orders_equipment_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_equipment_id_foreign FOREIGN KEY (equipment_id) REFERENCES public.equipment(id);


--
-- TOC entry 3367 (class 2606 OID 24740)
-- Name: service_orders service_orders_technician_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_technician_id_foreign FOREIGN KEY (technician_id) REFERENCES public.technicians(id);


--
-- TOC entry 3368 (class 2606 OID 24725)
-- Name: service_orders service_orders_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.service_orders
    ADD CONSTRAINT service_orders_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- TOC entry 3362 (class 2606 OID 24686)
-- Name: technicians technicians_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.technicians
    ADD CONSTRAINT technicians_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- TOC entry 3360 (class 2606 OID 24653)
-- Name: users users_tenant_id_foreign; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_foreign FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


-- Completed on 2026-08-19 06:56:37 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict BfSs5Vgeo884ac1WBarO7vdYPtsVNK1cSBDap0NdMEodCFZzabwn9nQpG8KQMob

